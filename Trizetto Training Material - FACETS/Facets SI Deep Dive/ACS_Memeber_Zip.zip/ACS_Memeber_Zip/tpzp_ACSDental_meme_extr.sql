/***************************************************************
  BEGIN MAINTENANCE WRAPPER.
***************************************************************/

IF OBJECT_ID('dbo.tpzp_ACSDental_meme_extr') IS NOT NULL
BEGIN
  DROP PROCEDURE dbo.tpzp_ACSDental_meme_extr

  IF OBJECT_ID('dbo.tpzp_ACSDental_meme_extr') IS NOT NULL
    PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_ACSDental_meme_extr >>>'
  ELSE
    PRINT '<<< DROPPED PROCEDURE dbo.tpzp_ACSDental_meme_extr >>>'
END
GO 

/****************************************************************  
** END MAINTENANCE WRAPPER.                                    **  
***************************************************************/  
  
CREATE PROCEDURE [dbo].[tpzp_ACSDental_meme_extr]  
(  
	@pRunFreq VARCHAR(10)  
)  
/****************************************************************  
**   NAME                  : dbo.tpzp_ACSDental_meme_extr      'MONTHLY'
**      
**      
**   PVCS LOCATION         :       
**      
**   FUNCTION              : For DAILY:      
**                           STEP 1: Truncate staging table tpzt_ACSDental_meme_extr_old      
**                           STEP 2: Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_old with the previous days record      
**                           STEP 3: Truncating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new      
**                           STEP 4: Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new with present days record      
**                           STEP 5: Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for SUBSCRIBER_NUMBER      
**                           STEP 6: Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for BENEFIT_EFFECTIVE_DATE,BENEFIT_EXPIRATION_DATE,DENTAL_CLASS_PLAN_CODE,GROUP_CONTRACT_EFFECT_DATE,LINE_OF_BUSINESS      
**                           STEP 7: Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for CUSTODIAL_PARENT_LAST_NAME,CUSTODIAL_PARENT_FIRST_NAME,CUSTODIAL_PARENT_MIDDLE_INITIAL,CUST_PARENT_TITLE_CODE      
**                           STEP 8: Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for COB_INSURANCE_CODE,COB_TYPE,COB_OTHER_INSURANCE_CARRIER_NAME,COB_EFFECTIVE_DATE,COB_TERMINATION_DATE      
**                           STEP 9: Updating EMPLOYEE_STATUS as Employed in stage table tpzt_ACSDental_meme_extr_new      
**                           STEP 10: Updating EMPLOYEE_STATUS as COBRA in stage table tpzt_ACSDental_meme_extr_new      
**                           STEP 11: Update staging table tpzt_ACSDental_meme_extr_new for TRANSACTION_DATE Column      
**                           STEP 12: Update staging table tpzt_ACSDental_meme_extr_new for PAID_THRU_DATE Column      
**                           STEP 13: Truncate Staging table tpzt_ACSDental_meme_error      
**                           STEP 14: Insert error records in staging table tpzt_ACSDental_meme_error      
**                           STEP 15: Truncating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr      
**                           STEP 16: Inserting updated records in stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr      
**                                 
**                                 
**                           For MONTHLY:      
**                           STEP 1: Truncate staging table tpzt_ACSDental_meme_extr_new      
**                           STEP 2: Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new      
**                           STEP 3: Populating the Staging table tpzt_ACSDental_meme_extr_new with terminated records      
**                           STEP 4: Updating stage table tpzt_ACSDental_meme_extr_new for SUBSCRIBER_NUMBER field      
**                           STEP 5: Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new  BENEFIT_EFFECTIVE_DATE,BENEFIT_EXPIRATION_DATE,DENTAL_CLASS_PLAN_CODE,GROUP_CONTRACT_EFFECT_DATE,LINE_OF_BUSINESS      
**                           STEP 6: Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for CUSTODIAL_PARENT_LAST_NAME,CUSTODIAL_PARENT_FIRST_NAME,CUSTODIAL_PARENT_MIDDLE_INITIAL,CUST_PARENT_TITLE_CODE      
**                           STEP 7: Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for COB_INSURANCE_CODE,COB_TYPE,COB_OTHER_INSURANCE_CARRIER_NAME,COB_EFFECTIVE_DATE,COB_TERMINATION_DATE      
**                           STEP 8: Updating EMPLOYEE_STATUS as Employed in stage table tpzt_ACSDental_meme_extr_new      
**                           STEP 9: Updating EMPLOYEE_STATUS as COBRA in stage table tpzt_ACSDental_meme_extr_new      
**                           STEP 10: Update staging table tpzt_ACSDental_meme_extr_new for TRANSACTION_DATE Column      
**                           STEP 11: Update staging table tpzt_ACSDental_meme_extr_new for PAID_THRU_DATE Column      
**                           STEP 12: Truncating stage table tpzt_ACSDental_meme_monthly_old      
**                           STEP 13: Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_monthly_old with the previous days record      
**                           STEP 14: Truncate staging table tpzt_ACSDental_meme_error      
**                           STEP 15: Insert error records in staging table tpzt_ACSDental_meme_error      
**                           STEP 16: Truncating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr      
**                           STEP 17: Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr with present days record      
**                                 
**      
**   PARAMETERS            :      
**                   INPUT :@pRunFreq      
**                  OUTPUT :      
**      
**   RETURN CODES          : 0 on success      
**      
**   TABLES REFERENCED     :      
**                FACETS   : fabncdv1.dbo.CMC_MEME_MEMBER      
**                           fabncdv1.dbo.CMC_SBSB_SUBSC      
**                           fabncdv1.dbo.CMC_MEPE_PRCS_ELIG      
**                           fabncdv1.dbo.CMC_GRGR_GROUP      
**                           fabncdv1.dbo.CMC_BPIO_COB      
**                           fabncdv1.dbo.CMC_MECB_COB      
**                           fabncdv1.dbo.CMC_SGSG_SUB_GROUP      
**                           fabncdv1.dbo.CMC_CSPI_CS_PLAN      
**                           fabncdv1.dbo.CMC_PDPD_PRODUCT      
**                           fabncdv1.dbo.CMC_SBEL_ELIG_ENT      
**                           fabncdv1.dbo.CMC_SBAD_ADDR      
**                           fabncdv1.dbo.FHP_PMED_MEMBER_D      
**                           fabncdv1.dbo.FHD_ENEN_ENTITY_D      
**                           fabncdv1.dbo.FHD_ENAD_ADDRESS_D      
**                           fabncdv1.dbo.FHP_PMCC_COMM_X      
**                           fabncdv1.dbo.CMC_MERP_RELATION      
**                           fabncdv1.dbo.CMC_MCRP_RELAT_PER   
**      
**                FACETSXC : N/A      
**                CUSTOM   : N/A      
**                STAGE    : fabncdv1stage.dbo.tpzp_comm_elig_extr      
**      
**   PROCEDURES REFERENCED :      
**                  FACETS :      
**                  CUSTOM :      
**   STANDARD LOGGING PROCS:      
**                           harcore.dbo.harsp_gen_util_job_hdr_lgr      
**                           harcore.dbo.harsp_gen_util_job_ftr_lgr      
**                           harcore.dbo.harsp_gen_util_step_hdr_lgr      
**                           harcore.dbo.harsp_gen_util_step_ftr_lgr      
**      
** REVISION HISTORY        :      
** VERSION  DATE         DEVELOPER           DESCRIPTION      
** -------- ----------   -----------------   --------------------      
** 1.0      07/01/2014    Ghazala Ameen      Initial Version      
** 1.1      07/18/2014    Ghazala Ameen      Updated for VOID_INDICATOR field and ZIP CODE field length      
** 1.2      08/07/2014    Ghazala Ameen      Updated for Error table change and updated as per new BRD 1.6      
** 1.3      08/11/2014    Ghazala Ameen      Updated for Server Name in Joins and updating conditions to exclude data from tpzt_ACSDental_meme_extr table      
** 1.4      08/13/2014    Shekhar Kadam      Updated for Member_Number, Relationship_Code, Language_Value3,Member_Language Columns      
                                             Updated  code for Waiting Period Effective Date, Waiting Period Expiration Date, DENTAL BASIC EFFECTIVE DATE       
      DENTAL BASIC EXPIRATION DATE, DENTAL MAJOR EFFECTIVE DATE, DENTAL MAJOR EXPIRATION DATE,DENTAL ORTHO EFFECTIVE DATE       
                                             DENTAL ORTHO EXPIRATION DATE columns      
** 1.5      08/21/2014    Shekhar Kadam      updated for MEMBER_STATUS, this field can hold blank value.      
** 1.6      08/21/2014    Shekhar Kadam      updated for MEMBER_NUMBER which holds Sub SSN with prefix of member      
** 1.7      08/24/2014    Shekhar Kadam      Updated logic for Waiting Period Effective Date and Waiting Period Expiration Date field,      
                                             Record is fetch for Dental plan only  
** 1.8      08/26/2014    Shekhar Kadam      Update logic for small group       
** 1.9      08/26/2014    Shekhar Kadam      Updated field for group size.      
** 1.10     08/31/2014    Shekhar Kadam      MEMBER_STATUS and EMPLOYEE_STATUS field will hold blank value.  
** 1.11     09/04/2014    Ghazala Ameen      Updated joins to fetch terminated members for monthly  
** 1.12     09/11/2014    Ghazala Ameen      Updated date conditions to fetch term members and for Dental Effective and Expiry dates  
** 1.13     09/16/2014    Shekhar Kadam      Logic for Member number for Monthly extract is updated.  
** 1.14     09/16/2014    Shekhar Kadam      Updated the logic for Benefit Eff and Termination date.  
** 1.15     09/19/2014    Shekhar Kadam      Updated the logic for Truncation date and updated facets high date to 99991231  
            Updated the logic  ortho wp should reflect member wp.  
** 1.16     09/19/2014    Shekhar Kadam      Updated the logic for Truncation date and updated facets high date to 99991231  
            Updated the logic  ortho wp should reflect member wp. for monthly extract  
** 1.17     09/23/2014    Shekhar Kadam      Language 1,2 and 3 field is set to blank.  
** 1.18     09/25/2014    Shekhar Kadam      logic updated for Transaction date .  
** 1.19     09/28/2014    Shekhar Kadam      Process date is excluded from comparsion  
** 1.20     09/30/2014    Shekhar Kadam      Update logic for COB other insurance carrier name  
** 1.21     10/02/2014    Shekhar Kadam      Fetching only those record with valid record logic updated
** 1.22     10/06/2014    Shekhar Kadam      Update the logic for DENTAL BASIC EXPIRATION DATE as per new change request
** 1.23     10/06/2014    Shekhar Kadam      Class plan Ped Dental  removed from selection condition.
** 1.24     10/14/2014    Shekhar Kadam      Line of Bussiness  changed DENT --> BDEN  and DBSL --> BDBS
** 1.25     10/14/2014    Shekhar Kadam      PEDIATRIC INDICATOR field logic updated.
** 1.26     10/25/2014    Shekhar Kadam      Extracting only those member whose subscriber is part of extract file.
												updated VOID_INDICATOR logic 
** 1.27     10/30/2014    Shekhar Kadam      Logic updated for Employee Status field and Memeber Status.
** 1.28     11/13/2014    Shekhar Kadam      Logic updated for Orth Eff date and Orth Term Date
** 1.29     11/19/2014    Shekhar Kadam      Logic updated Void Indicator.
** 1.30     11/24/2014    Shekhar Kadam      Logic updated Void Indicator.
											 Anytime the Void Indicator is set to �Y�, the term date should be 1 day minus the effective date. (i.e effective 9/1/14 � 8/31/14).  
** 1.31		12/09/2014	  Pradeep 			 Update logic in Stored Procedure to fetch the member records with other attachment types along with DNWP and blank.											 
** 1.32     01/26/2015    Ramkumar Paulraj   Modified to remove the non-alpha numeric check for first name and last name 
** 1.33     02/10/2015    Ramkumar Paulraj   Modified to implement changes similar to Monthly for Daily
** 1.34     02/17/2015    Ramkumar Paulraj   Modified to update Dependent details are still reflecting without the Subscriber,Date Format is incorrect in Group Files.
**                                            Two records are pulled for the same Member ID in the Full File
** 1.35     02/26/2015    Ramkumar Paulraj   Modified to remove Dependent removal for Daily
****************************************************************/      
AS      
      
BEGIN      
      
/****************************************************************      
**          DECLARE LOCAL VARIABLES                            **      
****************************************************************/      
      
    DECLARE @lnRetCd                INT              -- Proc return code      
    DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time      
    DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time      
    DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time      
    DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time      
    DECLARE @lnCurrentStep          INT              -- Current Step Number      
    DECLARE @lnTotalSteps           INT              -- Total Steps In Proc      
    DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field      
    DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name      
    DECLARE @lvcDBName              VARCHAR(32)      -- DB Name      
    DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version      
    DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name      
    DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name      
    DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step      
    DECLARE @ldtLastRunDt           DATETIME         -- Last run date      
    DECLARE @ldtCurrentDate         DATETIME         -- Current date      
    DECLARE @lvcCount				int 
    declare @groupContrExpdate		varchar(8) ='99991231'
    
    declare @CountVoidIndicator int = 0
      
/****************************************************************      
**          INITIALIZE  VARIABLES                              **      
****************************************************************/      
      
    SELECT @lnRetCd        = 0,  
      @lvcMsg              = NULL,  
      @lnCurrentStep       = 0,  
      @ldtStepEndTime      = NULL,  
      @lvcVersionNum       = '1.31'  
  
    IF (UPPER(@pRunFreq) = 'DAILY')  
    BEGIN  
       SELECT @lnTotalSteps        = 16  
    END  
    IF (UPPER(@pRunFreq) = 'MONTHLY')  
    BEGIN  
SELECT @lnTotalSteps        = 17  
    END  
          
    SELECT @lvcServerName  = @@SERVERNAME,  
      @lvcDBName           = DB_NAME(),  
      @lvcUser             = USER_NAME(),  
      @lvcObjectName       = OBJECT_NAME(@@PROCID),  
      @ldtProcessStartTime = GETDATE(),  
      @ldtCurrentDate      = CONVERT(VARCHAR (10), GETDATE (), 101)  
  
/****************************************************************  
**               BEGIN PROCESS                                 **      
*****************************************************************/      
      
/**************  PRINT JOB HEADER DATA *************************/      
      
    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr      
      @pchObjectName        = @lvcObjectName,      
      @pdtProcessStartTime  = @ldtProcessStartTime,      
      @pchServerName        = @lvcServerName,      
      @pchDBName            = @lvcDBName,      
      @pchUserName          = @lvcUser,      
      @pchVersionNum        = @lvcVersionNum      
            
            
 DECLARE @CTE_TEMP table       
    (  
		CSPI_ID		char(8) null,
		CSPD_CAT   char(1) null,    
        PDPD_ID        char(8) null,      
        PDBC_PFX    char(4) null,  
        PDBC_TYPE   CHAR(4) NULL  
    )      
          
insert into @CTE_TEMP(CSPI_ID,CSPD_CAT,PDPD_ID,PDBC_PFX,PDBC_TYPE)      
                  
 SELECT DISTINCT CSPI.CSPI_ID,CSPI.CSPD_CAT,PDDS.PDPD_ID, 
				 CASE WHEN PDPX.PDBC_PFX in  ('DENT','BDEN') 
						THEN 'DENT'
					  WHEN PDPX.PDBC_PFX in  ('DBSL','BDBS') 
						THEN 'DBSL'
				  END,
				 PDBC.PDBC_TYPE 
	FROM  fabncdv1.dbo.CMC_PDDS_PROD_DESC PDDS       
            INNER JOIN  fabncdv1.dbo.CMC_PDBC_PROD_COMP PDBC       
            ON             PDDS.PDPD_ID = PDBC.PDPD_ID       
            INNER JOIN fabncdv1.dbo.CMC_PDPX_DESC PDPX       
            ON             PDBC.PDBC_TYPE = PDPX.PDBC_TYPE AND PDBC.PDBC_PFX = PDPX.PDBC_PFX       
            INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN CSPI on CSPI.PDPD_ID = PDBC.PDPD_ID       
            WHERE  RTRIM(LTRIM(ISNULL(PDBC.PDBC_PFX,''))) <> ''        
            AND PDBC.PDBC_PFX in ('DENT','DBSL','BDEN','BDBS')       
         
                   
IF (UPPER(@pRunFreq) = 'DAILY')      
BEGIN      
      
/**************  PRINT STEP 1 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep  = @lnCurrentStep + 1,      
      @ldtStepStartTime   = GETDATE(),      
      @lvcMsg             = @lvcObjectName + ': Truncating stage table tpzt_ACSDental_meme_extr_old'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber        = @lnCurrentStep,      
      @pdtStepStartTime    = @ldtStepStartTime,      
      @pnTotalSteps        = @lnTotalSteps,      
      @pchStepMsg          = @lvcMsg      
      
/********** STEP 1 Truncate staging table tpzt_ACSDental_meme_extr_old **********/      
      
    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_old      
      
/**********        Error checking for TRUNCATE statement     ***********/      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      
    IF @lnRetCd <> 0      
    BEGIN      
       SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
         + ' : Truncating stage table tpzt_ACSDental_meme_extr_old FAILED'      
         + ' RETURNCODE: '      
         + CONVERT(CHAR(6),@lnRetCd)      
       PRINT        @lvcMsg      
       RETURN        @lnRetCd      
    END      
      
/**************  PRINT STEP 1 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
      
      
/**************  PRINT STEP 2 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_old with the previous days record'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
      
/********** STEP 2 Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_old with the previous days record **********/      
      
   INSERT INTO fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_old      
     (      
        MEME_CK,      
        GRGR_CK,      
        SGSG_CK,      
        SBSB_CK,      
        MEMBER_NUMBER,      
        SUBSCRIBER_NUMBER,      
        MEMBER_FIRST_NAME,      
        MEMBER_MIDDLE_INITIAL,      
        MEMBER_LAST_NAME,      
        MEMBER_BIRTH_DATE,      
        BENEFIT_EFFECTIVE_DATE,      
        BENEFIT_EXPIRATION_DATE,      
        RELATIONSHIP_CODE,      
        SEX_CODE,      
        LINE_OF_BUSINESS,      
        GROUP_NUMBER,      
        ACCOUNT_NUMBER,      
        LANGUAGE_VALUE_1,      
        LANGUAGE_VALUE_2,      
        LANGUAGE_VALUE_3,      
        MEMBER_LANGUAGE,      
        DENTAL_CLASS_PLAN_CODE,      
        PAID_THRU_DATE,      
        ADDRESS_LINE_1,      
        ADDRESS_LINE_2,      
        CITY_CODE,      
        STATE_CODE,      
        ZIP_CODE,      
        PROCESS_DATE,      
        SERVICE_EDITS_CODE,      
        CUSTODIAL_PARENT_LAST_NAME,      
        CUSTODIAL_PARENT_FIRST_NAME,      
        CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        CUST_PARENT_TITLE_CODE,      
        CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        CUSTODIAL_PARENT_CITY_CODE,      
        CUSTODIAL_PARENT_STATE_CODE,      
        CUSTODIAL_PARENT_ZIP_CODE,      
        CUSTODIAL_PARENT_PHONE_NUMBER,      
        COB_INSURANCE_CODE,      
        COB_TYPE,      
        COB_OTHER_INSURANCE_CARRIER_NAME,      
        COB_EFFECTIVE_DATE,      
        COB_TERMINATION_DATE,      
        WAITING_PERIOD_EFFECTIVE_DATE,      
        WAITING_PERIOD_EXPIRATION_DATE,      
        FINANCIAL_ARRANGEMENT,      
        ORIGINAL_EFFECTIVE_DATE,      
        GROUP_CONTRACT_EFFECT_DATE,      
        EXTERNAL_MEMBER_NUMBER,      
        EMPLOYEE_STATUS,      
        GROUP_SIZE,      
        TRANSACTION_DATE,      
        DENTAL_BASIC_EFFECTIVE_DATE,      
        DENTAL_BASIC_EXPIRATION_DATE,      
        DENTAL_MAJOR_EFFECTIVE_DATE,      
        DENTAL_MAJOR_EXPIRATION_DATE,      
        DENTAL_ORTHO_EFFECTIVE_DATE,      
        DENTAL_ORTHO_EXPIRATION_DATE,      
        MEMBER_STATUS,      
        PEDIATRIC_INDICATOR,      
        VOID_INDICATOR      
      )      
    SELECT DISTINCT           
        MEME_CK,      
        GRGR_CK,      
        SGSG_CK,      
        SBSB_CK,      
        MEMBER_NUMBER,      
        SUBSCRIBER_NUMBER,      
        MEMBER_FIRST_NAME,      
        MEMBER_MIDDLE_INITIAL,      
        MEMBER_LAST_NAME,      
        MEMBER_BIRTH_DATE,      
        BENEFIT_EFFECTIVE_DATE,      
        BENEFIT_EXPIRATION_DATE,      
        RELATIONSHIP_CODE,      
        SEX_CODE,      
        LINE_OF_BUSINESS,      
        GROUP_NUMBER,      
        ACCOUNT_NUMBER,      
        LANGUAGE_VALUE_1,      
        LANGUAGE_VALUE_2,      
        LANGUAGE_VALUE_3,      
        MEMBER_LANGUAGE,      
        DENTAL_CLASS_PLAN_CODE,      
        PAID_THRU_DATE,      
        ADDRESS_LINE_1,      
        ADDRESS_LINE_2,      
        CITY_CODE,      
        STATE_CODE,      
        ZIP_CODE,      
        PROCESS_DATE,      
        SERVICE_EDITS_CODE,      
        CUSTODIAL_PARENT_LAST_NAME,      
        CUSTODIAL_PARENT_FIRST_NAME,      
        CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        CUST_PARENT_TITLE_CODE,      
        CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        CUSTODIAL_PARENT_CITY_CODE,      
        CUSTODIAL_PARENT_STATE_CODE,      
        CUSTODIAL_PARENT_ZIP_CODE,      
        CUSTODIAL_PARENT_PHONE_NUMBER,      
        COB_INSURANCE_CODE,      
        COB_TYPE,      
        COB_OTHER_INSURANCE_CARRIER_NAME,      
        COB_EFFECTIVE_DATE,      
        COB_TERMINATION_DATE,      
        WAITING_PERIOD_EFFECTIVE_DATE,      
        WAITING_PERIOD_EXPIRATION_DATE,      
        FINANCIAL_ARRANGEMENT,      
        ORIGINAL_EFFECTIVE_DATE,      
        GROUP_CONTRACT_EFFECT_DATE,      
        EXTERNAL_MEMBER_NUMBER,      
        EMPLOYEE_STATUS,      
        GROUP_SIZE,      
        TRANSACTION_DATE,      
        DENTAL_BASIC_EFFECTIVE_DATE,      
        DENTAL_BASIC_EXPIRATION_DATE,      
        DENTAL_MAJOR_EFFECTIVE_DATE,      
        DENTAL_MAJOR_EXPIRATION_DATE,      
        DENTAL_ORTHO_EFFECTIVE_DATE,      
        DENTAL_ORTHO_EXPIRATION_DATE,      
        MEMBER_STATUS,      
        PEDIATRIC_INDICATOR,      
        VOID_INDICATOR      
     FROM      
        fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new         
                     
/********** Error Checking for insert statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Populating data in stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_old with the previous days record FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 2 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
            
/**************  PRINT STEP 3 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Truncating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
      
/********** STEP 3 Truncating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new **********/      
      
    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new      
                     
/********** Error Checking for truncate statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Truncating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 3 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
           
/**************  PRINT STEP 4 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new with present days record'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
      
/********** STEP 4 Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new with present days record **********/      


 --Instering at Subscriber whose for Void Event is set to Y
 
  INSERT INTO fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new        
      (      
        MEME_CK,      
        GRGR_CK,      
        SGSG_CK,      
        SBSB_CK,      
        MEME_SFX,      
        MEMBER_NUMBER,      
        SUBSCRIBER_NUMBER,      
        MEMBER_FIRST_NAME,      
        MEMBER_MIDDLE_INITIAL,      
        MEMBER_LAST_NAME,      
        MEMBER_BIRTH_DATE,      
        BENEFIT_EFFECTIVE_DATE,      
        BENEFIT_EXPIRATION_DATE,      
        RELATIONSHIP_CODE,      
        SEX_CODE,      
        LINE_OF_BUSINESS,      
        GROUP_NUMBER,      
        ACCOUNT_NUMBER,      
        LANGUAGE_VALUE_1,      
        LANGUAGE_VALUE_2,      
        LANGUAGE_VALUE_3,      
        MEMBER_LANGUAGE,      
        DENTAL_CLASS_PLAN_CODE,      
        PAID_THRU_DATE,      
        ADDRESS_LINE_1,      
        ADDRESS_LINE_2,      
        CITY_CODE,      
        STATE_CODE,      
        ZIP_CODE,      
        PROCESS_DATE,      
        SERVICE_EDITS_CODE,      
        CUSTODIAL_PARENT_LAST_NAME,      
        CUSTODIAL_PARENT_FIRST_NAME,      
        CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        CUST_PARENT_TITLE_CODE,      
        CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        CUSTODIAL_PARENT_CITY_CODE,      
        CUSTODIAL_PARENT_STATE_CODE,      
        CUSTODIAL_PARENT_ZIP_CODE,      
        CUSTODIAL_PARENT_PHONE_NUMBER,      
        COB_INSURANCE_CODE,      
        COB_TYPE,      
        COB_OTHER_INSURANCE_CARRIER_NAME,      
        COB_EFFECTIVE_DATE,      
        COB_TERMINATION_DATE,      
        WAITING_PERIOD_EFFECTIVE_DATE,      
        WAITING_PERIOD_EXPIRATION_DATE,      
        FINANCIAL_ARRANGEMENT,      
        ORIGINAL_EFFECTIVE_DATE,      
        GROUP_CONTRACT_EFFECT_DATE,      
        EXTERNAL_MEMBER_NUMBER,      
        EMPLOYEE_STATUS,      
        GROUP_SIZE,      
        TRANSACTION_DATE,      
        DENTAL_BASIC_EFFECTIVE_DATE,      
        DENTAL_BASIC_EXPIRATION_DATE,      
        DENTAL_MAJOR_EFFECTIVE_DATE,      
        DENTAL_MAJOR_EXPIRATION_DATE,      
        DENTAL_ORTHO_EFFECTIVE_DATE,      
        DENTAL_ORTHO_EXPIRATION_DATE,      
        MEMBER_STATUS,      
        PEDIATRIC_INDICATOR,      
        VOID_INDICATOR      
      ) 
      SELECT DISTINCT           
						MEME_CK = LTRIM(RTRIM(meme.MEME_CK)),      
						GRGR_CK = LTRIM(RTRIM(grgr.GRGR_CK)),      
						SGSG_CK = LTRIM(RTRIM(sgsg.SGSG_CK)),      
						SBSB_CK = LTRIM(RTRIM(sbsb.SBSB_CK)),      
						MEME_SFX = LTRIM(RTRIM(meme.MEME_SFX)),      
						MEMBER_NUMBER = SPACE(15),      
						SUBSCRIBER_NUMBER = SPACE(15),      
						MEMBER_FIRST_NAME = SUBSTRING(LTRIM(RTRIM(meme.MEME_FIRST_NAME)),1,15),      
						MEMBER_MIDDLE_INITIAL = LTRIM(RTRIM(meme.MEME_MID_INIT)),      
						MEMBER_LAST_NAME = SUBSTRING(LTRIM(RTRIM(meme.MEME_LAST_NAME)),1,20),      
						MEMBER_BIRTH_DATE = CONVERT(VARCHAR(8),meme.MEME_BIRTH_DT,112),      
						BENEFIT_EFFECTIVE_DATE = isnull(oldext.BENEFIT_EFFECTIVE_DATE,'00000000'), --CASE WHEN  CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) ='21991231'      --   
						--									THEN '99991231'  
						--									 ELSE  
						--										CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112)  
						--									 END ,  
						BENEFIT_EXPIRATION_DATE = case when isnull(oldext.BENEFIT_EFFECTIVE_DATE,'00000000') = '00000000'
													then '00000000'
													else 
														convert(varchar(8),DATEADD(day,-1,convert(datetime, substring(oldext.BENEFIT_EFFECTIVE_DATE,1,4) + substring(oldext.BENEFIT_EFFECTIVE_DATE,5,2) + substring(oldext.BENEFIT_EFFECTIVE_DATE,7,2),112)),112) 
													end,
						--BENEFIT_EXPIRATION_DATE = isnull(DATEADD(day,-1,convert(datetime,oldext.BENEFIT_EFFECTIVE_DATE)),'00000000'), --CASE WHEN  CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112)= '21991231'      
						--									 THEN '99991231'  
						--									 ELSE  
						--										 CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112)  
						--									 END ,  
						RELATIONSHIP_CODE =  CASE       
												WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'M'      
													THEN '1'      
												WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'H'    or LTRIM(RTRIM(meme.MEME_REL)) = 'W'      
													THEN '2'      
												WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'S'    or LTRIM(RTRIM(meme.MEME_REL)) = 'D'      
													THEN '3'          
												WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'O'          
													THEN '4'      
											 END,      
						SEX_CODE = LTRIM(RTRIM(meme.MEME_SEX)),      
						LINE_OF_BUSINESS = LTRIM(RTRIM(cte.PDBC_PFX)),      
						GROUP_NUMBER = LTRIM(RTRIM(grgr.GRGR_ID)),      
						ACCOUNT_NUMBER = SUBSTRING(LTRIM(RTRIM(sgsg.SGSG_ID)),1,15),      
						LANGUAGE_VALUE_1 = ' ',      
						LANGUAGE_VALUE_2 = ' ',      
						LANGUAGE_VALUE_3 = ' ',      
						MEMBER_LANGUAGE =  LTRIM(RTRIM(meme.MEME_MCTR_LANG)),      
						DENTAL_CLASS_PLAN_CODE = LTRIM(RTRIM(sbel.CSPI_ID)),      
						PAID_THRU_DATE = CONVERT(VARCHAR(8),grgr.GRGR_ORIG_EFF_DT,112),    
				            
						ADDRESS_LINE_1 = SUBSTRING(CASE       
														WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
														THEN LTRIM(RTRIM(enad.ENAD_ADDR1))      
														WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
														THEN LTRIM(RTRIM(mcrp.MCRP_ADDR1))      
														WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
														THEN LTRIM(RTRIM(sbad.SBAD_ADDR1))      
													 END,1,25),      
						ADDRESS_LINE_2 = SUBSTRING(CASE       
														WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
														THEN LTRIM(RTRIM(enad.ENAD_ADDR2))      
														WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
														THEN LTRIM(RTRIM(mcrp.MCRP_ADDR2))      
														WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
														THEN LTRIM(RTRIM(sbad.SBAD_ADDR2))      
													 END,1,25),      
						CITY_CODE = SUBSTRING(CASE       
														WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
														  THEN LTRIM(RTRIM(enad.ENAD_CITY))      
														  WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
														  THEN LTRIM(RTRIM(mcrp.MCRP_CITY))      
														  WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
														  THEN LTRIM(RTRIM(sbad.SBAD_CITY))      
													 END,1,16),      
						STATE_CODE = SUBSTRING(CASE       
														  WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
														  THEN LTRIM(RTRIM(enad.ENAD_STATE))      
														  WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
														  THEN LTRIM(RTRIM(mcrp.MCRP_STATE))      
														  WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
														  THEN LTRIM(RTRIM(sbad.SBAD_STATE))      
													 END,1,2),      
						ZIP_CODE = SUBSTRING(CASE       
												WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''       
												THEN	CASE WHEN LEN(LTRIM(RTRIM(enad.ENAD_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(enad.ENAD_ZIP,''))) NOT LIKE '%-%'  
															  THEN SUBSTRING(LTRIM(RTRIM(enad.ENAD_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(enad.ENAD_ZIP)),6,4)  
															  ELSE LTRIM(RTRIM(enad.ENAD_ZIP))  
														 END 
												WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''       
												THEN CASE WHEN LEN(LTRIM(RTRIM(mcrp.MCRP_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(mcrp.MCRP_ZIP,''))) NOT LIKE '%-%'  
															  THEN SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),6,4)  
															  ELSE LTRIM(RTRIM(mcrp.MCRP_ZIP))  
														 END 
												WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''       
												 THEN CASE WHEN LEN(LTRIM(RTRIM(sbad.SBAD_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(sbad.SBAD_ZIP,''))) NOT LIKE '%-%'  
															  THEN SUBSTRING(LTRIM(RTRIM(sbad.SBAD_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(sbad.SBAD_ZIP)),6,4)  
															  ELSE LTRIM(RTRIM(sbad.SBAD_ZIP))  
														 END 
											END,1,10),     
				          
						PROCESS_DATE = CONVERT(VARCHAR(8),GETDATE(),112),      
						SERVICE_EDITS_CODE = SPACE(3),      
				              
						CUSTODIAL_PARENT_LAST_NAME = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_LAST_NAME)),1,20),''),  
						CUSTODIAL_PARENT_FIRST_NAME = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_FIRST_NAME)),1,15),''),       
						CUSTODIAL_PARENT_MIDDLE_INITIAL = ISNULL(LTRIM(RTRIM(mcrp.MCRP_MID_INIT)),''),          
						CUST_PARENT_TITLE_CODE = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_TITLE)),1,4),''),     
				          
						CUSTODIAL_PARENT_ADDRESS_LINE_1 = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),1,25),''),      
						CUSTODIAL_PARENT_ADDRESS_LINE_2 = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ADDR2)),1,25),''),      
						CUSTODIAL_PARENT_CITY_CODE = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_CITY)),1,16),''),      
						CUSTODIAL_PARENT_STATE_CODE = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_STATE)),1,2),''),      
						CUSTODIAL_PARENT_ZIP_CODE = CASE  WHEN ISNULL(LTRIM(RTRIM(mcrp.MCRP_ZIP)),'') <> ''       
															 THEN CASE WHEN LEN(LTRIM(RTRIM(mcrp.MCRP_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(mcrp.MCRP_ZIP,''))) NOT LIKE '%-%'  
																	   THEN SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),6,4)  
																	  ELSE LTRIM(RTRIM(mcrp.MCRP_ZIP))  
																	END 
													END,
						CUSTODIAL_PARENT_PHONE_NUMBER = ISNULL(CASE WHEN LTRIM(RTRIM(ISNULL(mcrp.MCRP_ADDR1,'')))<>''      
															 THEN LTRIM(RTRIM(mcrp.MCRP_PHONE))      
															 ELSE ''      
														END,''),   
				          
				             
						COB_INSURANCE_CODE ='',      
						COB_TYPE = '',      
						COB_OTHER_INSURANCE_CARRIER_NAME = '',      
						COB_EFFECTIVE_DATE = '',      
						COB_TERMINATION_DATE = '',      
				              
				              
						WAITING_PERIOD_EFFECTIVE_DATE = CASE WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'      
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)      
															ELSE '00000000'      
														END,       
				                       
						WAITING_PERIOD_EXPIRATION_DATE = CASE WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'      
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)      
															ELSE '00000000'      
														 END ,   
				              
						FINANCIAL_ARRANGEMENT = 'UN',      
						ORIGINAL_EFFECTIVE_DATE = CONVERT(VARCHAR(8),meme.MEME_ORIG_EFF_DT,112),      
						GROUP_CONTRACT_EFFECT_DATE = CONVERT(VARCHAR(8),grgr.GRGR_CURR_ANNV_DT,112),  
						EXTERNAL_MEMBER_NUMBER = RIGHT(REPLICATE('0',9) + CAST(LTRIM(RTRIM(sbsb.SBSB_ID)) AS VARCHAR(9)),9) + RIGHT(REPLICATE('0',2) + CAST(meme.MEME_SFX AS VARCHAR(2)),2),      
						EMPLOYEE_STATUS = oldext.EMPLOYEE_STATUS, -- 'E', --CASE WHEN mepe.MEPE_ELIG_OVR_IND = 'C' THEN 'C' --Cobra   
						--						   WHEN mepe.MEPE_MCTR_RSN = 'SB21' THEN 'R'  --  
						--				   ELSE 'E' --Employed       
						--				END,		--'',   
				               
						GROUP_SIZE = 'SMAL' ,   
						TRANSACTION_DATE = '00000000',
				              
						DENTAL_BASIC_EFFECTIVE_DATE =   CASE WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101'   
																  AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'  
																  AND new.DENTAL_WAITING_PERIOD ='L' 
																  AND DATEDIFF(DAY, atuf.ATUF_DATE1, atuf.ATUF_DATE2) >= 1  
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)  
															WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101'   
																  AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'  
																  AND new.DENTAL_WAITING_PERIOD IN('A','S')    
																  AND DATEDIFF(MONTH, atuf.ATUF_DATE1, atuf.ATUF_DATE2) > 12  
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)  
															ELSE '00000000'      
													   END,      
						DENTAL_BASIC_EXPIRATION_DATE = CASE WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101'   
																 AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'  
				                                                   
																  AND new.DENTAL_WAITING_PERIOD ='L'
																 AND DATEDIFF(DAY, atuf.ATUF_DATE1, atuf.ATUF_DATE2) >= 1  
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)  
				                                            
															WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101'   
																 AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'   
																 AND new.DENTAL_WAITING_PERIOD IN('A','S')   
																 AND DATEDIFF(MONTH, atuf.ATUF_DATE1, atuf.ATUF_DATE2) > 12  
															THEN  CONVERT(VARCHAR(8),DATEADD(mm, 12, atuf.ATUF_DATE1-1),112)   --CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)  
															ELSE '00000000'      
													   END,      
						DENTAL_MAJOR_EFFECTIVE_DATE = CASE WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101'   
																AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'      
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)      
															ELSE '00000000'      
													  END,      
						DENTAL_MAJOR_EXPIRATION_DATE = CASE WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101'   
															AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'      
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)      
															ELSE '00000000'      
													  END,      
				        
				          
						DENTAL_ORTHO_EFFECTIVE_DATE = CASE WHEN (atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101' 
																	AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'  )
																	AND new.ORTHODONTIA_AGE = '18'   
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)      
															ELSE '00000000'      
														END,   
						DENTAL_ORTHO_EXPIRATION_DATE = CASE WHEN (atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101' 
																	AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231' )     
																	AND new.ORTHODONTIA_AGE = '18'      
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)  
															ELSE '00000000'      
														 END ,   
				              
						MEMBER_STATUS = '',	      
						PEDIATRIC_INDICATOR = case when 
															(case when DATEADD(YY, DATEDIFF(YY,  meme.MEME_BIRTH_DT , getdate()),   meme.MEME_BIRTH_DT )  > getdate() 
																  then DATEDIFF(YY,  meme.MEME_BIRTH_DT , getdate()) - 1 
																  else DATEDIFF(YY,  meme.MEME_BIRTH_DT , getdate()) 
															end	)< 19
													THEN 'Y'      
													   ELSE 'N'      
											   END,      
						VOID_INDICATOR = 'Y'      
				          
						FROM fabncdv1.dbo.CMC_GRGR_GROUP grgr
						inner join fabncdv1stage.dbo.tpzt_ACSDental_group_extr_new new on new.GROUP_NUMBER  = grgr.GRGR_ID
						INNER JOIN fabncdv1.dbo.CMC_GRGC_GROUP_COUNT grgc  ON grgc.GRGR_CK = grgr.GRGR_CK   
						INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg  ON sgsg.GRGR_CK = grgr.GRGR_CK      
						INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb   ON sbsb.GRGR_CK = grgr.GRGR_CK   
						INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme  ON meme.SBSB_CK = sbsb.SBSB_CK  
						INNER JOIN fabncdv1.dbo.CMC_SBAD_ADDR sbad   ON sbsb.SBSB_CK = sbad.SBSB_CK  
								AND meme.SBAD_TYPE_HOME = sbad.SBAD_TYPE  
						--INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe  ON meme.MEME_CK = mepe.MEME_CK  
						--		AND sgsg.SGSG_CK = mepe.SGSG_CK  
				        
				      
						INNER JOIN  fabncdv1.dbo.CMC_SBEL_ELIG_ENT sbel on sbel.SBSB_CK = sbsb.SBSB_CK 
															and sbel.GRGR_CK =grgr.GRGR_CK
															--and sbel.CSPD_CAT = mepe.CSPD_CAT
															and SBEL_VOID_IND = 'Y'	
															AND sbel.CSPI_ID  = new.PLAN_CODE															
				                   
						LEFT JOIN fabncdv1.dbo.CMC_GRRE_RELATION grre  ON  grgr.GRGR_CK = grre.GRGR_CK  
								AND grre.GRRE_CATEGORY = 'OT'    
								AND grre.GRRE_MCTR_TYPE = 'SIZE'   
						LEFT JOIN  fabncdv1.dbo.CMC_MCRE_RELAT_ENT mcre  ON mcre.MCRE_ID = grre.MCRE_GRRE_ID  
				          
				          
				          
						INNER JOIN  @CTE_TEMP cte                           ON cte.CSPI_ID = sbel.CSPI_ID
																				
                        LEFT JOIN fabncdv1.dbo.CER_ATXR_ATTACH_U atxr      ON atxr.ATXR_SOURCE_ID = meme.ATXR_SOURCE_ID
                                                                           AND LTRIM(RTRIM(atxr.ATSY_ID))  in ( 'DNWP')          
                        LEFT JOIN fabncdv1..CER_ATUF_USERFLD_D atuf  ON atuf.ATSY_ID = atxr.ATSY_ID      
																AND  atuf.ATXR_DEST_ID = atxr.ATXR_DEST_ID      
						left join fabncdv1..CMC_MERP_RELATION merp				ON merp.MEME_CK = meme.MEME_CK  
						LEFT JOIN fabncdv1..CMC_MCRP_RELAT_PER mcrp			ON mcrp.MCRP_ID = merp.MCRP_ID  
				 ------------------------------------------------------------------------------------------------------------------------------------        
						LEFT JOIN fabncdv1..FHP_PMED_MEMBER_D pmed ON pmed.PMED_ID = (CAST(grgr.GRGR_ID AS VARCHAR(24))   
							  +CAST(sbsb.SBSB_ID AS VARCHAR(24))  
							  +CAST(meme.MEME_SFX AS VARCHAR(24))  
							  +CAST(meme.MEME_REL AS VARCHAR(24)))   
				  LEFT JOIN fabncdv1..FHD_ENEN_ENTITY_D enen ON enen.ENEN_CKE = pmed.PMED_CKE  
				  LEFT JOIN fabncdv1..FHD_ENAD_ADDRESS_D enad ON enad.ENEN_CKE = enen.ENEN_CKE  
				  LEFT JOIN fabncdv1..FHP_PMCC_COMM_X pmcc ON pmcc.PMED_CKE = pmed.PMED_CKE         
				   LEFT JOIN fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_old  oldext  on oldext.MEME_CK = meme.MEME_CK
																					and oldext.GRGR_CK = grgr. GRGR_CK
																					and oldext.SGSG_CK = sgsg.SGSG_CK
				               
				WHERE  sbel.CSPD_CAT ='1'   
					and meme.MEME_SFX = '0'
					
 ----Instering the records whose  Void Event is N ---------------------------          
    INSERT INTO fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new        
      (      
        MEME_CK,      
        GRGR_CK,      
        SGSG_CK,      
        SBSB_CK,      
        MEME_SFX,      
        MEMBER_NUMBER,      
        SUBSCRIBER_NUMBER,      
        MEMBER_FIRST_NAME,      
        MEMBER_MIDDLE_INITIAL,      
        MEMBER_LAST_NAME,      
        MEMBER_BIRTH_DATE,      
        BENEFIT_EFFECTIVE_DATE,      
        BENEFIT_EXPIRATION_DATE,      
        RELATIONSHIP_CODE,      
        SEX_CODE,      
        LINE_OF_BUSINESS,      
        GROUP_NUMBER,      
        ACCOUNT_NUMBER,      
        LANGUAGE_VALUE_1,      
        LANGUAGE_VALUE_2,      
        LANGUAGE_VALUE_3,      
        MEMBER_LANGUAGE,      
        DENTAL_CLASS_PLAN_CODE,      
        PAID_THRU_DATE,      
        ADDRESS_LINE_1,      
        ADDRESS_LINE_2,      
        CITY_CODE,      
        STATE_CODE,      
        ZIP_CODE,      
        PROCESS_DATE,      
        SERVICE_EDITS_CODE,      
        CUSTODIAL_PARENT_LAST_NAME,      
        CUSTODIAL_PARENT_FIRST_NAME,      
        CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        CUST_PARENT_TITLE_CODE,      
        CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        CUSTODIAL_PARENT_CITY_CODE,      
        CUSTODIAL_PARENT_STATE_CODE,      
        CUSTODIAL_PARENT_ZIP_CODE,      
        CUSTODIAL_PARENT_PHONE_NUMBER,      
        COB_INSURANCE_CODE,      
        COB_TYPE,      
        COB_OTHER_INSURANCE_CARRIER_NAME,      
        COB_EFFECTIVE_DATE,      
        COB_TERMINATION_DATE,      
        WAITING_PERIOD_EFFECTIVE_DATE,      
        WAITING_PERIOD_EXPIRATION_DATE,      
        FINANCIAL_ARRANGEMENT,      
        ORIGINAL_EFFECTIVE_DATE,      
        GROUP_CONTRACT_EFFECT_DATE,      
        EXTERNAL_MEMBER_NUMBER,      
        EMPLOYEE_STATUS,      
        GROUP_SIZE,      
        TRANSACTION_DATE,      
        DENTAL_BASIC_EFFECTIVE_DATE,      
        DENTAL_BASIC_EXPIRATION_DATE,      
        DENTAL_MAJOR_EFFECTIVE_DATE,      
        DENTAL_MAJOR_EXPIRATION_DATE,      
        DENTAL_ORTHO_EFFECTIVE_DATE,      
        DENTAL_ORTHO_EXPIRATION_DATE,      
        MEMBER_STATUS,      
        PEDIATRIC_INDICATOR,      
        VOID_INDICATOR      
      )  
      SELECT DISTINCT           
        MEME_CK = LTRIM(RTRIM(meme.MEME_CK)),      
        GRGR_CK = LTRIM(RTRIM(grgr.GRGR_CK)),      
        SGSG_CK = LTRIM(RTRIM(sgsg.SGSG_CK)),      
        SBSB_CK = LTRIM(RTRIM(sbsb.SBSB_CK)),      
        MEME_SFX = LTRIM(RTRIM(meme.MEME_SFX)),      
        MEMBER_NUMBER = SPACE(15),      
        SUBSCRIBER_NUMBER = SPACE(15),      
        MEMBER_FIRST_NAME = SUBSTRING(LTRIM(RTRIM(meme.MEME_FIRST_NAME)),1,15),      
        MEMBER_MIDDLE_INITIAL = LTRIM(RTRIM(meme.MEME_MID_INIT)),      
        MEMBER_LAST_NAME = SUBSTRING(LTRIM(RTRIM(meme.MEME_LAST_NAME)),1,20),      
        MEMBER_BIRTH_DATE = CONVERT(VARCHAR(8),meme.MEME_BIRTH_DT,112),      
        BENEFIT_EFFECTIVE_DATE = CASE WHEN  CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) ='21991231'      --   
											THEN '99991231'  
											 ELSE  
												CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112)  
											 END ,  
        BENEFIT_EXPIRATION_DATE = CASE WHEN  CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112)= '21991231'      
											 THEN '99991231'  
											 ELSE  
												 CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112)  
											 END ,  
        RELATIONSHIP_CODE =  CASE       
                                WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'M'      
                                    THEN '1'      
                                WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'H'    or LTRIM(RTRIM(meme.MEME_REL)) = 'W'      
                                    THEN '2'      
								WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'S'    or LTRIM(RTRIM(meme.MEME_REL)) = 'D'      
                                    THEN '3'          
                                WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'O'          
                                    THEN '4'      
                             END,      
        SEX_CODE = LTRIM(RTRIM(meme.MEME_SEX)),      
        LINE_OF_BUSINESS = LTRIM(RTRIM(cte.PDBC_PFX)),      
        GROUP_NUMBER = LTRIM(RTRIM(grgr.GRGR_ID)),      
        ACCOUNT_NUMBER = SUBSTRING(LTRIM(RTRIM(sgsg.SGSG_ID)),1,15),      
        LANGUAGE_VALUE_1 = ' ',      
        LANGUAGE_VALUE_2 = ' ',      
        LANGUAGE_VALUE_3 = ' ',      
        MEMBER_LANGUAGE =  LTRIM(RTRIM(meme.MEME_MCTR_LANG)),      
        DENTAL_CLASS_PLAN_CODE = LTRIM(RTRIM(mepe.CSPI_ID)),      
        PAID_THRU_DATE = CONVERT(VARCHAR(8),grgr.GRGR_ORIG_EFF_DT,112),    
            
        ADDRESS_LINE_1 = SUBSTRING(CASE       
                                        WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
                                        THEN LTRIM(RTRIM(enad.ENAD_ADDR1))      
                                        WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
                                        THEN LTRIM(RTRIM(mcrp.MCRP_ADDR1))      
                                        WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
                                        THEN LTRIM(RTRIM(sbad.SBAD_ADDR1))      
                                     END,1,25),      
        ADDRESS_LINE_2 = SUBSTRING(CASE       
                                        WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
                                        THEN LTRIM(RTRIM(enad.ENAD_ADDR2))      
                                        WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
                                        THEN LTRIM(RTRIM(mcrp.MCRP_ADDR2))      
                                        WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
                                        THEN LTRIM(RTRIM(sbad.SBAD_ADDR2))      
                                     END,1,25),      
        CITY_CODE = SUBSTRING(CASE       
                                        WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
                                          THEN LTRIM(RTRIM(enad.ENAD_CITY))      
                                          WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
                                          THEN LTRIM(RTRIM(mcrp.MCRP_CITY))      
                                          WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
                                          THEN LTRIM(RTRIM(sbad.SBAD_CITY))      
                                     END,1,16),      
        STATE_CODE = SUBSTRING(CASE       
                                          WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
                                          THEN LTRIM(RTRIM(enad.ENAD_STATE))      
                                          WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
                                          THEN LTRIM(RTRIM(mcrp.MCRP_STATE))      
                                          WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
                                          THEN LTRIM(RTRIM(sbad.SBAD_STATE))      
                                     END,1,2),      
        ZIP_CODE = SUBSTRING(CASE       
                                WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''       
								THEN	CASE WHEN LEN(LTRIM(RTRIM(enad.ENAD_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(enad.ENAD_ZIP,''))) NOT LIKE '%-%'  
											  THEN SUBSTRING(LTRIM(RTRIM(enad.ENAD_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(enad.ENAD_ZIP)),6,4)  
											  ELSE LTRIM(RTRIM(enad.ENAD_ZIP))  
										 END 
                                WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''       
                                THEN CASE WHEN LEN(LTRIM(RTRIM(mcrp.MCRP_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(mcrp.MCRP_ZIP,''))) NOT LIKE '%-%'  
											  THEN SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),6,4)  
											  ELSE LTRIM(RTRIM(mcrp.MCRP_ZIP))  
										 END 
                                WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''       
                                 THEN CASE WHEN LEN(LTRIM(RTRIM(sbad.SBAD_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(sbad.SBAD_ZIP,''))) NOT LIKE '%-%'  
											  THEN SUBSTRING(LTRIM(RTRIM(sbad.SBAD_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(sbad.SBAD_ZIP)),6,4)  
											  ELSE LTRIM(RTRIM(sbad.SBAD_ZIP))  
										 END 
                            END,1,10),     
          
        PROCESS_DATE = CONVERT(VARCHAR(8),GETDATE(),112),      
        SERVICE_EDITS_CODE = SPACE(3),      
              
        CUSTODIAL_PARENT_LAST_NAME = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_LAST_NAME)),1,20),''),  
        CUSTODIAL_PARENT_FIRST_NAME = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_FIRST_NAME)),1,15),''),       
        CUSTODIAL_PARENT_MIDDLE_INITIAL = ISNULL(LTRIM(RTRIM(mcrp.MCRP_MID_INIT)),''),          
        CUST_PARENT_TITLE_CODE = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_TITLE)),1,4),''),     
          
        CUSTODIAL_PARENT_ADDRESS_LINE_1 = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),1,25),''),      
        CUSTODIAL_PARENT_ADDRESS_LINE_2 = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ADDR2)),1,25),''),      
        CUSTODIAL_PARENT_CITY_CODE = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_CITY)),1,16),''),      
        CUSTODIAL_PARENT_STATE_CODE = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_STATE)),1,2),''),      
        CUSTODIAL_PARENT_ZIP_CODE = CASE  WHEN ISNULL(LTRIM(RTRIM(mcrp.MCRP_ZIP)),'') <> ''       
											 THEN CASE WHEN LEN(LTRIM(RTRIM(mcrp.MCRP_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(mcrp.MCRP_ZIP,''))) NOT LIKE '%-%'  
													   THEN SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),6,4)  
													  ELSE LTRIM(RTRIM(mcrp.MCRP_ZIP))  
													END 
									END,
        CUSTODIAL_PARENT_PHONE_NUMBER = ISNULL(CASE WHEN LTRIM(RTRIM(ISNULL(mcrp.MCRP_ADDR1,'')))<>''      
                                             THEN LTRIM(RTRIM(mcrp.MCRP_PHONE))      
                                             ELSE ''      
                                        END,''),   
          
             
        COB_INSURANCE_CODE ='',      
        COB_TYPE = '',      
        COB_OTHER_INSURANCE_CARRIER_NAME = '',      
        COB_EFFECTIVE_DATE = '',      
        COB_TERMINATION_DATE = '',      
              
              
        WAITING_PERIOD_EFFECTIVE_DATE = CASE WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'      
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)      
                                            ELSE '00000000'      
                                        END,       
                       
        WAITING_PERIOD_EXPIRATION_DATE = CASE WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'      
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)      
                                            ELSE '00000000'      
                                         END ,   
              
        FINANCIAL_ARRANGEMENT = 'UN',      
        ORIGINAL_EFFECTIVE_DATE = CONVERT(VARCHAR(8),meme.MEME_ORIG_EFF_DT,112),      
        GROUP_CONTRACT_EFFECT_DATE = CONVERT(VARCHAR(8),grgr.GRGR_CURR_ANNV_DT,112),  
        EXTERNAL_MEMBER_NUMBER = RIGHT(REPLICATE('0',9) + CAST(LTRIM(RTRIM(sbsb.SBSB_ID)) AS VARCHAR(9)),9) + RIGHT(REPLICATE('0',2) + CAST(meme.MEME_SFX AS VARCHAR(2)),2),      
        EMPLOYEE_STATUS = CASE WHEN mepe.MEPE_ELIG_OVR_IND = 'C' THEN 'C' --Cobra   
								   WHEN mepe.MEPE_MCTR_RSN = 'SB21' THEN 'R'  --  
                           ELSE 'E' --Employed       
                        END,		--'',   
               
        GROUP_SIZE = 'SMAL' ,   
        TRANSACTION_DATE = '00000000',
              
        DENTAL_BASIC_EFFECTIVE_DATE =   CASE WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101'   
                                                  AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'  
												  AND new.DENTAL_WAITING_PERIOD ='L' 
                                                  AND DATEDIFF(DAY, atuf.ATUF_DATE1, atuf.ATUF_DATE2) >= 1  
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)  
                                            WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101'   
                                                  AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'  
                                                  AND new.DENTAL_WAITING_PERIOD IN('A','S')    
                                                  AND DATEDIFF(MONTH, atuf.ATUF_DATE1, atuf.ATUF_DATE2) > 12  
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)  
                                            ELSE '00000000'      
                                       END,      
        DENTAL_BASIC_EXPIRATION_DATE = CASE WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101'   
                                                 AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'  
                                                   
                                                  AND new.DENTAL_WAITING_PERIOD ='L'
                                                 AND DATEDIFF(DAY, atuf.ATUF_DATE1, atuf.ATUF_DATE2) >= 1  
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)  
                                            
                                            WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101'   
                                                 AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'   
                                                 AND new.DENTAL_WAITING_PERIOD IN('A','S')   
                                                 AND DATEDIFF(MONTH, atuf.ATUF_DATE1, atuf.ATUF_DATE2) > 12  
                                            THEN  CONVERT(VARCHAR(8),DATEADD(mm, 12, atuf.ATUF_DATE1-1),112)   --CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)  
                                            ELSE '00000000'      
                                       END,      
        DENTAL_MAJOR_EFFECTIVE_DATE = CASE WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101'   
                                                AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'      
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)      
                                            ELSE '00000000'      
                                      END,      
        DENTAL_MAJOR_EXPIRATION_DATE = CASE WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101'   
                                            AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'      
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)      
                                            ELSE '00000000'      
                                      END,      
        
          
        DENTAL_ORTHO_EFFECTIVE_DATE = CASE WHEN (atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101' 
													AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'  )
													AND new.ORTHODONTIA_AGE = '18'   
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)      
                                            ELSE '00000000'      
                                        END,   
        DENTAL_ORTHO_EXPIRATION_DATE = CASE WHEN (atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101' 
													AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231' )     
													AND new.ORTHODONTIA_AGE = '18'      
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)  
                                            
                                            ELSE '00000000'      
                                         END ,   
              
        MEMBER_STATUS = '',	      
        PEDIATRIC_INDICATOR = case when 
											(case when DATEADD(YY, DATEDIFF(YY,  meme.MEME_BIRTH_DT , getdate()),   meme.MEME_BIRTH_DT )  > getdate() 
												  then DATEDIFF(YY,  meme.MEME_BIRTH_DT , getdate()) - 1 
												  else DATEDIFF(YY,  meme.MEME_BIRTH_DT , getdate()) 
											end	)< 19
									THEN 'Y'      
									   ELSE 'N'      
                               END,      
        VOID_INDICATOR = 'N'      
          
        FROM fabncdv1.dbo.CMC_GRGR_GROUP grgr
		inner join fabncdv1stage.dbo.tpzt_ACSDental_group_extr_new new on new.GROUP_NUMBER  = grgr.GRGR_ID
		INNER JOIN fabncdv1.dbo.CMC_GRGC_GROUP_COUNT grgc  ON grgc.GRGR_CK = grgr.GRGR_CK   
        INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg  ON sgsg.GRGR_CK = grgr.GRGR_CK      
        INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb   ON sbsb.GRGR_CK = grgr.GRGR_CK   
        INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme  ON meme.SBSB_CK = sbsb.SBSB_CK  
        INNER JOIN fabncdv1.dbo.CMC_SBAD_ADDR sbad   ON sbsb.SBSB_CK = sbad.SBSB_CK  
                AND meme.SBAD_TYPE_HOME = sbad.SBAD_TYPE  
        INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe  ON meme.MEME_CK = mepe.MEME_CK  
                AND sgsg.SGSG_CK = mepe.SGSG_CK  
				AND mepe.CSPI_ID  = new.PLAN_CODE
                   
  LEFT JOIN fabncdv1.dbo.CMC_GRRE_RELATION grre  ON  grgr.GRGR_CK = grre.GRGR_CK  
                AND grre.GRRE_CATEGORY = 'OT'    
                AND grre.GRRE_MCTR_TYPE = 'SIZE'   
        LEFT JOIN  fabncdv1.dbo.CMC_MCRE_RELAT_ENT mcre  ON mcre.MCRE_ID = grre.MCRE_GRRE_ID  
          
          
          
        INNER JOIN  @CTE_TEMP cte                           ON cte.PDPD_ID=mepe.PDPD_ID      
        LEFT JOIN fabncdv1.dbo.CER_ATXR_ATTACH_U atxr      ON atxr.ATXR_SOURCE_ID = meme.ATXR_SOURCE_ID
  														   AND LTRIM(RTRIM(atxr.ATSY_ID))  in ( 'DNWP')          
        LEFT JOIN fabncdv1..CER_ATUF_USERFLD_D atuf  ON atuf.ATSY_ID = atxr.ATSY_ID      
                AND  atuf.ATXR_DEST_ID = atxr.ATXR_DEST_ID      
  left join fabncdv1..CMC_MERP_RELATION merp  ON merp.MEME_CK = meme.MEME_CK  
        LEFT JOIN fabncdv1..CMC_MCRP_RELAT_PER mcrp  ON mcrp.MCRP_ID = merp.MCRP_ID  
 ------------------------------------------------------------------------------------------------------------------------------------        
        LEFT JOIN fabncdv1..FHP_PMED_MEMBER_D pmed ON pmed.PMED_ID = (CAST(grgr.GRGR_ID AS VARCHAR(24))   
              +CAST(sbsb.SBSB_ID AS VARCHAR(24))  
              +CAST(meme.MEME_SFX AS VARCHAR(24))  
              +CAST(meme.MEME_REL AS VARCHAR(24)))   
  LEFT JOIN fabncdv1..FHD_ENEN_ENTITY_D enen ON enen.ENEN_CKE = pmed.PMED_CKE  
  LEFT JOIN fabncdv1..FHD_ENAD_ADDRESS_D enad ON enad.ENEN_CKE = enen.ENEN_CKE  
  LEFT JOIN fabncdv1..FHP_PMCC_COMM_X pmcc ON pmcc.PMED_CKE = pmed.PMED_CKE         
               
WHERE  mepe.CSPD_CAT ='1'   
     AND mepe.MEPE_ELIG_IND='Y'     
 
       

           
/********** Error Checking for insert statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new with present days record FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 4 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
      
   
/**************  PRINT STEP 5 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Updating logic for void indicator'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
      
/********** STEP 5 Updating logic for void indicator **********/      
   
   
--declare @CountVoidIndicator int = 0

SELECT @CountVoidIndicator = Count(new.MEME_CK) FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new   new	
	INNER JOIN  fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe ON mepe.MEME_CK = new.MEME_CK
														AND new.GRGR_CK = mepe.GRGR_CK
														AND mepe.SGSG_CK = new.SGSG_CK
														AND mepe.CSPI_ID= new.DENTAL_CLASS_PLAN_CODE
WHERE new.VOID_INDICATOR = 'Y'
AND new.MEME_SFX = '0'

 if (@CountVoidIndicator > 0)
	begin
		
		update new
			set  new.BENEFIT_EFFECTIVE_DATE = CASE WHEN  CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) ='21991231'      --   
													THEN '99991231'  
												 ELSE  
													CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112)  
												END ,  
				
				 new.BENEFIT_EXPIRATION_DATE = CASE WHEN  CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) ='21991231'       
													THEN '99991231'  
												 ELSE  
													CONVERT(VARCHAR(8),DATEADD(day,-1,mepe.MEPE_EFF_DT),112) 
												 END
												 
				
			FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new   new	
					INNER JOIN  fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe ON mepe.MEME_CK = new.MEME_CK
														AND new.GRGR_CK = mepe.GRGR_CK
														AND mepe.SGSG_CK = new.SGSG_CK
														AND mepe.CSPI_ID= new.DENTAL_CLASS_PLAN_CODE
				WHERE new.VOID_INDICATOR = 'Y'
				AND new.MEME_SFX = '0'
	end 
   
   

    
    
                         
/********** Error Checking for Updating logic for void indicator ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Updating logic for void indicator FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 5 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed   
      
            
/**************  PRINT STEP 5 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for SUBSCRIBER_NUMBER'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
      
/********** STEP 5 Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for SUBSCRIBER_NUMBER **********/      
    UPDATE new       
    SET new.SUBSCRIBER_NUMBER = LEFT(RIGHT(REPLICATE('0',9) + CAST(LTRIM(RTRIM(meme.MEME_SSN)) AS VARCHAR(9)),9) +        
                         RIGHT(REPLICATE('0',2) + CAST(LTRIM(RTRIM(meme.MEME_SFX)) AS VARCHAR(2)),2) + SPACE(15),15)      
    FROM       
        fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new,      
        fabncdv1.dbo.CMC_MEME_MEMBER meme,      
        fabncdv1.dbo.CMC_SBSB_SUBSC sbsb      
    WHERE       
        SUBSTRING(new.EXTERNAL_MEMBER_NUMBER,1,9) = sbsb.SBSB_ID      
    AND meme.SBSB_CK = sbsb.SBSB_CK      
    AND meme.MEME_REL = 'M' 
    
    
                         
/********** Error Checking for update statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for SUBSCRIBER_NUMBER FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 5 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
      
      
      
/**************  PRINT STEP 5A HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for MEMBER_NUMBER'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
      
/********** STEP 5A Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for SUBSCRIBER_NUMBER **********/      
          
      ;with temp1 as      
    (      
         SELECT DISTINCT new.SBSB_CK, new.GRGR_CK, new.MEME_CK, meme.MEME_SSN, meme.MEME_REL, meme.MEME_SFX        
            FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new        
                left join fabncdv1.dbo.CMC_SBSB_SUBSC sbsb on  SUBSTRING(new.EXTERNAL_MEMBER_NUMBER,1,9) = sbsb.SBSB_ID 
				     inner join fabncdv1.dbo.CMC_MEME_MEMBER meme on meme.SBSB_CK = sbsb.SBSB_CK  
        where meme.MEME_REL = 'M'         
    )      
              
    UPDATE new      
        SET new.MEMBER_NUMBER =CONCAT(t.MEME_SSN ,right('00'+ convert(varchar,new.MEME_SFX,2),2 ) )      
    FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new      
        LEFT JOIN temp1 t on t.SBSB_CK = new.SBSB_CK      
      
/********** Error Checking for update statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for MEMBER_NUMBER FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 5A FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
      
      
/**************  PRINT STEP 8 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for COB_INSURANCE_CODE,COB_TYPE,COB_OTHER_INSURANCE_CARRIER_NAME,COB_EFFECTIVE_DATE,COB_TERMINATION_DATE'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
   
/********** STEP 8 Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for COB_INSURANCE_CODE,COB_TYPE,COB_OTHER_INSURANCE_CARRIER_NAME,COB_EFFECTIVE_DATE,COB_TERMINATION_DATE **********/      
      
    UPDATE new      
    SET new.COB_INSURANCE_CODE = LTRIM(RTRIM(mecb.MECB_INSUR_TYPE)),      
        new.COB_TYPE = LTRIM(RTRIM(mecb.MECB_INSUR_ORDER)),      
        new.COB_OTHER_INSURANCE_CARRIER_NAME = LTRIM(RTRIM(mcre.MCRE_NAME)),      
        new.COB_EFFECTIVE_DATE = CONVERT(VARCHAR(8),mecb.MECB_EFF_DT,112),      
        new.COB_TERMINATION_DATE = CONVERT(VARCHAR(8),mecb.MECB_TERM_DT,112)      
    FROM       
        fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new      
        INNER JOIN fabncdv1.dbo.CMC_MECB_COB mecb  on mecb.MEME_CK = new.MEME_CK  
		INNER JOIN fabncdv1.dbo.CMC_MCRE_RELAT_ENT mcre  ON mecb.MCRE_ID = mcre.MCRE_ID 
			WHERE mecb.MCRE_ID  <> ''
             
    
/********** Error Checking for update statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for COB_INSURANCE_CODE,COB_TYPE,COB_OTHER_INSURANCE_CARRIER_NAME,COB_EFFECTIVE_DATE,COB_TERMINATION_DATE FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 8 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
  
  /**************  PRINT STEP 9  HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
    @ldtStepStartTime    = GETDATE(),      
    @lvcMsg              = @lvcObjectName + ': Update MEMBER STATUS    '      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
     @pnStepNumber       = @lnCurrentStep,      
     @pdtStepStartTime   = @ldtStepStartTime,      
     @pnTotalSteps       = @lnTotalSteps,      
     @pchStepMsg         = @lvcMsg     
  
            
/************* STEP 10 Update MEMBER STATUS    in stage table tpzt_ACSDental_meme_extr_new *************/       
 
	--member updated for Handicapped
	
	     UPDATE  new
			SET MEMBER_STATUS = 'H'

			FROM  fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new     
					INNER JOIN fabncdv1.dbo.CMC_MEHD_HANDICAP mehd on mehd.MEME_CK = new.MEME_CK
																	and mehd.GRGR_CK = new.GRGR_CK
			where mehd.MEHD_TYPE = 'P'
			 and GETDATE() between mehd.MEHD_EFF_DT and mehd.MEHD_TERM_DT 
	
	--member updated for Student
		UPDATE  new
			SET MEMBER_STATUS = 'S'

			FROM  fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new     
					INNER JOIN fabncdv1.dbo.CMC_MEST_STUDENT mest on mest.MEME_CK = new.MEME_CK
																  and mest.GRGR_CK = new.GRGR_CK
			where GETDATE() between mest.MEST_EFF_DT and mest.MEST_TERM_DT 
			
			
		--member updated for disable
		UPDATE  new
			SET MEMBER_STATUS = 'D'

			FROM  fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new     
					INNER JOIN fabncdv1.dbo.CMC_MEMD_MECR_DETL memd on memd.MEME_CK = new.MEME_CK
																  and memd.GRGR_CK = new.GRGR_CK
			where MEMD_EVENT_CD = 'DABL'
				and GETDATE() between memd.MEMD_HCFA_EFF_DT and memd.MEMD_HCFA_TERM_DT 		
 
/************* Error Checking  *************/        
           
   SELECT @lnRetCd    = @@ERROR,        
   @lnRowsProcessed = @@ROWCOUNT        
        
   IF @lnRetCd <> 0        
       BEGIN        
           SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)        
           + ' : Updating void indicator  FAILED'        
           + ' RETURNCODE: '        
           + CONVERT(CHAR(6),@lnRetCd)        
           PRINT  @lvcMsg        
           RETURN @lnRetCd        
     END      
/**************  PRINT STEP 10 FOOTER DATA *************************/      
      
SELECT @ldtStepEndTime    = GETDATE()      
     EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
         @pdtStepStartTime       = @ldtStepStartTime,      
         @pdtStepEndTime         = @ldtStepEndTime,      
         @pdtProcessStartTime    = @ldtProcessStartTime,      
         @pnRowCount             = @lnRowsProcessed              
 

 

/**************  PRINT STEP 10  HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
    @ldtStepStartTime    = GETDATE(),      
    @lvcMsg              = @lvcObjectName + ': Update void indicator  '      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
     @pnStepNumber       = @lnCurrentStep,      
     @pdtStepStartTime   = @ldtStepStartTime,      
     @pnTotalSteps       = @lnTotalSteps,      
     @pchStepMsg         = @lvcMsg      
           
/************* STEP 10 Update void indicator in stage table tpzt_ACSDental_meme_extr_new *************/       
     
     UPDATE  new
			SET VOID_INDICATOR = 'Y',
				
				BENEFIT_EXPIRATION_DATE = CASE WHEN  CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) ='21991231'       
													THEN '99991231'  
												 ELSE  
													CONVERT(VARCHAR(8),DATEADD(day,-1,mepe.MEPE_EFF_DT),112) 
												 END 

			FROM  fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new  
				inner join fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe on mepe. MEME_CK = new.MEME_CK 
																and mepe.GRGR_CK = new.GRGR_CK
																and mepe.SGSG_CK = new. SGSG_CK
																and mepe.CSPI_ID = new. DENTAL_CLASS_PLAN_CODE
			WHERE new. MEME_CK IN ( SELECT mepe.MEME_CK 
										FROM fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe  
													WHERE mepe.MEME_CK IN (
												 				SELECT mepe1.MEME_CK   --  , VOID_INDICATOR = 'Y'   
												    				FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new  
															    	       
																			INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe1        ON new.MEME_CK = mepe1.MEME_CK  
																															AND new.DENTAL_CLASS_PLAN_CODE = mepe1.CSPI_ID	
																															AND new.GRGR_CK = mepe1.GRGR_CK
																															AND new.SGSG_CK = mepe1.SGSG_CK
																															
																			AND mepe1.MEPE_EFF_DT = mepe1.MEPE_TERM_DT 
																		   --	WHERE  mepe1.MEME_CK =69951
																			--AND mepe.MEPE_MCTR_RSN = 'ME24'
															)
									AND mepe.MEPE_MCTR_RSN = 'ME24'
								  )

 
  
         
/************* Error Checking  *************/        
           
   SELECT @lnRetCd    = @@ERROR,        
   @lnRowsProcessed = @@ROWCOUNT        
        
   IF @lnRetCd <> 0        
       BEGIN        
           SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)        
           + ' : Updating void indicator  FAILED'        
           + ' RETURNCODE: '        
           + CONVERT(CHAR(6),@lnRetCd)        
           PRINT  @lvcMsg        
           RETURN @lnRetCd        
     END      
/**************  PRINT STEP 10 FOOTER DATA *************************/      
      
SELECT @ldtStepEndTime    = GETDATE()      
     EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
         @pdtStepStartTime       = @ldtStepStartTime,      
         @pdtStepEndTime         = @ldtStepEndTime,      
         @pdtProcessStartTime    = @ldtProcessStartTime,      
         @pnRowCount             = @lnRowsProcessed              
 




               
/**************  PRINT STEP 11  HEADER DATA *************************/        
        
     SELECT  @lnCurrentStep    = @lnCurrentStep + 1,        
             @ldtStepStartTime = GETDATE(),        
             @lvcMsg = @lvcObjectName + ': Update staging table tpzt_ACSDental_meme_extr_new for Transaction Date Column '        
      
     EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr        
             @pnStepNumber     = @lnCurrentStep,        
             @pdtStepStartTime = @ldtStepStartTime,        
             @pnTotalSteps     = @lnTotalSteps,        
             @pchStepMsg       = @lvcMsg       
      
                       
/************* STEP 11 Update staging table tpzt_ACSDental_meme_extr_new for Transaction Date Column ***********/        
                
  
  
select @lvcCount = count (*) from fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_old old 

IF @lvcCount > 0

begin   
  ;with CTE_MEME_EXTR       
      (      
        MEMBER_NUMBER,      
        SUBSCRIBER_NUMBER,      
        MEMBER_FIRST_NAME,      
        MEMBER_MIDDLE_INITIAL,      
        MEMBER_LAST_NAME,      
        MEMBER_BIRTH_DATE,      
        BENEFIT_EFFECTIVE_DATE,      
        BENEFIT_EXPIRATION_DATE,      
        RELATIONSHIP_CODE,      
        SEX_CODE,      
        LINE_OF_BUSINESS,      
        GROUP_NUMBER,      
        ACCOUNT_NUMBER,      
        LANGUAGE_VALUE_1,      
        LANGUAGE_VALUE_2,      
        LANGUAGE_VALUE_3,      
        MEMBER_LANGUAGE,      
        DENTAL_CLASS_PLAN_CODE,      
        PAID_THRU_DATE,      
        ADDRESS_LINE_1,      
        ADDRESS_LINE_2,      
        CITY_CODE,      
        STATE_CODE,      
        ZIP_CODE,      
       -- PROCESS_DATE,      
        SERVICE_EDITS_CODE,      
        CUSTODIAL_PARENT_LAST_NAME,      
        CUSTODIAL_PARENT_FIRST_NAME,      
        CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        CUST_PARENT_TITLE_CODE,      
        CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        CUSTODIAL_PARENT_CITY_CODE,      
        CUSTODIAL_PARENT_STATE_CODE,      
        CUSTODIAL_PARENT_ZIP_CODE,      
        CUSTODIAL_PARENT_PHONE_NUMBER,      
        COB_INSURANCE_CODE,      
        COB_TYPE,      
        COB_OTHER_INSURANCE_CARRIER_NAME,      
        COB_EFFECTIVE_DATE,      
        COB_TERMINATION_DATE,      
        WAITING_PERIOD_EFFECTIVE_DATE,      
        WAITING_PERIOD_EXPIRATION_DATE,      
        FINANCIAL_ARRANGEMENT,      
        ORIGINAL_EFFECTIVE_DATE,      
        GROUP_CONTRACT_EFFECT_DATE,      
        EXTERNAL_MEMBER_NUMBER,      
        EMPLOYEE_STATUS,      
        GROUP_SIZE,      
        --TRANSACTION_DATE,      
        DENTAL_BASIC_EFFECTIVE_DATE,      
        DENTAL_BASIC_EXPIRATION_DATE,      
        DENTAL_MAJOR_EFFECTIVE_DATE,      
        DENTAL_MAJOR_EXPIRATION_DATE,      
        DENTAL_ORTHO_EFFECTIVE_DATE,      
        DENTAL_ORTHO_EXPIRATION_DATE,      
        MEMBER_STATUS,      
        PEDIATRIC_INDICATOR,      
        VOID_INDICATOR      
      )  AS    
    ( SELECT DISTINCT      
        new.MEMBER_NUMBER,      
        new.SUBSCRIBER_NUMBER,      
        new.MEMBER_FIRST_NAME,      
        new.MEMBER_MIDDLE_INITIAL,      
        new.MEMBER_LAST_NAME,      
        new.MEMBER_BIRTH_DATE,      
        new.BENEFIT_EFFECTIVE_DATE,      
        new.BENEFIT_EXPIRATION_DATE,      
        new.RELATIONSHIP_CODE,      
        new.SEX_CODE,      
        new.LINE_OF_BUSINESS,      
        new.GROUP_NUMBER,     
        new.ACCOUNT_NUMBER,      
        new.LANGUAGE_VALUE_1,      
        new.LANGUAGE_VALUE_2,      
        new.LANGUAGE_VALUE_3,      
        new.MEMBER_LANGUAGE,      
        new.DENTAL_CLASS_PLAN_CODE,      
        new.PAID_THRU_DATE,      
        new.ADDRESS_LINE_1,      
        new.ADDRESS_LINE_2,      
        new.CITY_CODE,      
        new.STATE_CODE,      
        new.ZIP_CODE,      
       -- new.PROCESS_DATE,      
        new.SERVICE_EDITS_CODE,      
        new.CUSTODIAL_PARENT_LAST_NAME,      
        new.CUSTODIAL_PARENT_FIRST_NAME,      
        new.CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        new.CUST_PARENT_TITLE_CODE,      
        new.CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        new.CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        new.CUSTODIAL_PARENT_CITY_CODE,      
        new.CUSTODIAL_PARENT_STATE_CODE,      
        new.CUSTODIAL_PARENT_ZIP_CODE,      
        new.CUSTODIAL_PARENT_PHONE_NUMBER,      
        new.COB_INSURANCE_CODE,      
        new.COB_TYPE,      
        new.COB_OTHER_INSURANCE_CARRIER_NAME,      
        new.COB_EFFECTIVE_DATE,      
        new.COB_TERMINATION_DATE,      
        new.WAITING_PERIOD_EFFECTIVE_DATE,      
        new.WAITING_PERIOD_EXPIRATION_DATE,      
        new.FINANCIAL_ARRANGEMENT,      
        new.ORIGINAL_EFFECTIVE_DATE,      
        new.GROUP_CONTRACT_EFFECT_DATE,      
        new.EXTERNAL_MEMBER_NUMBER,      
        new.EMPLOYEE_STATUS,      
        new.GROUP_SIZE,      
        --new.TRANSACTION_DATE,      
        new.DENTAL_BASIC_EFFECTIVE_DATE,      
        new.DENTAL_BASIC_EXPIRATION_DATE,      
        new.DENTAL_MAJOR_EFFECTIVE_DATE,      
        new.DENTAL_MAJOR_EXPIRATION_DATE,      
        new.DENTAL_ORTHO_EFFECTIVE_DATE,      
        new.DENTAL_ORTHO_EXPIRATION_DATE,      
        new.MEMBER_STATUS,      
        new.PEDIATRIC_INDICATOR,      
        new.VOID_INDICATOR      
    FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new      
         
    EXCEPT      
    SELECT      
        old.MEMBER_NUMBER,      
        old.SUBSCRIBER_NUMBER,      
        old.MEMBER_FIRST_NAME,      
        old.MEMBER_MIDDLE_INITIAL,      
        old.MEMBER_LAST_NAME,      
        old.MEMBER_BIRTH_DATE,      
        old.BENEFIT_EFFECTIVE_DATE,      
        old.BENEFIT_EXPIRATION_DATE,      
        old.RELATIONSHIP_CODE,      
        old.SEX_CODE,      
        old.LINE_OF_BUSINESS,      
        old.GROUP_NUMBER,      
        old.ACCOUNT_NUMBER,      
        old.LANGUAGE_VALUE_1,      
        old.LANGUAGE_VALUE_2,      
        old.LANGUAGE_VALUE_3,      
        old.MEMBER_LANGUAGE,      
        old.DENTAL_CLASS_PLAN_CODE,      
        old.PAID_THRU_DATE,      
        old.ADDRESS_LINE_1,      
        old.ADDRESS_LINE_2,      
        old.CITY_CODE,      
        old.STATE_CODE,      
        old.ZIP_CODE,      
        --old.PROCESS_DATE,      
        old.SERVICE_EDITS_CODE,      
        old.CUSTODIAL_PARENT_LAST_NAME,      
        old.CUSTODIAL_PARENT_FIRST_NAME,      
        old.CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        old.CUST_PARENT_TITLE_CODE,      
        old.CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        old.CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        old.CUSTODIAL_PARENT_CITY_CODE,      
        old.CUSTODIAL_PARENT_STATE_CODE,      
        old.CUSTODIAL_PARENT_ZIP_CODE,      
        old.CUSTODIAL_PARENT_PHONE_NUMBER,      
        old.COB_INSURANCE_CODE,      
        old.COB_TYPE,      
        old.COB_OTHER_INSURANCE_CARRIER_NAME,      
        old.COB_EFFECTIVE_DATE,      
        old.COB_TERMINATION_DATE,      
        old.WAITING_PERIOD_EFFECTIVE_DATE,      
        old.WAITING_PERIOD_EXPIRATION_DATE,      
        old.FINANCIAL_ARRANGEMENT,      
        old.ORIGINAL_EFFECTIVE_DATE,      
        old.GROUP_CONTRACT_EFFECT_DATE,      
        old.EXTERNAL_MEMBER_NUMBER,      
        old.EMPLOYEE_STATUS,      
        old.GROUP_SIZE,      
       -- old.TRANSACTION_DATE,      
        old.DENTAL_BASIC_EFFECTIVE_DATE,      
        old.DENTAL_BASIC_EXPIRATION_DATE,      
        old.DENTAL_MAJOR_EFFECTIVE_DATE,      
        old.DENTAL_MAJOR_EXPIRATION_DATE,      
        old.DENTAL_ORTHO_EFFECTIVE_DATE,      
        old.DENTAL_ORTHO_EXPIRATION_DATE,      
        old.MEMBER_STATUS,      
        old.PEDIATRIC_INDICATOR,      
        old.VOID_INDICATOR      
    FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_old old      
   
  )


  UPDATE curr      
     SET curr.TRANSACTION_DATE = CONVERT(VARCHAR(8),GETDATE(),112)       
     FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new curr      
   WHERE curr.MEMBER_NUMBER in (SELECT prev.MEMBER_NUMBER FROM CTE_MEME_EXTR prev WHERE prev.MEMBER_NUMBER = curr.MEMBER_NUMBER)  
  
end
  
  
 --UPDATING DATE FOR THE MEMBER WHICH IS BEING TERMINATED   
  UPDATE curr      
     SET curr.TRANSACTION_DATE = CONVERT(VARCHAR(8),GETDATE(),112)      
     FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new curr      
   inner join fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe on  mepe.MEME_CK = curr.MEME_CK  
               and mepe.GRGR_CK = curr. GRGR_CK  
               and mepe.SGSG_CK = curr.SGSG_CK  
  WHERE mepe.MEPE_TERM_DT < getdate() and  mepe.MEPE_ELIG_IND ='Y'  
  
  
  
  ----------------------------------update the record add ---------------------
  
  select @lvcCount = count (*) from fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_old old 

IF @lvcCount > 0

begin   
  ;with CTE_MEME_EXTR       
      (      
        MEMBER_NUMBER,      
        SUBSCRIBER_NUMBER     
      )  
      AS    
    ( 
		SELECT DISTINCT      
			new.MEMBER_NUMBER,      
			new.SUBSCRIBER_NUMBER    
		FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new      
         
    EXCEPT      
		SELECT      
			curr.MEMBER_NUMBER,      
			curr.SUBSCRIBER_NUMBER     
		FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr curr      
   
  )


  UPDATE curr      
     SET curr.TRANSACTION_DATE = '00000000'      
     FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new curr      
   WHERE curr.MEMBER_NUMBER in (SELECT prev.MEMBER_NUMBER FROM CTE_MEME_EXTR prev WHERE prev.MEMBER_NUMBER = curr.MEMBER_NUMBER)  
  
end
  
  
              
/************* Error Checking for Update staging table tpzt_ACSDental_meme_extr_new for Transaction Date Column *************/        
                
     SELECT @lnRetCd    = @@ERROR,        
     @lnRowsProcessed = @@ROWCOUNT        
           
     IF @lnRetCd <> 0        
         BEGIN        
             SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)        
             + ' : Update staging table tpzt_ACSDental_meme_extr_new for Transaction Date Column FAILED'        
             + ' RETURNCODE: '        
             + CONVERT(CHAR(6),@lnRetCd)        
             PRINT  @lvcMsg        
             RETURN @lnRetCd        
         END             
                
/**************  PRINT STEP 11 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime      = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
        @pdtStepStartTime       = @ldtStepStartTime,      
        @pdtStepEndTime         = @ldtStepEndTime,      
        @pdtProcessStartTime    = @ldtProcessStartTime,      
        @pnRowCount             = @lnRowsProcessed       
      
/**************  PRINT STEP 12  HEADER DATA *************************/        
        
     SELECT  @lnCurrentStep    = @lnCurrentStep + 1,        
             @ldtStepStartTime = GETDATE(),        
             @lvcMsg = @lvcObjectName + ': Update staging table tpzt_ACSDental_meme_extr_new for PAID_THRU_DATE Column '        
      
     EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr        
             @pnStepNumber     = @lnCurrentStep,        
             @pdtStepStartTime = @ldtStepStartTime,        
             @pnTotalSteps     = @lnTotalSteps,        
             @pchStepMsg       = @lvcMsg       
      
                       
/************* STEP 12 Update staging table tpzt_ACSDental_meme_extr_new for PAID_THRU_DATE Column ***********/        
                
     UPDATE  new      
     SET new.PAID_THRU_DATE = CONVERT(VARCHAR(8), blbe.BLBL_END_DT,112)      
     FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new      
       JOIN      
           ( SELECT blei.BLEI_CK,blei.BLEI_BILL_LEVEL_CK, MAX(blbl.BLBL_END_DT) AS BLBL_END_DT       
                    FROM fabncdv1.dbo.CMC_BLBL_BILL_SUMM blbl      
                            inner join fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei on blei.BLEI_CK = blbl.BLEI_CK      
                                  
                 WHERE  blbl.BLBL_PAID_STS in (2,3)      
                 GROUP BY blei.BLEI_CK,blei.BLEI_BILL_LEVEL_CK) as blbe      
                 ON blbe.BLEI_BILL_LEVEL_CK = new.SGSG_CK      
              
/************* Error Checking for Update staging table tpzt_ACSDental_meme_extr_new for PAID_THRU_DATE Column *************/        
                
     SELECT @lnRetCd    = @@ERROR,        
     @lnRowsProcessed = @@ROWCOUNT        
           
     IF @lnRetCd <> 0        
         BEGIN        
             SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)        
             + ' : Update staging table tpzt_ACSDental_meme_extr_new for PAID_THRU_DATE Column FAILED'        
             + ' RETURNCODE: '        
             + CONVERT(CHAR(6),@lnRetCd)        
             PRINT  @lvcMsg        
             RETURN @lnRetCd        
         END             
                
/**************  PRINT STEP 12 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime      = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
        @pdtStepStartTime       = @ldtStepStartTime,      
        @pdtStepEndTime         = @ldtStepEndTime,      
        @pdtProcessStartTime    = @ldtProcessStartTime,      
        @pnRowCount             = @lnRowsProcessed       
      
/**************  PRINT STEP 13  HEADER DATA *************************/        
        
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,        
            @ldtStepStartTime = GETDATE(),        
            @lvcMsg = @lvcObjectName + ': Truncate staging table tpzt_ACSDental_meme_error'        
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr        
        @pnStepNumber     = @lnCurrentStep,        
        @pdtStepStartTime = @ldtStepStartTime,        
        @pnTotalSteps     = @lnTotalSteps,        
        @pchStepMsg       = @lvcMsg       
               
/************* STEP 13 Truncate Staging table tpzt_ACSDental_meme_error *************/        
                
   TRUNCATE TABLE fabncdv1stage.dbo.tpzt_ACSDental_meme_error        
                
/************* Error Checking for Truncate Staging table tpzt_ACSDental_meme_error *************/        
                
        SELECT @lnRetCd    = @@ERROR,        
        @lnRowsProcessed = @@ROWCOUNT        
      
        IF @lnRetCd <> 0        
            BEGIN        
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)        
                + ' : Truncate Staging table tpzt_ACSDental_meme_error FAILED'        
                + ' RETURNCODE: '        
                + CONVERT(CHAR(6),@lnRetCd)        
                PRINT  @lvcMsg        
                RETURN @lnRetCd        
            END             
                
/**************  PRINT STEP 13 FOOTER DATA *************************/      
      
        SELECT @ldtStepEndTime      = GETDATE()      
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
            @pdtStepStartTime       = @ldtStepStartTime,      
            @pdtStepEndTime         = @ldtStepEndTime,      
            @pdtProcessStartTime    = @ldtProcessStartTime,      
            @pnRowCount             = @lnRowsProcessed         
         
/**************  PRINT STEP 14  HEADER DATA *************************/        
        
        SELECT  @lnCurrentStep    = @lnCurrentStep + 1,        
                @ldtStepStartTime = GETDATE(),        
                @lvcMsg = @lvcObjectName + ': Insert error records in staging table tpzt_ACSDental_meme_error'        
      
        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr        
                @pnStepNumber     = @lnCurrentStep,        
                @pdtStepStartTime = @ldtStepStartTime,        
                @pnTotalSteps     = @lnTotalSteps,        
                @pchStepMsg       = @lvcMsg       
      
                       
/************* STEP 14 Insert error records in staging table tpzt_ACSDental_meme_error *************/        
                
    INSERT INTO fabncdv1stage.dbo.tpzt_ACSDental_meme_error      
        (      
            MEMBER_NUMBER,                         
            SUBSCRIBER_NUMBER,                     
            MEMBER_FIRST_NAME,                     
            MEMBER_MIDDLE_INITIAL,                 
            MEMBER_LAST_NAME,                      
            MEMBER_BIRTH_DATE,                     
            BENEFIT_EFFECTIVE_DATE,                
            BENEFIT_EXPIRATION_DATE,               
            RELATIONSHIP_CODE,                     
            SEX_CODE,                              
			LINE_OF_BUSINESS,                      
            GROUP_NUMBER,                          
            ACCOUNT_NUMBER,                        
            LANGUAGE_VALUE_1,                      
            LANGUAGE_VALUE_2,                      
            LANGUAGE_VALUE_3,                      
            MEMBER_LANGUAGE ,                      
            DENTAL_CLASS_PLAN_CODE,                
            PAID_THRU_DATE,                       
            ADDRESS_LINE_1,                       
            ADDRESS_LINE_2,                       
            CITY_CODE ,                            
            STATE_CODE ,                           
            ZIP_CODE ,                             
            PROCESS_DATE,                          
            SERVICE_EDITS_CODE,                    
            CUSTODIAL_PARENT_LAST_NAME,            
            CUSTODIAL_PARENT_FIRST_NAME,           
            CUSTODIAL_PARENT_MIDDLE_INITIAL,       
            CUST_PARENT_TITLE_CODE,                
            CUSTODIAL_PARENT_ADDRESS_LINE_1,       
            CUSTODIAL_PARENT_ADDRESS_LINE_2,       
            CUSTODIAL_PARENT_CITY_CODE,            
            CUSTODIAL_PARENT_STATE_CODE,           
            CUSTODIAL_PARENT_ZIP_CODE ,            
            CUSTODIAL_PARENT_PHONE_NUMBER ,        
            COB_INSURANCE_CODE,                    
            COB_TYPE,                              
            COB_OTHER_INSURANCE_CARRIER_NAME,      
            COB_EFFECTIVE_DATE,                   
            COB_TERMINATION_DATE,                  
            WAITING_PERIOD_EFFECTIVE_DATE,         
            WAITING_PERIOD_EXPIRATION_DATE,        
            FINANCIAL_ARRANGEMENT,                 
            ORIGINAL_EFFECTIVE_DATE,               
            GROUP_CONTRACT_EFFECT_DATE,            
            EXTERNAL_MEMBER_NUMBER,                
            EMPLOYEE_STATUS,                       
            GROUP_SIZE,                            
            TRANSACTION_DATE,                      
            DENTAL_BASIC_EFFECTIVE_DATE ,          
            DENTAL_BASIC_EXPIRATION_DATE,          
            DENTAL_MAJOR_EFFECTIVE_DATE ,          
            DENTAL_MAJOR_EXPIRATION_DATE,          
            DENTAL_ORTHO_EFFECTIVE_DATE ,          
            DENTAL_ORTHO_EXPIRATION_DATE,          
            MEMBER_STATUS,                         
            PEDIATRIC_INDICATOR,                   
            VOID_INDICATOR      
        )      
    SELECT DISTINCT       
            MEMBER_NUMBER                    = new.MEMBER_NUMBER,                         
            SUBSCRIBER_NUMBER                = new.SUBSCRIBER_NUMBER,                     
            MEMBER_FIRST_NAME                = new.MEMBER_FIRST_NAME,                     
            MEMBER_MIDDLE_INITIAL            = new.MEMBER_MIDDLE_INITIAL,                 
            MEMBER_LAST_NAME                 = new.MEMBER_LAST_NAME,                      
            MEMBER_BIRTH_DATE                = new.MEMBER_BIRTH_DATE,                     
            BENEFIT_EFFECTIVE_DATE           = new.BENEFIT_EFFECTIVE_DATE,                
            BENEFIT_EXPIRATION_DATE          = new.BENEFIT_EXPIRATION_DATE,               
            RELATIONSHIP_CODE                = new.RELATIONSHIP_CODE,                     
            SEX_CODE                         = new.SEX_CODE     ,                         
            LINE_OF_BUSINESS                 = new.LINE_OF_BUSINESS ,                     
            GROUP_NUMBER                     = new.GROUP_NUMBER  ,                        
            ACCOUNT_NUMBER                   = new.ACCOUNT_NUMBER ,                       
            LANGUAGE_VALUE_1                 = new.LANGUAGE_VALUE_1,                     
            LANGUAGE_VALUE_2                 = new.LANGUAGE_VALUE_2,                     
            LANGUAGE_VALUE_3                 = new.LANGUAGE_VALUE_3,                     
            MEMBER_LANGUAGE                  = new.MEMBER_LANGUAGE ,                     
            DENTAL_CLASS_PLAN_CODE           = new.DENTAL_CLASS_PLAN_CODE ,               
            PAID_THRU_DATE                   = new.PAID_THRU_DATE,                      
            ADDRESS_LINE_1                   = new.ADDRESS_LINE_1,                      
            ADDRESS_LINE_2                   = new.ADDRESS_LINE_2,                  
            CITY_CODE                        = new.CITY_CODE ,                            
            STATE_CODE                       = new.STATE_CODE ,                           
            ZIP_CODE                         = new.ZIP_CODE ,                             
            PROCESS_DATE                     = new.PROCESS_DATE,                          
            SERVICE_EDITS_CODE               = new.SERVICE_EDITS_CODE ,                   
            CUSTODIAL_PARENT_LAST_NAME       = new.CUSTODIAL_PARENT_LAST_NAME,            
            CUSTODIAL_PARENT_FIRST_NAME      = new.CUSTODIAL_PARENT_FIRST_NAME,           
            CUSTODIAL_PARENT_MIDDLE_INITIAL  = new.CUSTODIAL_PARENT_MIDDLE_INITIAL,       
            CUST_PARENT_TITLE_CODE           = new.CUST_PARENT_TITLE_CODE,                
            CUSTODIAL_PARENT_ADDRESS_LINE_1  = new.CUSTODIAL_PARENT_ADDRESS_LINE_1,       
            CUSTODIAL_PARENT_ADDRESS_LINE_2  = new.CUSTODIAL_PARENT_ADDRESS_LINE_2,       
            CUSTODIAL_PARENT_CITY_CODE       = new.CUSTODIAL_PARENT_CITY_CODE,            
            CUSTODIAL_PARENT_STATE_CODE      = new.CUSTODIAL_PARENT_STATE_CODE ,          
            CUSTODIAL_PARENT_ZIP_CODE        = new.CUSTODIAL_PARENT_ZIP_CODE,             
            CUSTODIAL_PARENT_PHONE_NUMBER    = new.CUSTODIAL_PARENT_PHONE_NUMBER,         
            COB_INSURANCE_CODE               = new.COB_INSURANCE_CODE,                    
            COB_TYPE                         = new.COB_TYPE,                              
            COB_OTHER_INSURANCE_CARRIER_NAME = new.COB_OTHER_INSURANCE_CARRIER_NAME,      
            COB_EFFECTIVE_DATE               = new.COB_EFFECTIVE_DATE ,                   
            COB_TERMINATION_DATE             = new.COB_TERMINATION_DATE,                  
            WAITING_PERIOD_EFFECTIVE_DATE    = new.WAITING_PERIOD_EFFECTIVE_DATE ,        
            WAITING_PERIOD_EXPIRATION_DATE   = new.WAITING_PERIOD_EXPIRATION_DATE ,       
            FINANCIAL_ARRANGEMENT            = new.FINANCIAL_ARRANGEMENT ,                
            ORIGINAL_EFFECTIVE_DATE          = new.ORIGINAL_EFFECTIVE_DATE ,              
            GROUP_CONTRACT_EFFECT_DATE       = new.GROUP_CONTRACT_EFFECT_DATE ,           
            EXTERNAL_MEMBER_NUMBER           = new.EXTERNAL_MEMBER_NUMBER,                
            EMPLOYEE_STATUS                  = new.EMPLOYEE_STATUS,                       
            GROUP_SIZE                       = new.GROUP_SIZE,                            
            TRANSACTION_DATE                 = new.TRANSACTION_DATE ,                     
            DENTAL_BASIC_EFFECTIVE_DATE      = new.DENTAL_BASIC_EFFECTIVE_DATE ,          
            DENTAL_BASIC_EXPIRATION_DATE     = new.DENTAL_BASIC_EXPIRATION_DATE,          
            DENTAL_MAJOR_EFFECTIVE_DATE      = new.DENTAL_MAJOR_EFFECTIVE_DATE ,          
            DENTAL_MAJOR_EXPIRATION_DATE     = new.DENTAL_MAJOR_EXPIRATION_DATE,          
            DENTAL_ORTHO_EFFECTIVE_DATE      = new.DENTAL_ORTHO_EFFECTIVE_DATE ,          
            DENTAL_ORTHO_EXPIRATION_DATE     = new.DENTAL_ORTHO_EXPIRATION_DATE,          
            MEMBER_STATUS                    = new.MEMBER_STATUS ,                        
            PEDIATRIC_INDICATOR              = new.PEDIATRIC_INDICATOR,                   
            VOID_INDICATOR                   = new.VOID_INDICATOR      
                  
        FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new      
        WHERE LTRIM(RTRIM(ISNULL(new.MEMBER_NUMBER,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.SUBSCRIBER_NUMBER,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.MEMBER_FIRST_NAME,'')))=''      
            --OR LTRIM(RTRIM(new.MEMBER_FIRST_NAME)) LIKE '%[^0-9a-zA-Z ]%'      
            OR LTRIM(RTRIM(ISNULL(new.MEMBER_LAST_NAME,'')))=''      
            --OR LTRIM(RTRIM(new.MEMBER_LAST_NAME)) LIKE '%[^0-9a-zA-Z ]%'      
            OR LTRIM(RTRIM(ISNULL(new.MEMBER_BIRTH_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.BENEFIT_EFFECTIVE_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.BENEFIT_EXPIRATION_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.RELATIONSHIP_CODE,'')))=''      
            OR LTRIM(RTRIM(new.RELATIONSHIP_CODE))NOT IN ('1','2','3','4')      
            OR LTRIM(RTRIM(ISNULL(new.SEX_CODE,'')))=''       
            OR LTRIM(RTRIM(new.SEX_CODE)) NOT IN ('F','M','U')      
            OR LTRIM(RTRIM(ISNULL(new.LINE_OF_BUSINESS,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.GROUP_NUMBER,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.ACCOUNT_NUMBER,'')))=''      
                
            OR LTRIM(RTRIM(ISNULL(new.DENTAL_CLASS_PLAN_CODE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.PAID_THRU_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.ADDRESS_LINE_1,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.CITY_CODE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.STATE_CODE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.ZIP_CODE,'')))=''      
                
            OR LTRIM(RTRIM(ISNULL(new.WAITING_PERIOD_EFFECTIVE_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.WAITING_PERIOD_EXPIRATION_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.ORIGINAL_EFFECTIVE_DATE,''))) IN ('99991231','')
            OR LTRIM(RTRIM(ISNULL(new.GROUP_CONTRACT_EFFECT_DATE,''))) IN ('99991231','')    
            OR LTRIM(RTRIM(ISNULL(new.EXTERNAL_MEMBER_NUMBER,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.EMPLOYEE_STATUS,''))) NOT IN ('C','E','R','I','U', '')  
            OR LTRIM(RTRIM(ISNULL(new.GROUP_SIZE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.TRANSACTION_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.DENTAL_BASIC_EFFECTIVE_DATE,'')))=''       
            OR LTRIM(RTRIM(ISNULL(new.DENTAL_BASIC_EXPIRATION_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.DENTAL_MAJOR_EFFECTIVE_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.DENTAL_MAJOR_EXPIRATION_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.DENTAL_ORTHO_EFFECTIVE_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.DENTAL_ORTHO_EXPIRATION_DATE,'')))=''      
            OR LTRIM(RTRIM(new.MEMBER_STATUS)) NOT IN ('D','H','S','')      
            OR LTRIM(RTRIM(new.PEDIATRIC_INDICATOR)) NOT IN ('Y','N')      
            OR LTRIM(RTRIM(ISNULL(new.PEDIATRIC_INDICATOR,'')))=''      
            OR LTRIM(RTRIM(new.VOID_INDICATOR)) NOT IN ('Y','N')      
            OR LTRIM(RTRIM(ISNULL(new.VOID_INDICATOR,'')))=''      
        
                     
/************* Error Checking for Inserting in Staging table tpzt_ACSDental_meme_error  *************/        
                
        SELECT @lnRetCd    = @@ERROR,        
        @lnRowsProcessed = @@ROWCOUNT        
      
        IF @lnRetCd <> 0        
            BEGIN        
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)        
                + ' : Inserting error records in staging table tpzt_ACSDental_meme_error FAILED'        
                + ' RETURNCODE: '        
                + CONVERT(CHAR(6),@lnRetCd)        
                PRINT  @lvcMsg        
                RETURN @lnRetCd        
            END             
                
/**************  PRINT STEP 14 FOOTER DATA *************************/      
      
        SELECT @ldtStepEndTime      = GETDATE()      
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
            @pdtStepStartTime       = @ldtStepStartTime,      
            @pdtStepEndTime         = @ldtStepEndTime,      
            @pdtProcessStartTime    = @ldtProcessStartTime,      
            @pnRowCount             = @lnRowsProcessed         

/**************  PRINT STEP 14A HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Truncating the member whose subscriber is not in extracted'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
      
/********** STEP 14A Truncating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr **********/      
      
    DELETE  FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new  
		WHERE substring(EXTERNAL_MEMBER_NUMBER,1,9)   NOT IN  (SELECT DISTINCT substring(new1.EXTERNAL_MEMBER_NUMBER,1,9) 
																			 FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new1
																			 WHERE new1.MEME_SFX = 0 
																   )
		 
                     
/********** Error Checking for truncate statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Truncating the member whose subscriber is not in extracted FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 14A FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
      
      
             
           
/**************  PRINT STEP 15 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Truncating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
      
/********** STEP 15 Truncating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr **********/      
      
   TRUNCATE TABLE fabncdv1stage.dbo.tpzt_ACSDental_meme_extr      
                     
/********** Error Checking for truncate statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Truncating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 15 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
      
      
      
      
            
/**************  PRINT STEP 16 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Inserting updated records in stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
      
/********** STEP 16 Inserting updated records in stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr **********/      
      
    INSERT INTO fabncdv1stage.dbo.tpzt_ACSDental_meme_extr       
      (      
        MEMBER_NUMBER,      
        SUBSCRIBER_NUMBER,      
        MEMBER_FIRST_NAME,      
        MEMBER_MIDDLE_INITIAL,      
        MEMBER_LAST_NAME,      
        MEMBER_BIRTH_DATE,      
        BENEFIT_EFFECTIVE_DATE,      
        BENEFIT_EXPIRATION_DATE,      
        RELATIONSHIP_CODE,      
        SEX_CODE,      
        LINE_OF_BUSINESS,      
        GROUP_NUMBER,      
        ACCOUNT_NUMBER,      
        LANGUAGE_VALUE_1,      
        LANGUAGE_VALUE_2,      
        LANGUAGE_VALUE_3,      
        MEMBER_LANGUAGE,      
        DENTAL_CLASS_PLAN_CODE,      
        PAID_THRU_DATE,      
        ADDRESS_LINE_1,      
        ADDRESS_LINE_2,      
        CITY_CODE,      
        STATE_CODE,      
        ZIP_CODE,      
        --PROCESS_DATE,      
        SERVICE_EDITS_CODE,      
        CUSTODIAL_PARENT_LAST_NAME,      
        CUSTODIAL_PARENT_FIRST_NAME,      
        CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        CUST_PARENT_TITLE_CODE,      
        CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        CUSTODIAL_PARENT_CITY_CODE,      
        CUSTODIAL_PARENT_STATE_CODE,      
        CUSTODIAL_PARENT_ZIP_CODE,      
        CUSTODIAL_PARENT_PHONE_NUMBER,      
        COB_INSURANCE_CODE,      
        COB_TYPE,      
        COB_OTHER_INSURANCE_CARRIER_NAME,      
        COB_EFFECTIVE_DATE,      
        COB_TERMINATION_DATE,      
        WAITING_PERIOD_EFFECTIVE_DATE,      
        WAITING_PERIOD_EXPIRATION_DATE,      
        FINANCIAL_ARRANGEMENT,      
        ORIGINAL_EFFECTIVE_DATE,      
        GROUP_CONTRACT_EFFECT_DATE,      
        EXTERNAL_MEMBER_NUMBER,      
        EMPLOYEE_STATUS,      
        GROUP_SIZE,      
        --TRANSACTION_DATE,      
        DENTAL_BASIC_EFFECTIVE_DATE,      
        DENTAL_BASIC_EXPIRATION_DATE,      
        DENTAL_MAJOR_EFFECTIVE_DATE,      
        DENTAL_MAJOR_EXPIRATION_DATE,      
        DENTAL_ORTHO_EFFECTIVE_DATE,      
        DENTAL_ORTHO_EXPIRATION_DATE,      
        MEMBER_STATUS,      
        PEDIATRIC_INDICATOR,      
        VOID_INDICATOR      
      )      
    SELECT DISTINCT      
        new.MEMBER_NUMBER,      
        new.SUBSCRIBER_NUMBER,      
        new.MEMBER_FIRST_NAME,      
        new.MEMBER_MIDDLE_INITIAL,      
        new.MEMBER_LAST_NAME,      
        new.MEMBER_BIRTH_DATE,      
        new.BENEFIT_EFFECTIVE_DATE,      
        new.BENEFIT_EXPIRATION_DATE,      
        new.RELATIONSHIP_CODE,      
        new.SEX_CODE,      
        new.LINE_OF_BUSINESS,      
        new.GROUP_NUMBER,     
        new.ACCOUNT_NUMBER,      
        new.LANGUAGE_VALUE_1,      
        new.LANGUAGE_VALUE_2,      
        new.LANGUAGE_VALUE_3,      
        new.MEMBER_LANGUAGE,      
        new.DENTAL_CLASS_PLAN_CODE,      
        new.PAID_THRU_DATE,      
        new.ADDRESS_LINE_1,      
        new.ADDRESS_LINE_2,      
        new.CITY_CODE,      
        new.STATE_CODE,      
        new.ZIP_CODE,      
       -- new.PROCESS_DATE,      
        new.SERVICE_EDITS_CODE,      
        new.CUSTODIAL_PARENT_LAST_NAME,      
        new.CUSTODIAL_PARENT_FIRST_NAME,      
        new.CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        new.CUST_PARENT_TITLE_CODE,      
        new.CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        new.CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        new.CUSTODIAL_PARENT_CITY_CODE,      
        new.CUSTODIAL_PARENT_STATE_CODE,      
        new.CUSTODIAL_PARENT_ZIP_CODE,      
        new.CUSTODIAL_PARENT_PHONE_NUMBER,      
        new.COB_INSURANCE_CODE,      
        new.COB_TYPE,      
        new.COB_OTHER_INSURANCE_CARRIER_NAME,      
        new.COB_EFFECTIVE_DATE,      
        new.COB_TERMINATION_DATE,      
        new.WAITING_PERIOD_EFFECTIVE_DATE,      
        new.WAITING_PERIOD_EXPIRATION_DATE,      
        new.FINANCIAL_ARRANGEMENT,      
        new.ORIGINAL_EFFECTIVE_DATE,      
        new.GROUP_CONTRACT_EFFECT_DATE,      
        new.EXTERNAL_MEMBER_NUMBER,      
        new.EMPLOYEE_STATUS,      
        new.GROUP_SIZE,      
        --new.TRANSACTION_DATE,      
        new.DENTAL_BASIC_EFFECTIVE_DATE,      
        new.DENTAL_BASIC_EXPIRATION_DATE,      
        new.DENTAL_MAJOR_EFFECTIVE_DATE,      
        new.DENTAL_MAJOR_EXPIRATION_DATE,      
        new.DENTAL_ORTHO_EFFECTIVE_DATE,      
        new.DENTAL_ORTHO_EXPIRATION_DATE,      
        new.MEMBER_STATUS,      
        new.PEDIATRIC_INDICATOR,      
        new.VOID_INDICATOR      
    FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new      
    WHERE LTRIM(RTRIM(ISNULL(new.MEMBER_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.SUBSCRIBER_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.MEMBER_FIRST_NAME,'')))<>''      
            --AND LTRIM(RTRIM(new.MEMBER_FIRST_NAME)) NOT LIKE '%[^0-9a-zA-Z ]%'      
              
            AND LTRIM(RTRIM(ISNULL(new.MEMBER_LAST_NAME,'')))<>''      
            --AND LTRIM(RTRIM(new.MEMBER_LAST_NAME)) NOT LIKE '%[^0-9a-zA-Z ]%'      
            AND LTRIM(RTRIM(ISNULL(new.MEMBER_BIRTH_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.BENEFIT_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.BENEFIT_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.RELATIONSHIP_CODE,'')))<>''      
            AND LTRIM(RTRIM(new.RELATIONSHIP_CODE)) IN ('1','2','3','4')   
            AND LTRIM(RTRIM(ISNULL(new.SEX_CODE,'')))<>''       
            AND LTRIM(RTRIM(new.SEX_CODE)) IN ('F','M','U')      
            AND LTRIM(RTRIM(ISNULL(new.LINE_OF_BUSINESS,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.GROUP_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.ACCOUNT_NUMBER,'')))<>''      
             
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_CLASS_PLAN_CODE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.PAID_THRU_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.ADDRESS_LINE_1,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.CITY_CODE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.STATE_CODE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.ZIP_CODE,'')))<>''      
                 
            AND LTRIM(RTRIM(ISNULL(new.WAITING_PERIOD_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.WAITING_PERIOD_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.ORIGINAL_EFFECTIVE_DATE,'')))NOT IN ('99991231','')   
            AND LTRIM(RTRIM(ISNULL(new.GROUP_CONTRACT_EFFECT_DATE,'')))NOT IN ('99991231','')
            AND LTRIM(RTRIM(ISNULL(new.EXTERNAL_MEMBER_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.EMPLOYEE_STATUS,''))) IN ('C','E','R','I','U','')      
			AND LTRIM(RTRIM(ISNULL(new.GROUP_SIZE,'')))<>''      
           
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_BASIC_EFFECTIVE_DATE,'')))<>''       
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_BASIC_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_MAJOR_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_MAJOR_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_ORTHO_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_ORTHO_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(new.MEMBER_STATUS)) IN ('D','H','S','')      
              
            AND LTRIM(RTRIM(new.PEDIATRIC_INDICATOR)) IN ('Y','N')      
            AND LTRIM(RTRIM(ISNULL(new.PEDIATRIC_INDICATOR,'')))<>''      
            AND LTRIM(RTRIM(new.VOID_INDICATOR)) IN ('Y','N')      
            AND LTRIM(RTRIM(ISNULL(new.VOID_INDICATOR,'')))<>''      
    EXCEPT      
    SELECT      
        old.MEMBER_NUMBER,      
        old.SUBSCRIBER_NUMBER,      
        old.MEMBER_FIRST_NAME,      
        old.MEMBER_MIDDLE_INITIAL,      
        old.MEMBER_LAST_NAME,      
        old.MEMBER_BIRTH_DATE,      
        old.BENEFIT_EFFECTIVE_DATE,      
        old.BENEFIT_EXPIRATION_DATE,      
        old.RELATIONSHIP_CODE,      
        old.SEX_CODE,      
        old.LINE_OF_BUSINESS,      
        old.GROUP_NUMBER,      
        old.ACCOUNT_NUMBER,      
        old.LANGUAGE_VALUE_1,      
        old.LANGUAGE_VALUE_2,      
        old.LANGUAGE_VALUE_3,      
        old.MEMBER_LANGUAGE,      
        old.DENTAL_CLASS_PLAN_CODE,      
        old.PAID_THRU_DATE,      
        old.ADDRESS_LINE_1,      
        old.ADDRESS_LINE_2,      
        old.CITY_CODE,      
        old.STATE_CODE,      
        old.ZIP_CODE,      
        --old.PROCESS_DATE,      
        old.SERVICE_EDITS_CODE,      
        old.CUSTODIAL_PARENT_LAST_NAME,      
        old.CUSTODIAL_PARENT_FIRST_NAME,      
        old.CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        old.CUST_PARENT_TITLE_CODE,      
        old.CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        old.CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        old.CUSTODIAL_PARENT_CITY_CODE,      
        old.CUSTODIAL_PARENT_STATE_CODE,      
        old.CUSTODIAL_PARENT_ZIP_CODE,      
        old.CUSTODIAL_PARENT_PHONE_NUMBER,      
        old.COB_INSURANCE_CODE,      
        old.COB_TYPE,      
        old.COB_OTHER_INSURANCE_CARRIER_NAME,      
        old.COB_EFFECTIVE_DATE,      
        old.COB_TERMINATION_DATE,      
        old.WAITING_PERIOD_EFFECTIVE_DATE,      
        old.WAITING_PERIOD_EXPIRATION_DATE,      
        old.FINANCIAL_ARRANGEMENT,      
        old.ORIGINAL_EFFECTIVE_DATE,      
        old.GROUP_CONTRACT_EFFECT_DATE,      
        old.EXTERNAL_MEMBER_NUMBER,      
        old.EMPLOYEE_STATUS,      
        old.GROUP_SIZE,      
        --old.TRANSACTION_DATE,      
        old.DENTAL_BASIC_EFFECTIVE_DATE,      
        old.DENTAL_BASIC_EXPIRATION_DATE,      
        old.DENTAL_MAJOR_EFFECTIVE_DATE,      
        old.DENTAL_MAJOR_EXPIRATION_DATE,      
        old.DENTAL_ORTHO_EFFECTIVE_DATE,      
        old.DENTAL_ORTHO_EXPIRATION_DATE,      
        old.MEMBER_STATUS,      
        old.PEDIATRIC_INDICATOR,      
        old.VOID_INDICATOR      
    FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_old old      
    WHERE LTRIM(RTRIM(ISNULL(old.MEMBER_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.SUBSCRIBER_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.MEMBER_FIRST_NAME,'')))<>''      
            --AND LTRIM(RTRIM(old.MEMBER_FIRST_NAME)) NOT LIKE '%[^0-9a-zA-Z ]%'      
              
            AND LTRIM(RTRIM(ISNULL(old.MEMBER_LAST_NAME,'')))<>''      
            --AND LTRIM(RTRIM(old.MEMBER_LAST_NAME)) NOT LIKE '%[^0-9a-zA-Z ]%'      
            AND LTRIM(RTRIM(ISNULL(old.MEMBER_BIRTH_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.BENEFIT_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.BENEFIT_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.RELATIONSHIP_CODE,'')))<>''   
            AND LTRIM(RTRIM(old.RELATIONSHIP_CODE)) IN ('1','2','3','4')               
            AND LTRIM(RTRIM(ISNULL(old.SEX_CODE,'')))<>''       
            AND LTRIM(RTRIM(old.SEX_CODE)) IN ('F','M','U')      
            AND LTRIM(RTRIM(ISNULL(old.LINE_OF_BUSINESS,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.GROUP_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.ACCOUNT_NUMBER,'')))<>''      
           
            AND LTRIM(RTRIM(ISNULL(old.DENTAL_CLASS_PLAN_CODE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.PAID_THRU_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.ADDRESS_LINE_1,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.CITY_CODE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.STATE_CODE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.ZIP_CODE,'')))<>''      
                  
            AND LTRIM(RTRIM(ISNULL(old.WAITING_PERIOD_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.WAITING_PERIOD_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.ORIGINAL_EFFECTIVE_DATE,'')))NOT IN ('99991231','')
            --AND LTRIM(RTRIM(ISNULL(old.GROUP_CONTRACT_EFFECT_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.GROUP_CONTRACT_EFFECT_DATE,'')))NOT IN ('99991231','')
            AND LTRIM(RTRIM(ISNULL(old.EXTERNAL_MEMBER_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.EMPLOYEE_STATUS,''))) IN ('C','E','R','I','U','')      
              
            AND LTRIM(RTRIM(ISNULL(old.GROUP_SIZE,'')))<>''      
           
            AND LTRIM(RTRIM(ISNULL(old.DENTAL_BASIC_EFFECTIVE_DATE,'')))<>''       
            AND LTRIM(RTRIM(ISNULL(old.DENTAL_BASIC_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.DENTAL_MAJOR_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.DENTAL_MAJOR_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.DENTAL_ORTHO_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.DENTAL_ORTHO_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(old.MEMBER_STATUS)) IN ('D','H','S','')      
            AND LTRIM(RTRIM(old.PEDIATRIC_INDICATOR)) IN ('Y','N')      
            AND LTRIM(RTRIM(ISNULL(old.PEDIATRIC_INDICATOR,'')))<>''      
            AND LTRIM(RTRIM(old.VOID_INDICATOR)) IN ('Y','N')      
            AND LTRIM(RTRIM(ISNULL(old.VOID_INDICATOR,'')))<>''      
    
/********** Error Checking for insert statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Inserting updated records in stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 16 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
      

/**************  PRINT STEP 18 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Skipping Dependents remove if Susbcriber not present'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg     
	  
	/**************  Delete member record if the Subscriber is not sent *************************/     
	--DELETE memb
	--FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr  memb
	--WHERE 
	--	NOT EXISTS (SELECT 
	--					1 
	--				FROM 
	--					fabncdv1stage.dbo.tpzt_ACSDental_meme_extr subs
	--				WHERE 
	--					memb.SUBSCRIBER_NUMBER  = subs.MEMBER_NUMBER
	--				)
					
/********** Error Checking for insert statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : deleting member record if the Subscriber is not sent'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 18 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,  
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed 
	
	
	
	/**************  PRINT STEP 17 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep  = @lnCurrentStep + 1,            
      @ldtStepStartTime   = GETDATE(),      
      @lvcMsg             = @lvcObjectName + ': Truncation date'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber        = @lnCurrentStep,      
      @pdtStepStartTime    = @ldtStepStartTime,      
      @pnTotalSteps        = @lnTotalSteps,      
      @pchStepMsg          = @lvcMsg      
      
/********** STEP 17 Trunsaction date in table tpzt_ACSDental_meme_extr_new **********/      
    
     update extr
		set extr.PROCESS_DATE = CONVERT(VARCHAR(8),GETDATE(),112)
	from fabncdv1stage.dbo.tpzt_ACSDental_meme_extr extr
     
     
    update extr
		set extr.TRANSACTION_DATE = new.TRANSACTION_DATE
	from fabncdv1stage.dbo.tpzt_ACSDental_meme_extr extr
			inner join  fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new on new.MEMBER_NUMBER = extr.MEMBER_NUMBER
      
/**********        Error checking for trunsaction date    ***********/      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      
    IF @lnRetCd <> 0      
    BEGIN      
       SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
         + ' : Trunsaction Date'      
         + ' RETURNCODE: '      
         + CONVERT(CHAR(6),@lnRetCd)      
       PRINT        @lvcMsg      
       RETURN        @lnRetCd      
    END      
      
/**************  PRINT STEP 17 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed       
      


      
END      
      
ELSE IF(UPPER(@pRunFreq) = 'MONTHLY')      
BEGIN      
      
/**************  PRINT STEP 1 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep  = @lnCurrentStep + 1,            
      @ldtStepStartTime   = GETDATE(),      
      @lvcMsg             = @lvcObjectName + ': Truncating stage table tpzt_ACSDental_meme_extr_new'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber        = @lnCurrentStep,      
      @pdtStepStartTime    = @ldtStepStartTime,      
      @pnTotalSteps        = @lnTotalSteps,      
      @pchStepMsg          = @lvcMsg      
      
/********** STEP 1 Truncate staging table tpzt_ACSDental_meme_extr_new **********/      
      
    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new      
      
/**********        Error checking for truncate statement     ***********/      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      
    IF @lnRetCd <> 0      
    BEGIN      
       SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
         + ' : Truncating stage table tpzt_ACSDental_meme_extr_new FAILED'      
         + ' RETURNCODE: '      
         + CONVERT(CHAR(6),@lnRetCd)      
       PRINT        @lvcMsg      
       RETURN        @lnRetCd      
    END      
      
/**************  PRINT STEP 1 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
      
      
/**************  PRINT STEP 2 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
  /********** STEP 2 Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new **********/      
      



 --Instering at Subscriber whose for Void Event is set to Y
 
  INSERT INTO fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new        
      (      
        MEME_CK,      
        GRGR_CK,      
        SGSG_CK,      
        SBSB_CK,      
        MEME_SFX,      
        MEMBER_NUMBER,      
        SUBSCRIBER_NUMBER,      
        MEMBER_FIRST_NAME,      
        MEMBER_MIDDLE_INITIAL,      
        MEMBER_LAST_NAME,      
        MEMBER_BIRTH_DATE,      
        BENEFIT_EFFECTIVE_DATE,      
        BENEFIT_EXPIRATION_DATE,      
        RELATIONSHIP_CODE,      
        SEX_CODE,      
        LINE_OF_BUSINESS,      
        GROUP_NUMBER,      
        ACCOUNT_NUMBER,      
        LANGUAGE_VALUE_1,      
        LANGUAGE_VALUE_2,      
        LANGUAGE_VALUE_3,      
        MEMBER_LANGUAGE,      
        DENTAL_CLASS_PLAN_CODE,      
        PAID_THRU_DATE,      
        ADDRESS_LINE_1,      
        ADDRESS_LINE_2,      
        CITY_CODE,      
        STATE_CODE,      
        ZIP_CODE,      
        PROCESS_DATE,      
        SERVICE_EDITS_CODE,      
        CUSTODIAL_PARENT_LAST_NAME,      
        CUSTODIAL_PARENT_FIRST_NAME,      
        CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        CUST_PARENT_TITLE_CODE,      
        CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        CUSTODIAL_PARENT_CITY_CODE,      
        CUSTODIAL_PARENT_STATE_CODE,      
        CUSTODIAL_PARENT_ZIP_CODE,      
        CUSTODIAL_PARENT_PHONE_NUMBER,      
        COB_INSURANCE_CODE,      
        COB_TYPE,      
        COB_OTHER_INSURANCE_CARRIER_NAME,      
        COB_EFFECTIVE_DATE,      
        COB_TERMINATION_DATE,      
        WAITING_PERIOD_EFFECTIVE_DATE,      
        WAITING_PERIOD_EXPIRATION_DATE,      
        FINANCIAL_ARRANGEMENT,      
        ORIGINAL_EFFECTIVE_DATE,      
        GROUP_CONTRACT_EFFECT_DATE,      
        EXTERNAL_MEMBER_NUMBER,      
        EMPLOYEE_STATUS,      
        GROUP_SIZE,      
        TRANSACTION_DATE,      
        DENTAL_BASIC_EFFECTIVE_DATE,      
        DENTAL_BASIC_EXPIRATION_DATE,      
        DENTAL_MAJOR_EFFECTIVE_DATE,      
        DENTAL_MAJOR_EXPIRATION_DATE,      
        DENTAL_ORTHO_EFFECTIVE_DATE,      
        DENTAL_ORTHO_EXPIRATION_DATE,      
        MEMBER_STATUS,      
        PEDIATRIC_INDICATOR,      
        VOID_INDICATOR      
      ) 
       SELECT DISTINCT           
						MEME_CK = LTRIM(RTRIM(meme.MEME_CK)),      
						GRGR_CK = LTRIM(RTRIM(grgr.GRGR_CK)),      
						SGSG_CK = LTRIM(RTRIM(sgsg.SGSG_CK)),      
						SBSB_CK = LTRIM(RTRIM(sbsb.SBSB_CK)),      
						MEME_SFX = LTRIM(RTRIM(meme.MEME_SFX)),      
						MEMBER_NUMBER = SPACE(15),      
						SUBSCRIBER_NUMBER = SPACE(15),      
						MEMBER_FIRST_NAME = SUBSTRING(LTRIM(RTRIM(meme.MEME_FIRST_NAME)),1,15),      
						MEMBER_MIDDLE_INITIAL = LTRIM(RTRIM(meme.MEME_MID_INIT)),      
						MEMBER_LAST_NAME = SUBSTRING(LTRIM(RTRIM(meme.MEME_LAST_NAME)),1,20),      
						MEMBER_BIRTH_DATE = CONVERT(VARCHAR(8),meme.MEME_BIRTH_DT,112),      
						BENEFIT_EFFECTIVE_DATE = isnull(oldext.BENEFIT_EFFECTIVE_DATE,'00000000'), --CASE WHEN  CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) ='21991231'      --   
						--									THEN '99991231'  
						--									 ELSE  
						--										CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112)  
						--									 END ,  
						BENEFIT_EXPIRATION_DATE = case when isnull(oldext.BENEFIT_EFFECTIVE_DATE,'00000000') = '00000000'
													then '00000000'
													else 
														convert(varchar(8),DATEADD(day,-1,convert(datetime, substring(oldext.BENEFIT_EFFECTIVE_DATE,1,4) + substring(oldext.BENEFIT_EFFECTIVE_DATE,5,2) + substring(oldext.BENEFIT_EFFECTIVE_DATE,7,2),112)),112) 
													end,
						--BENEFIT_EXPIRATION_DATE = isnull(oldext.BENEFIT_EXPIRATION_DATE,'00000000'), --CASE WHEN  CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112)= '21991231'      
						--									 THEN '99991231'  
						--									 ELSE  
						--										 CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112)  
						--									 END ,  
						RELATIONSHIP_CODE =  CASE       
												WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'M'      
													THEN '1'      
												WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'H'    or LTRIM(RTRIM(meme.MEME_REL)) = 'W'      
													THEN '2'      
												WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'S'    or LTRIM(RTRIM(meme.MEME_REL)) = 'D'      
													THEN '3'          
												WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'O'          
													THEN '4'      
											 END,      
						SEX_CODE = LTRIM(RTRIM(meme.MEME_SEX)),      
						LINE_OF_BUSINESS = LTRIM(RTRIM(cte.PDBC_PFX)),      
						GROUP_NUMBER = LTRIM(RTRIM(grgr.GRGR_ID)),      
						ACCOUNT_NUMBER = SUBSTRING(LTRIM(RTRIM(sgsg.SGSG_ID)),1,15),      
						LANGUAGE_VALUE_1 = ' ',      
						LANGUAGE_VALUE_2 = ' ',      
						LANGUAGE_VALUE_3 = ' ',      
						MEMBER_LANGUAGE =  LTRIM(RTRIM(meme.MEME_MCTR_LANG)),      
						DENTAL_CLASS_PLAN_CODE = LTRIM(RTRIM(sbel.CSPI_ID)),      
						PAID_THRU_DATE = CONVERT(VARCHAR(8),grgr.GRGR_ORIG_EFF_DT,112),    
				            
						ADDRESS_LINE_1 = SUBSTRING(CASE       
														WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
														THEN LTRIM(RTRIM(enad.ENAD_ADDR1))      
														WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
														THEN LTRIM(RTRIM(mcrp.MCRP_ADDR1))      
														WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
														THEN LTRIM(RTRIM(sbad.SBAD_ADDR1))      
													 END,1,25),      
						ADDRESS_LINE_2 = SUBSTRING(CASE       
														WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
														THEN LTRIM(RTRIM(enad.ENAD_ADDR2))      
														WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
														THEN LTRIM(RTRIM(mcrp.MCRP_ADDR2))      
														WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
														THEN LTRIM(RTRIM(sbad.SBAD_ADDR2))      
													 END,1,25),      
						CITY_CODE = SUBSTRING(CASE       
														WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
														  THEN LTRIM(RTRIM(enad.ENAD_CITY))      
														  WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
														  THEN LTRIM(RTRIM(mcrp.MCRP_CITY))      
														  WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
														  THEN LTRIM(RTRIM(sbad.SBAD_CITY))      
													 END,1,16),      
						STATE_CODE = SUBSTRING(CASE       
														  WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
														  THEN LTRIM(RTRIM(enad.ENAD_STATE))      
														  WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
														  THEN LTRIM(RTRIM(mcrp.MCRP_STATE))      
														  WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
														  THEN LTRIM(RTRIM(sbad.SBAD_STATE))      
													 END,1,2),      
						ZIP_CODE = SUBSTRING(CASE       
												WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''       
												THEN	CASE WHEN LEN(LTRIM(RTRIM(enad.ENAD_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(enad.ENAD_ZIP,''))) NOT LIKE '%-%'  
															  THEN SUBSTRING(LTRIM(RTRIM(enad.ENAD_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(enad.ENAD_ZIP)),6,4)  
															  ELSE LTRIM(RTRIM(enad.ENAD_ZIP))  
														 END 
												WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''       
												THEN CASE WHEN LEN(LTRIM(RTRIM(mcrp.MCRP_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(mcrp.MCRP_ZIP,''))) NOT LIKE '%-%'  
															  THEN SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),6,4)  
															  ELSE LTRIM(RTRIM(mcrp.MCRP_ZIP))  
														 END 
												WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''       
												 THEN CASE WHEN LEN(LTRIM(RTRIM(sbad.SBAD_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(sbad.SBAD_ZIP,''))) NOT LIKE '%-%'  
															  THEN SUBSTRING(LTRIM(RTRIM(sbad.SBAD_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(sbad.SBAD_ZIP)),6,4)  
															  ELSE LTRIM(RTRIM(sbad.SBAD_ZIP))  
														 END 
											END,1,10),     
				          
						PROCESS_DATE = CONVERT(VARCHAR(8),GETDATE(),112),      
						SERVICE_EDITS_CODE = SPACE(3),      
				              
						CUSTODIAL_PARENT_LAST_NAME = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_LAST_NAME)),1,20),''),  
						CUSTODIAL_PARENT_FIRST_NAME = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_FIRST_NAME)),1,15),''),       
						CUSTODIAL_PARENT_MIDDLE_INITIAL = ISNULL(LTRIM(RTRIM(mcrp.MCRP_MID_INIT)),''),          
						CUST_PARENT_TITLE_CODE = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_TITLE)),1,4),''),     
				          
						CUSTODIAL_PARENT_ADDRESS_LINE_1 = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),1,25),''),      
						CUSTODIAL_PARENT_ADDRESS_LINE_2 = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ADDR2)),1,25),''),      
						CUSTODIAL_PARENT_CITY_CODE = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_CITY)),1,16),''),      
						CUSTODIAL_PARENT_STATE_CODE = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_STATE)),1,2),''),      
						CUSTODIAL_PARENT_ZIP_CODE = CASE  WHEN ISNULL(LTRIM(RTRIM(mcrp.MCRP_ZIP)),'') <> ''       
															 THEN CASE WHEN LEN(LTRIM(RTRIM(mcrp.MCRP_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(mcrp.MCRP_ZIP,''))) NOT LIKE '%-%'  
																	   THEN SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),6,4)  
																	  ELSE LTRIM(RTRIM(mcrp.MCRP_ZIP))  
																	END 
													END,
						CUSTODIAL_PARENT_PHONE_NUMBER = ISNULL(CASE WHEN LTRIM(RTRIM(ISNULL(mcrp.MCRP_ADDR1,'')))<>''      
															 THEN LTRIM(RTRIM(mcrp.MCRP_PHONE))      
															 ELSE ''      
														END,''),   
				          
				             
						COB_INSURANCE_CODE ='',      
						COB_TYPE = '',      
						COB_OTHER_INSURANCE_CARRIER_NAME = '',      
						COB_EFFECTIVE_DATE = '',      
						COB_TERMINATION_DATE = '',      
				              
				              
						WAITING_PERIOD_EFFECTIVE_DATE = CASE WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'      
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)      
															ELSE '00000000'      
														END,       
				                       
						WAITING_PERIOD_EXPIRATION_DATE = CASE WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'      
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)      
															ELSE '00000000'      
														 END ,   
				              
						FINANCIAL_ARRANGEMENT = 'UN',      
						ORIGINAL_EFFECTIVE_DATE = CONVERT(VARCHAR(8),meme.MEME_ORIG_EFF_DT,112),      
						GROUP_CONTRACT_EFFECT_DATE = CONVERT(VARCHAR(8),grgr.GRGR_CURR_ANNV_DT,112),  
						EXTERNAL_MEMBER_NUMBER = RIGHT(REPLICATE('0',9) + CAST(LTRIM(RTRIM(sbsb.SBSB_ID)) AS VARCHAR(9)),9) + RIGHT(REPLICATE('0',2) + CAST(meme.MEME_SFX AS VARCHAR(2)),2),      
						EMPLOYEE_STATUS = oldext.EMPLOYEE_STATUS, -- 'E', --CASE WHEN mepe.MEPE_ELIG_OVR_IND = 'C' THEN 'C' --Cobra   
						--						   WHEN mepe.MEPE_MCTR_RSN = 'SB21' THEN 'R'  --  
						--				   ELSE 'E' --Employed       
						--				END,		--'',   
				               
						GROUP_SIZE = 'SMAL' ,   
						TRANSACTION_DATE = '00000000',
				              
						DENTAL_BASIC_EFFECTIVE_DATE =   CASE WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101'   
																  AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'  
																  AND new.DENTAL_WAITING_PERIOD ='L' 
																  AND DATEDIFF(DAY, atuf.ATUF_DATE1, atuf.ATUF_DATE2) >= 1  
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)  
															WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101'   
																  AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'  
																  AND new.DENTAL_WAITING_PERIOD IN('A','S')    
																  AND DATEDIFF(MONTH, atuf.ATUF_DATE1, atuf.ATUF_DATE2) > 12  
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)  
															ELSE '00000000'      
													   END,      
						DENTAL_BASIC_EXPIRATION_DATE = CASE WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101'   
																 AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'  
				                                                   
																  AND new.DENTAL_WAITING_PERIOD ='L'
																 AND DATEDIFF(DAY, atuf.ATUF_DATE1, atuf.ATUF_DATE2) >= 1  
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)  
				                                            
															WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101'   
																 AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'   
																 AND new.DENTAL_WAITING_PERIOD IN('A','S')   
																 AND DATEDIFF(MONTH, atuf.ATUF_DATE1, atuf.ATUF_DATE2) > 12  
															THEN  CONVERT(VARCHAR(8),DATEADD(mm, 12, atuf.ATUF_DATE1-1),112)   --CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)  
															ELSE '00000000'      
													   END,      
						DENTAL_MAJOR_EFFECTIVE_DATE = CASE WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101'   
																AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'      
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)      
															ELSE '00000000'      
													  END,      
						DENTAL_MAJOR_EXPIRATION_DATE = CASE WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101'   
															AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'      
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)      
															ELSE '00000000'      
													  END,      
				        
				          
						DENTAL_ORTHO_EFFECTIVE_DATE = CASE WHEN (atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101' 
																	AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'  )
																	AND new.ORTHODONTIA_AGE = '18'   
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)      
															ELSE '00000000'      
														END,   
						DENTAL_ORTHO_EXPIRATION_DATE = CASE WHEN (atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101' 
																	AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231' )     
																	AND new.ORTHODONTIA_AGE = '18'      
															THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)  
															ELSE '00000000'      
														 END ,   
				              
						MEMBER_STATUS = '',	      
						PEDIATRIC_INDICATOR = case when 
															(case when DATEADD(YY, DATEDIFF(YY,  meme.MEME_BIRTH_DT , getdate()),   meme.MEME_BIRTH_DT )  > getdate() 
																  then DATEDIFF(YY,  meme.MEME_BIRTH_DT , getdate()) - 1 
																  else DATEDIFF(YY,  meme.MEME_BIRTH_DT , getdate()) 
															end	)< 19
													THEN 'Y'      
													   ELSE 'N'      
											   END,      
						VOID_INDICATOR = 'Y'      
				          
						FROM fabncdv1.dbo.CMC_GRGR_GROUP grgr
						inner join fabncdv1stage.dbo.tpzt_ACSDental_group_extr_new new on new.GROUP_NUMBER  = grgr.GRGR_ID
						INNER JOIN fabncdv1.dbo.CMC_GRGC_GROUP_COUNT grgc  ON grgc.GRGR_CK = grgr.GRGR_CK   
						INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg  ON sgsg.GRGR_CK = grgr.GRGR_CK      
						INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb   ON sbsb.GRGR_CK = grgr.GRGR_CK   
						INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme  ON meme.SBSB_CK = sbsb.SBSB_CK  
						INNER JOIN fabncdv1.dbo.CMC_SBAD_ADDR sbad   ON sbsb.SBSB_CK = sbad.SBSB_CK  
								AND meme.SBAD_TYPE_HOME = sbad.SBAD_TYPE  
				        
				      
						INNER JOIN  fabncdv1.dbo.CMC_SBEL_ELIG_ENT sbel on sbel.SBSB_CK = sbsb.SBSB_CK 
															and sbel.GRGR_CK =grgr.GRGR_CK
															and SBEL_VOID_IND = 'Y'	
															AND sbel.CSPI_ID  = new.PLAN_CODE															
				                   
						LEFT JOIN fabncdv1.dbo.CMC_GRRE_RELATION grre  ON  grgr.GRGR_CK = grre.GRGR_CK  
								AND grre.GRRE_CATEGORY = 'OT'    
								AND grre.GRRE_MCTR_TYPE = 'SIZE'   
						LEFT JOIN  fabncdv1.dbo.CMC_MCRE_RELAT_ENT mcre  ON mcre.MCRE_ID = grre.MCRE_GRRE_ID  
				          
				          
				          
						INNER JOIN  @CTE_TEMP cte                           ON cte.CSPI_ID = sbel.CSPI_ID
                        LEFT JOIN fabncdv1.dbo.CER_ATXR_ATTACH_U atxr      ON atxr.ATXR_SOURCE_ID = meme.ATXR_SOURCE_ID
                                                                           AND LTRIM(RTRIM(atxr.ATSY_ID))  in ( 'DNWP')          
                        LEFT JOIN fabncdv1..CER_ATUF_USERFLD_D atuf  ON atuf.ATSY_ID = atxr.ATSY_ID
																		AND  atuf.ATXR_DEST_ID = atxr.ATXR_DEST_ID      
						left join fabncdv1..CMC_MERP_RELATION merp				ON merp.MEME_CK = meme.MEME_CK  
						LEFT JOIN fabncdv1..CMC_MCRP_RELAT_PER mcrp			ON mcrp.MCRP_ID = merp.MCRP_ID  
				 ------------------------------------------------------------------------------------------------------------------------------------        
						LEFT JOIN fabncdv1..FHP_PMED_MEMBER_D pmed ON pmed.PMED_ID = (CAST(grgr.GRGR_ID AS VARCHAR(24))   
							  +CAST(sbsb.SBSB_ID AS VARCHAR(24))  
							  +CAST(meme.MEME_SFX AS VARCHAR(24))  
							  +CAST(meme.MEME_REL AS VARCHAR(24)))   
				  LEFT JOIN fabncdv1..FHD_ENEN_ENTITY_D enen ON enen.ENEN_CKE = pmed.PMED_CKE  
				  LEFT JOIN fabncdv1..FHD_ENAD_ADDRESS_D enad ON enad.ENEN_CKE = enen.ENEN_CKE  
				  LEFT JOIN fabncdv1..FHP_PMCC_COMM_X pmcc ON pmcc.PMED_CKE = pmed.PMED_CKE         
				   LEFT JOIN fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_old  oldext  on oldext.MEME_CK = meme.MEME_CK
																					and oldext.GRGR_CK = grgr. GRGR_CK
																					and oldext.SGSG_CK = sgsg.SGSG_CK
				               
				WHERE  sbel.CSPD_CAT ='1'   
					and meme.MEME_SFX = '0'
					
					
					
 ----Instering the records whose  Void Event is N ---------------------------
              
   INSERT INTO fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new        
      (      
        MEME_CK,      
        GRGR_CK,      
        SGSG_CK,      
        SBSB_CK,      
        MEME_SFX,      
        MEMBER_NUMBER,      
        SUBSCRIBER_NUMBER,      
        MEMBER_FIRST_NAME,      
        MEMBER_MIDDLE_INITIAL,      
        MEMBER_LAST_NAME,      
        MEMBER_BIRTH_DATE,      
        BENEFIT_EFFECTIVE_DATE,      
        BENEFIT_EXPIRATION_DATE,      
        RELATIONSHIP_CODE,      
        SEX_CODE,      
        LINE_OF_BUSINESS,      
        GROUP_NUMBER,      
        ACCOUNT_NUMBER,      
        LANGUAGE_VALUE_1,      
        LANGUAGE_VALUE_2,      
        LANGUAGE_VALUE_3,      
        MEMBER_LANGUAGE,      
        DENTAL_CLASS_PLAN_CODE,      
        PAID_THRU_DATE,      
        ADDRESS_LINE_1,      
        ADDRESS_LINE_2,      
        CITY_CODE,      
        STATE_CODE,      
        ZIP_CODE,      
        PROCESS_DATE,      
        SERVICE_EDITS_CODE,      
        CUSTODIAL_PARENT_LAST_NAME,      
        CUSTODIAL_PARENT_FIRST_NAME,      
        CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        CUST_PARENT_TITLE_CODE,      
        CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        CUSTODIAL_PARENT_CITY_CODE,      
        CUSTODIAL_PARENT_STATE_CODE,      
        CUSTODIAL_PARENT_ZIP_CODE,      
        CUSTODIAL_PARENT_PHONE_NUMBER,      
        COB_INSURANCE_CODE,      
        COB_TYPE,      
        COB_OTHER_INSURANCE_CARRIER_NAME,      
        COB_EFFECTIVE_DATE,      
        COB_TERMINATION_DATE,      
        WAITING_PERIOD_EFFECTIVE_DATE,      
        WAITING_PERIOD_EXPIRATION_DATE,      
        FINANCIAL_ARRANGEMENT,      
        ORIGINAL_EFFECTIVE_DATE,      
        GROUP_CONTRACT_EFFECT_DATE,      
        EXTERNAL_MEMBER_NUMBER,      
        EMPLOYEE_STATUS,      
        GROUP_SIZE,      
        TRANSACTION_DATE,      
        DENTAL_BASIC_EFFECTIVE_DATE,      
        DENTAL_BASIC_EXPIRATION_DATE,      
        DENTAL_MAJOR_EFFECTIVE_DATE,      
        DENTAL_MAJOR_EXPIRATION_DATE,      
        DENTAL_ORTHO_EFFECTIVE_DATE,      
        DENTAL_ORTHO_EXPIRATION_DATE,      
        MEMBER_STATUS,      
        PEDIATRIC_INDICATOR,      
        VOID_INDICATOR      
      )         
    SELECT DISTINCT           
        MEME_CK = LTRIM(RTRIM(meme.MEME_CK)),      
        GRGR_CK = LTRIM(RTRIM(grgr.GRGR_CK)),      
        SGSG_CK = LTRIM(RTRIM(sgsg.SGSG_CK)),      
        SBSB_CK = LTRIM(RTRIM(sbsb.SBSB_CK)),      
        MEME_SFX = LTRIM(RTRIM(meme.MEME_SFX)),      
        MEMBER_NUMBER = SPACE(15),      
        SUBSCRIBER_NUMBER = SPACE(15),      
        MEMBER_FIRST_NAME = SUBSTRING(LTRIM(RTRIM(meme.MEME_FIRST_NAME)),1,15),      
        MEMBER_MIDDLE_INITIAL = LTRIM(RTRIM(meme.MEME_MID_INIT)),      
        MEMBER_LAST_NAME = SUBSTRING(LTRIM(RTRIM(meme.MEME_LAST_NAME)),1,20),      
        MEMBER_BIRTH_DATE = CONVERT(VARCHAR(8),meme.MEME_BIRTH_DT,112),      
        BENEFIT_EFFECTIVE_DATE = CASE WHEN  CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) ='21991231'      --   
         THEN '99991231'  
         ELSE  
         CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112)  
         END ,  
         BENEFIT_EXPIRATION_DATE = CASE WHEN  CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112)= '21991231'      
         THEN '99991231'  
         ELSE  
         CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112)  
         END ,    
         RELATIONSHIP_CODE =  CASE       
                                WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'M'      
                                    THEN '1'      
                                WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'H'    or LTRIM(RTRIM(meme.MEME_REL)) = 'W'      
                                    THEN '2'      
                                WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'S'    or LTRIM(RTRIM(meme.MEME_REL)) = 'D'      
                                    THEN '3'          
                                WHEN LTRIM(RTRIM(meme.MEME_REL)) = 'O'          
                                    THEN '4'      
                             END,      
        SEX_CODE = LTRIM(RTRIM(meme.MEME_SEX)),      
        LINE_OF_BUSINESS = LTRIM(RTRIM(cte.PDBC_PFX)),      
        GROUP_NUMBER = LTRIM(RTRIM(grgr.GRGR_ID)),      
        ACCOUNT_NUMBER = SUBSTRING(LTRIM(RTRIM(sgsg.SGSG_ID)),1,15),      
        LANGUAGE_VALUE_1 = ' ',      
        LANGUAGE_VALUE_2 = ' ',      
        LANGUAGE_VALUE_3 = ' ',      
        MEMBER_LANGUAGE =  LTRIM(RTRIM(meme.MEME_MCTR_LANG)),      
        DENTAL_CLASS_PLAN_CODE = LTRIM(RTRIM(mepe.CSPI_ID)),      
        PAID_THRU_DATE = CONVERT(VARCHAR(8),grgr.GRGR_ORIG_EFF_DT,112),    
            
        ADDRESS_LINE_1 = SUBSTRING(CASE       
                                        WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
                                        THEN LTRIM(RTRIM(enad.ENAD_ADDR1))      
                                        WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
                                        THEN LTRIM(RTRIM(mcrp.MCRP_ADDR1))      
                                        WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
                                        THEN LTRIM(RTRIM(sbad.SBAD_ADDR1))      
                                     END,1,25),      
        ADDRESS_LINE_2 = SUBSTRING(CASE       
                                        WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
                                        THEN LTRIM(RTRIM(enad.ENAD_ADDR2))      
                                        WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
                                        THEN LTRIM(RTRIM(mcrp.MCRP_ADDR2))      
                                        WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
                                        THEN LTRIM(RTRIM(sbad.SBAD_ADDR2))      
                                     END,1,25),      
        CITY_CODE = SUBSTRING(CASE       
                                        WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
                                          THEN LTRIM(RTRIM(enad.ENAD_CITY))      
                                          WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
                              THEN LTRIM(RTRIM(mcrp.MCRP_CITY))      
                                          WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
                                          THEN LTRIM(RTRIM(sbad.SBAD_CITY))      
                                     END,1,16),      
        STATE_CODE = SUBSTRING(CASE       
                                          WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''      
                                          THEN LTRIM(RTRIM(enad.ENAD_STATE))      
                                          WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''      
                                          THEN LTRIM(RTRIM(mcrp.MCRP_STATE))      
                                          WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''      
                                          THEN LTRIM(RTRIM(sbad.SBAD_STATE))      
                                     END,1,2),      
        
        ZIP_CODE = SUBSTRING(CASE       
                                WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') <> ''       
								THEN	CASE WHEN LEN(LTRIM(RTRIM(enad.ENAD_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(enad.ENAD_ZIP,''))) NOT LIKE '%-%'  
											  THEN SUBSTRING(LTRIM(RTRIM(enad.ENAD_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(enad.ENAD_ZIP)),6,4)  
											  ELSE LTRIM(RTRIM(enad.ENAD_ZIP))  
										 END 
                                WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') <> ''       
                                THEN CASE WHEN LEN(LTRIM(RTRIM(mcrp.MCRP_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(mcrp.MCRP_ZIP,''))) NOT LIKE '%-%'  
											  THEN SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),6,4)  
											  ELSE LTRIM(RTRIM(mcrp.MCRP_ZIP))  
										 END 
                                WHEN ISNULL(LTRIM(RTRIM(enad.ENAD_ADDR1)),'') = '' AND ISNULL(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),'') = ''       
                                 THEN CASE WHEN LEN(LTRIM(RTRIM(sbad.SBAD_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(sbad.SBAD_ZIP,''))) NOT LIKE '%-%'  
											  THEN SUBSTRING(LTRIM(RTRIM(sbad.SBAD_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(sbad.SBAD_ZIP)),6,4)  
											  ELSE LTRIM(RTRIM(sbad.SBAD_ZIP))  
										 END 
                            END,1,10),    
          
        PROCESS_DATE = CONVERT(VARCHAR(8),GETDATE(),112),      
        SERVICE_EDITS_CODE = SPACE(3),      
        CUSTODIAL_PARENT_LAST_NAME = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_LAST_NAME)),1,20),''),  
        CUSTODIAL_PARENT_FIRST_NAME = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_FIRST_NAME)),1,15),''),       
        CUSTODIAL_PARENT_MIDDLE_INITIAL = ISNULL(LTRIM(RTRIM(mcrp.MCRP_MID_INIT)),''),          
        CUST_PARENT_TITLE_CODE = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_TITLE)),1,4),''),     
          
        CUSTODIAL_PARENT_ADDRESS_LINE_1 = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ADDR1)),1,25),''),      
        CUSTODIAL_PARENT_ADDRESS_LINE_2 = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ADDR2)),1,25),''),      
        CUSTODIAL_PARENT_CITY_CODE = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_CITY)),1,16),''),      
        CUSTODIAL_PARENT_STATE_CODE = ISNULL(SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_STATE)),1,2),''),      
       
       
         CUSTODIAL_PARENT_ZIP_CODE = CASE  WHEN ISNULL(LTRIM(RTRIM(mcrp.MCRP_ZIP)),'') <> ''       
											 THEN CASE WHEN LEN(LTRIM(RTRIM(mcrp.MCRP_ZIP))) = 9 AND LTRIM(RTRIM(ISNULL(mcrp.MCRP_ZIP,''))) NOT LIKE '%-%'  
													   THEN SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),1,5) + '-' + SUBSTRING(LTRIM(RTRIM(mcrp.MCRP_ZIP)),6,4)  
													  ELSE LTRIM(RTRIM(mcrp.MCRP_ZIP))  
													END 
									END,
									      
        CUSTODIAL_PARENT_PHONE_NUMBER = ISNULL(CASE WHEN LTRIM(RTRIM(ISNULL(mcrp.MCRP_ADDR1,'')))<>''      
                                             THEN LTRIM(RTRIM(mcrp.MCRP_PHONE))      
                                             ELSE ''      
                                        END,''),   
             
        COB_INSURANCE_CODE ='',      
        COB_TYPE = '',      
        COB_OTHER_INSURANCE_CARRIER_NAME = '',      
        COB_EFFECTIVE_DATE = '',      
        COB_TERMINATION_DATE = '',      
              
              
        WAITING_PERIOD_EFFECTIVE_DATE = CASE WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'      
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)      
                                            ELSE '00000000'      
                                        END, 
                       
        WAITING_PERIOD_EXPIRATION_DATE = CASE WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'      
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)      
                                            ELSE '00000000'      
                                         END ,
              
        FINANCIAL_ARRANGEMENT = 'UN',      
        ORIGINAL_EFFECTIVE_DATE = CONVERT(VARCHAR(8),meme.MEME_ORIG_EFF_DT,112),      
        GROUP_CONTRACT_EFFECT_DATE = CONVERT(VARCHAR(8),grgr.GRGR_CURR_ANNV_DT,112),  
        EXTERNAL_MEMBER_NUMBER = RIGHT(REPLICATE('0',9) + CAST(LTRIM(RTRIM(sbsb.SBSB_ID)) AS VARCHAR(9)),9) + RIGHT(REPLICATE('0',2) + CAST(meme.MEME_SFX AS VARCHAR(2)),2),      
       
        EMPLOYEE_STATUS = CASE WHEN mepe.MEPE_ELIG_OVR_IND = 'C' THEN 'C' --Cobra   
							   WHEN mepe.MEPE_MCTR_RSN = 'SB21' THEN 'R'  --  
                           ELSE 'E' --Employed       
                        END , --'',   
               
        GROUP_SIZE = 'SMAL' , 
        TRANSACTION_DATE = '00000000',
              
        DENTAL_BASIC_EFFECTIVE_DATE =   CASE WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101'   
                                                  AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'  
                                                  AND new.DENTAL_WAITING_PERIOD ='L'
                                                  AND DATEDIFF(DAY, atuf.ATUF_DATE1, atuf.ATUF_DATE2) >= 1  
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)  
                                            WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101'   
                                                  AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'  
                                                  AND new.DENTAL_WAITING_PERIOD IN('A','S')      
                                                  AND DATEDIFF(MONTH, atuf.ATUF_DATE1, atuf.ATUF_DATE2) > 12  
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)  
                                            ELSE '00000000'      
                                       END,      
        DENTAL_BASIC_EXPIRATION_DATE = CASE WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101'   
                                                 AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'  
                                                   
                                                 AND new.DENTAL_WAITING_PERIOD ='L' 
                                                 AND DATEDIFF(DAY, atuf.ATUF_DATE1, atuf.ATUF_DATE2) >= 1  
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)  
                                            WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101'   
                                                 AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'  
                                                 AND new.DENTAL_WAITING_PERIOD IN('A','S')   
                                                 AND DATEDIFF(MONTH, atuf.ATUF_DATE1, atuf.ATUF_DATE2) > 12  
                                            THEN  CONVERT(VARCHAR(8),DATEADD(mm, 12, atuf.ATUF_DATE1-1),112)   --CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)  
                                            ELSE '00000000'      
                                       END,      
        DENTAL_MAJOR_EFFECTIVE_DATE = CASE WHEN atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101'   
                                                AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231'      
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)      
                                            ELSE '00000000'      
                                      END,      
        DENTAL_MAJOR_EXPIRATION_DATE = CASE WHEN atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101'   
                                            AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231'      
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)      
                                            ELSE '00000000'      
                                      END,      
          
        DENTAL_ORTHO_EFFECTIVE_DATE = CASE WHEN (atuf.ATUF_DATE1<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '17530101' 
													AND CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112) <> '99991231' )
													AND new.ORTHODONTIA_AGE = '18'        
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE1,112)      
                                            ELSE '00000000'      
                                        END,  
          
        DENTAL_ORTHO_EXPIRATION_DATE = CASE WHEN (atuf.ATUF_DATE2<> '' AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '17530101' 
													AND CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112) <> '99991231' )     
													AND new.ORTHODONTIA_AGE = '18'   
                                            THEN CONVERT(VARCHAR(8),atuf.ATUF_DATE2,112)      
                                            ELSE '00000000'      
                                         END ,  
             
        MEMBER_STATUS = '', --LTRIM(RTRIM(mepe.MEPE_ELIG_OVR_IND)),      
        PEDIATRIC_INDICATOR = case when 
											(case when DATEADD(YY, DATEDIFF(YY,  meme.MEME_BIRTH_DT , getdate()),   meme.MEME_BIRTH_DT )  > getdate() 
												  then DATEDIFF(YY,  meme.MEME_BIRTH_DT , getdate()) - 1 
												  else DATEDIFF(YY,  meme.MEME_BIRTH_DT , getdate()) 
											end	)< 19
									THEN 'Y'      
									   ELSE 'N'      
                               END,      
        VOID_INDICATOR = 'N' --CASE WHEN mepe.MEPE_EFF_DT = mepe.MEPE_TERM_DT AND mepe.MEPE_MCTR_RSN = 'ME24'       
        --                      THEN 'Y'      
        --                      ELSE 'N'      
        --                 END      
          
        FROM fabncdv1.dbo.CMC_GRGR_GROUP grgr  
        inner join fabncdv1stage.dbo.tpzt_ACSDental_group_extr_new new on new.GROUP_NUMBER  = grgr.GRGR_ID
  INNER JOIN fabncdv1.dbo.CMC_GRGC_GROUP_COUNT grgc  ON grgc.GRGR_CK = grgr.GRGR_CK   
        INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg  ON sgsg.GRGR_CK = grgr.GRGR_CK      
        INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb   ON sbsb.GRGR_CK = grgr.GRGR_CK   
        INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme  ON meme.SBSB_CK = sbsb.SBSB_CK  
        INNER JOIN fabncdv1.dbo.CMC_SBAD_ADDR sbad   ON sbsb.SBSB_CK = sbad.SBSB_CK  
                AND meme.SBAD_TYPE_HOME = sbad.SBAD_TYPE  
        INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe  ON meme.MEME_CK = mepe.MEME_CK  
                AND sgsg.SGSG_CK = mepe.SGSG_CK  
				AND mepe.CSPI_ID  = new.PLAN_CODE
  LEFT JOIN fabncdv1.dbo.CMC_GRRE_RELATION grre  ON  grgr.GRGR_CK = grre.GRGR_CK  
                AND grre.GRRE_CATEGORY = 'OT'    
                AND grre.GRRE_MCTR_TYPE = 'SIZE'   
        LEFT JOIN  fabncdv1.dbo.CMC_MCRE_RELAT_ENT mcre  ON mcre.MCRE_ID = grre.MCRE_GRRE_ID  
          
          
        INNER JOIN  @CTE_TEMP cte                           ON cte.PDPD_ID=mepe.PDPD_ID      
        LEFT JOIN fabncdv1.dbo.CER_ATXR_ATTACH_U atxr      ON atxr.ATXR_SOURCE_ID = meme.ATXR_SOURCE_ID
  														   AND LTRIM(RTRIM(atxr.ATSY_ID))  in ( 'DNWP')          
        LEFT JOIN fabncdv1..CER_ATUF_USERFLD_D atuf  ON atuf.ATSY_ID = atxr.ATSY_ID      
                AND  atuf.ATXR_DEST_ID = atxr.ATXR_DEST_ID      
  left join fabncdv1..CMC_MERP_RELATION merp  ON merp.MEME_CK = meme.MEME_CK  
        LEFT JOIN fabncdv1..CMC_MCRP_RELAT_PER mcrp  ON mcrp.MCRP_ID = merp.MCRP_ID  
 ------------------------------------------------------------------------------------------------------------------------------------        
        LEFT JOIN fabncdv1..FHP_PMED_MEMBER_D pmed ON pmed.PMED_ID = (CAST(grgr.GRGR_ID AS VARCHAR(24))   
              +CAST(sbsb.SBSB_ID AS VARCHAR(24))  
              +CAST(meme.MEME_SFX AS VARCHAR(24))  
              +CAST(meme.MEME_REL AS VARCHAR(24)))   
  LEFT JOIN fabncdv1..FHD_ENEN_ENTITY_D enen ON enen.ENEN_CKE = pmed.PMED_CKE  
  LEFT JOIN fabncdv1..FHD_ENAD_ADDRESS_D enad ON enad.ENEN_CKE = enen.ENEN_CKE  
  LEFT JOIN fabncdv1..FHP_PMCC_COMM_X pmcc ON pmcc.PMED_CKE = pmed.PMED_CKE         
                 
WHERE --UPPER(mcre.MCRE_NAME) = 'SMALL GROUP' AND      
     mepe.CSPD_CAT = '1'
     AND mepe.MEPE_ELIG_IND='Y'     
    AND (CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112) >= DATEADD(YEAR,-2,CONVERT(VARCHAR(8),GETDATE(),112))  
          OR CONVERT(VARCHAR(8),GETDATE(),112) BETWEEN CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) AND CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112)  
          OR CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) >= CONVERT(VARCHAR(8),GETDATE(),112)  
        )   


    
/********** Error Checking for insert statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Populating data in stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 2 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
      

   
/**************  PRINT STEP 3 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep  = @lnCurrentStep + 1,      
      @ldtStepStartTime   = GETDATE(),      
      @lvcMsg             = @lvcObjectName + ': Logic udpated for Void indicator '      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber        = @lnCurrentStep,      
      @pdtStepStartTime    = @ldtStepStartTime,      
      @pnTotalSteps        = @lnTotalSteps,      
      @pchStepMsg          = @lvcMsg      
      
/********** STEP 3 Logic udpated for Void indicator **********/      
    
SELECT @CountVoidIndicator = Count(new.MEME_CK) FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new   new	
	INNER JOIN  fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe ON mepe.MEME_CK = new.MEME_CK
														AND new.GRGR_CK = mepe.GRGR_CK
														AND mepe.SGSG_CK = new.SGSG_CK
														AND mepe.CSPI_ID= new.DENTAL_CLASS_PLAN_CODE
WHERE new.VOID_INDICATOR = 'Y'
AND new.MEME_SFX = '0'

 if (@CountVoidIndicator > 0)
	begin
		
		update new
			set  new.BENEFIT_EFFECTIVE_DATE = CASE WHEN  CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) ='21991231'      --   
													THEN '99991231'  
												 ELSE  
													CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112)  
												END ,  
				
				new.BENEFIT_EXPIRATION_DATE = CASE WHEN  CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) = '21991231'      
													THEN '99991231'  
												 ELSE  
													CONVERT(VARCHAR(8),DATEADD(day,-1,mepe.MEPE_EFF_DT),112)  
												 END
												 
												 
				 --new.BENEFIT_EXPIRATION_DATE = CASE WHEN  CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112)= '21991231'      
					--								THEN '99991231'  
					--							 ELSE  
					--								CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112)  
					--							 END 
			FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new   new	
					INNER JOIN  fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe ON mepe.MEME_CK = new.MEME_CK
														AND new.GRGR_CK = mepe.GRGR_CK
														AND mepe.SGSG_CK = new.SGSG_CK
														AND mepe.CSPI_ID= new.DENTAL_CLASS_PLAN_CODE
				WHERE new.VOID_INDICATOR = 'Y'
				AND new.MEME_SFX = '0'
	end 
              
/**********        Error checking Logic udpated for Void indicator     ***********/      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      
    IF @lnRetCd <> 0      
    BEGIN      
       SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
         + ' : Logic udpated for Void indicator FAILED'      
         + ' RETURNCODE: '      
         + CONVERT(CHAR(6),@lnRetCd)      
       PRINT        @lvcMsg      
       RETURN        @lnRetCd      
    END      
      
/**************  PRINT STEP 3 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed    
      
           
      
/**************  PRINT STEP 4 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep  = @lnCurrentStep + 1,      
      @ldtStepStartTime   = GETDATE(),      
      @lvcMsg             = @lvcObjectName + ': Updating stage table tpzt_ACSDental_meme_extr_new for SUBSCRIBER_NUMBER field '      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber        = @lnCurrentStep,      
      @pdtStepStartTime    = @ldtStepStartTime,      
      @pnTotalSteps        = @lnTotalSteps,      
      @pchStepMsg          = @lvcMsg      
      
/********** STEP 4 Updating stage table tpzt_ACSDental_meme_extr_new for SUBSCRIBER_NUMBER field **********/      
      
    UPDATE new       
    SET new.SUBSCRIBER_NUMBER = LEFT(RIGHT(REPLICATE('0',9) + CAST(LTRIM(RTRIM(meme.MEME_SSN)) AS VARCHAR(9)),9) +        
                         RIGHT(REPLICATE('0',2) + CAST(LTRIM(RTRIM(meme.MEME_SFX)) AS VARCHAR(2)),2) + SPACE(15),15)      
    FROM       
        fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new,      
        fabncdv1.dbo.CMC_MEME_MEMBER meme,      
        fabncdv1.dbo.CMC_SBSB_SUBSC sbsb      
    WHERE       
        SUBSTRING(new.EXTERNAL_MEMBER_NUMBER,1,9) = sbsb.SBSB_ID      
    AND meme.SBSB_CK = sbsb.SBSB_CK      
    AND meme.MEME_REL = 'M' 
   
  
              
/**********        Error checking for Update statement     ***********/      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      
    IF @lnRetCd <> 0      
    BEGIN      
       SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
         + ' : Updating stage table tpzt_ACSDental_meme_extr_new for SUBSCRIBER_NUMBER field FAILED'      
         + ' RETURNCODE: '      
         + CONVERT(CHAR(6),@lnRetCd)      
       PRINT        @lvcMsg      
       RETURN        @lnRetCd      
    END      
      
/**************  PRINT STEP 4 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
      
      
/**************  PRINT STEP 5A HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for MEMBER_NUMBER'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
      
/********** STEP 5A Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for SUBSCRIBER_NUMBER **********/      
          
    ;with temp1 as      
    (      
         SELECT DISTINCT new.SBSB_CK, new.GRGR_CK, new.MEME_CK, meme.MEME_SSN, meme.MEME_REL, meme.MEME_SFX        
            FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new        
				left join fabncdv1.dbo.CMC_SBSB_SUBSC sbsb on  SUBSTRING(new.EXTERNAL_MEMBER_NUMBER,1,9) = sbsb.SBSB_ID 
				     inner join fabncdv1.dbo.CMC_MEME_MEMBER meme on meme.SBSB_CK = sbsb.SBSB_CK  
                
        where meme.MEME_REL = 'M'         
    )      
              
    UPDATE new      
        SET new.MEMBER_NUMBER =CONCAT(t.MEME_SSN ,right('00'+ convert(varchar,new.MEME_SFX,2),2 ) )      
    FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new      
        LEFT JOIN temp1 t on t.SBSB_CK = new.SBSB_CK      
      
/********** Error Checking for update statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for MEMBER_NUMBER FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
             
     
      
/**************  PRINT STEP 7 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for COB_INSURANCE_CODE,COB_TYPE,COB_OTHER_INSURANCE_CARRIER_NAME,COB_EFFECTIVE_DATE,COB_TERMINATION_DATE'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
      
/********** STEP 7 Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for COB_INSURANCE_CODE,COB_TYPE,COB_OTHER_INSURANCE_CARRIER_NAME,COB_EFFECTIVE_DATE,COB_TERMINATION_DATE **********/      
    
   UPDATE new      
    SET new.COB_INSURANCE_CODE = LTRIM(RTRIM(mecb.MECB_INSUR_TYPE)),      
        new.COB_TYPE = LTRIM(RTRIM(mecb.MECB_INSUR_ORDER)),      
        new.COB_OTHER_INSURANCE_CARRIER_NAME = LTRIM(RTRIM(mcre.MCRE_NAME)),      
        new.COB_EFFECTIVE_DATE = CONVERT(VARCHAR(8),mecb.MECB_EFF_DT,112),      
        new.COB_TERMINATION_DATE = CONVERT(VARCHAR(8),mecb.MECB_TERM_DT,112)      
    FROM       
        fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new      
        INNER JOIN fabncdv1.dbo.CMC_MECB_COB mecb  on mecb.MEME_CK = new.MEME_CK  
		INNER JOIN fabncdv1.dbo.CMC_MCRE_RELAT_ENT mcre  ON mecb.MCRE_ID = mcre.MCRE_ID 
			WHERE mecb.MCRE_ID  <> ''
			
                     
/********** Error Checking for update statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Updating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new for COB_INSURANCE_CODE,COB_TYPE,COB_OTHER_INSURANCE_CARRIER_NAME,COB_EFFECTIVE_DATE,COB_TERMINATION_DATE FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 7 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
      
          
    
      
/**************  PRINT STEP 10  HEADER DATA *************************/        
      
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,        
            @ldtStepStartTime = GETDATE(),        
            @lvcMsg = @lvcObjectName + ': Update staging table tpzt_ACSDental_meme_extr_new for Transaction Date Column '        
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr        
            @pnStepNumber     = @lnCurrentStep,        
            @pdtStepStartTime = @ldtStepStartTime,        
            @pnTotalSteps     = @lnTotalSteps,        
            @pchStepMsg       = @lvcMsg       
      
                   
/************* STEP 10 Update staging table tpzt_ACSDental_meme_extr_new for Transaction Date Column ***********/        
     
  
  
  
 --UPDATING DATE FOR THE MEMBER WHICH IS BEING TERMINATED   
  UPDATE curr      
     SET curr.TRANSACTION_DATE = CONVERT(VARCHAR(8),GETDATE(),112)  --'00000000'      
     FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new curr      
   inner join fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe on  mepe.MEME_CK = curr.MEME_CK  
               and mepe.GRGR_CK = curr. GRGR_CK  
               and mepe.SGSG_CK = curr.SGSG_CK  
  WHERE mepe.MEPE_TERM_DT < getdate() and  mepe.MEPE_ELIG_IND ='Y'   
          
/************* Error Checking for Update staging table tpzt_ACSDental_meme_extr_new for Transaction Date Column *************/        
            
    SELECT @lnRetCd    = @@ERROR,        
    @lnRowsProcessed = @@ROWCOUNT        
      
    IF @lnRetCd <> 0        
        BEGIN        
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)        
            + ' : Update staging table tpzt_ACSDental_meme_extr_new for Transaction Date Column FAILED'        
            + ' RETURNCODE: '        
            + CONVERT(CHAR(6),@lnRetCd)        
            PRINT  @lvcMsg        
            RETURN @lnRetCd        
        END             
            
/**************  PRINT STEP 10 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime      = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
        @pdtStepStartTime       = @ldtStepStartTime,      
        @pdtStepEndTime         = @ldtStepEndTime,      
        @pdtProcessStartTime    = @ldtProcessStartTime,      
        @pnRowCount             = @lnRowsProcessed     
        
        

     
/************* STEP 10 Update MEMBER STATUS    in stage table tpzt_ACSDental_meme_extr_new *************/       
 
	--member updated for Handicapped
	
	     UPDATE  new
			SET MEMBER_STATUS = 'H'

			FROM  fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new     
					INNER JOIN fabncdv1.dbo.CMC_MEHD_HANDICAP mehd on mehd.MEME_CK = new.MEME_CK
																	and mehd.GRGR_CK = new.GRGR_CK
			where mehd.MEHD_TYPE = 'P'
			 and GETDATE() between mehd.MEHD_EFF_DT and mehd.MEHD_TERM_DT 
	
	--member updated for Student
		UPDATE  new
			SET MEMBER_STATUS = 'S'

			FROM  fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new     
					INNER JOIN fabncdv1.dbo.CMC_MEST_STUDENT mest on mest.MEME_CK = new.MEME_CK
																  and mest.GRGR_CK = new.GRGR_CK
			where GETDATE() between mest.MEST_EFF_DT and mest.MEST_TERM_DT 
			
			
		--member updated for disable
		UPDATE  new
			SET MEMBER_STATUS = 'D'

			FROM  fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new     
					INNER JOIN fabncdv1.dbo.CMC_MEMD_MECR_DETL memd on memd.MEME_CK = new.MEME_CK
																  and memd.GRGR_CK = new.GRGR_CK
			where MEMD_EVENT_CD = 'DABL'
				and GETDATE() between memd.MEMD_HCFA_EFF_DT and memd.MEMD_HCFA_TERM_DT 		
 
/************* Error Checking  *************/        
           
   SELECT @lnRetCd    = @@ERROR,        
   @lnRowsProcessed = @@ROWCOUNT        
        
   IF @lnRetCd <> 0        
       BEGIN        
           SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)        
           + ' : Updating void indicator  FAILED'        
           + ' RETURNCODE: '        
           + CONVERT(CHAR(6),@lnRetCd)        
           PRINT  @lvcMsg        
           RETURN @lnRetCd        
     END      
/**************  PRINT STEP 10 FOOTER DATA *************************/      
      
SELECT @ldtStepEndTime    = GETDATE()      
     EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
         @pdtStepStartTime       = @ldtStepStartTime,      
         @pdtStepEndTime         = @ldtStepEndTime,      
         @pdtProcessStartTime    = @ldtProcessStartTime,      
         @pnRowCount             = @lnRowsProcessed              
 

           
      
/**************  PRINT STEP 11  HEADER DATA *************************/        
        
     SELECT  @lnCurrentStep    = @lnCurrentStep + 1,        
             @ldtStepStartTime = GETDATE(),        
             @lvcMsg = @lvcObjectName + ': Update staging table tpzt_ACSDental_meme_extr_new for PAID_THRU_DATE Column '        
      
     EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr        
       @pnStepNumber     = @lnCurrentStep,        
             @pdtStepStartTime = @ldtStepStartTime,        
             @pnTotalSteps     = @lnTotalSteps,        
             @pchStepMsg       = @lvcMsg       
      
                       
/************* STEP 11 Update staging table tpzt_ACSDental_meme_extr_new for PAID_THRU_DATE Column ***********/        
                
     UPDATE  new      
     SET new.PAID_THRU_DATE = CONVERT(VARCHAR(8), blbe.BLBL_END_DT,112)      
     FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new      
       JOIN      
           ( SELECT blei.BLEI_CK,blei.BLEI_BILL_LEVEL_CK, MAX(blbl.BLBL_END_DT) AS BLBL_END_DT       
                    FROM fabncdv1.dbo.CMC_BLBL_BILL_SUMM blbl      
                            inner join fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei on blei.BLEI_CK = blbl.BLEI_CK      
                                  
                 WHERE  blbl.BLBL_PAID_STS in (2,3)      
                 GROUP BY blei.BLEI_CK,blei.BLEI_BILL_LEVEL_CK) as blbe      
                 ON blbe.BLEI_BILL_LEVEL_CK = new.SGSG_CK      
              
/************* Error Checking for Update staging table tpzt_ACSDental_meme_extr_new for PAID_THRU_DATE Column *************/        
                
     SELECT @lnRetCd    = @@ERROR,        
     @lnRowsProcessed = @@ROWCOUNT        
           
     IF @lnRetCd <> 0        
         BEGIN        
             SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)        
             + ' : Update staging table tpzt_ACSDental_meme_extr_new for PAID_THRU_DATE Column FAILED'        
             + ' RETURNCODE: '        
             + CONVERT(CHAR(6),@lnRetCd)        
             PRINT  @lvcMsg        
             RETURN @lnRetCd        
         END             
                
/**************  PRINT STEP 11 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime      = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
        @pdtStepStartTime       = @ldtStepStartTime,      
        @pdtStepEndTime         = @ldtStepEndTime,      
        @pdtProcessStartTime    = @ldtProcessStartTime,      
        @pnRowCount             = @lnRowsProcessed      
 
 
 
 
 
 /**************  PRINT STEP 11A  HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
    @ldtStepStartTime    = GETDATE(),      
    @lvcMsg              = @lvcObjectName + ': Update void indicator  '      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
     @pnStepNumber       = @lnCurrentStep,      
     @pdtStepStartTime   = @ldtStepStartTime,      
     @pnTotalSteps       = @lnTotalSteps,      
     @pchStepMsg         = @lvcMsg      
           
/************* STEP 11A Update void indicator in stage table tpzt_ACSDental_meme_extr_new *************/       
     
        UPDATE  new
			SET VOID_INDICATOR = 'Y',
				
				BENEFIT_EXPIRATION_DATE = CASE WHEN  CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) ='21991231'       
													THEN '99991231'  
												 ELSE  
													CONVERT(VARCHAR(8),DATEADD(day,-1,mepe.MEPE_EFF_DT),112) 
												 END 

			FROM  fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new  
				inner join fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe on mepe. MEME_CK = new.MEME_CK 
																and mepe.GRGR_CK = new.GRGR_CK
																and mepe.SGSG_CK = new. SGSG_CK
																and mepe.CSPI_ID = new. DENTAL_CLASS_PLAN_CODE
			WHERE new. MEME_CK IN ( SELECT mepe.MEME_CK 
										FROM fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe  
													WHERE mepe.MEME_CK IN (
												 				SELECT mepe1.MEME_CK   --  , VOID_INDICATOR = 'Y'   
												    				FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new  
															    	       
																			INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe1        ON new.MEME_CK = mepe1.MEME_CK  
																															AND new.DENTAL_CLASS_PLAN_CODE = mepe1.CSPI_ID	
																															AND new.GRGR_CK = mepe1.GRGR_CK
																															AND new.SGSG_CK = mepe1.SGSG_CK
																															
																			AND mepe1.MEPE_EFF_DT = mepe1.MEPE_TERM_DT 
																		   --	WHERE  mepe1.MEME_CK =69951
																			--AND mepe.MEPE_MCTR_RSN = 'ME24'
															)
									AND mepe.MEPE_MCTR_RSN = 'ME24'
								  )


 
  
         
/************* Error Checking *************/        
		           
		   SELECT @lnRetCd    = @@ERROR,        
		   @lnRowsProcessed = @@ROWCOUNT        
		        
		   IF @lnRetCd <> 0        
			   BEGIN        
				   SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)        
				   + ' : Updating void indicator  FAILED'        
				   + ' RETURNCODE: '        
				   + CONVERT(CHAR(6),@lnRetCd)        
				   PRINT  @lvcMsg        
				   RETURN @lnRetCd        
			 END      
/**************  PRINT STEP 11A FOOTER DATA *************************/      
		      
		SELECT @ldtStepEndTime    = GETDATE()      
			 EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
				 @pdtStepStartTime       = @ldtStepStartTime,      
				 @pdtStepEndTime         = @ldtStepEndTime,      
				 @pdtProcessStartTime    = @ldtProcessStartTime,      
				 @pnRowCount             = @lnRowsProcessed              
		 

        
/**************  PRINT STEP 12 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep  = @lnCurrentStep + 1,      
      @ldtStepStartTime   = GETDATE(),      
      @lvcMsg             = @lvcObjectName + ': Truncating stage table tpzt_ACSDental_meme_monthly_old'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber        = @lnCurrentStep,      
      @pdtStepStartTime    = @ldtStepStartTime,      
      @pnTotalSteps        = @lnTotalSteps,      
      @pchStepMsg          = @lvcMsg      
      
/********** STEP 12 Truncate staging table tpzt_ACSDental_meme_monthly_old **********/      
      
    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_ACSDental_meme_monthly_old      
      
/**********        Error checking for TRUNCATE statement     ***********/      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      
    IF @lnRetCd <> 0      
    BEGIN      
       SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
         + ' : Truncating stage table tpzt_ACSDental_meme_monthly_old FAILED'      
         + ' RETURNCODE: '      
         + CONVERT(CHAR(6),@lnRetCd)      
       PRINT        @lvcMsg      
       RETURN        @lnRetCd      
    END      
      
/**************  PRINT STEP 12 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
      
      
/**************  PRINT STEP 13 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_monthly_old with the previous days record'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
      
/********** STEP 13 Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_monthly_old with the previous days record **********/      
      
   INSERT INTO fabncdv1stage.dbo.tpzt_ACSDental_meme_monthly_old      
     (      
        MEME_CK,      
        GRGR_CK,      
        SGSG_CK,      
        SBSB_CK,              
        MEMBER_NUMBER,      
        SUBSCRIBER_NUMBER,      
        MEMBER_FIRST_NAME,      
        MEMBER_MIDDLE_INITIAL,      
        MEMBER_LAST_NAME,      
        MEMBER_BIRTH_DATE,      
        BENEFIT_EFFECTIVE_DATE,      
        BENEFIT_EXPIRATION_DATE,      
        RELATIONSHIP_CODE,      
        SEX_CODE,      
        LINE_OF_BUSINESS,      
        GROUP_NUMBER,      
        ACCOUNT_NUMBER,      
        LANGUAGE_VALUE_1,      
        LANGUAGE_VALUE_2,      
        LANGUAGE_VALUE_3,      
        MEMBER_LANGUAGE,      
        DENTAL_CLASS_PLAN_CODE,      
        PAID_THRU_DATE,      
        ADDRESS_LINE_1,      
        ADDRESS_LINE_2,      
        CITY_CODE,      
        STATE_CODE,      
        ZIP_CODE,      
        PROCESS_DATE,      
        SERVICE_EDITS_CODE,      
        CUSTODIAL_PARENT_LAST_NAME,      
        CUSTODIAL_PARENT_FIRST_NAME,      
        CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        CUST_PARENT_TITLE_CODE,      
        CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        CUSTODIAL_PARENT_CITY_CODE,      
        CUSTODIAL_PARENT_STATE_CODE,      
        CUSTODIAL_PARENT_ZIP_CODE,      
        CUSTODIAL_PARENT_PHONE_NUMBER,      
        COB_INSURANCE_CODE,      
        COB_TYPE,      
        COB_OTHER_INSURANCE_CARRIER_NAME,      
        COB_EFFECTIVE_DATE,      
        COB_TERMINATION_DATE,      
        WAITING_PERIOD_EFFECTIVE_DATE,      
        WAITING_PERIOD_EXPIRATION_DATE,      
        FINANCIAL_ARRANGEMENT,      
        ORIGINAL_EFFECTIVE_DATE,      
        GROUP_CONTRACT_EFFECT_DATE,      
        EXTERNAL_MEMBER_NUMBER,      
        EMPLOYEE_STATUS,      
        GROUP_SIZE,      
        TRANSACTION_DATE,      
        DENTAL_BASIC_EFFECTIVE_DATE,      
        DENTAL_BASIC_EXPIRATION_DATE,      
        DENTAL_MAJOR_EFFECTIVE_DATE,      
        DENTAL_MAJOR_EXPIRATION_DATE,      
        DENTAL_ORTHO_EFFECTIVE_DATE,      
        DENTAL_ORTHO_EXPIRATION_DATE,      
        MEMBER_STATUS,      
        PEDIATRIC_INDICATOR,      
        VOID_INDICATOR      
      )      
    SELECT DISTINCT           
        MEME_CK,      
        GRGR_CK,      
        SGSG_CK,      
        SBSB_CK,      
        MEMBER_NUMBER,      
        SUBSCRIBER_NUMBER,      
        MEMBER_FIRST_NAME,      
        MEMBER_MIDDLE_INITIAL,      
        MEMBER_LAST_NAME,      
        MEMBER_BIRTH_DATE,      
        BENEFIT_EFFECTIVE_DATE,      
        BENEFIT_EXPIRATION_DATE,      
        RELATIONSHIP_CODE,      
        SEX_CODE,      
        LINE_OF_BUSINESS,      
        GROUP_NUMBER,      
        ACCOUNT_NUMBER,      
        LANGUAGE_VALUE_1,      
        LANGUAGE_VALUE_2,      
        LANGUAGE_VALUE_3,      
        MEMBER_LANGUAGE,      
        DENTAL_CLASS_PLAN_CODE,      
        PAID_THRU_DATE,      
        ADDRESS_LINE_1,      
        ADDRESS_LINE_2,      
        CITY_CODE,      
        STATE_CODE,      
        ZIP_CODE,      
        PROCESS_DATE,      
        SERVICE_EDITS_CODE,      
        CUSTODIAL_PARENT_LAST_NAME,      
        CUSTODIAL_PARENT_FIRST_NAME,      
        CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        CUST_PARENT_TITLE_CODE,      
        CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        CUSTODIAL_PARENT_CITY_CODE,      
        CUSTODIAL_PARENT_STATE_CODE,      
        CUSTODIAL_PARENT_ZIP_CODE,      
        CUSTODIAL_PARENT_PHONE_NUMBER,      
        COB_INSURANCE_CODE,      
        COB_TYPE,      
        COB_OTHER_INSURANCE_CARRIER_NAME,      
        COB_EFFECTIVE_DATE,      
        COB_TERMINATION_DATE,      
        WAITING_PERIOD_EFFECTIVE_DATE,      
        WAITING_PERIOD_EXPIRATION_DATE,      
        FINANCIAL_ARRANGEMENT,      
        ORIGINAL_EFFECTIVE_DATE,      
        GROUP_CONTRACT_EFFECT_DATE,      
        EXTERNAL_MEMBER_NUMBER,      
        EMPLOYEE_STATUS,      
        GROUP_SIZE,      
        TRANSACTION_DATE,      
        DENTAL_BASIC_EFFECTIVE_DATE,      
        DENTAL_BASIC_EXPIRATION_DATE,      
        DENTAL_MAJOR_EFFECTIVE_DATE,      
        DENTAL_MAJOR_EXPIRATION_DATE,      
        DENTAL_ORTHO_EFFECTIVE_DATE,      
        DENTAL_ORTHO_EXPIRATION_DATE,      
        MEMBER_STATUS,      
        PEDIATRIC_INDICATOR,      
        VOID_INDICATOR      
     FROM      
        fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new      

	
	
	----------------update transaction date
	
	
select @lvcCount = count (*) from fabncdv1stage.dbo.tpzt_ACSDental_meme_monthly_old old 

IF @lvcCount > 0

begin   
  ;with CTE_MEME_EXTR       
      (      
        MEMBER_NUMBER,      
        SUBSCRIBER_NUMBER,      
        MEMBER_FIRST_NAME,      
        MEMBER_MIDDLE_INITIAL,      
        MEMBER_LAST_NAME,      
        MEMBER_BIRTH_DATE,      
        BENEFIT_EFFECTIVE_DATE,      
        BENEFIT_EXPIRATION_DATE,      
        RELATIONSHIP_CODE,      
        SEX_CODE,      
        LINE_OF_BUSINESS,      
        GROUP_NUMBER,      
        ACCOUNT_NUMBER,      
        LANGUAGE_VALUE_1,      
        LANGUAGE_VALUE_2,      
        LANGUAGE_VALUE_3,      
        MEMBER_LANGUAGE,      
        DENTAL_CLASS_PLAN_CODE,      
        PAID_THRU_DATE,      
        ADDRESS_LINE_1,      
        ADDRESS_LINE_2,      
        CITY_CODE,      
        STATE_CODE,      
        ZIP_CODE,      
       -- PROCESS_DATE,      
        SERVICE_EDITS_CODE,      
        CUSTODIAL_PARENT_LAST_NAME,      
        CUSTODIAL_PARENT_FIRST_NAME,      
        CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        CUST_PARENT_TITLE_CODE,      
        CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        CUSTODIAL_PARENT_CITY_CODE,      
        CUSTODIAL_PARENT_STATE_CODE,      
        CUSTODIAL_PARENT_ZIP_CODE,      
        CUSTODIAL_PARENT_PHONE_NUMBER,      
        COB_INSURANCE_CODE,      
        COB_TYPE,      
        COB_OTHER_INSURANCE_CARRIER_NAME,      
        COB_EFFECTIVE_DATE,      
        COB_TERMINATION_DATE,      
        WAITING_PERIOD_EFFECTIVE_DATE,      
        WAITING_PERIOD_EXPIRATION_DATE,      
        FINANCIAL_ARRANGEMENT,      
        ORIGINAL_EFFECTIVE_DATE,      
        GROUP_CONTRACT_EFFECT_DATE,      
        EXTERNAL_MEMBER_NUMBER,      
        EMPLOYEE_STATUS,      
        GROUP_SIZE,      
        --TRANSACTION_DATE,      
        DENTAL_BASIC_EFFECTIVE_DATE,      
        DENTAL_BASIC_EXPIRATION_DATE,      
        DENTAL_MAJOR_EFFECTIVE_DATE,      
        DENTAL_MAJOR_EXPIRATION_DATE,      
        DENTAL_ORTHO_EFFECTIVE_DATE,      
        DENTAL_ORTHO_EXPIRATION_DATE,      
        MEMBER_STATUS,      
        PEDIATRIC_INDICATOR,      
        VOID_INDICATOR      
      )  AS    
    ( SELECT DISTINCT      
        new.MEMBER_NUMBER,      
        new.SUBSCRIBER_NUMBER,      
        new.MEMBER_FIRST_NAME,      
        new.MEMBER_MIDDLE_INITIAL,      
        new.MEMBER_LAST_NAME,      
        new.MEMBER_BIRTH_DATE,      
        new.BENEFIT_EFFECTIVE_DATE,      
        new.BENEFIT_EXPIRATION_DATE,      
        new.RELATIONSHIP_CODE,      
        new.SEX_CODE,      
        new.LINE_OF_BUSINESS,      
        new.GROUP_NUMBER,     
        new.ACCOUNT_NUMBER,      
        new.LANGUAGE_VALUE_1,      
        new.LANGUAGE_VALUE_2,      
        new.LANGUAGE_VALUE_3,      
        new.MEMBER_LANGUAGE,      
        new.DENTAL_CLASS_PLAN_CODE,      
        new.PAID_THRU_DATE,      
        new.ADDRESS_LINE_1,      
        new.ADDRESS_LINE_2,      
        new.CITY_CODE,      
        new.STATE_CODE,      
        new.ZIP_CODE,      
        --new.PROCESS_DATE,      
        new.SERVICE_EDITS_CODE,      
        new.CUSTODIAL_PARENT_LAST_NAME,      
        new.CUSTODIAL_PARENT_FIRST_NAME,      
        new.CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        new.CUST_PARENT_TITLE_CODE,      
        new.CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        new.CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        new.CUSTODIAL_PARENT_CITY_CODE,      
        new.CUSTODIAL_PARENT_STATE_CODE,      
        new.CUSTODIAL_PARENT_ZIP_CODE,      
        new.CUSTODIAL_PARENT_PHONE_NUMBER,      
        new.COB_INSURANCE_CODE,      
        new.COB_TYPE,      
        new.COB_OTHER_INSURANCE_CARRIER_NAME,      
        new.COB_EFFECTIVE_DATE,      
        new.COB_TERMINATION_DATE,      
        new.WAITING_PERIOD_EFFECTIVE_DATE,      
        new.WAITING_PERIOD_EXPIRATION_DATE,      
        new.FINANCIAL_ARRANGEMENT,      
        new.ORIGINAL_EFFECTIVE_DATE,      
        new.GROUP_CONTRACT_EFFECT_DATE,      
        new.EXTERNAL_MEMBER_NUMBER,      
        new.EMPLOYEE_STATUS,      
        new.GROUP_SIZE,      
       -- new.TRANSACTION_DATE,      
        new.DENTAL_BASIC_EFFECTIVE_DATE,      
        new.DENTAL_BASIC_EXPIRATION_DATE,      
        new.DENTAL_MAJOR_EFFECTIVE_DATE,      
        new.DENTAL_MAJOR_EXPIRATION_DATE,      
        new.DENTAL_ORTHO_EFFECTIVE_DATE,      
        new.DENTAL_ORTHO_EXPIRATION_DATE,      
        new.MEMBER_STATUS,      
        new.PEDIATRIC_INDICATOR,      
        new.VOID_INDICATOR      
    FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new      
    WHERE LTRIM(RTRIM(ISNULL(new.MEMBER_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.SUBSCRIBER_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.MEMBER_FIRST_NAME,'')))<>''      
            --AND LTRIM(RTRIM(new.MEMBER_FIRST_NAME)) NOT LIKE '%[^0-9a-zA-Z ]%'      
              
            AND LTRIM(RTRIM(ISNULL(new.MEMBER_LAST_NAME,'')))<>''      
            --AND LTRIM(RTRIM(new.MEMBER_LAST_NAME)) NOT LIKE '%[^0-9a-zA-Z ]%'      
            AND LTRIM(RTRIM(ISNULL(new.MEMBER_BIRTH_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.BENEFIT_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.BENEFIT_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.RELATIONSHIP_CODE,'')))<>''      
            AND LTRIM(RTRIM(new.RELATIONSHIP_CODE)) IN ('1','2','3','4')   
            AND LTRIM(RTRIM(ISNULL(new.SEX_CODE,'')))<>''       
            AND LTRIM(RTRIM(new.SEX_CODE)) IN ('F','M','U')      
            AND LTRIM(RTRIM(ISNULL(new.LINE_OF_BUSINESS,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.GROUP_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.ACCOUNT_NUMBER,'')))<>''      
                
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_CLASS_PLAN_CODE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.PAID_THRU_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.ADDRESS_LINE_1,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.CITY_CODE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.STATE_CODE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.ZIP_CODE,'')))<>''      
               
            AND LTRIM(RTRIM(ISNULL(new.WAITING_PERIOD_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.WAITING_PERIOD_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.ORIGINAL_EFFECTIVE_DATE,'')))NOT IN ('99991231','')    
            AND LTRIM(RTRIM(ISNULL(new.GROUP_CONTRACT_EFFECT_DATE,'')))NOT IN ('99991231','')      
            AND LTRIM(RTRIM(ISNULL(new.EXTERNAL_MEMBER_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.EMPLOYEE_STATUS,''))) IN ('C','E','R','I','U','')      
                  
            AND LTRIM(RTRIM(ISNULL(new.GROUP_SIZE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_BASIC_EFFECTIVE_DATE,'')))<>''       
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_BASIC_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_MAJOR_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_MAJOR_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_ORTHO_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_ORTHO_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(new.MEMBER_STATUS)) IN ('D','H','S','')      
              
            AND LTRIM(RTRIM(new.PEDIATRIC_INDICATOR)) IN ('Y','N')      
            AND LTRIM(RTRIM(ISNULL(new.PEDIATRIC_INDICATOR,'')))<>''      
            AND LTRIM(RTRIM(new.VOID_INDICATOR)) IN ('Y','N')      
            AND LTRIM(RTRIM(ISNULL(new.VOID_INDICATOR,'')))<>''      
    EXCEPT      
    SELECT      
        old.MEMBER_NUMBER,      
        old.SUBSCRIBER_NUMBER,      
        old.MEMBER_FIRST_NAME,      
        old.MEMBER_MIDDLE_INITIAL,      
        old.MEMBER_LAST_NAME,      
        old.MEMBER_BIRTH_DATE,      
        old.BENEFIT_EFFECTIVE_DATE,      
        old.BENEFIT_EXPIRATION_DATE,      
        old.RELATIONSHIP_CODE,      
        old.SEX_CODE,      
        old.LINE_OF_BUSINESS,      
        old.GROUP_NUMBER,      
        old.ACCOUNT_NUMBER,      
        old.LANGUAGE_VALUE_1,      
        old.LANGUAGE_VALUE_2,      
        old.LANGUAGE_VALUE_3,      
        old.MEMBER_LANGUAGE,      
        old.DENTAL_CLASS_PLAN_CODE,      
        old.PAID_THRU_DATE,      
        old.ADDRESS_LINE_1,      
        old.ADDRESS_LINE_2,      
        old.CITY_CODE,      
        old.STATE_CODE,      
        old.ZIP_CODE,      
       -- old.PROCESS_DATE,      
        old.SERVICE_EDITS_CODE,      
        old.CUSTODIAL_PARENT_LAST_NAME,      
        old.CUSTODIAL_PARENT_FIRST_NAME,      
        old.CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        old.CUST_PARENT_TITLE_CODE,      
        old.CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        old.CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        old.CUSTODIAL_PARENT_CITY_CODE,      
        old.CUSTODIAL_PARENT_STATE_CODE,      
        old.CUSTODIAL_PARENT_ZIP_CODE,      
        old.CUSTODIAL_PARENT_PHONE_NUMBER,      
        old.COB_INSURANCE_CODE,      
        old.COB_TYPE,      
        old.COB_OTHER_INSURANCE_CARRIER_NAME,      
        old.COB_EFFECTIVE_DATE,      
        old.COB_TERMINATION_DATE,      
        old.WAITING_PERIOD_EFFECTIVE_DATE,      
        old.WAITING_PERIOD_EXPIRATION_DATE,      
        old.FINANCIAL_ARRANGEMENT,      
        old.ORIGINAL_EFFECTIVE_DATE,      
        old.GROUP_CONTRACT_EFFECT_DATE,      
        old.EXTERNAL_MEMBER_NUMBER,      
        old.EMPLOYEE_STATUS,      
        old.GROUP_SIZE,      
        --old.TRANSACTION_DATE,      
        old.DENTAL_BASIC_EFFECTIVE_DATE,      
        old.DENTAL_BASIC_EXPIRATION_DATE,      
        old.DENTAL_MAJOR_EFFECTIVE_DATE,      
        old.DENTAL_MAJOR_EXPIRATION_DATE,      
        old.DENTAL_ORTHO_EFFECTIVE_DATE,      
        old.DENTAL_ORTHO_EXPIRATION_DATE,      
        old.MEMBER_STATUS,      
        old.PEDIATRIC_INDICATOR,      
        old.VOID_INDICATOR      
    FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_monthly_old old      
    WHERE LTRIM(RTRIM(ISNULL(old.MEMBER_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.SUBSCRIBER_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.MEMBER_FIRST_NAME,'')))<>''      
            --AND LTRIM(RTRIM(old.MEMBER_FIRST_NAME)) NOT LIKE '%[^0-9a-zA-Z ]%'      
              
            AND LTRIM(RTRIM(ISNULL(old.MEMBER_LAST_NAME,'')))<>''      
            --AND LTRIM(RTRIM(old.MEMBER_LAST_NAME)) NOT LIKE '%[^0-9a-zA-Z ]%'      
            AND LTRIM(RTRIM(ISNULL(old.MEMBER_BIRTH_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.BENEFIT_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.BENEFIT_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.RELATIONSHIP_CODE,'')))<>''   
            AND LTRIM(RTRIM(old.RELATIONSHIP_CODE)) IN ('1','2','3','4')               
            AND LTRIM(RTRIM(ISNULL(old.SEX_CODE,'')))<>''       
            AND LTRIM(RTRIM(old.SEX_CODE)) IN ('F','M','U')      
            AND LTRIM(RTRIM(ISNULL(old.LINE_OF_BUSINESS,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.GROUP_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.ACCOUNT_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.DENTAL_CLASS_PLAN_CODE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.PAID_THRU_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.ADDRESS_LINE_1,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.CITY_CODE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.STATE_CODE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.ZIP_CODE,'')))<>''      
               
            AND LTRIM(RTRIM(ISNULL(old.WAITING_PERIOD_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.WAITING_PERIOD_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.ORIGINAL_EFFECTIVE_DATE,'')))NOT IN ('99991231','')     
            AND LTRIM(RTRIM(ISNULL(old.GROUP_CONTRACT_EFFECT_DATE,''))) NOT IN ('99991231','')     
            AND LTRIM(RTRIM(ISNULL(old.EXTERNAL_MEMBER_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.EMPLOYEE_STATUS,''))) IN ('C','E','R','I','U','')      
              
            AND LTRIM(RTRIM(ISNULL(old.GROUP_SIZE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.DENTAL_BASIC_EFFECTIVE_DATE,'')))<>''       
            AND LTRIM(RTRIM(ISNULL(old.DENTAL_BASIC_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.DENTAL_MAJOR_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.DENTAL_MAJOR_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.DENTAL_ORTHO_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(old.DENTAL_ORTHO_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(old.MEMBER_STATUS)) IN ('D','H','S','')      
            AND LTRIM(RTRIM(old.PEDIATRIC_INDICATOR)) IN ('Y','N')      
            AND LTRIM(RTRIM(ISNULL(old.PEDIATRIC_INDICATOR,'')))<>''      
            AND LTRIM(RTRIM(old.VOID_INDICATOR)) IN ('Y','N')      
            AND LTRIM(RTRIM(ISNULL(old.VOID_INDICATOR,'')))<>''   
  )


  UPDATE curr      
     SET curr.TRANSACTION_DATE = CONVERT(VARCHAR(8),GETDATE(),112) --'00000000'      
     FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new curr      
   WHERE curr.MEMBER_NUMBER in (SELECT prev.MEMBER_NUMBER FROM CTE_MEME_EXTR prev WHERE prev.MEMBER_NUMBER = curr.MEMBER_NUMBER)  
  
end

              
/********** Error Checking for insert statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Populating data in stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_old with the previous days record FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 13 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
      
      
/**************  PRINT STEP 14  HEADER DATA *************************/        
        
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,        
            @ldtStepStartTime = GETDATE(),        
            @lvcMsg = @lvcObjectName + ': Truncate staging table tpzt_ACSDental_meme_error'        
      
   EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr        
        @pnStepNumber     = @lnCurrentStep,        
        @pdtStepStartTime = @ldtStepStartTime,        
        @pnTotalSteps     = @lnTotalSteps,        
        @pchStepMsg       = @lvcMsg       
                       
/************* STEP 14 Truncate Staging table tpzt_ACSDental_meme_error *************/        
                
    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_ACSDental_meme_error        
                
/************* Error Checking for Truncate in Staging table tpzt_ACSDental_meme_error *************/        
                
        SELECT @lnRetCd    = @@ERROR,        
        @lnRowsProcessed = @@ROWCOUNT        
      
        IF @lnRetCd <> 0        
            BEGIN        
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)        
                + ' : Truncate Staging table tpzt_ACSDental_meme_error FAILED'        
                + ' RETURNCODE: '        
                + CONVERT(CHAR(6),@lnRetCd)        
                PRINT  @lvcMsg        
                RETURN @lnRetCd        
            END             
                
/**************  PRINT STEP 14 FOOTER DATA *************************/      
      
        SELECT @ldtStepEndTime      = GETDATE()      
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
            @pdtStepStartTime       = @ldtStepStartTime,      
            @pdtStepEndTime         = @ldtStepEndTime,      
            @pdtProcessStartTime    = @ldtProcessStartTime,      
            @pnRowCount             = @lnRowsProcessed         
         
/**************  PRINT STEP 15  HEADER DATA *************************/        
        
        SELECT  @lnCurrentStep    = @lnCurrentStep + 1,        
                @ldtStepStartTime = GETDATE(),        
                @lvcMsg = @lvcObjectName + ': Insert error records in staging table tpzt_ACSDental_meme_error'        
      
        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr        
                @pnStepNumber     = @lnCurrentStep,        
                @pdtStepStartTime = @ldtStepStartTime,        
                @pnTotalSteps     = @lnTotalSteps,        
                @pchStepMsg       = @lvcMsg       
      
                       
/************* STEP 15 Insert error records in staging table tpzt_ACSDental_meme_error *************/        
                
    INSERT INTO fabncdv1stage.dbo.tpzt_ACSDental_meme_error      
        (      
            MEMBER_NUMBER,                         
            SUBSCRIBER_NUMBER,                     
            MEMBER_FIRST_NAME,                     
            MEMBER_MIDDLE_INITIAL,                 
            MEMBER_LAST_NAME ,                     
            MEMBER_BIRTH_DATE ,                    
            BENEFIT_EFFECTIVE_DATE,                
            BENEFIT_EXPIRATION_DATE,               
            RELATIONSHIP_CODE  ,                   
            SEX_CODE ,                       
            LINE_OF_BUSINESS,                      
            GROUP_NUMBER ,                         
            ACCOUNT_NUMBER ,                       
            LANGUAGE_VALUE_1,                      
            LANGUAGE_VALUE_2,                      
            LANGUAGE_VALUE_3,                      
            MEMBER_LANGUAGE ,                      
            DENTAL_CLASS_PLAN_CODE ,               
            PAID_THRU_DATE ,                       
            ADDRESS_LINE_1 ,                       
            ADDRESS_LINE_2 ,                       
            CITY_CODE ,                            
            STATE_CODE ,                           
            ZIP_CODE ,                             
            PROCESS_DATE,                          
            SERVICE_EDITS_CODE ,                   
            CUSTODIAL_PARENT_LAST_NAME ,           
            CUSTODIAL_PARENT_FIRST_NAME ,          
            CUSTODIAL_PARENT_MIDDLE_INITIAL ,      
            CUST_PARENT_TITLE_CODE ,               
            CUSTODIAL_PARENT_ADDRESS_LINE_1,       
            CUSTODIAL_PARENT_ADDRESS_LINE_2,       
            CUSTODIAL_PARENT_CITY_CODE,            
            CUSTODIAL_PARENT_STATE_CODE ,          
            CUSTODIAL_PARENT_ZIP_CODE ,            
            CUSTODIAL_PARENT_PHONE_NUMBER,         
            COB_INSURANCE_CODE,                    
            COB_TYPE ,              
            COB_OTHER_INSURANCE_CARRIER_NAME,      
            COB_EFFECTIVE_DATE ,                   
            COB_TERMINATION_DATE,                  
            WAITING_PERIOD_EFFECTIVE_DATE,         
            WAITING_PERIOD_EXPIRATION_DATE,        
            FINANCIAL_ARRANGEMENT ,                
            ORIGINAL_EFFECTIVE_DATE ,              
            GROUP_CONTRACT_EFFECT_DATE,            
            EXTERNAL_MEMBER_NUMBER,                
            EMPLOYEE_STATUS,                       
            GROUP_SIZE ,                           
            TRANSACTION_DATE,                      
            DENTAL_BASIC_EFFECTIVE_DATE ,          
            DENTAL_BASIC_EXPIRATION_DATE,          
            DENTAL_MAJOR_EFFECTIVE_DATE ,          
            DENTAL_MAJOR_EXPIRATION_DATE,          
            DENTAL_ORTHO_EFFECTIVE_DATE ,          
            DENTAL_ORTHO_EXPIRATION_DATE,          
            MEMBER_STATUS,                         
            PEDIATRIC_INDICATOR,                   
            VOID_INDICATOR      
        )      
    SELECT DISTINCT       
            MEMBER_NUMBER                    = new.MEMBER_NUMBER ,                        
            SUBSCRIBER_NUMBER                = new.SUBSCRIBER_NUMBER ,                    
            MEMBER_FIRST_NAME                = new.MEMBER_FIRST_NAME,                     
            MEMBER_MIDDLE_INITIAL            = new.MEMBER_MIDDLE_INITIAL,                 
            MEMBER_LAST_NAME                 = new.MEMBER_LAST_NAME ,                     
            MEMBER_BIRTH_DATE                = new.MEMBER_BIRTH_DATE,                     
            BENEFIT_EFFECTIVE_DATE           = new.BENEFIT_EFFECTIVE_DATE ,               
            BENEFIT_EXPIRATION_DATE          = new.BENEFIT_EXPIRATION_DATE,               
            RELATIONSHIP_CODE                = new.RELATIONSHIP_CODE,                     
            SEX_CODE                         = new.SEX_CODE ,                             
            LINE_OF_BUSINESS                 = new.LINE_OF_BUSINESS ,                     
            GROUP_NUMBER                     = new.GROUP_NUMBER,                          
            ACCOUNT_NUMBER                   = new.ACCOUNT_NUMBER ,                       
            LANGUAGE_VALUE_1                 = new.LANGUAGE_VALUE_1,                     
            LANGUAGE_VALUE_2                 = new.LANGUAGE_VALUE_2,                     
            LANGUAGE_VALUE_3                 = new.LANGUAGE_VALUE_3,                     
            MEMBER_LANGUAGE                  = new.MEMBER_LANGUAGE ,                     
            DENTAL_CLASS_PLAN_CODE           = new.DENTAL_CLASS_PLAN_CODE,                
            PAID_THRU_DATE                   = new.PAID_THRU_DATE,                       
      ADDRESS_LINE_1            = new.ADDRESS_LINE_1,                       
            ADDRESS_LINE_2                   = new.ADDRESS_LINE_2,                       
            CITY_CODE                        = new.CITY_CODE ,                            
            STATE_CODE                       = new.STATE_CODE ,                           
            ZIP_CODE                         = new.ZIP_CODE,                              
            PROCESS_DATE                     = new.PROCESS_DATE,                          
            SERVICE_EDITS_CODE               = new.SERVICE_EDITS_CODE,                    
            CUSTODIAL_PARENT_LAST_NAME       = new.CUSTODIAL_PARENT_LAST_NAME ,           
            CUSTODIAL_PARENT_FIRST_NAME      = new.CUSTODIAL_PARENT_FIRST_NAME ,          
            CUSTODIAL_PARENT_MIDDLE_INITIAL  = new.CUSTODIAL_PARENT_MIDDLE_INITIAL,       
            CUST_PARENT_TITLE_CODE           = new.CUST_PARENT_TITLE_CODE ,               
            CUSTODIAL_PARENT_ADDRESS_LINE_1  = new.CUSTODIAL_PARENT_ADDRESS_LINE_1,      
            CUSTODIAL_PARENT_ADDRESS_LINE_2  = new.CUSTODIAL_PARENT_ADDRESS_LINE_2,      
            CUSTODIAL_PARENT_CITY_CODE       = new.CUSTODIAL_PARENT_CITY_CODE ,           
            CUSTODIAL_PARENT_STATE_CODE      = new.CUSTODIAL_PARENT_STATE_CODE,           
            CUSTODIAL_PARENT_ZIP_CODE        = new.CUSTODIAL_PARENT_ZIP_CODE,             
            CUSTODIAL_PARENT_PHONE_NUMBER    = new.CUSTODIAL_PARENT_PHONE_NUMBER,         
            COB_INSURANCE_CODE               = new.COB_INSURANCE_CODE,                    
            COB_TYPE                         = new.COB_TYPE,                              
            COB_OTHER_INSURANCE_CARRIER_NAME = new.COB_OTHER_INSURANCE_CARRIER_NAME,      
            COB_EFFECTIVE_DATE               = new.COB_EFFECTIVE_DATE ,                   
            COB_TERMINATION_DATE             = new.COB_TERMINATION_DATE,                  
            WAITING_PERIOD_EFFECTIVE_DATE    = new.WAITING_PERIOD_EFFECTIVE_DATE,         
            WAITING_PERIOD_EXPIRATION_DATE   = new.WAITING_PERIOD_EXPIRATION_DATE,        
            FINANCIAL_ARRANGEMENT            = new.FINANCIAL_ARRANGEMENT ,                
            ORIGINAL_EFFECTIVE_DATE          = new.ORIGINAL_EFFECTIVE_DATE ,              
            GROUP_CONTRACT_EFFECT_DATE       = new.GROUP_CONTRACT_EFFECT_DATE,            
            EXTERNAL_MEMBER_NUMBER           = new.EXTERNAL_MEMBER_NUMBER,                
            EMPLOYEE_STATUS                  = new.EMPLOYEE_STATUS,                       
            GROUP_SIZE                       = new.GROUP_SIZE,                            
            TRANSACTION_DATE                 = new.TRANSACTION_DATE,                      
            DENTAL_BASIC_EFFECTIVE_DATE      = new.DENTAL_BASIC_EFFECTIVE_DATE ,         
            DENTAL_BASIC_EXPIRATION_DATE     = new.DENTAL_BASIC_EXPIRATION_DATE,         
            DENTAL_MAJOR_EFFECTIVE_DATE      = new.DENTAL_MAJOR_EFFECTIVE_DATE ,         
            DENTAL_MAJOR_EXPIRATION_DATE     = new.DENTAL_MAJOR_EXPIRATION_DATE,         
            DENTAL_ORTHO_EFFECTIVE_DATE      = new.DENTAL_ORTHO_EFFECTIVE_DATE ,         
            DENTAL_ORTHO_EXPIRATION_DATE     = new.DENTAL_ORTHO_EXPIRATION_DATE,         
            MEMBER_STATUS                    = new.MEMBER_STATUS ,                        
            PEDIATRIC_INDICATOR              = new.PEDIATRIC_INDICATOR,                   
            VOID_INDICATOR                   = new.VOID_INDICATOR       
                  
        FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new      
        WHERE LTRIM(RTRIM(ISNULL(new.MEMBER_NUMBER,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.SUBSCRIBER_NUMBER,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.MEMBER_FIRST_NAME,'')))=''      
            --OR LTRIM(RTRIM(new.MEMBER_FIRST_NAME)) LIKE '%[^0-9a-zA-Z ]%'      
              
            OR LTRIM(RTRIM(ISNULL(new.MEMBER_LAST_NAME,'')))=''      
            --OR LTRIM(RTRIM(new.MEMBER_LAST_NAME)) LIKE '%[^0-9a-zA-Z ]%'      
            OR LTRIM(RTRIM(ISNULL(new.MEMBER_BIRTH_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.BENEFIT_EFFECTIVE_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.BENEFIT_EXPIRATION_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.RELATIONSHIP_CODE,'')))=''    
            OR LTRIM(RTRIM(new.RELATIONSHIP_CODE)) NOT IN ('1','2','3','4')              
            OR LTRIM(RTRIM(ISNULL(new.SEX_CODE,'')))=''       
            OR LTRIM(RTRIM(new.SEX_CODE)) NOT IN ('F','M','U')      
            OR LTRIM(RTRIM(ISNULL(new.LINE_OF_BUSINESS,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.GROUP_NUMBER,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.ACCOUNT_NUMBER,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.DENTAL_CLASS_PLAN_CODE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.PAID_THRU_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.ADDRESS_LINE_1,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.CITY_CODE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.STATE_CODE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.ZIP_CODE,'')))=''      
                 
            OR LTRIM(RTRIM(ISNULL(new.WAITING_PERIOD_EFFECTIVE_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.WAITING_PERIOD_EXPIRATION_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.ORIGINAL_EFFECTIVE_DATE,''))) IN ('99991231','')      
            OR LTRIM(RTRIM(ISNULL(new.GROUP_CONTRACT_EFFECT_DATE,''))) IN ('99991231','')           
            OR LTRIM(RTRIM(ISNULL(new.EXTERNAL_MEMBER_NUMBER,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.EMPLOYEE_STATUS,''))) NOT IN ('C','E','R','I','U','')      
              
            OR LTRIM(RTRIM(ISNULL(new.GROUP_SIZE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.TRANSACTION_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.DENTAL_BASIC_EFFECTIVE_DATE,'')))=''       
            OR LTRIM(RTRIM(ISNULL(new.DENTAL_BASIC_EXPIRATION_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.DENTAL_MAJOR_EFFECTIVE_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.DENTAL_MAJOR_EXPIRATION_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.DENTAL_ORTHO_EFFECTIVE_DATE,'')))=''      
            OR LTRIM(RTRIM(ISNULL(new.DENTAL_ORTHO_EXPIRATION_DATE,'')))=''      
            OR LTRIM(RTRIM(new.MEMBER_STATUS)) NOT IN ('D','H','S','')      
              
            OR LTRIM(RTRIM(new.PEDIATRIC_INDICATOR)) NOT IN ('Y','N')      
            OR LTRIM(RTRIM(ISNULL(new.PEDIATRIC_INDICATOR,'')))=''      
            OR LTRIM(RTRIM(new.VOID_INDICATOR)) NOT IN ('Y','N')      
            OR LTRIM(RTRIM(ISNULL(new.VOID_INDICATOR,'')))=''      
                  
/************* Error Checking for Insert in Staging table tpzt_ACSDental_meme_error  *************/        
                
        SELECT @lnRetCd    = @@ERROR,        
        @lnRowsProcessed = @@ROWCOUNT        
      
        IF @lnRetCd <> 0        
            BEGIN        
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)        
                + ' : Insert error records in staging table tpzt_ACSDental_meme_error FAILED'        
                + ' RETURNCODE: '        
                + CONVERT(CHAR(6),@lnRetCd)        
                PRINT  @lvcMsg        
           RETURN @lnRetCd        
            END             
                
/**************  PRINT STEP 15 FOOTER DATA *************************/      
      
        SELECT @ldtStepEndTime      = GETDATE()      
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
            @pdtStepStartTime       = @ldtStepStartTime,      
            @pdtStepEndTime         = @ldtStepEndTime,      
            @pdtProcessStartTime    = @ldtProcessStartTime,      
            @pnRowCount             = @lnRowsProcessed         




/**************  PRINT STEP 15A HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Truncating the member whose subscriber is not in extracted'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
      
/********** STEP 15A Truncating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr **********/      
      
   DELETE  FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new  
		WHERE substring(EXTERNAL_MEMBER_NUMBER,1,9)   NOT IN  (SELECT DISTINCT substring(new1.EXTERNAL_MEMBER_NUMBER,1,9) 
																			 FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new1
																			 WHERE new1.MEME_SFX = 0 
																   )
		 
                     
/********** Error Checking for truncate statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Truncating the member whose subscriber is not in extracted FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 15A FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
      


                 
/**************  PRINT STEP 16 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Truncating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg   = @lvcMsg      
      
/********** STEP 16 Truncating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr **********/      
      
    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_ACSDental_meme_extr      
                     
/********** Error Checking for truncate statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Truncating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 16 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,      
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed      
            
/**************  PRINT STEP 17 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr with present days record'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg      
      
/********** STEP 17 Populating stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr with present days record **********/      
      
   INSERT INTO fabncdv1stage.dbo.tpzt_ACSDental_meme_extr      
     (      
        MEMBER_NUMBER,      
        SUBSCRIBER_NUMBER,      
        MEMBER_FIRST_NAME,      
        MEMBER_MIDDLE_INITIAL,      
        MEMBER_LAST_NAME,      
        MEMBER_BIRTH_DATE,      
        BENEFIT_EFFECTIVE_DATE,      
        BENEFIT_EXPIRATION_DATE,      
        RELATIONSHIP_CODE,      
        SEX_CODE,      
        LINE_OF_BUSINESS,      
        GROUP_NUMBER,      
        ACCOUNT_NUMBER,      
        LANGUAGE_VALUE_1,      
        LANGUAGE_VALUE_2,      
        LANGUAGE_VALUE_3,      
        MEMBER_LANGUAGE,      
        DENTAL_CLASS_PLAN_CODE,      
        PAID_THRU_DATE,      
        ADDRESS_LINE_1,      
        ADDRESS_LINE_2,      
        CITY_CODE,      
        STATE_CODE,              ZIP_CODE,      
        PROCESS_DATE,      
        SERVICE_EDITS_CODE,      
        CUSTODIAL_PARENT_LAST_NAME,      
        CUSTODIAL_PARENT_FIRST_NAME,      
        CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        CUST_PARENT_TITLE_CODE,      
        CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        CUSTODIAL_PARENT_CITY_CODE,      
        CUSTODIAL_PARENT_STATE_CODE,      
        CUSTODIAL_PARENT_ZIP_CODE,      
        CUSTODIAL_PARENT_PHONE_NUMBER,      
        COB_INSURANCE_CODE,      
        COB_TYPE,      
        COB_OTHER_INSURANCE_CARRIER_NAME,      
        COB_EFFECTIVE_DATE,      
        COB_TERMINATION_DATE,      
        WAITING_PERIOD_EFFECTIVE_DATE,      
        WAITING_PERIOD_EXPIRATION_DATE,      
        FINANCIAL_ARRANGEMENT,      
        ORIGINAL_EFFECTIVE_DATE,      
        GROUP_CONTRACT_EFFECT_DATE,      
        EXTERNAL_MEMBER_NUMBER,      
        EMPLOYEE_STATUS,      
        GROUP_SIZE,      
        TRANSACTION_DATE,      
        DENTAL_BASIC_EFFECTIVE_DATE,      
        DENTAL_BASIC_EXPIRATION_DATE,      
        DENTAL_MAJOR_EFFECTIVE_DATE,      
        DENTAL_MAJOR_EXPIRATION_DATE,      
        DENTAL_ORTHO_EFFECTIVE_DATE,      
        DENTAL_ORTHO_EXPIRATION_DATE,      
        MEMBER_STATUS,      
        PEDIATRIC_INDICATOR,      
        VOID_INDICATOR      
      )      
    SELECT DISTINCT      
        new.MEMBER_NUMBER,      
        new.SUBSCRIBER_NUMBER,      
        new.MEMBER_FIRST_NAME,      
        new.MEMBER_MIDDLE_INITIAL,      
        new.MEMBER_LAST_NAME,     
        new.MEMBER_BIRTH_DATE,      
        new.BENEFIT_EFFECTIVE_DATE,      
        new.BENEFIT_EXPIRATION_DATE,      
        new.RELATIONSHIP_CODE,      
        new.SEX_CODE,      
        new.LINE_OF_BUSINESS,      
        new.GROUP_NUMBER,      
        new.ACCOUNT_NUMBER,      
        new.LANGUAGE_VALUE_1,      
        new.LANGUAGE_VALUE_2,      
        new.LANGUAGE_VALUE_3,      
        new.MEMBER_LANGUAGE,      
        new.DENTAL_CLASS_PLAN_CODE,      
        new.PAID_THRU_DATE,      
        new.ADDRESS_LINE_1,      
        new.ADDRESS_LINE_2,      
        new.CITY_CODE,      
        new.STATE_CODE,      
        new.ZIP_CODE,      
        new.PROCESS_DATE,      
        new.SERVICE_EDITS_CODE,      
        new.CUSTODIAL_PARENT_LAST_NAME,      
        new.CUSTODIAL_PARENT_FIRST_NAME,      
        new.CUSTODIAL_PARENT_MIDDLE_INITIAL,      
        new.CUST_PARENT_TITLE_CODE,      
        new.CUSTODIAL_PARENT_ADDRESS_LINE_1,      
        new.CUSTODIAL_PARENT_ADDRESS_LINE_2,      
        new.CUSTODIAL_PARENT_CITY_CODE,      
        new.CUSTODIAL_PARENT_STATE_CODE,      
        new.CUSTODIAL_PARENT_ZIP_CODE,      
        new.CUSTODIAL_PARENT_PHONE_NUMBER,      
        new.COB_INSURANCE_CODE,      
        new.COB_TYPE,      
        new.COB_OTHER_INSURANCE_CARRIER_NAME,      
        new.COB_EFFECTIVE_DATE,      
        new.COB_TERMINATION_DATE,      
        new.WAITING_PERIOD_EFFECTIVE_DATE,      
        new.WAITING_PERIOD_EXPIRATION_DATE,      
        new.FINANCIAL_ARRANGEMENT,      
        new.ORIGINAL_EFFECTIVE_DATE,      
        new.GROUP_CONTRACT_EFFECT_DATE,      
        new.EXTERNAL_MEMBER_NUMBER,      
        new.EMPLOYEE_STATUS,      
        new.GROUP_SIZE,      
        new.TRANSACTION_DATE,      
        new.DENTAL_BASIC_EFFECTIVE_DATE,      
        new.DENTAL_BASIC_EXPIRATION_DATE,      
        new.DENTAL_MAJOR_EFFECTIVE_DATE,      
        new.DENTAL_MAJOR_EXPIRATION_DATE,      
        new.DENTAL_ORTHO_EFFECTIVE_DATE,      
        new.DENTAL_ORTHO_EXPIRATION_DATE,      
        new.MEMBER_STATUS,      
        new.PEDIATRIC_INDICATOR,      
        new.VOID_INDICATOR      
    FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr_new new      
    WHERE LTRIM(RTRIM(ISNULL(new.MEMBER_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.SUBSCRIBER_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.MEMBER_FIRST_NAME,'')))<>'' 			
            --AND LTRIM(RTRIM(new.MEMBER_FIRST_NAME)) NOT LIKE '%[^0-9a-zA-Z ]%'       -- Commented to allow free form text - V 1.32              
            AND LTRIM(RTRIM(ISNULL(new.MEMBER_LAST_NAME,'')))<>''      
            --AND LTRIM(RTRIM(new.MEMBER_LAST_NAME)) NOT LIKE '%[^0-9a-zA-Z ]%'          -- Commented to allow free form text - V 1.32    
            AND LTRIM(RTRIM(ISNULL(new.MEMBER_BIRTH_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.BENEFIT_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.BENEFIT_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.RELATIONSHIP_CODE,'')))<>''   
            AND LTRIM(RTRIM(new.RELATIONSHIP_CODE)) IN ('1','2','3','4')              
            AND LTRIM(RTRIM(ISNULL(new.SEX_CODE,'')))<>''       
            AND LTRIM(RTRIM(new.SEX_CODE)) IN ('F','M','U')      
            AND LTRIM(RTRIM(ISNULL(new.LINE_OF_BUSINESS,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.GROUP_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.ACCOUNT_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_CLASS_PLAN_CODE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.PAID_THRU_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.ADDRESS_LINE_1,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.CITY_CODE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.STATE_CODE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.ZIP_CODE,'')))<>''      
                  
            AND LTRIM(RTRIM(ISNULL(new.WAITING_PERIOD_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.WAITING_PERIOD_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.ORIGINAL_EFFECTIVE_DATE,''))) not in ('99991231','')     
            --AND LTRIM(RTRIM(ISNULL(new.GROUP_CONTRACT_EFFECT_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.GROUP_CONTRACT_EFFECT_DATE,'')))not in ('99991231','')
            AND LTRIM(RTRIM(ISNULL(new.EXTERNAL_MEMBER_NUMBER,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.EMPLOYEE_STATUS,''))) IN ('C','E','R','I','U','')      
              
            AND LTRIM(RTRIM(ISNULL(new.GROUP_SIZE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_BASIC_EFFECTIVE_DATE,'')))<>''       
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_BASIC_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_MAJOR_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_MAJOR_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_ORTHO_EFFECTIVE_DATE,'')))<>''      
            AND LTRIM(RTRIM(ISNULL(new.DENTAL_ORTHO_EXPIRATION_DATE,'')))<>''      
            AND LTRIM(RTRIM(new.MEMBER_STATUS)) IN ('D','H','S','')      
                
            AND LTRIM(RTRIM(new.PEDIATRIC_INDICATOR)) IN ('Y','N')      
            AND LTRIM(RTRIM(ISNULL(new.PEDIATRIC_INDICATOR,'')))<>''      
            AND LTRIM(RTRIM(new.VOID_INDICATOR)) IN ('Y','N')      
            AND LTRIM(RTRIM(ISNULL(new.VOID_INDICATOR,'')))<>''      
                                 
/********** Error Checking for insert statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : Populating data in stage table fabncdv1stage.dbo.tpzt_ACSDental_meme_extr with present days record FAILED'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 17 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,  
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed        
	  
	  
/**************  PRINT STEP 18 HEADER DATA *************************/      
      
    SELECT @lnCurrentStep = @lnCurrentStep + 1,      
     @ldtStepStartTime    = GETDATE(),      
     @lvcMsg              = @lvcObjectName + ': Delete member record if the Subscriber is not sent'      
      
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr      
      @pnStepNumber       = @lnCurrentStep,      
      @pdtStepStartTime   = @ldtStepStartTime,      
      @pnTotalSteps       = @lnTotalSteps,      
      @pchStepMsg         = @lvcMsg     
	  
	/**************  Delete member record if the Subscriber is not sent *************************/     
	DELETE memb
	FROM fabncdv1stage.dbo.tpzt_ACSDental_meme_extr  memb
	WHERE 
		NOT EXISTS (SELECT 
						1 
					FROM 
						fabncdv1stage.dbo.tpzt_ACSDental_meme_extr subs
					WHERE 
						memb.SUBSCRIBER_NUMBER  = subs.MEMBER_NUMBER
					)
					
/********** Error Checking for insert statement ************************/      
      
    SELECT @lnRetCd    = @@ERROR,      
      @lnRowsProcessed = @@ROWCOUNT      
      IF @lnRetCd <> 0      
       BEGIN      
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)      
          + ' : deleting member record if the Subscriber is not sent'      
          + ' RETURNCODE: '      
          + CONVERT(CHAR(6),@lnRetCd)      
        PRINT  @lvcMsg      
        RETURN @lnRetCd      
       END      
      
/**************  PRINT STEP 18 FOOTER DATA *************************/      
      
    SELECT @ldtStepEndTime    = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr      
      @pdtStepStartTime       = @ldtStepStartTime,  
      @pdtStepEndTime         = @ldtStepEndTime,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pnRowCount             = @lnRowsProcessed     
	  
 
	  
	END      
/**************  PRINT JOB FOOTER DATA ****************************/      
      
    SELECT @ldtProcessEndTime = GETDATE()      
    EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr      
      @pchObjectName          = @lvcObjectName,      
      @pdtProcessStartTime    = @ldtProcessStartTime,      
      @pdtProcessEndTime      = @ldtProcessEndTime      
    RETURN  @lnRetCd      
END   
GO
/****************************************************************
 BEGIN MAINTENANCE WRAPPER:
*****************************************************************/
IF OBJECT_ID('dbo.tpzp_ACSDental_meme_extr') IS NOT NULL
  PRINT '<<< CREATED PROCEDURE dbo.tpzp_ACSDental_meme_extr >>>'
       
ELSE
  PRINT '<<<ERROR CREATING PROCEDURE dbo.tpzp_ACSDental_meme_extr >>>'
GO

/****************************************************************
 END MAINTENANCE WRAPPER:
*****************************************************************/

