﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;

namespace TzgTst3ClmExtract
{
    /// <summary>
    /// Use this code as the starting point for the assignment
    /// 
    /// Version     Date            Developer       Description
    /// 1.00        12/10/2014      Masato Nakai    Initial Release
    /// </summary>
    class TzgTst3ClmExtract
    {
        /// <summary>
        /// private variable(s)
        /// </summary>
        private const string m_strErrorExit = "ERROR EXIT";

        /// <summary>
        /// Main() method. This is the entry point.
        /// </summary>
        /// <param name="args">Arguments from the command prompt
        /// args[0] - Database Server
        /// args[1] - Custom Database
        /// args[2] - Output Directory
        /// </param>
        /// <returns>
        /// 0 for Success
        /// 8 for Error
        /// </returns>
        /// <summary>
        /// Main() method. This is the entry point.
        /// </summary>
        /// <param name="args">Arguments from the command prompt
        /// args[0] - Database Server
        /// args[1] - Custom Database
        /// args[2] - Output Directory
        /// args[3] - Group ID (optional)
        /// </param>
        /// <returns>
        /// 0 for Success
        /// 8 for Error
        /// </returns>
        static int Main(string[] args)
        {
            if (args.Length != 3 && args.Length != 4)
            {
                /// Exist the application if all parameters are not provided
                Console.WriteLine("Usage: ");
                Console.WriteLine("Parameters: <Database Server> <Custom Database> <Output Directory>");
                Environment.Exit(8);
            }

            Console.WriteLine("Message - " + "TzgTst3ClmExtract.exe started...");

            /// Call the method to create two output files.
            TzgTst3ClmExtract objTst3ClmExtract = new TzgTst3ClmExtract();
            int intReturnCode = objTst3ClmExtract.ExtractClaims(args);

            Console.WriteLine("Message - " + "TzgTst3ClmExtract.exe completed!");

            return intReturnCode;
        }

        private int ExtractClaims(string[] pstrArguments)
        {
            string strDataSource = pstrArguments[0];
            string strCustomDatabase = pstrArguments[1];
            string strOutputDir = pstrArguments[2];

            int intReturnCode = 0;

            SqlConnection objConnection = new SqlConnection();
            SqlCommand objCommand = new SqlCommand();
            SqlDataAdapter daDataAdapter = new SqlDataAdapter();
            DataSet dsClaimData = new DataSet();

            try
            {
                Console.WriteLine("Message - " + "Connecting to the database...");

                string strConnectionString = "Server=" + strDataSource + ";Database=" + strCustomDatabase + ";Trusted_Connection=True;";
                objConnection.ConnectionString = strConnectionString;
                objConnection.Open();

                Console.WriteLine("Message - " + "Connected!");
                Console.WriteLine("Message - " + "Executing the stored procedure...");

                objCommand.Connection = objConnection;
                objCommand.CommandTimeout = 0;
                objCommand.CommandText = "TZGSP_TST3_CLAIMS";
                objCommand.CommandType = CommandType.StoredProcedure;

                // Find the parameter
                SqlCommandBuilder.DeriveParameters(objCommand);
                
                // Execute the stored procedure and save the returned records in the DataSet object
                daDataAdapter.SelectCommand = objCommand;
                daDataAdapter.Fill(dsClaimData);

                Console.WriteLine("Message - " + "Finished executing the stored procedure...");

                if (int.Parse(objCommand.Parameters["@RETURN_VALUE"].Value.ToString()) == 0)
                {
                    // Convert the DataSet to XmlReader
                    XmlReader csvClaimXmlReader = XmlReader.Create(new StringReader(dsClaimData.GetXml()));
                    XmlReader fixedClaimXmlReader = XmlReader.Create(new StringReader(dsClaimData.GetXml()));
                    XmlReader excelClaimXmlReader = XmlReader.Create(new StringReader(dsClaimData.GetXml()));

                    // TODO: Add logic to save the claim data in a comma separated file
                    XslCompiledTransform csvXslt = new XslCompiledTransform();
                    csvXslt.Load("DelimitedFile.xslt", new XsltSettings(true, true), null);
                    XsltArgumentList csvArguments = new XsltArgumentList();
                    csvArguments.AddParam("delim", "", ",");
                    TextWriter csvWriter = new StreamWriter(@"D:\Interfaces\Output\TST3\TST3_CSV.txt");

                    csvXslt.Transform(csvClaimXmlReader, csvArguments, csvWriter);
                    csvWriter.Close();
                    csvClaimXmlReader.Close();

                    // TODO: Challenge 1. Save the claim data in a fixed length file.
                    XslCompiledTransform fixedXslt = new XslCompiledTransform();
                    fixedXslt.Load("FixedLengthFile.xslt", new XsltSettings(true, true), null);
                    TextWriter fixedWriter = new StreamWriter(@"D:\Interfaces\Output\TST3\TST3_FIXED.txt");

                    fixedXslt.Transform(fixedClaimXmlReader, null, fixedWriter);
                    fixedWriter.Close();
                    fixedClaimXmlReader.Close();

                    // TODO: Challenge 2. Save the claim data in an Excel spreadsheet.
                    // Apply the stylesheet for Excel
                    XslCompiledTransform excelXslt = new XslCompiledTransform();
                    excelXslt.Load("Excel.xslt");
                    TextWriter xcelWriter = new StreamWriter(@"D:\Interfaces\Output\TST3\TST3_EXCEL.xls");

                    // Write the Excel spreadsheet
                    excelXslt.Transform(excelClaimXmlReader, null, xcelWriter);
                    xcelWriter.Close();
                    excelClaimXmlReader.Close();
                }
            }
            catch (Exception ex)
            {
                // Report the error and change the return code to 8
                Console.WriteLine("");
                Console.WriteLine("Message - " + "Exception thrown\n");
                Console.WriteLine(ex.Message);
                Console.WriteLine(m_strErrorExit);
                Console.WriteLine("");

                intReturnCode = 8;
            }
            finally
            {
                Console.WriteLine("Message - " + "Disposing objects...");

                // Dispose the objects if necesary
                if (dsClaimData != null)
                {
                    // Dispose DataSEt
                    dsClaimData.Dispose();
                }

                if (daDataAdapter != null)
                {
                    // Dispose DataAdapter
                    daDataAdapter.Dispose();
                }

                if (objCommand != null)
                {
                    // Dispose OdbcCommand
                    objCommand.Dispose();
                }

                // If the database connection is created, release the memory.
                if (objConnection != null)
                {
                    if (objConnection.State == ConnectionState.Open)
                    {
                        objConnection.Close();
                    }

                    objConnection.Dispose();
                }

                Console.WriteLine("Message - " + "Objects disposed!");
            }

            return intReturnCode;
        }
    }
}
