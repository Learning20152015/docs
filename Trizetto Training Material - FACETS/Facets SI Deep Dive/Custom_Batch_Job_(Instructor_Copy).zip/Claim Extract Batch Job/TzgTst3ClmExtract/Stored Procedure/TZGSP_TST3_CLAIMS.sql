/*********************************************************************************
 BEGIN MAINTENANCE WRAPPER:
*********************************************************************************/
IF EXISTS (SELECT 1
        FROM   sysobjects
        WHERE  name = 'TZGSP_TST3_CLAIMS'
        AND    uid  = USER_ID('dbo')
        AND    type = 'P')
BEGIN
    DROP PROCEDURE  
        dbo.TZGSP_TST3_CLAIMS

      --Indicate successfully dropping the table...
    PRINT 'DROPPED PROCEDRUE TZGSP_TST3_CLAIMS'
END
GO
/*********************************************************************************
 END MAINTENANCE WRAPPER.
*********************************************************************************/

CREATE PROCEDURE
	TZGSP_TST3_CLAIMS
/****************************************************************      
** Procedure Name:   TZGSP_TST3_CLAIMS
** 
** Purpose:          Select claims
** 
** Input:            None
** 
** Output:           None
** 
** Returns:          0 if successful
**                   Else, pass through Sybase error
** 
** Dependencies:
** 
**    Tables:        TBD
** 
**    Procedures:    None
** 
** Revision History:
** 
**    1.0 - 12/10/2014 Masato Nakai
**          initial version
**
****************************************************************/
AS
BEGIN
    /****************************************************************
    **          DECLARE LOCAL VARIABLES                            **
    ****************************************************************/
    DECLARE @lnRetCd                INT				-- Proc return code

    /* Set the default values */
    SELECT
		@lnRetCd = 0
	
	/* Drop the temp table if exists */
	IF OBJECT_ID('tempdb..#tzg_clcl_claim') IS NOT NULL
	BEGIN 
		DROP TABLE #tzg_clcl_claim
	END	

	/* Select claims paid in 1999 */
	SELECT
		CLCL.CLCL_ID,
		CLCL.GRGR_CK,
		CLCL.SBSB_CK,
		CLCL.MEME_CK,
		CLCL.CLCL_LOW_SVC_DT,
		CLCL.CLCL_PAID_DT
	INTO
		#tzg_clcl_claim
	FROM
		fatzgdv1..CMC_CLCL_CLAIM CLCL
	WHERE
		CLCL.CLCL_CUR_STS IN ('02', '91') -- "02" = Paid and "91" = Adjusted
	AND LEFT(CONVERT(VARCHAR, CLCL.CLCL_PAID_DT, 112), 4) = '1999'

	/* Find Group ID, Subscriber ID, Member Suffix, and Member Name*/
	SELECT 
		CLCL.CLCL_ID,
		CLCL.CLCL_LOW_SVC_DT,
		CLCL.CLCL_PAID_DT,
		GRGR.GRGR_ID,
		SBSB.SBSB_ID,
		RIGHT('00' + CONVERT(VARCHAR, MEME.MEME_SFX), 2) MEME_SFX,
		MEME.MEME_LAST_NAME,
		MEME.MEME_FIRST_NAME
	FROM
		#tzg_clcl_claim CLCL
	INNER JOIN
		fatzgdv1..CMC_GRGR_GROUP GRGR
	ON
		GRGR.GRGR_CK = CLCL.GRGR_CK
	INNER JOIN
		fatzgdv1..CMC_SBSB_SUBSC SBSB
	ON
		SBSB.SBSB_CK = CLCL.SBSB_CK
	INNER JOIN
		fatzgdv1..CMC_MEME_MEMBER MEME
	ON
		MEME.MEME_CK = CLCL.MEME_CK
		
    RETURN @lnRetCd
END
GO

/*********************************************************************************
 BEGIN MAINTENANCE WRAPPER:
*********************************************************************************/
IF EXISTS (SELECT 1
        FROM   sysobjects
        WHERE  name = 'TZGSP_TST3_CLAIMS'
        AND    uid  = USER_ID('dbo')
        AND    type = 'P')
BEGIN
    --Indicate successful compile...
    PRINT 'CREATED PROCEDURE TZGSP_TST3_CLAIMS'
END
ELSE
BEGIN
    --Indicate unsuccessful compile...
    PRINT 'ERROR CREATING PROCEDURE TZGSP_TST3_CLAIMS'
END
GO
/*********************************************************************************
 END MAINTENANCE WRAPPER.
*********************************************************************************/