﻿// ClsConstants.cs
//
// Assembly:
//    MagellanMemberExtract.dll
//
// Description:
//   Magellan Membership Extract
// --------------------------------------------------------------
// 
// Copyright © 2008-2014 The TriZetto Group, Inc.
// All rights reserved.
// Warning:  This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of
// this program, or any portion of it, may result in severe civil and
// criminal penalties, and will be prosecuted to the maximum extent
// possible under the law.
// This source code is the confidential and proprietary information of The
// TriZetto Group, Inc.
// You shall not disclose such Confidential Information to any third parties
// and shall use it only in accordance with the terms of the license agreement
// you entered into with The TriZetto Group, Inc.
// This source code and information is provided "as is" without warranty
// of any kind, either expressed or implied, including but not limited to
// the implied warranties of merchantability and/or fitness for a particular
// purpose.
// Author : The TriZetto Corporation
// -----------------------------------------------------------------------------
// Revision History:
// 1.0   03-25-2014   Amol Sangar    Initial creation.
// 1.1   04-25-2014   Amol Sangar    Updated...
// 1.2   05-12-2014   Amol Sangar    Updated....
//-------------------------------------------------------------------------------

namespace MagellanMemberExtract
{
    public static class ClsConstants
    {
        // Return codes
        public const int p_RET_CODE_SUCCESS = 0;
        public const int p_RET_CODE_PLAN_FILE_FAIL = 2;
        public const int p_RET_CODE_PARTIAL_FAIL = 4;
        public const int p_RET_CODE_FAIL = 8;

        // Constant integer values
        public const int p_VALUE_ZERO = 0;
        public const int p_VALUE_ONE = 1;
        public const int p_VALUE_TWO = 2;
        public const int p_VALUE_THREE = 3;
        public const int p_VALUE_FOUR = 4;
        public const int p_VALUE_FIVE = 5;
        public const int p_VALUE_SIX = 6;
        public const int p_VALUE_SEVEN = 7;
        public const int p_VALUE_EIGHT = 8;
        public const int p_VALUE_NINE = 9;
        public const int p_VALUE_TEN = 10;
        public const int p_VALUE_MINUS_ONE = -1;

        //Constant string value
        public const string p_STR_FREQUENCY = "pRunFreq";
        public const string p_STR_DATASET = "MagellanMember";
        public const string p_STR_FREQUENCY_DAILY = "DAILY";
        public const string p_STR_FREQUENCY_QUARTERLY = "QUARTERLY";

        //"Columns Values"
        public const char p_CH_SPACE = ' ';
        public const string p_STR_STAR = "*";
        public const string p_STR_TILT = "~";
        public const string p_STR_DOUBLE_SLASH = "\\";
        public const string p_STR_STARS_TILT = "***~";
        public const string p_STR_ISA = "ISA";
        public const string p_STR_GS = "GS";
        public const string p_STR_ST = "ST";
        public const string p_STR_BGN = "BGN";
        public const string p_STR_N1 = "N1";
        public const string p_STR_INS = "INS";
        public const string p_STR_REF = "REF";
        public const string p_STR_NM1 = "NM1";
        public const string p_STR_PER = "PER";
        public const string p_STR_N3 = "N3";
        public const string p_STR_N4 = "N4";
        public const string p_STR_DMG = "DMG";
        public const string p_STR_HD = "HD";
        public const string p_STR_DTP = "DTP";
        public const string p_STR_SE = "SE";
        public const string p_STR_GE = "GE";
        public const string p_STR_IEA = "IEA";
        public const string p_STR_DATEFORMAT_1 = "yyMMdd";
        public const string p_STR_DATEFORMAT_2 = "yyyyMMdd";
        public const string p_STR_TIMEFORMAT = "HHmm";
        public const string p_COL_ISA01_VAL = "00";
        public const string p_COL_ISA05_VAL = "ZZ";
        public const string p_COL_ISA07_VAL = "33";
        public const string p_COL_ISA11_VAL = "^";
        public const string p_COL_ISA12_VAL = "00501";
        public const string p_COL_ISA16_VAL = "|";
        public const string p_COL_GS01_VAL = "BE";
        public const string p_COL_GS06_VAL = "101";
        public const string p_COL_GS07_VAL = "X";
        public const string p_COL_GS08_VAL = "005010X220";
        public const string p_COL_ST01_VAL = "834";
        public const string p_COL_ST03_VAL = "005010X220";
        public const string p_COL_BGN01_VAL = "00";
        public const string p_COL_BGN08_VAL_D = "2";
        public const string p_COL_BGN08_VAL_Q = "4";
        public const string p_COL_1000A_N101_VAL = "P5";
        public const string p_COL_1000A_N102_VAL = "BCBSNC";
        public const string p_COL_1000A_N103_VAL = "FI";//"ZZ";
        public const string p_COL_1000A_N104_VAL = "560894904";
        public const string p_COL_1000B_N101_VAL = "IN";
        public const string p_COL_1000B_N102_VAL = "MBH";
        public const string p_COL_1000B_N103_VAL = "FI";
        public const string p_COL_1000B_N104_VAL = "522135463";
        public const string p_COL_2000_REF01_SUBSCRIBER_VAL = "0F";
        public const string p_COL_2000_REF01_GROUP_VAL = "1L";
        public const string p_COL_2000_DTP01_DATE_VAL = "303";
        public const string p_STR_DATE_TIME_FORMAT = "D8";
        public const string p_STR_DATE_TIME_QULIFIER_348 = "348";
        public const string p_STR_DATE_TIME_QULIFIER_349 = "349";
        public const string p_STR_DATE_TIME_QULIFIER_356 = "356";
        public const string p_STR_DATE_TIME_QULIFIER_357 = "357";
        public const string p_COL_2100A_NM101_VAL = "IL";
        public const string p_COL_2100A_NM102_VAL = "1";
        public const string p_COL_2100A_NM108_VAL = "34";
        public const string p_COL_2000_INS05_VAL = "A";
        public const string p_COL_2100A_PER01_VAL = "IP";
        public const string p_COL_2100A_PER03_VAL = "HP";
        public const string p_COL_2100C_NM101_VAL = "31";
        public const string p_COL_2100C_NM102_VAL = "1";
        public const string p_COL_IEA01_VAL = "A";
        public const string p_COL_SE01_VAL = "ESA";
        public const string p_COL_SE02_VAL = "1001";

        //Columns from table tpzt_magellan_member_extr
        public const string p_COL_ISA13 = "ISA13";
        public const string p_COL_GS06 = "GS06";
        public const string p_COL_SE02 = "SE02";
        public const string p_COL_2000_INS01_IS_SUBSCRIBER = "2000_INS01_IS_SUBSCRIBER";
        public const string p_COL_2000_INS02_F_RELATION = "2000_INS02_F_RELATION";
        public const string p_COL_2000_INS03 = "2000_INS03";
        public const string p_COL_2000_REF02_F_SUBSCRIBER_ID = "2000_REF02_F_SUBSCRIBER_ID";
        public const string p_COL_2000_REF02_F_GROUP_ID = "2000_REF02_F_GROUP_ID";
        public const string p_COL_2100A_NM103_F_LAST_NAME = "2100A_NM103_F_LAST_NAME";
        public const string p_COL_2100A_NM104_F_FIRST_NAME = "2100A_NM104_F_FIRST_NAME";
        public const string p_COL_2100A_NM105_F_MIDDLE_INIT = "2100A_NM105_F_MIDDLE_INIT";
        public const string p_COL_2100A_NM107_F_TITLE = "2100A_NM107_F_TITLE";
        public const string p_COL_2100A_N301_F_ADDRESS_1 = "2100A_N301_F_ADDRESS_1";
        public const string p_COL_2100A_N302_F_ADDRESS_2 = "2100A_N302_F_ADDRESS_2";
        public const string p_COL_2100A_N401_F_CITY = "2100A_N401_F_CITY";
        public const string p_COL_2100A_N402_F_STATE = "2100A_N402_F_STATE";
        public const string p_COL_2100A_N403_F_ZIP = "2100A_N403_F_ZIP";
        public const string p_COL_2100A_DMG02_F_BIRTH_DATE = "2100A_DMG02_F_BIRTH_DATE";
        public const string p_COL_2100A_DMG03_F_GENDER = "2100A_DMG03_F_GENDER";
        public const string p_COL_2300_HD01 = "2300_HD01";
        public const string p_COL_2300_HD03 = "2300_HD03";
        public const string p_COL_2300_HD04_F_CSPI_ID = "2300_HD04_F_CSPI_ID";
        public const string p_COL_2300_DTP01 = "2300_DTP01";
        public const string p_COL_2300_DTP02 = "2300_DTP02";
        public const string p_COL_2300_DTP03_F_FROM_DATE = "2300_DTP03_F_FROM_DATE";
        public const string p_COL_2300_DTP03_F_TERM_DATE = "2300_DTP03_F_TERM_DATE";
        public const string p_COL_2300_DTP03_F_GROUP_FROM_DATE = "2300_DTP03_F_GROUP_FROM_DATE";
        public const string p_COL_2300_DTP03_F_GROUP_TERM_DATE = "2300_DTP03_F_GROUP_TERM_DATE";
        ////834 XML Segments
        #region"Segments"
        //public const string p_XML_TAG_THG834X2 = "THG834X2";
        //public const string p_XML_TAG_TZG_IPROC = "TZG_IProc";
        //public const string p_XML_TAG_THG_IPROC = "THG_IProc";
        //public const string p_XML_TAG_PRODUCT_SPECIFICS = "ProductSpecifics";
        //public const string p_XML_TAG_PRODUCT = "Product";
        //public const string p_XML_TAG_X12_DELIMITERS = "X12_Delimiters";
        //public const string p_XML_TAG_ELEMENTDELIMITER = "ElementDelimiter";
        //public const string p_XML_TAG_SUB_ELEMENT_DELIMITER = "SubElementDelimiter";
        //public const string p_XML_TAG_SEGMENT_DELIMITER = "SegmentDelimiter";
        //public const string p_XML_TAG_X12_ENVELOPE = "X12_Envelope";

        //////ISA Segments
        //public const string p_XML_TAG_ISA = "ISA__InterchangeControlHeader";
        //public const string p_XML_TAG_ISA01 = "ISA01__AuthorizationInformationQualifier";
        //public const string p_XML_TAG_ISA02 = "ISA02__AuthorizationInformation";
        //public const string p_XML_TAG_ISA03 = "ISA03__SecurityInformationQualifier";
        //public const string p_XML_TAG_ISA04 = "ISA04__SecurityInformation";
        //public const string p_XML_TAG_ISA05 = "ISA05__InterchangeIDQualifier";
        //public const string p_XML_TAG_ISA06 = "ISA06__InterchangeSenderID";
        //public const string p_XML_TAG_ISA07 = "ISA07__InterchangeIDQualifier";
        //public const string p_XML_TAG_ISA08 = "ISA08__InterchangeReceiverID";
        //public const string p_XML_TAG_ISA09 = "ISA09__InterchangeDate";
        //public const string p_XML_TAG_ISA10 = "ISA10__InterchangeTime";
        //public const string p_XML_TAG_ISA11 = "ISA11__RepetitionSeparator";
        //public const string p_XML_TAG_ISA12 = "ISA12__InterchangeControlVersionNumber";
        //public const string p_XML_TAG_ISA13 = "ISA13__InterchangeControlNumber";
        //public const string p_XML_TAG_ISA14 = "ISA14__AcknowledgmentRequested";
        //public const string p_XML_TAG_ISA15 = "ISA15__InterchangeUsageIndicator";
        //public const string p_XML_TAG_ISA16 = "ISA16__ComponentElementSeparator";

        //////GS Segments
        //public const string p_XML_TAG_GS = "GS__FunctionalGroupHeader";
        //public const string p_XML_TAG_GS01 = "GS01__FunctionalIdentifierCode";
        //public const string p_XML_TAG_GS02 = "GS02__ApplicationSendersCode";
        //public const string p_XML_TAG_GS03 = "GS03__ApplicationReceiversCode";
        //public const string p_XML_TAG_GS04 = "GS04__Date";
        //public const string p_XML_TAG_GS05 = "GS05__Time";
        //public const string p_XML_TAG_GS06 = "GS06__GroupControlNumber";
        //public const string p_XML_TAG_GS07 = "GS07__ResponsibleAgencyCode";
        //public const string p_XML_TAG_GS08 = "GS08__VersionReleaseIndustryIdentifierCode";

        //////ST Segments
        //public const string p_XML_TAG_THG834X2_ST = "THG834X2__ST__TransactionSetHeader";
        //public const string p_XML_TAG_THG834X2_ST01 = "THG834X2__ST01__TransactionSetIdentifierCode";
        //public const string p_XML_TAG_THG834X2_ST02 = "THG834X2__ST02__TransactionSetControlNumber";
        //public const string p_XML_TAG_THG834X2_ST03 = "THG834X2__ST03__ImplementationGuideVersionName";

        //////Beginning Segments
        //public const string p_XML_TAG_THG834X2_BGN = "THG834X2__BGN__BeginningSegment";
        //public const string p_XML_TAG_THG834X2_BGN01 = "THG834X2__BGN01__TransactionSetPurposeCode";
        //public const string p_XML_TAG_THG834X2_BGN02 = "THG834X2__BGN02__TransactionSetReferenceNumber";
        //public const string p_XML_TAG_THG834X2_BGN03 = "THG834X2__BGN03__TransactionSetCreationDate";
        //public const string p_XML_TAG_THG834X2_BGN04 = "THG834X2__BGN04__TransactionSetCreationTime";
        //public const string p_XML_TAG_THG834X2_BGN08 = "THG834X2__BGN08__ActionCode";

        //////THG834X2_1000A Segment
        //public const string p_XML_TAG_THG834X2_1000A = "THG834X2_1000A";
        //public const string p_XML_TAG_THG834X2_1000A_N1 = "THG834X2_1000A_N1__SponsorName";
        //public const string p_XML_TAG_THG834X2_1000A_N101 = "THG834X2_1000A_N101__EntityIdentifierCode";
        //public const string p_XML_TAG_THG834X2_1000A_N102 = "THG834X2_1000A_N102__PlanSponsorName";
        //public const string p_XML_TAG_THG834X2_1000A_N103 = "THG834X2_1000A_N103__IdentificationCodeQualifier";
        //public const string p_XML_TAG_THG834X2_1000A_N104 = "THG834X2_1000A_N104__SponsorIdentifier";

        ////////THG834X2_1000B Segment
        //public const string p_XML_TAG_THG834X2_1000B = "THG834X2_1000B";
        //public const string p_XML_TAG_THG834X2_1000B_N1 = "THG834X2_1000B_N1__Payer";
        //public const string p_XML_TAG_THG834X2_1000B_N101 = "THG834X2_1000B_N101__EntityIdentifierCode";
        //public const string p_XML_TAG_THG834X2_1000B_N102 = "THG834X2_1000B_N102__InsurerName";
        //public const string p_XML_TAG_THG834X2_1000B_N103 = "THG834X2_1000B_N103__IdentificationCodeQualifier";
        //public const string p_XML_TAG_THG834X2_1000B_N104 = "THG834X2_1000B_N104__InsurerIdentificationCode";

        //////THG834X2_2000 Segment
        //public const string p_XML_TAG_THG834X2_2000 = "THG834X2_2000";
        //public const string p_XML_TAG_THG834X2_2000_INS = "THG834X2_2000_INS__MemberLevelDetail";
        //public const string p_XML_TAG_THG834X2_2000_INS01 = "THG834X2_2000_INS01__MemberIndicator";
        //public const string p_XML_TAG_THG834X2_2000_INS02 = "THG834X2_2000_INS02__IndividualRelationshipCode";
        //public const string p_XML_TAG_THG834X2_2000_INS03 = "THG834X2_2000_INS03__MaintenanceTypeCode";
        //public const string p_XML_TAG_THG834X2_2000_INS05 = "THG834X2_2000_INS05__BenefitStatusCode";
        //public const string p_XML_TAG_THG834X2_2000_INS06_C052 = "THG834X2_2000_INS06_C052";
        //public const string p_XML_TAG_THG834X2_2000_INS06_C05201 = "THG834X2_2000_INS06_C05201_MedicarePlanCode";
        //public const string p_XML_TAG_THG834X2_2000_INS08 = "THG834X2_2000_INS08__EmploymentStatusCode";
        //public const string p_XML_TAG_THG834X2_2000_INS09 = "THG834X2_2000_INS09__StudentStatusCode";
        //public const string p_XML_TAG_THG834X2_2000_INS10 = "THG834X2_2000_INS10__HandicapIndicator";
        //public const string p_XML_TAG_THG834X2_2000_REF_SUBSCRIBER_IDENTIFIER = "THG834X2_2000_REF__SubscriberIdentifier";
        //public const string p_XML_TAG_THG834X2_2000_REF01_REFERENCE_IDENTIFICATION_QUALIFIER = "THG834X2_2000_REF01__ReferenceIdentificationQualifier";
        //public const string p_XML_TAG_THG834X2_2000_REF02_SUBSCRIBER_IDENTIFIER = "THG834X2_2000_REF02__SubscriberIdentifier";
        //public const string p_XML_TAG_THG834X2_2000_REF_MEMBER_POLICY_NUMBER = "THG834X2_2000_REF__MemberPolicyNumber";
        ////public const string p_XML_TAG_THG834X2_2000_REF01_REFERENCE_IDENTIFICATION_QUALIFIER = "THG834X2_2000_REF01__ReferenceIdentificationQualifier";
        //public const string p_XML_TAG_THG834X2_2000_REF02_MEMBER_GROUP_OR_POLICYNUMBER = "THG834X2_2000_REF02__MemberGrouporPolicyNumber";

        //////THG834X2_2100A Segment

        //public const string p_XML_TAG_THG834X2_2100A = "THG834X2_2100A";
        //public const string p_XML_TAG_THG834X2_2100A_NM1 = "THG834X2_2100A_NM1__MemberName";
        //public const string p_XML_TAG_THG834X2_2100A_NM101 = "THG834X2_2100A_NM101__EntityIdentifierCode";
        //public const string p_XML_TAG_THG834X2_2100A_NM102 = "THG834X2_2100A_NM102__EntityTypeQualifier";
        //public const string p_XML_TAG_THG834X2_2100A_NM103 = "THG834X2_2100A_NM103__MemberLastName";
        //public const string p_XML_TAG_THG834X2_2100A_NM104 = "THG834X2_2100A_NM104__MemberFirstName";
        //public const string p_XML_TAG_THG834X2_2100A_NM105 = "THG834X2_2100A_NM105__MemberMiddleName";
        //public const string p_XML_TAG_THG834X2_2100A_NM107 = "THG834X2_2100A_NM107__MemberNameSuffix";
        //public const string p_XML_TAG_THG834X2_2100A_NM108 = "THG834X2_2100A_NM108__IdentificationCodeQualifier";
        //public const string p_XML_TAG_THG834X2_2100A_NM109 = "THG834X2_2100A_NM109__MemberIdentifier";
        //public const string p_XML_TAG_THG834X2_2100A_PER = "THG834X2_2100A_PER__MemberCommunicationsNumbers";
        //public const string p_XML_TAG_THG834X2_2100A_PER01 = "THG834X2_2100A_PER01__ContactFunctionCode";
        //public const string p_XML_TAG_THG834X2_2100A_PER03 = "THG834X2_2100A_PER03__CommunicationNumberQualifier";
        //public const string p_XML_TAG_THG834X2_2100A_PER04 = "THG834X2_2100A_PER04__CommunicationNumber";
        //public const string p_XML_TAG_THG834X2_2100A_N3 = "THG834X2_2100A_N3__MemberResidenceStreetAddress";
        //public const string p_XML_TAG_THG834X2_2100A_N301 = "THG834X2_2100A_N301__MemberAddressLine";
        //public const string p_XML_TAG_THG834X2_2100A_N302 = "THG834X2_2100A_N302__MemberAddressLine";
        //public const string p_XML_TAG_THG834X2_2100A_N4 = "THG834X2_2100A_N4__MemberCityStateZIPCode";
        //public const string p_XML_TAG_THG834X2_2100A_N401 = "THG834X2_2100A_N401__MemberCityName";
        //public const string p_XML_TAG_THG834X2_2100A_N402 = "THG834X2_2100A_N402__MemberStateCode";
        //public const string p_XML_TAG_THG834X2_2100A_N403 = "THG834X2_2100A_N403__MemberPostalZoneorZipCode";
        //public const string p_XML_TAG_THG834X2_2100A_N404 = "THG834X2_2100A_N404__CountryCode";
        //public const string p_XML_TAG_THG834X2_2100A_DMG = "THG834X2_2100A_DMG__MemberDemographics";
        //public const string p_XML_TAG_THG834X2_2100A_DMG01 = "THG834X2_2100A_DMG01__DateTimePeriodFormatQualifier";
        //public const string p_XML_TAG_THG834X2_2100A_DMG02 = "THG834X2_2100A_DMG02__MemberBirthDate";
        //public const string p_XML_TAG_THG834X2_2100A_DMG03 = "THG834X2_2100A_DMG03__GenderCode";

        ////THG834X2_2100C Segmnet
        //public const string p_XML_TAG_THG834X2_2100C = "THG834X2_2100C";
        //public const string p_XML_TAG_THG834X2_2100C_NM1 = "THG834X2_2100C_NM1__MemberMailingAddress";
        //public const string p_XML_TAG_THG834X2_2100C_NM101 = "THG834X2_2100C_NM101__EntityIdentifierCode";
        //public const string p_XML_TAG_THG834X2_2100C_NM102 = "THG834X2_2100C_NM102__EntityTypeQualifier";
        //public const string p_XML_TAG_THG834X2_2100C_N3 = "THG834X2_2100C_N3__MemberMailStreetAddress";
        //public const string p_XML_TAG_THG834X2_2100C_NM301 = "THG834X2_2100C_N301__MemberAddressLine";
        //public const string p_XML_TAG_THG834X2_2100C_NM302 = "THG834X2_2100C_N302__MemberAddressLine";
        //public const string p_XML_TAG_THG834X2_2100C_N4 = "THG834X2_2100C_N4__MemberMailCityStateZIPCode";
        //public const string p_XML_TAG_THG834X2_2100C_NM401 = "THG834X2_2100C_N401__MemberMailCityName";
        //public const string p_XML_TAG_THG834X2_2100C_NM402 = "THG834X2_2100C_N402__MemberMailStateCode";
        //public const string p_XML_TAG_THG834X2_2100C_NM403 = "THG834X2_2100C_N403__MemberMailPostalZoneorZIPCode";
        //public const string p_XML_TAG_THG834X2_2100C_NM404 = "THG834X2_2100C_N404__CountryCode";

        //////THG834X2_2300 Segment
        //public const string p_XML_TAG_THG834X2_2300 = "THG834X2_2300";
        //public const string p_XML_TAG_THG834X2_2300_HD = "THG834X2_2300_HD__HealthCoverage";
        //public const string p_XML_TAG_THG834X2_2300_HD01 = "THG834X2_2300_HD01__MaintenanceTypeCode";
        //public const string p_XML_TAG_THG834X2_2300_HD03 = "THG834X2_2300_HD03__InsuranceLineCode";
        //public const string p_XML_TAG_THG834X2_2300_HD04 = "THG834X2_2300_HD04__PlanCoverageDescription";
        //public const string p_XML_TAG_THG834X2_2300_HD05 = "THG834X2_2300_HD05__CoverageLevelCode";
        //public const string p_XML_TAG_THG834X2_2300_DTP = "THG834X2_2300_DTP__HealthCoverageDates";
        //public const string p_XML_TAG_THG834X2_2300_DTP01 = "THG834X2_2300_DTP01__DateTimeQualifier";
        //public const string p_XML_TAG_THG834X2_2300_DTP02 = "THG834X2_2300_DTP02__DateTimePeriodFormatQualifier";
        //public const string p_XML_TAG_THG834X2_2300_DTP03 = "THG834X2_2300_DTP03__CoveragePeriod";

        ////THG834X2__SE__TransactionSetTrailer Segment
        //public const string p_XML_TAG_THG834X2_SE = "THG834X2__SE__TransactionSetTrailer";
        //public const string p_XML_TAG_THG834X2_SE01 = "THG834X2__SE01__TransactionSegmentCount";
        //public const string p_XML_TAG_THG834X2_SE02 = "THG834X2__SE02__TransactionSetControlNumber";
        #endregion
        // Log messages
        public const string p_LOG_PARAM_COUNT = "Parameters Passed - Count: ";
        public const string p_LOG_MTM_STARTED = "Magellan Membership Extract Program Started";
        public const string p_LOG_DB_SERVER_LOC = "DB Server Location: ";
        public const string p_LOG_DB_NAME = "Stage DB Name: ";
        public const string p_LOG_IN_DIR = "Input Directory: ";
        public const string p_LOG_OUTPUT_DIR = "Output Directory: ";
        public const string p_LOG_FILE_NAME = "File Name: ";
        public const string p_LOG_SENDER_ID = "Sender Id: ";
        public const string p_LOG_RECEIVER_ID = "Receiver Id: ";
        public const string p_LOG_ENVIRONMENT = "Environment: ";
        public const string p_LOG_DATA_IMPORTED = "Magellan tpzt_magellan_member_extr Table Import – Data Imported: ";
        public const string p_LOG_COMPLETED_SUCCESS = "Magellan Membership Extract Program completed successfully.";
        public const string p_LOG_NO_TABLE = "No Table Found.Check Database Conncetion.";
        public const string p_LOG_NO_TABLE_DATA = "No Data Found In Table.Check Database.";
        public const string p_LOG_SP_START = "Executing Magellan Stored Procedure tpzp_magellan_member_extr.";
        public const string p_LOG_XML_START = "Started Creation of XML file for Magellan Membership Extract.";
        public const string p_LOG_XML_END = "Creation of  XML file completed for Magellan Membership Extract.";
        public const string p_LOG_EDI_START = "Started Creation of EDI file for Magellan Membership Extract.";
        public const string p_LOG_EDI_FILE_PATH = "Started Creation of EDI file for Magellan Membership Extract at location .";
        public const string p_LOG_EDI_END = "Creation of  EDI file completed for Magellan Membership Extract.";
        public const string p_LOG_RECORD_INFO = "INS03 and HD01 value is blank or null";


        // Error messages
        public const string p_LOG_PARAM_NOT_VALID = "Parameters are not valid";
        public const string p_LOG_PARAM_NOT_IN_FORMAT = "Some of the parameters are not in correct format.";
        public const string p_LOG_ERR_INVALID_PATH = "Input/Output Path is invalid or directory doesn't exists";
        public const string p_LOG_COMPLETED_WITH_ERROR = "Magellan Membership Extract Program completed with error. Error Code: ";

        // Possible Input file extensions
        public const string p_IN_FILE_PATTERN_XML = ".xml";
        public const string p_IN_FILE_PATTERN_EDI = ".edi";

        // Datatype of columns for making the datatable according to custom tables
        public const string p_DATATYPE_STRING = "System.String";
        public const string p_DATATYPE_INT32 = "System.Int32";
        public const string p_DATATYPE_DTM = "System.DateTime";

        // Stored Procedure to truncate the custom tables
        public const string p_SP_Extract_Magellan_Membership_Data = "tpzp_magellan_member_extr";
    }
}
