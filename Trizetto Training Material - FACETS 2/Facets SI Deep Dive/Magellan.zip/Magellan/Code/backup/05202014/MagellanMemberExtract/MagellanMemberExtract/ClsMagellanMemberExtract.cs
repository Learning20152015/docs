﻿// ClsMagellanMemberExtract.cs
//
// Assembly:
//    MagellanMemberExtract.dll
//
// Description:
//   Magellan Membership Extract
// --------------------------------------------------------------
// 
// Copyright © 2008-2014 The TriZetto Group, Inc.
// All rights reserved.
// Warning:  This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of
// this program, or any portion of it, may result in severe civil and
// criminal penalties, and will be prosecuted to the maximum extent
// possible under the law.
// This source code is the confidential and proprietary information of The
// TriZetto Group, Inc.
// You shall not disclose such Confidential Information to any third parties
// and shall use it only in accordance with the terms of the license agreement
// you entered into with The TriZetto Group, Inc.
// This source code and information is provided "as is" without warranty
// of any kind, either expressed or implied, including but not limited to
// the implied warranties of merchantability and/or fitness for a particular
// purpose.
// Author : The TriZetto Corporation
// -----------------------------------------------------------------------------
// Revision History:
// 1.0   03-25-2014   Amol Sangar    Initial creation..
// 1.1   04-25-2014   Amol Sangar    Updated..
// 1.2   04-29-2014   Amol Sangar    Updated with Headers,Details and Trailors of file..
// 1.3   05-12-2014   Amol Sangar    Removed spaces.
// 1.4   05-14-2014   Amol Sangar    Added Group DTP at 2000 and removed from 2300.
//-------------------------------------------------------------------------------
using System;
using System.Collections;
using System.Data;
using System.IO;
using System.Text;
using InterfaceFramework;
using System.Xml.Linq;

namespace MagellanMemberExtract
{
    public class ClsMagellanMemberExtract
    {
        // object for logging the processing activity of the application
        ConsoleLogger objConsoleLogger;

        // object for performing sql/database functions
        SqlServerHelper objSqlHelper;
        // Initializing the return variable
        bool boolRetVal = true;

        /// <summary>
        /// Constructor for Magellan Membership Extract Class
        /// </summary>
        /// <param name="objLogger">Logger Object</param>
        /// <param name="strDbServerLocation">Database Server Location for connecting to SQL Server</param>
        /// <param name="strCstmDbName">Name of the Custom Database</param>
        /// <param name="strUserName">User Name</param>
        /// <param name="strPassword">Password</param>

        public ClsMagellanMemberExtract(ConsoleLogger objLogger, string strDbServerLocation, string strCstmDbName, string strUserName, string strPassword)
        {
            // Initializing object for ConsoleLogger class
            this.objConsoleLogger = objLogger;
            // Initializing object for SqlServerHelper class
            objSqlHelper = new SqlServerHelper(objConsoleLogger, strCstmDbName, strUserName, strPassword, strDbServerLocation);

        }

        /// <summary>
        /// Entry point for execution for Magellan Membership Extract.
        /// </summary>
        /// <param name="strOutputDir">Output Directory</param>
        /// <returns>Boolean True - Success, False - Failure</returns>

        public bool ExecuteInterface(string strOutputDir, string strFrequency, string strFileName, string strSenderId, string strReceiverId, string strENV)
        {
            // Initializing the DataSet
            DataSet dsOutputDataset = null;
            try
            {
                if (!Directory.Exists(strOutputDir))
                {
                    objConsoleLogger.Write(ClsConstants.p_LOG_ERR_INVALID_PATH);
                    boolRetVal = false;
                }
                else
                {
                    // Opening the sql server connection
                    objSqlHelper.Open();
                    Hashtable objHastParams;
                    objHastParams = new Hashtable(ClsConstants.p_VALUE_ONE);
                    //DAILY or QUARTERLY
                    objHastParams[ClsConstants.p_STR_FREQUENCY] = strFrequency;
                    objConsoleLogger.Write(ClsConstants.p_LOG_SP_START);
                    // Executing the procedure ClsConstants.p_SP_Extract_Magellan_Membership_Data and storing the result in dataset dsOutputDataset 
                    dsOutputDataset = objSqlHelper.ExecuteProcedure(ClsConstants.p_SP_Extract_Magellan_Membership_Data, objHastParams);
                    objConsoleLogger.Write(ClsConstants.p_LOG_DATA_IMPORTED);
                    objConsoleLogger.Write(ClsConstants.p_LOG_EDI_START);
                    boolRetVal = WriteDataToEDIFile(dsOutputDataset, strOutputDir, strFileName, strSenderId, strReceiverId, strENV, strFrequency);
                    //boolRetVal = WriteDataToXMLFile(dsOutputDataset, strOutputDir, strFileName, strSenderId, strReceiverId, strENV);
                    objConsoleLogger.Write(ClsConstants.p_LOG_EDI_END);
                }
            }
            catch (Exception ex)
            {
                objConsoleLogger.Write(ex.Message + Environment.NewLine);
            }
            finally
            {
                dsOutputDataset.Dispose();
            }
            return (boolRetVal);
        }

        /// <summary>
        /// Create edi file as per data with respective frequency run
        /// </summary>
        /// <param name="objResultSet">Data from facets database</param>
        /// <param name="strOutputDir">Directory name at which file will be stored</param>
        /// <param name="strFileName">File name as per frequency Daily/Quarterly</param>
        /// <param name="strSenderId">Sender id</param>
        /// <param name="strReceiverId">receiver id</param>
        /// <param name="strENV">Environment T/P</param>
        /// <returns></returns>
        private bool WriteDataToEDIFile(DataSet objResultSet, string strOutputDir, string strFileName, string strSenderId, string strReceiverId, string strENV, string strFrequency)
        {
            StringBuilder sbEnrollmentData = new StringBuilder();
            string strISA06_SenderID = string.Empty;
            string strISA08_ReceiverID = string.Empty;
            string strISA15_Indicator = string.Empty;
            string strCurrSubscriberID = string.Empty;
            int intSegmentCount = 0;
            string strX12FileData = string.Empty;
            string strSpace = string.Empty;
            int intCounterNoValue = 0;

            try
            {
                strISA06_SenderID = strSenderId;
                strISA08_ReceiverID = strReceiverId;
                strISA15_Indicator = strENV;
                if (strISA06_SenderID.Length < 15)
                {
                    strISA06_SenderID = strISA06_SenderID.PadRight(15, ClsConstants.p_CH_SPACE);
                }
                if (strISA08_ReceiverID.Length < 15)
                {
                    strISA08_ReceiverID = strISA08_ReceiverID.PadRight(15, ClsConstants.p_CH_SPACE);

                }
                strSpace = strSpace.PadRight(10, ClsConstants.p_CH_SPACE);

                //Log File Directory and File Path
                objConsoleLogger.Write(ClsConstants.p_LOG_EDI_FILE_PATH + strOutputDir + ClsConstants.p_STR_DOUBLE_SLASH + strFileName + ClsConstants.p_IN_FILE_PATTERN_EDI);
                //Create edi file using StreamWriter
                using (StreamWriter swCreateEdiFile = File.CreateText(strOutputDir + ClsConstants.p_STR_DOUBLE_SLASH + strFileName + ClsConstants.p_IN_FILE_PATTERN_EDI))
                {
                    #region"Transaction Set"
                    //Valiadate table is present or not
                    if (objResultSet.Tables.Count > 0)
                    {
                        //Validate rows are present or not
                        if (objResultSet.Tables[0].Rows.Count > 0)
                        {
                            
                            #region"Header"
                            #region"ISA"
                            swCreateEdiFile.Write(ClsConstants.p_STR_ISA);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ISA01_VAL);//ISA1
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(strSpace);//ISA2
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ISA01_VAL);//ISA3
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(strSpace);//ISA4
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ISA05_VAL);//ISA5
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(strISA06_SenderID);//ISA6
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ISA07_VAL);//ISA7
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(strISA08_ReceiverID);//ISA8
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(DateTime.Now.ToString(ClsConstants.p_STR_DATEFORMAT_1));//ISA9
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(DateTime.Now.ToString(ClsConstants.p_STR_TIMEFORMAT));//ISA10
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ISA11_VAL);//ISA11
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ISA12_VAL);//ISA12
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[0][ClsConstants.p_COL_ISA13]).Trim());//ISA13
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(0);//ISA14
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(strISA15_Indicator);//ISA15
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ISA16_VAL);//ISA16
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            #endregion

                            #region"GS"
                            swCreateEdiFile.Write(ClsConstants.p_STR_GS);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_GS01_VAL);//GS01
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(strISA06_SenderID.Trim());//GS02
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(strISA08_ReceiverID.Trim());//GS03
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(DateTime.Now.ToString(ClsConstants.p_STR_DATEFORMAT_2));//GS04
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(DateTime.Now.ToString(ClsConstants.p_STR_TIMEFORMAT));//GS05
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[0][ClsConstants.p_COL_GS06]).Trim());//GS06
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_GS07_VAL);//GS07
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_GS08_VAL);//GS08
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            #endregion

                            intSegmentCount = 1;
                            #region"ST"
                            swCreateEdiFile.Write(ClsConstants.p_STR_ST);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ST01_VAL);//ST01
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[0][ClsConstants.p_COL_SE02]).Trim());//(ClsConstants.p_COL_GS06_VAL);//ST02
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ST03_VAL);//ST03
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            intSegmentCount += 1;
                            #endregion

                            #region"BGN"
                            swCreateEdiFile.Write(ClsConstants.p_STR_BGN);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_BGN01_VAL);//BGN01
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[0][ClsConstants.p_COL_GS06]).Trim());//BGN02
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(DateTime.Now.ToString(ClsConstants.p_STR_DATEFORMAT_2));//BGN03
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(DateTime.Now.ToString(ClsConstants.p_STR_TIMEFORMAT));//BGN04
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            if (strFrequency == ClsConstants.p_STR_FREQUENCY_DAILY)
                            {
                                swCreateEdiFile.Write(ClsConstants.p_COL_BGN08_VAL_D);//BGN08
                            }
                            else if (strFrequency == ClsConstants.p_STR_FREQUENCY_QUARTERLY)
                            {
                                swCreateEdiFile.Write(ClsConstants.p_COL_BGN08_VAL_Q);//BGN08
                            }

                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            intSegmentCount += 1;
                            #endregion

                            #region"1000A"
                            swCreateEdiFile.Write(ClsConstants.p_STR_N1);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000A_N101_VAL);//N101
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000A_N102_VAL);//N102
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000A_N103_VAL);//N103
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000A_N104_VAL);//N104
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            intSegmentCount += 1;
                            #endregion

                            #region"1000B"
                            swCreateEdiFile.Write(ClsConstants.p_STR_N1);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000B_N101_VAL);//N101
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000B_N102_VAL);//N102
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000B_N103_VAL);//N103
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000B_N104_VAL);//N104
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            intSegmentCount += 1;
                            #endregion
                            #endregion

                            #region"Detail"
                            for (int i = 0; i < objResultSet.Tables[0].Rows.Count; i++)
                            {
                                if (!string.IsNullOrEmpty(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS03].ToString())
                                && !string.IsNullOrEmpty(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD01].ToString()))
                                {
                                    #region"2000"
                                    #region"INS"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_INS);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS01_IS_SUBSCRIBER]);//INS01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS02_F_RELATION]);//INS02
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS03]);//INS03
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_COL_2000_INS05_VAL);//INS05
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #region"REF_SubscriberIdentifier"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_REF);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_COL_2000_REF01_SUBSCRIBER_VAL);//REF01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_REF02_F_SUBSCRIBER_ID]);//REF02
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #region"REF_MemberPolicyNumber"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_REF);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_COL_2000_REF01_GROUP_VAL);//REF01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_REF02_F_GROUP_ID]);//REF02
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #region"MemberLevelDates"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DTP);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_COL_2000_DTP01_DATE_VAL);//DTP01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(DateTime.Now.ToString(ClsConstants.p_STR_DATEFORMAT_2));//DTP03
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #region"DTP_Group Effective Date"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DTP);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_QULIFIER_356);//DTP01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_GROUP_FROM_DATE]).Trim()))
                                    {
                                        swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                        swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_GROUP_FROM_DATE]).Trim());//DTP03
                                    }
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #region"DTP_Group Expiration Date"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DTP);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_QULIFIER_357);//DTP01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_GROUP_TERM_DATE]).Trim()))
                                    {
                                        swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                        swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_GROUP_TERM_DATE]).Trim());//DTP03
                                    }
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion
                                    #endregion

                                    #region"2100A"
                                    #region"NM1"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_NM1);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_COL_2100A_NM101_VAL);//NM101
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_COL_2100A_NM102_VAL);//NM102
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM103_F_LAST_NAME]).Trim()))
                                    {
                                        swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                        swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM103_F_LAST_NAME]).Trim());//NM103
                                    }
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM104_F_FIRST_NAME]).Trim()))
                                    {
                                        swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                        swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM104_F_FIRST_NAME]).Trim());//NM104
                                    }
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM105_F_MIDDLE_INIT]).Trim()))
                                    {
                                        swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                        swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM105_F_MIDDLE_INIT]).Trim());//NM105
                                    }
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);

                                    intSegmentCount += 1;

                                    #endregion

                                    #region"N3"
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N301_F_ADDRESS_1]).Trim()) ||
                                        !string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N302_F_ADDRESS_2]).Trim()))
                                    {
                                        swCreateEdiFile.Write(ClsConstants.p_STR_N3);
                                        if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N301_F_ADDRESS_1]).Trim()))
                                        {
                                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N301_F_ADDRESS_1]).Trim());//N301
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N302_F_ADDRESS_2]).Trim()))
                                        {
                                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N302_F_ADDRESS_2]).Trim());//N302
                                        }
                                        swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                        intSegmentCount += 1;
                                    }
                                    #endregion

                                    #region"N4"
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N401_F_CITY]).Trim()) ||
                                        !string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N402_F_STATE]).Trim()) ||
                                        !string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N403_F_ZIP]).Trim())
                                       )
                                    {
                                        swCreateEdiFile.Write(ClsConstants.p_STR_N4);
                                        if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N401_F_CITY]).Trim()))
                                        {
                                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N401_F_CITY]).Trim());//N401
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N402_F_STATE]).Trim()))
                                        {
                                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N402_F_STATE]).Trim());//N402
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N403_F_ZIP]).Trim()))
                                        {
                                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N403_F_ZIP]).Trim());//N403
                                        }
                                        swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                        intSegmentCount += 1;
                                    }
                                    #endregion

                                    #region"DMG"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DMG);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_FORMAT);
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG02_F_BIRTH_DATE]).Trim()) ||
                                        !string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG03_F_GENDER]).Trim()))
                                    {
                                        if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG02_F_BIRTH_DATE]).Trim()))
                                        {
                                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG02_F_BIRTH_DATE]).Trim());//DMG02
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG03_F_GENDER]).Trim()))
                                        {
                                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG03_F_GENDER]).Trim());//DMG03
                                        }
                                    }
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion
                                    #endregion

                                    #region"2300"
                                    #region"HD"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_HD);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD01]);//HD01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD03]);//HD03
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD04_F_CSPI_ID]).Trim()))
                                    {
                                        swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                        swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD04_F_CSPI_ID]).Trim());//HD04
                                    }
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #region"DTP_Benefit Begin Date"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DTP);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_QULIFIER_348);//DTP01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_FROM_DATE]).Trim()))
                                    {
                                        swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                        swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_FROM_DATE]).Trim());//DTP03
                                    }
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #region"DTP_Benefit End date"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DTP);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_QULIFIER_349);//DTP01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_TERM_DATE]).Trim()))
                                    {
                                        swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                        swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_TERM_DATE]).Trim());//DTP03
                                    }
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #endregion
                                }
                                else
                                {
                                    intCounterNoValue += 1;
                                    //Write record in log
                                    objConsoleLogger.Write(ClsConstants.p_LOG_RECORD_INFO);
                                    #region"2000"
                                    #region"INS"
                                    StringBuilder sb = new StringBuilder();
                                    sb.Append(ClsConstants.p_STR_INS);
                                    
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS01_IS_SUBSCRIBER].ToString());//INS01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS02_F_RELATION].ToString());//INS02
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS03].ToString());//INS03
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_COL_2000_INS05_VAL);//INS05
                                    sb.Append(ClsConstants.p_STR_TILT);
                                   
                                    #endregion

                                    #region"REF_SubscriberIdentifier"
                                    sb.Append(ClsConstants.p_STR_REF);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_COL_2000_REF01_SUBSCRIBER_VAL);//REF01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_REF02_F_SUBSCRIBER_ID].ToString());//REF02
                                    sb.Append(ClsConstants.p_STR_TILT);
                                   
                                    #endregion

                                    #region"REF_MemberPolicyNumber"
                                    sb.Append(ClsConstants.p_STR_REF);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_COL_2000_REF01_GROUP_VAL);//REF01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_REF02_F_GROUP_ID].ToString());//REF02
                                    sb.Append(ClsConstants.p_STR_TILT);
                                   
                                    #endregion

                                    #region"MemberLevelDates"
                                    sb.Append(ClsConstants.p_STR_DTP);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_COL_2000_DTP01_DATE_VAL);//DTP01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(DateTime.Now.ToString(ClsConstants.p_STR_DATEFORMAT_2));//DTP03
                                    sb.Append(ClsConstants.p_STR_TILT);
                                   
                                    #endregion

                                    #region"DTP_Group Effective Date"
                                    sb.Append(ClsConstants.p_STR_DTP);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_QULIFIER_356);//DTP01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_GROUP_FROM_DATE]).Trim()))
                                    {
                                        sb.Append(ClsConstants.p_STR_STAR);
                                        sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_GROUP_FROM_DATE]).Trim());//DTP03
                                    }
                                    sb.Append(ClsConstants.p_STR_TILT);
                                   
                                    #endregion

                                    #region"DTP_Group Expiration Date"
                                    sb.Append(ClsConstants.p_STR_DTP);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_QULIFIER_357);//DTP01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_GROUP_TERM_DATE]).Trim()))
                                    {
                                        sb.Append(ClsConstants.p_STR_STAR);
                                        sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_GROUP_TERM_DATE]).Trim());//DTP03
                                    }
                                    sb.Append(ClsConstants.p_STR_TILT);
                                   
                                    #endregion
                                    #endregion

                                    #region"2100A"
                                    #region"NM1"
                                    sb.Append(ClsConstants.p_STR_NM1);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_COL_2100A_NM101_VAL);//NM101
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_COL_2100A_NM102_VAL);//NM102
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM103_F_LAST_NAME]).Trim()))
                                    {
                                        sb.Append(ClsConstants.p_STR_STAR);
                                        sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM103_F_LAST_NAME]).Trim());//NM103
                                    }
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM104_F_FIRST_NAME]).Trim()))
                                    {
                                        sb.Append(ClsConstants.p_STR_STAR);
                                        sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM104_F_FIRST_NAME]).Trim());//NM104
                                    }
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM105_F_MIDDLE_INIT]).Trim()))
                                    {
                                        sb.Append(ClsConstants.p_STR_STAR);
                                        sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM105_F_MIDDLE_INIT]).Trim());//NM105
                                    }
                                    sb.Append(ClsConstants.p_STR_TILT);

                                   

                                    #endregion

                                    #region"N3"
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N301_F_ADDRESS_1]).Trim()) ||
                                        !string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N302_F_ADDRESS_2]).Trim()))
                                    {
                                        sb.Append(ClsConstants.p_STR_N3);
                                        if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N301_F_ADDRESS_1]).Trim()))
                                        {
                                            sb.Append(ClsConstants.p_STR_STAR);
                                            sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N301_F_ADDRESS_1]).Trim());//N301
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N302_F_ADDRESS_2]).Trim()))
                                        {
                                            sb.Append(ClsConstants.p_STR_STAR);
                                            sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N302_F_ADDRESS_2]).Trim());//N302
                                        }
                                        sb.Append(ClsConstants.p_STR_TILT);
                                       
                                    }
                                    #endregion

                                    #region"N4"
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N401_F_CITY]).Trim()) ||
                                        !string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N402_F_STATE]).Trim()) ||
                                        !string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N403_F_ZIP]).Trim())
                                       )
                                    {
                                        sb.Append(ClsConstants.p_STR_N4);
                                        if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N401_F_CITY]).Trim()))
                                        {
                                            sb.Append(ClsConstants.p_STR_STAR);
                                            sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N401_F_CITY]).Trim());//N401
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N402_F_STATE]).Trim()))
                                        {
                                            sb.Append(ClsConstants.p_STR_STAR);
                                            sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N402_F_STATE]).Trim());//N402
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N403_F_ZIP]).Trim()))
                                        {
                                            sb.Append(ClsConstants.p_STR_STAR);
                                            sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N403_F_ZIP]).Trim());//N403
                                        }
                                        sb.Append(ClsConstants.p_STR_TILT);
                                       
                                    }
                                    #endregion

                                    #region"DMG"
                                    sb.Append(ClsConstants.p_STR_DMG);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_FORMAT);
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG02_F_BIRTH_DATE]).Trim()) ||
                                        !string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG03_F_GENDER]).Trim()))
                                    {
                                        if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG02_F_BIRTH_DATE]).Trim()))
                                        {
                                            sb.Append(ClsConstants.p_STR_STAR);
                                            sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG02_F_BIRTH_DATE]).Trim());//DMG02
                                        }
                                        if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG03_F_GENDER]).Trim()))
                                        {
                                            sb.Append(ClsConstants.p_STR_STAR);
                                            sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG03_F_GENDER]).Trim());//DMG03
                                        }
                                    }
                                    sb.Append(ClsConstants.p_STR_TILT);
                                   
                                    #endregion
                                    #endregion

                                    #region"2300"
                                    #region"HD"
                                    sb.Append(ClsConstants.p_STR_HD);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD01].ToString());//HD01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD03].ToString());//HD03
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD04_F_CSPI_ID]).Trim()))
                                    {
                                        sb.Append(ClsConstants.p_STR_STAR);
                                        sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD04_F_CSPI_ID]).Trim());//HD04
                                    }
                                    sb.Append(ClsConstants.p_STR_TILT);
                                   
                                    #endregion

                                    #region"DTP_Benefit Begin Date"
                                    sb.Append(ClsConstants.p_STR_DTP);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_QULIFIER_348);//DTP01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_FROM_DATE]).Trim()))
                                    {
                                        sb.Append(ClsConstants.p_STR_STAR);
                                        sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_FROM_DATE]).Trim());//DTP03
                                    }
                                    sb.Append(ClsConstants.p_STR_TILT);
                                    
                                    #endregion

                                    #region"DTP_Benefit End date"
                                    sb.Append(ClsConstants.p_STR_DTP);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_QULIFIER_349);//DTP01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_TERM_DATE]).Trim()))
                                    {
                                        sb.Append(ClsConstants.p_STR_STAR);
                                        sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_TERM_DATE]).Trim());//DTP03
                                    }
                                    sb.Append(ClsConstants.p_STR_TILT);

                                    objConsoleLogger.Write(sb.ToString());
                                    sb.Remove(0, sb.Length);
                                    #endregion

                                    #endregion
                                }
                            }
                            #endregion

                            #region"Trailer"

                            #region"SE"
                            swCreateEdiFile.Write(ClsConstants.p_STR_SE);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(intSegmentCount);//SE01
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[0][ClsConstants.p_COL_SE02]).Trim());//(ClsConstants.p_COL_SE02_VAL);//SE02
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            intSegmentCount = 0;

                            #endregion

                            #region"GE"
                            swCreateEdiFile.Write(ClsConstants.p_STR_GE);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(1);//GE01
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[0][ClsConstants.p_COL_GS06]).Trim());//GE02
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            #endregion

                            #region"IEA"
                            swCreateEdiFile.Write(ClsConstants.p_STR_IEA);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_IEA01_VAL);//IEA01
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[0][ClsConstants.p_COL_ISA13]).Trim());//IEA02
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            #endregion
                            #endregion

                            if (objResultSet.Tables[0].Rows.Count == 1 && intCounterNoValue == 1)
                            {
                                swCreateEdiFile.Flush();
                                
                            }
                        }

                        else
                        {
                            objConsoleLogger.Write(ClsConstants.p_LOG_NO_TABLE_DATA);
                        }
                    }
                    else
                    {
                        objConsoleLogger.Write(ClsConstants.p_LOG_NO_TABLE);
                    }
                    #endregion
                }
                boolRetVal = true;
            }
            catch (Exception ex)
            {
                boolRetVal = false;
                throw ex;
            }
            return (boolRetVal);
        }

        #region"Code For XML"
        ///// <summary>
        ///// Write data to Text File
        ///// </summary>
        ///// <param name="objResultSet"></param>
        //private bool WriteDataToXMLFile(DataSet objResultSet, string strOutputDir, string strFileName, string strSenderId, string strReceiverId, string strENV)
        //{
        //    StringBuilder sbEnrollmentData = new StringBuilder();
        //    string strISA06_SenderID = string.Empty;
        //    string strISA08_ReceiverID = string.Empty;
        //    string strISA15_Indicator = string.Empty;
        //    string strCurrSubscriberID = string.Empty;
        //    string strPrevSubscriberID = string.Empty;
        //    string strNextSubscriberID = string.Empty;
        //    int intSegmentCount = 0;
        //    XDocument doc834XML = new XDocument();

        //    XElement xEle_Root = new XElement(ClsConstants.p_XML_TAG_THG834X2);
        //    XElement xEle_TZG_IProc = new XElement(ClsConstants.p_XML_TAG_TZG_IPROC);
        //    XElement xEle_THG_IProc = new XElement(ClsConstants.p_XML_TAG_THG_IPROC);

        //    #region Xml Element Declaration

        //    XElement xEle_THG834X2_ST_TransactionSetHeader = new XElement(ClsConstants.p_XML_TAG_THG834X2_ST);
        //    XElement xEle_THG834X2_BGN_BeginningSegment = new XElement(ClsConstants.p_XML_TAG_THG834X2_BGN);
        //    XElement xEle_THG834X2_1000A = new XElement(ClsConstants.p_XML_TAG_THG834X2_1000A);
        //    XElement xEle_THG834X2_1000B = new XElement(ClsConstants.p_XML_TAG_THG834X2_1000B);

        //    XElement xEle_THG834X2_SE_TransactionSetTrailer = new XElement(ClsConstants.p_XML_TAG_THG834X2_SE);
        //    #endregion

        //    doc834XML.Add(xEle_Root);
        //    try
        //    {
        //        strISA06_SenderID = strSenderId;//ConfigurationManager.AppSettings.Get("ISA06");
        //        strISA08_ReceiverID = strReceiverId;// ConfigurationManager.AppSettings.Get("ISA08");

        //        strISA15_Indicator = strENV;// ConfigurationManager.AppSettings.Get("ISA15");
        //        if (strISA06_SenderID.Length < 15)
        //        {
        //            strISA06_SenderID = strISA06_SenderID.PadRight(15, ' ');
        //        }
        //        if (strISA08_ReceiverID.Length < 15)
        //        {
        //            strISA08_ReceiverID = strISA08_ReceiverID.PadRight(15, ' ');

        //        }
        //        #region "Header-ISA & GS Segment"
        //        xEle_TZG_IProc.Add(
        //            new XElement(ClsConstants.p_XML_TAG_PRODUCT_SPECIFICS,
        //                new XElement(ClsConstants.p_XML_TAG_PRODUCT, " ",
        //                new XAttribute("id", "FA")),
        //                new XElement(ClsConstants.p_XML_TAG_PRODUCT, " ",
        //                new XAttribute("id", "HG"))));


        //        xEle_THG_IProc.Add(
        //            new XElement(ClsConstants.p_XML_TAG_X12_DELIMITERS,
        //                new XElement(ClsConstants.p_XML_TAG_ELEMENTDELIMITER, "*"),
        //                new XElement(ClsConstants.p_XML_TAG_SUB_ELEMENT_DELIMITER, "|"),
        //                new XElement(ClsConstants.p_XML_TAG_SEGMENT_DELIMITER, "~")),
        //            new XElement(ClsConstants.p_XML_TAG_X12_ENVELOPE,
        //                new XElement(ClsConstants.p_XML_TAG_ISA,
        //                    new XElement(ClsConstants.p_XML_TAG_ISA01, "00"),
        //                    new XElement(ClsConstants.p_XML_TAG_ISA02, "          "),
        //                    new XElement(ClsConstants.p_XML_TAG_ISA03, "00"),
        //                    new XElement(ClsConstants.p_XML_TAG_ISA04, "          "),
        //                    new XElement(ClsConstants.p_XML_TAG_ISA05, "ZZ"),
        //                    new XElement(ClsConstants.p_XML_TAG_ISA06, strISA06_SenderID),
        //                    new XElement(ClsConstants.p_XML_TAG_ISA07, "33"),
        //                    new XElement(ClsConstants.p_XML_TAG_ISA08, strISA08_ReceiverID),
        //                    new XElement(ClsConstants.p_XML_TAG_ISA09, DateTime.Now.ToString("yyMMdd")),////
        //                    new XElement(ClsConstants.p_XML_TAG_ISA10, DateTime.Now.ToString("HHmm")),//////
        //                    new XElement(ClsConstants.p_XML_TAG_ISA11, "^"),
        //                    new XElement(ClsConstants.p_XML_TAG_ISA12, "00501"),
        //                    new XElement(ClsConstants.p_XML_TAG_ISA13, "100000000"),
        //                    new XElement(ClsConstants.p_XML_TAG_ISA14, "0"),
        //                    new XElement(ClsConstants.p_XML_TAG_ISA15, strISA15_Indicator),
        //                    new XElement(ClsConstants.p_XML_TAG_ISA16, "|")),
        //                new XElement(ClsConstants.p_XML_TAG_GS,
        //                    new XElement(ClsConstants.p_XML_TAG_GS01, "BE"),
        //                    new XElement(ClsConstants.p_XML_TAG_GS02, "BCBSNC"),
        //                    new XElement(ClsConstants.p_XML_TAG_GS03, "1260"),
        //                    new XElement(ClsConstants.p_XML_TAG_GS04, DateTime.Now.ToString("yyMMdd")),/////
        //                    new XElement(ClsConstants.p_XML_TAG_GS05, DateTime.Now.ToString("HHmm")),///////
        //                    new XElement(ClsConstants.p_XML_TAG_GS06, "101"),
        //                    new XElement(ClsConstants.p_XML_TAG_GS07, "X"),
        //                    new XElement(ClsConstants.p_XML_TAG_GS08, "005010X220A1"))));

        //        xEle_Root.Add(xEle_TZG_IProc);
        //        xEle_Root.Add(xEle_THG_IProc);
        //        #endregion

        //        if (objResultSet.Tables.Count > 0)
        //        {

        //            if (objResultSet.Tables[0].Rows.Count > 0)
        //            {
        //                //For first time as previous subscriber is 1st record
        //                strPrevSubscriberID = objResultSet.Tables[0].Rows[0][ClsConstants.p_COL_2000_REF02_F_SUBSCRIBER_ID].ToString();

        //                for (int i = 0; i < objResultSet.Tables[0].Rows.Count; i++)
        //                {
        //                    strCurrSubscriberID = objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_REF02_F_SUBSCRIBER_ID].ToString();
        //                    if ((i + 1) < objResultSet.Tables[0].Rows.Count)
        //                    {
        //                        strNextSubscriberID = objResultSet.Tables[0].Rows[i + 1][ClsConstants.p_COL_2000_REF02_F_SUBSCRIBER_ID].ToString();
        //                    }
        //                    if (strCurrSubscriberID != strPrevSubscriberID || i == 0)
        //                    {
        //                        intSegmentCount = 1;
        //                        #region"ST"
        //                        //THG834X2__ST__TransactionSetHeader
        //                        xEle_THG834X2_ST_TransactionSetHeader = new XElement(ClsConstants.p_XML_TAG_THG834X2_ST);
        //                        xEle_THG834X2_ST_TransactionSetHeader.Add(
        //                                            new XElement(ClsConstants.p_XML_TAG_THG834X2_ST01, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_ST01]),
        //                                            new XElement(ClsConstants.p_XML_TAG_THG834X2_ST02, "1001"),//, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_ST02]),
        //                                            new XElement(ClsConstants.p_XML_TAG_THG834X2_ST03, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_ST03]));
        //                        intSegmentCount += 1;
        //                        #endregion

        //                        #region"BGN"
        //                        //BeginningSegment-THG834X2__BGN__BeginningSegment
        //                        xEle_THG834X2_BGN_BeginningSegment = new XElement(ClsConstants.p_XML_TAG_THG834X2_BGN);
        //                        xEle_THG834X2_BGN_BeginningSegment.Add(
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_BGN01, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_BGN01]),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_BGN02, "1178"),//, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_BGN02]),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_BGN03, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_BGN03_DATE]),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_BGN04, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_BGN04_TIME]),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_BGN08, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_BGN08]));
        //                        intSegmentCount += 1;
        //                        #endregion

        //                        #region"1000A"
        //                        //THG834X2_1000A Segment
        //                        xEle_THG834X2_1000A = new XElement(ClsConstants.p_XML_TAG_THG834X2_1000A);
        //                        xEle_THG834X2_1000A.Add(
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_1000A_N1,
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_1000A_N101, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_1000A_N101]),
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_1000A_N102, "SponsorXYZ"),//objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_1000A_N102]),
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_1000A_N103, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_1000A_N103]),
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_1000A_N104, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_1000A_N104])));
        //                        intSegmentCount += 1;
        //                        #endregion

        //                        #region"1000B"
        //                        //THG834X2_1000B Segment
        //                        xEle_THG834X2_1000B = new XElement(ClsConstants.p_XML_TAG_THG834X2_1000B);
        //                        xEle_THG834X2_1000B.Add(
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_1000B_N1,
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_1000B_N101, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_1000B_N101]),
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_1000B_N102, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_1000B_N102]),
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_1000B_N103, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_1000B_N103]),
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_1000B_N104, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_1000B_N104])));
        //                        intSegmentCount += 1;
        //                        #endregion

        //                    }

        //                    #region "2000"
        //                    //THG834X2_2000 Segment
        //                    XElement xEle_THG834X2_2000 = new XElement(ClsConstants.p_XML_TAG_THG834X2_2000);
        //                    XElement xEle_THG834X2_2000_INS__MemberLevelDetail = new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_INS);
        //                    xEle_THG834X2_2000_INS__MemberLevelDetail.Add(
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_INS01, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS01]),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_INS02, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS02_F_RELATION]),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_INS03, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS03]),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_INS05, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS05]));
        //                    //If CSPD_CAT is blank or null exculde this Segment from XML
        //                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS06_F_CSPD_CAT]).Trim()))
        //                    {
        //                        xEle_THG834X2_2000_INS__MemberLevelDetail.Add(
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_INS06_C052,
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_INS06_C05201, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS06_F_CSPD_CAT])));
        //                    }
        //                    xEle_THG834X2_2000_INS__MemberLevelDetail.Add(
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_INS08, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS08_F_CSPD_CAT]),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_INS09, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS09_F_MEST_TYPE]),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_INS10, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS10_F_MEHD_TYPE]));

        //                    XElement xEle_THG834X2_2000_REF_SubscriberIdentifier = new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_REF_SUBSCRIBER_IDENTIFIER);

        //                    xEle_THG834X2_2000_REF_SubscriberIdentifier.Add(
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_REF01_REFERENCE_IDENTIFICATION_QUALIFIER, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_REF01_SUBSCRIBER]),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_REF02_SUBSCRIBER_IDENTIFIER, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_REF02_F_SUBSCRIBER_ID]));


        //                    XElement xEle_THG834X2_2000_REF_MemberPolicyNumber = new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_REF_MEMBER_POLICY_NUMBER);
        //                    xEle_THG834X2_2000_REF_MemberPolicyNumber.Add(
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_REF01_REFERENCE_IDENTIFICATION_QUALIFIER, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_REF01_GROUP]),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2000_REF02_MEMBER_GROUP_OR_POLICYNUMBER, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_REF02_F_GROUP_ID]));

        //                    xEle_THG834X2_2000.Add(xEle_THG834X2_2000_INS__MemberLevelDetail);
        //                    intSegmentCount += 1;
        //                    xEle_THG834X2_2000.Add(xEle_THG834X2_2000_REF_SubscriberIdentifier);
        //                    intSegmentCount += 1;
        //                    xEle_THG834X2_2000.Add(xEle_THG834X2_2000_REF_MemberPolicyNumber);
        //                    intSegmentCount += 1;

        //                    #endregion

        //                    #region "2100A"
        //                    // THG834X2_2100A Segment
        //                    XElement xEle_THG834X2_2100A = new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A);
        //                    XElement xEle_THG834X2_2100A_NM1_MemberName = new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_NM1);
        //                    xEle_THG834X2_2100A_NM1_MemberName.Add(
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_NM101, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM101]),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_NM102, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM102]),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_NM103, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM103_F_LAST_NAME]).Trim()),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_NM104, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM104_F_FIRST_NAME]).Trim()),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_NM105, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM105_F_MIDDLE_INIT]).Trim()),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_NM107, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM107_F_TITLE]).Trim()));
        //                    //If SSN is blank then do not populate NM108 and 109 tag
        //                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM109_F_SSN]).Trim()))
        //                    {
        //                        xEle_THG834X2_2100A_NM1_MemberName.Add(
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_NM108, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM108]),
        //                            new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_NM109, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM109_F_SSN]).Trim()));
        //                    }

        //                    //THG834X2_2100A_PER__MemberCommunicationsNumbers
        //                    XElement xEle_THG834X2_2100A_PER_MemberCommunicationsNumbers = new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_PER);
        //                    xEle_THG834X2_2100A_PER_MemberCommunicationsNumbers.Add(
        //                        new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_PER01, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_PER01]),
        //                        new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_PER03, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_PER03]),
        //                        new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_PER04, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_PER04_F_PHONE]).Trim()));

        //                    //THG834X2_2100A_N3__MemberResidenceStreetAddress
        //                    XElement xEle_THG834X2_2100A_N3_MemberResidenceStreetAddress = new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_N3);
        //                    xEle_THG834X2_2100A_N3_MemberResidenceStreetAddress.Add(
        //                         new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_N301, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N301_F_ADDRESS_1]).Trim()),
        //                         new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_N302, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N302_F_ADDRESS_2]).Trim()));

        //                    //THG834X2_2100A_N4__MemberCityStateZIPCode
        //                    XElement xEle_THG834X2_2100A_N4_MemberCityStateZIPCode = new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_N4);
        //                    xEle_THG834X2_2100A_N4_MemberCityStateZIPCode.Add(
        //                         new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_N401, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N401_F_CITY]).Trim()),
        //                         new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_N402, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N402_F_STATE]).Trim()),
        //                         new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_N403, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N403_F_ZIP]).Trim()),
        //                         new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_N404, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N404_F_COUNTRY_CODE]).Trim()));

        //                    //THG834X2_2100A_DMG__MemberDemographics
        //                    XElement xEle_THG834X2_2100A_DMG_MemberDemographics = new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_DMG);
        //                    xEle_THG834X2_2100A_DMG_MemberDemographics.Add(
        //                           new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_DMG01, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG01]),
        //                           new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_DMG02, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG02_F_BIRTH_DATE]),
        //                           new XElement(ClsConstants.p_XML_TAG_THG834X2_2100A_DMG03, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG03_F_GENDER]));


        //                    xEle_THG834X2_2100A.Add(xEle_THG834X2_2100A_NM1_MemberName);
        //                    intSegmentCount += 1;
        //                    xEle_THG834X2_2100A.Add(xEle_THG834X2_2100A_PER_MemberCommunicationsNumbers);
        //                    intSegmentCount += 1;
        //                    xEle_THG834X2_2100A.Add(xEle_THG834X2_2100A_N3_MemberResidenceStreetAddress);
        //                    intSegmentCount += 1;
        //                    xEle_THG834X2_2100A.Add(xEle_THG834X2_2100A_N4_MemberCityStateZIPCode);
        //                    intSegmentCount += 1;
        //                    xEle_THG834X2_2100A.Add(xEle_THG834X2_2100A_DMG_MemberDemographics);
        //                    intSegmentCount += 1;
        //                    #endregion

        //                    #region"2100C"
        //                    //THG834X2_2100C Segment
        //                    XElement xEle_THG834X2_2100C = new XElement(ClsConstants.p_XML_TAG_THG834X2_2100C);
        //                    XElement xEle_THG834X2_2100C_NM1__MemberMailingAddress = new XElement(ClsConstants.p_XML_TAG_THG834X2_2100C_NM1);
        //                    xEle_THG834X2_2100C_NM1__MemberMailingAddress.Add(
        //                               new XElement(ClsConstants.p_XML_TAG_THG834X2_2100C_NM101, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100C_NM101]),
        //                               new XElement(ClsConstants.p_XML_TAG_THG834X2_2100C_NM102, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100C_NM102]));
        //                    //THG834X2_2100C_N3__MemberMailStreetAddress
        //                    XElement xEle_THG834X2_2100C_N3__MemberMailStreetAddress = new XElement(ClsConstants.p_XML_TAG_THG834X2_2100C_N3);
        //                    xEle_THG834X2_2100C_N3__MemberMailStreetAddress.Add(
        //                               new XElement(ClsConstants.p_XML_TAG_THG834X2_2100C_NM301, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100C_N301_F_ADDRESS_1]).Trim()),
        //                               new XElement(ClsConstants.p_XML_TAG_THG834X2_2100C_NM302, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100C_N302_F_ADDRESS_2]).Trim()));
        //                    //THG834X2_2100C_N4__MemberMailCityStateZIPCode
        //                    XElement xEle_THG834X2_2100C_N4__MemberMailCityStateZIPCode = new XElement(ClsConstants.p_XML_TAG_THG834X2_2100C_N4);
        //                    xEle_THG834X2_2100C_N4__MemberMailCityStateZIPCode.Add(
        //                               new XElement(ClsConstants.p_XML_TAG_THG834X2_2100C_NM401, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100C_N401_F_CITY]).Trim()),
        //                               new XElement(ClsConstants.p_XML_TAG_THG834X2_2100C_NM402, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100C_N402_F_STATE]).Trim()),
        //                               new XElement(ClsConstants.p_XML_TAG_THG834X2_2100C_NM403, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100C_N403_F_ZIP]).Trim()),
        //                               new XElement(ClsConstants.p_XML_TAG_THG834X2_2100C_NM404, Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100C_N404_F_COUNTRY_CODE]).Trim()));

        //                    xEle_THG834X2_2100C.Add(xEle_THG834X2_2100C_NM1__MemberMailingAddress);
        //                    intSegmentCount += 1;
        //                    xEle_THG834X2_2100C.Add(xEle_THG834X2_2100C_N3__MemberMailStreetAddress);
        //                    intSegmentCount += 1;
        //                    xEle_THG834X2_2100C.Add(xEle_THG834X2_2100C_N4__MemberMailCityStateZIPCode);
        //                    intSegmentCount += 1;
        //                    #endregion

        //                    #region"2300"
        //                    //THG834X2_2300 Segment
        //                    XElement xEle_THG834X2_2300 = new XElement(ClsConstants.p_XML_TAG_THG834X2_2300);
        //                    xEle_THG834X2_2300.Add(
        //                         new XElement(ClsConstants.p_XML_TAG_THG834X2_2300_HD,
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_2300_HD01, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD01]),
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_2300_HD03, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD03]),
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_2300_HD04, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD04_F_CSPI_ID]),
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_2300_HD05, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD05_F_MEPE_FI])));
        //                    intSegmentCount += 1;
        //                    //THG834X2_2300_DTP__HealthCoverageDates
        //                    xEle_THG834X2_2300.Add(
        //                        new XElement(ClsConstants.p_XML_TAG_THG834X2_2300_DTP,
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_2300_DTP01, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP01]),
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_2300_DTP02, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP02]),
        //                                new XElement(ClsConstants.p_XML_TAG_THG834X2_2300_DTP03, objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_FROM_DATE])));
        //                    intSegmentCount += 1;
        //                    #endregion

        //                    if (strCurrSubscriberID != strPrevSubscriberID || i == 0)
        //                    {
        //                        xEle_Root.Add(xEle_THG834X2_ST_TransactionSetHeader);
        //                        xEle_Root.Add(xEle_THG834X2_BGN_BeginningSegment);
        //                        xEle_Root.Add(xEle_THG834X2_1000A);
        //                        xEle_Root.Add(xEle_THG834X2_1000B);
        //                    }

        //                    xEle_Root.Add(xEle_THG834X2_2000);
        //                    xEle_Root.Add(xEle_THG834X2_2100A);
        //                    xEle_Root.Add(xEle_THG834X2_2100C);
        //                    xEle_Root.Add(xEle_THG834X2_2300);
        //                    if (strCurrSubscriberID != strNextSubscriberID || strNextSubscriberID == string.Empty)
        //                    {
        //                        #region "SE"
        //                        //THG834X2__SE__TransactionSetTrailer Segment
        //                        xEle_THG834X2_SE_TransactionSetTrailer = new XElement(ClsConstants.p_XML_TAG_THG834X2_SE);
        //                        xEle_THG834X2_SE_TransactionSetTrailer.Add(
        //                                    new XElement(ClsConstants.p_XML_TAG_THG834X2_SE01, intSegmentCount),//objResultSet.Tables[0].Rows[i]["ClsConstants.p_COL_SE01"]),
        //                                    new XElement(ClsConstants.p_XML_TAG_THG834X2_SE02, "1001"));//objResultSet.Tables[0].Rows[i]["ClsConstants.p_COL_SE02"]));
        //                        #endregion
        //                        xEle_Root.Add(xEle_THG834X2_SE_TransactionSetTrailer);
        //                        intSegmentCount = 0;
        //                    }
        //                    strPrevSubscriberID = strCurrSubscriberID;
        //                    strNextSubscriberID = string.Empty;

        //                }

        //                //Save the file to specified output directory
        //                objConsoleLogger.Write("Creation of file in " + strOutputDir + "\\" + strFileName + ClsConstants.p_IN_FILE_PATTERN_XML);
        //                doc834XML.Save(strOutputDir + "\\" + strFileName + ClsConstants.p_IN_FILE_PATTERN_XML);
        //            }
        //            else
        //            {
        //                objConsoleLogger.Write(ClsConstants.p_LOG_NO_TABLE_DATA);
        //            }
        //        }
        //        else
        //        {
        //            objConsoleLogger.Write(ClsConstants.p_LOG_NO_TABLE);
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return (boolRetVal);
        //}
        #endregion
    }
}
