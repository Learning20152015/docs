﻿// ClsMagellanMemberExtract.cs
//
// Assembly:
//    MagellanMemberExtract.dll
//
// Description:
//   Magellan Membership Extract
// --------------------------------------------------------------
// 
// Copyright © 2008-2014 The TriZetto Group, Inc.
// All rights reserved.
// Warning:  This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of
// this program, or any portion of it, may result in severe civil and
// criminal penalties, and will be prosecuted to the maximum extent
// possible under the law.
// This source code is the confidential and proprietary information of The
// TriZetto Group, Inc.
// You shall not disclose such Confidential Information to any third parties
// and shall use it only in accordance with the terms of the license agreement
// you entered into with The TriZetto Group, Inc.
// This source code and information is provided "as is" without warranty
// of any kind, either expressed or implied, including but not limited to
// the implied warranties of merchantability and/or fitness for a particular
// purpose.
// Author : The TriZetto Corporation
// -----------------------------------------------------------------------------
// Revision History:
// 1.0   03-25-2014   Amol Sangar    Initial creation..
// 1.1   04-25-2014   Amol Sangar    Updated..
// 1.2   04-29-2014   Amol Sangar    Updated with Headers,Details and Trailors of file..
// 1.3   05-12-2014   Amol Sangar    Removed spaces.
// 1.4   05-14-2014   Amol Sangar    Added Group DTP at 2000 and removed from 2300.
// 1.5   05-20-2014   Amol Sangar    Updated.
// 1.6   05-20-2014   Amol Sangar    Validate INS03 and HD01 segments..
// 1.7   06-03-2014   Amol Sangar    Removed unwanted code.
// 1.8   06-09-2014   Amol Sangar    Splitted code as per Process and Select command.
//-------------------------------------------------------------------------------
using System;
using System.Collections;
using System.Data;
using System.IO;
using System.Text;
using InterfaceFramework;
using System.Xml.Linq;

namespace MagellanMemberExtract
{
    public class ClsMagellanMemberExtract
    {
        // object for logging the processing activity of the application
        ConsoleLogger objConsoleLogger;

        // object for performing sql/database functions
        SqlServerHelper objSqlHelper;
        // Initializing the return variable
        bool boolRetVal = true;

        /// <summary>
        /// Constructor for Magellan Membership Extract Class
        /// </summary>
        /// <param name="objLogger">Logger Object</param>
        /// <param name="strDbServerLocation">Database Server Location for connecting to SQL Server</param>
        /// <param name="strCstmDbName">Name of the Custom Database</param>
        /// <param name="strUserName">User Name</param>
        /// <param name="strPassword">Password</param>

        public ClsMagellanMemberExtract(ConsoleLogger objLogger, string strDbServerLocation, string strCstmDbName, string strUserName, string strPassword)
        {
            // Initializing object for ConsoleLogger class
            this.objConsoleLogger = objLogger;
            // Initializing object for SqlServerHelper class
            objSqlHelper = new SqlServerHelper(objConsoleLogger, strCstmDbName, strUserName, strPassword, strDbServerLocation);
        }

        /// <summary>
        /// Entry point for execution for Magellan Membership Extract.
        /// </summary>
        /// <param name="strOutputDir">Output Directory</param>
        /// <returns>Boolean True - Success, False - Failure</returns>

        public bool ExecuteInterface(string strOutputDir, string strFrequency, string strFileName, string strSenderId, string strReceiverId, string strENV, string strCommand)
        {
            // Initializing the DataSet
            DataSet dsOutputDataset = null;
            try
            {
                if (!Directory.Exists(strOutputDir))
                {
                    objConsoleLogger.Write(ClsConstants.p_LOG_ERR_INVALID_PATH);
                    boolRetVal = false;
                }
                else
                {
                    // Opening the sql server connection
                    objSqlHelper.Open();
                    Hashtable objHastParams;
                    if (strCommand == ClsConstants.p_STR_PROCESS_DATA)
                    {
                        objHastParams = new Hashtable(ClsConstants.p_VALUE_ONE);
                        //DAILY or QUARTERLY
                        objHastParams[ClsConstants.p_STR_FREQUENCY] = strFrequency;
                        objConsoleLogger.Write(ClsConstants.p_LOG_PROCESS_SP_START);
                        //Executing tpzp_magellan_member_extr store procedure
                        objSqlHelper.ExecuteProcedure(ClsConstants.p_PROCESS_SP_Extract_Magellan_Membership_Data, objHastParams);
                        objConsoleLogger.Write(strFrequency + ClsConstants.p_LOG_PROCESS_SP_END);
                    }
                    else if (strCommand == ClsConstants.p_STR_SELECT_DATA)
                    {
                        objHastParams = new Hashtable(ClsConstants.p_VALUE_ZERO);
                        objConsoleLogger.Write(ClsConstants.p_LOG_SELECT_SP_START);
                        // Executing the procedure tpzp_magellan_member_select_extr and storing the result in dataset dsOutputDataset 
                        dsOutputDataset = objSqlHelper.ExecuteProcedure(ClsConstants.p_SELECT_SP_Extract_Magellan_Membership_Data, objHastParams);
                        objConsoleLogger.Write(ClsConstants.p_LOG_SELECT_SP_END);
                        objConsoleLogger.Write(ClsConstants.p_LOG_EDI_START);
                        boolRetVal = WriteDataToEDIFile(dsOutputDataset, strOutputDir, strFileName, strSenderId, strReceiverId, strENV, strFrequency);
                        objConsoleLogger.Write(ClsConstants.p_LOG_EDI_END);
                    }
                }
            }
            catch (Exception ex)
            {
                objConsoleLogger.Write(ex.Message + Environment.NewLine);
            }
            finally
            {
                if (dsOutputDataset != null)
                {
                    dsOutputDataset.Dispose();
                }
            }
            return (boolRetVal);
        }

        /// <summary>
        /// Create edi file as per data with respective frequency run
        /// </summary>
        /// <param name="objResultSet">Data from facets database</param>
        /// <param name="strOutputDir">Directory name at which file will be stored</param>
        /// <param name="strFileName">File name as per frequency Daily/Quarterly</param>
        /// <param name="strSenderId">Sender id</param>
        /// <param name="strReceiverId">receiver id</param>
        /// <param name="strENV">Environment T/P</param>
        /// <returns></returns>
        private bool WriteDataToEDIFile(DataSet objResultSet, string strOutputDir, string strFileName, string strSenderId, string strReceiverId, string strENV, string strFrequency)
        {
            StringBuilder sbEnrollmentData = new StringBuilder();
            string strISA06_SenderID = string.Empty;
            string strISA08_ReceiverID = string.Empty;
            string strISA15_Indicator = string.Empty;
            string strCurrSubscriberID = string.Empty;
            int intSegmentCount = 0;
            string strX12FileData = string.Empty;
            string strSpace = string.Empty;
            int intCounterNoValue = 0;

            try
            {
                strISA06_SenderID = strSenderId;
                strISA08_ReceiverID = strReceiverId;
                strISA15_Indicator = strENV;
                if (strISA06_SenderID.Length < 15)
                {
                    strISA06_SenderID = strISA06_SenderID.PadRight(15, ClsConstants.p_CH_SPACE);
                }
                if (strISA08_ReceiverID.Length < 15)
                {
                    strISA08_ReceiverID = strISA08_ReceiverID.PadRight(15, ClsConstants.p_CH_SPACE);

                }
                strSpace = strSpace.PadRight(10, ClsConstants.p_CH_SPACE);

                //Log File Directory and File Path
                objConsoleLogger.Write(ClsConstants.p_LOG_EDI_FILE_PATH + strOutputDir + ClsConstants.p_STR_DOUBLE_SLASH + strFileName + ClsConstants.p_IN_FILE_PATTERN_EDI);
                //Create edi file using StreamWriter
                using (StreamWriter swCreateEdiFile = File.CreateText(strOutputDir + ClsConstants.p_STR_DOUBLE_SLASH + strFileName + ClsConstants.p_IN_FILE_PATTERN_EDI))
                {
                    #region"Transaction Set"
                    //Valiadate table is present or not
                    if (objResultSet.Tables.Count > 0)
                    {
                        //Validate rows are present or not
                        if (objResultSet.Tables[0].Rows.Count > 0)
                        {

                            #region"Header"
                            #region"ISA"
                            swCreateEdiFile.Write(ClsConstants.p_STR_ISA);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ISA01_VAL);//ISA1
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(strSpace);//ISA2
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ISA01_VAL);//ISA3
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(strSpace);//ISA4
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ISA05_VAL);//ISA5
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(strISA06_SenderID);//ISA6
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ISA07_VAL);//ISA7
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(strISA08_ReceiverID);//ISA8
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(DateTime.Now.ToString(ClsConstants.p_STR_DATEFORMAT_1));//ISA9
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(DateTime.Now.ToString(ClsConstants.p_STR_TIMEFORMAT));//ISA10
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ISA11_VAL);//ISA11
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ISA12_VAL);//ISA12
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[0][ClsConstants.p_COL_ISA13]).Trim());//ISA13
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(0);//ISA14
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(strISA15_Indicator);//ISA15
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ISA16_VAL);//ISA16
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            #endregion

                            #region"GS"
                            swCreateEdiFile.Write(ClsConstants.p_STR_GS);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_GS01_VAL);//GS01
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(strISA06_SenderID.Trim());//GS02
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(strISA08_ReceiverID.Trim());//GS03
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(DateTime.Now.ToString(ClsConstants.p_STR_DATEFORMAT_2));//GS04
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(DateTime.Now.ToString(ClsConstants.p_STR_TIMEFORMAT));//GS05
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[0][ClsConstants.p_COL_GS06]).Trim());//GS06
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_GS07_VAL);//GS07
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_GS08_VAL);//GS08
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            #endregion

                            intSegmentCount = 1;
                            #region"ST"
                            swCreateEdiFile.Write(ClsConstants.p_STR_ST);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ST01_VAL);//ST01
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[0][ClsConstants.p_COL_SE02]).Trim());//(ClsConstants.p_COL_GS06_VAL);//ST02
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_ST03_VAL);//ST03
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            intSegmentCount += 1;
                            #endregion

                            #region"BGN"
                            swCreateEdiFile.Write(ClsConstants.p_STR_BGN);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_BGN01_VAL);//BGN01
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[0][ClsConstants.p_COL_GS06]).Trim());//BGN02
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(DateTime.Now.ToString(ClsConstants.p_STR_DATEFORMAT_2));//BGN03
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(DateTime.Now.ToString(ClsConstants.p_STR_TIMEFORMAT));//BGN04
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            if (strFrequency == ClsConstants.p_STR_FREQUENCY_DAILY)
                            {
                                swCreateEdiFile.Write(ClsConstants.p_COL_BGN08_VAL_D);//BGN08
                            }
                            else if (strFrequency == ClsConstants.p_STR_FREQUENCY_QUARTERLY)
                            {
                                swCreateEdiFile.Write(ClsConstants.p_COL_BGN08_VAL_Q);//BGN08
                            }

                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            intSegmentCount += 1;
                            #endregion

                            #region"1000A"
                            swCreateEdiFile.Write(ClsConstants.p_STR_N1);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000A_N101_VAL);//N101
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000A_N102_VAL);//N102
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000A_N103_VAL);//N103
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000A_N104_VAL);//N104
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            intSegmentCount += 1;
                            #endregion

                            #region"1000B"
                            swCreateEdiFile.Write(ClsConstants.p_STR_N1);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000B_N101_VAL);//N101
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000B_N102_VAL);//N102
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000B_N103_VAL);//N103
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_1000B_N104_VAL);//N104
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            intSegmentCount += 1;
                            #endregion
                            #endregion

                            #region"Detail"
                            for (int i = 0; i < objResultSet.Tables[0].Rows.Count; i++)
                            {
                                if (!string.IsNullOrEmpty(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS03].ToString())
                                && !string.IsNullOrEmpty(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD01].ToString()))
                                {
                                    #region"2000"
                                    #region"INS"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_INS);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS01_IS_SUBSCRIBER]);//INS01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS02_F_RELATION]);//INS02
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS03]);//INS03
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_COL_2000_INS05_VAL);//INS05
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #region"REF_SubscriberIdentifier"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_REF);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_COL_2000_REF01_SUBSCRIBER_VAL);//REF01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_REF02_F_SUBSCRIBER_ID]);//REF02
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #region"REF_MemberPolicyNumber"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_REF);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_COL_2000_REF01_GROUP_VAL);//REF01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_REF02_F_GROUP_ID]);//REF02
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #region"MemberLevelDates"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DTP);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_COL_2000_DTP01_DATE_VAL);//DTP01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(DateTime.Now.ToString(ClsConstants.p_STR_DATEFORMAT_2));//DTP03
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #region"DTP_Group Effective Date"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DTP);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_QULIFIER_356);//DTP01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_GROUP_FROM_DATE]).Trim());//DTP03
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #region"DTP_Group Expiration Date"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DTP);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_QULIFIER_357);//DTP01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_GROUP_TERM_DATE]).Trim());//DTP03
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion
                                    #endregion

                                    #region"2100A"
                                    #region"NM1"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_NM1);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_COL_2100A_NM101_VAL);//NM101
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_COL_2100A_NM102_VAL);//NM102
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM103_F_LAST_NAME]).Trim());//NM103
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM104_F_FIRST_NAME]).Trim());//NM104
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM105_F_MIDDLE_INIT]).Trim()))
                                    {
                                        swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                        swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM105_F_MIDDLE_INIT]).Trim());//NM105
                                    }
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;

                                    #endregion

                                    #region"N3"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_N3);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N301_F_ADDRESS_1]).Trim());//N301
                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N302_F_ADDRESS_2]).Trim()))
                                    {
                                        swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                        swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N302_F_ADDRESS_2]).Trim());//N302
                                    }
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;

                                    #endregion

                                    #region"N4"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_N4);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N401_F_CITY]).Trim());//N401
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N402_F_STATE]).Trim());//N402
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N403_F_ZIP]).Trim());//N403
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #region"DMG"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DMG);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_FORMAT);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG02_F_BIRTH_DATE]).Trim());//DMG02
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG03_F_GENDER]).Trim());//DMG03
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion
                                    #endregion

                                    #region"2300"
                                    #region"HD"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_HD);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD01]);//HD01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD03]);//HD03
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD04_F_CSPI_ID]).Trim());//HD04
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #region"DTP_Benefit Begin Date"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DTP);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_QULIFIER_348);//DTP01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_FROM_DATE]).Trim());//DTP03
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #region"DTP_Benefit End date"
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DTP);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_QULIFIER_349);//DTP01
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                                    swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_TERM_DATE]).Trim());//DTP03
                                    swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                                    intSegmentCount += 1;
                                    #endregion

                                    #endregion
                                }
                                else
                                {
                                    intCounterNoValue += 1;
                                    //Write record in log
                                    objConsoleLogger.Write(ClsConstants.p_LOG_RECORD_INFO);
                                    #region"2000"
                                    #region"INS"
                                    StringBuilder sb = new StringBuilder();
                                    sb.Append(ClsConstants.p_STR_INS);

                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS01_IS_SUBSCRIBER].ToString());//INS01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS02_F_RELATION].ToString());//INS02
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_INS03].ToString());//INS03
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_COL_2000_INS05_VAL);//INS05
                                    sb.Append(ClsConstants.p_STR_TILT);

                                    #endregion

                                    #region"REF_SubscriberIdentifier"
                                    sb.Append(ClsConstants.p_STR_REF);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_COL_2000_REF01_SUBSCRIBER_VAL);//REF01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_REF02_F_SUBSCRIBER_ID].ToString());//REF02
                                    sb.Append(ClsConstants.p_STR_TILT);

                                    #endregion

                                    #region"REF_MemberPolicyNumber"
                                    sb.Append(ClsConstants.p_STR_REF);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_COL_2000_REF01_GROUP_VAL);//REF01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2000_REF02_F_GROUP_ID].ToString());//REF02
                                    sb.Append(ClsConstants.p_STR_TILT);

                                    #endregion

                                    #region"MemberLevelDates"
                                    sb.Append(ClsConstants.p_STR_DTP);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_COL_2000_DTP01_DATE_VAL);//DTP01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(DateTime.Now.ToString(ClsConstants.p_STR_DATEFORMAT_2));//DTP03
                                    sb.Append(ClsConstants.p_STR_TILT);

                                    #endregion

                                    #region"DTP_Group Effective Date"
                                    sb.Append(ClsConstants.p_STR_DTP);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_QULIFIER_356);//DTP01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_GROUP_FROM_DATE]).Trim());//DTP03
                                    sb.Append(ClsConstants.p_STR_TILT);

                                    #endregion

                                    #region"DTP_Group Expiration Date"
                                    sb.Append(ClsConstants.p_STR_DTP);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_QULIFIER_357);//DTP01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_GROUP_TERM_DATE]).Trim());//DTP03
                                    sb.Append(ClsConstants.p_STR_TILT);

                                    #endregion
                                    #endregion

                                    #region"2100A"
                                    #region"NM1"
                                    sb.Append(ClsConstants.p_STR_NM1);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_COL_2100A_NM101_VAL);//NM101
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_COL_2100A_NM102_VAL);//NM102
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM103_F_LAST_NAME]).Trim());//NM103

                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM104_F_FIRST_NAME]).Trim());//NM104

                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM105_F_MIDDLE_INIT]).Trim()))
                                    {
                                        sb.Append(ClsConstants.p_STR_STAR);
                                        sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_NM105_F_MIDDLE_INIT]).Trim());//NM105
                                    }
                                    sb.Append(ClsConstants.p_STR_TILT);



                                    #endregion

                                    #region"N3"
                                    sb.Append(ClsConstants.p_STR_N3);

                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N301_F_ADDRESS_1]).Trim());//N301

                                    if (!string.IsNullOrEmpty(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N302_F_ADDRESS_2]).Trim()))
                                    {
                                        sb.Append(ClsConstants.p_STR_STAR);
                                        sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N302_F_ADDRESS_2]).Trim());//N302
                                    }
                                    sb.Append(ClsConstants.p_STR_TILT);


                                    #endregion

                                    #region"N4"

                                    sb.Append(ClsConstants.p_STR_N4);

                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N401_F_CITY]).Trim());//N401

                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N402_F_STATE]).Trim());//N402

                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_N403_F_ZIP]).Trim());//N403

                                    sb.Append(ClsConstants.p_STR_TILT);


                                    #endregion

                                    #region"DMG"
                                    sb.Append(ClsConstants.p_STR_DMG);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_FORMAT);

                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG02_F_BIRTH_DATE]).Trim());//DMG02

                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2100A_DMG03_F_GENDER]).Trim());//DMG03

                                    sb.Append(ClsConstants.p_STR_TILT);

                                    #endregion
                                    #endregion

                                    #region"2300"
                                    #region"HD"
                                    sb.Append(ClsConstants.p_STR_HD);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD01].ToString());//HD01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD03].ToString());//HD03
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_HD04_F_CSPI_ID]).Trim());//HD04
                                    sb.Append(ClsConstants.p_STR_TILT);

                                    #endregion

                                    #region"DTP_Benefit Begin Date"
                                    sb.Append(ClsConstants.p_STR_DTP);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_QULIFIER_348);//DTP01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_FROM_DATE]).Trim());//DTP03
                                    sb.Append(ClsConstants.p_STR_TILT);

                                    #endregion

                                    #region"DTP_Benefit End date"
                                    sb.Append(ClsConstants.p_STR_DTP);
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_QULIFIER_349);//DTP01
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(ClsConstants.p_STR_DATE_TIME_FORMAT);//DTP02
                                    sb.Append(ClsConstants.p_STR_STAR);
                                    sb.Append(Convert.ToString(objResultSet.Tables[0].Rows[i][ClsConstants.p_COL_2300_DTP03_F_TERM_DATE]).Trim());//DTP03
                                    sb.Append(ClsConstants.p_STR_TILT);

                                    objConsoleLogger.Write(sb.ToString());
                                    sb.Remove(0, sb.Length);
                                    #endregion

                                    #endregion
                                }
                            }
                            #endregion

                            #region"Trailer"

                            #region"SE"
                            swCreateEdiFile.Write(ClsConstants.p_STR_SE);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(intSegmentCount);//SE01
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[0][ClsConstants.p_COL_SE02]).Trim());//(ClsConstants.p_COL_SE02_VAL);//SE02
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            intSegmentCount = 0;

                            #endregion

                            #region"GE"
                            swCreateEdiFile.Write(ClsConstants.p_STR_GE);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(1);//GE01
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[0][ClsConstants.p_COL_GS06]).Trim());//GE02
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            #endregion

                            #region"IEA"
                            swCreateEdiFile.Write(ClsConstants.p_STR_IEA);
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(ClsConstants.p_COL_IEA01_VAL);//IEA01
                            swCreateEdiFile.Write(ClsConstants.p_STR_STAR);
                            swCreateEdiFile.Write(Convert.ToString(objResultSet.Tables[0].Rows[0][ClsConstants.p_COL_ISA13]).Trim());//IEA02
                            swCreateEdiFile.Write(ClsConstants.p_STR_TILT);
                            #endregion
                            #endregion
                        }

                        else
                        {
                            objConsoleLogger.Write(ClsConstants.p_LOG_NO_TABLE_DATA);
                        }
                    }
                    else
                    {
                        objConsoleLogger.Write(ClsConstants.p_LOG_NO_TABLE);
                    }
                    #endregion
                }
                if (objResultSet.Tables.Count > 0)
                {
                    //Validate rows are present or not
                    if (objResultSet.Tables[0].Rows.Count > 0)
                    {
                        if (objResultSet.Tables[0].Rows.Count == intCounterNoValue)
                        {
                            string strTextToReplace = File.ReadAllText(strOutputDir + ClsConstants.p_STR_DOUBLE_SLASH + strFileName + ClsConstants.p_IN_FILE_PATTERN_EDI);
                            strTextToReplace = string.Empty;
                            File.WriteAllText(strOutputDir + ClsConstants.p_STR_DOUBLE_SLASH + strFileName + ClsConstants.p_IN_FILE_PATTERN_EDI, strTextToReplace);
                        }
                    }
                }
                boolRetVal = true;
            }
            catch (Exception ex)
            {
                boolRetVal = false;
                throw ex;
            }
            return (boolRetVal);
        }
    }
}
