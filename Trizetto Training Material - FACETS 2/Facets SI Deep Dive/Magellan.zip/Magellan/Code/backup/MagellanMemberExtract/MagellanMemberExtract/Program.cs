﻿// Program.cs
//
// Assembly:
//    MagellanMemberExtract.dll
//
// Description:
//    Magellan Membership Extract
// --------------------------------------------------------------
// 
// Copyright © 2008-2014 The TriZetto Group, Inc.
// All rights reserved.
// Warning:  This computer program is protected by copyright law and
// international treaties. Unauthorized reproduction or distribution of
// this program, or any portion of it, may result in severe civil and
// criminal penalties, and will be prosecuted to the maximum extent
// possible under the law.
// This source code is the confidential and proprietary information of The
// TriZetto Group, Inc.
// You shall not disclose such Confidential Information to any third parties
// and shall use it only in accordance with the terms of the license agreement
// you entered into with The TriZetto Group, Inc.
// This source code and information is provided "as is" without warranty
// of any kind, either expressed or implied, including but not limited to
// the implied warranties of merchantability and/or fitness for a particular
// purpose.
// Author : The TriZetto Corporation
// -----------------------------------------------------------------------------
// Revision History:
// 1.0   03-25-2014   Amol Sangar    Initial creation.
//-------------------------------------------------------------------------------
using System;
using InterfaceFramework;

namespace MagellanMemberExtract
{
    class Program
    {
        public static int Main(string[] args)
        {
            // object for logging the processing activity of the application
            ConsoleLogger objConsoleLogger = new ConsoleLogger();

            // Declaring the variables for input values
            string strDbServerLocation = string.Empty;
            string strStageDbName = string.Empty;
            string strUserName = string.Empty;
            string strPassword = string.Empty;
            string strFrequency = string.Empty;
            string strOutputDir = string.Empty;
            string strFileName = string.Empty;
            string strSenderId = string.Empty;
            string strReceiverId = string.Empty;
            string strENV = string.Empty;


            // Return codes
            int intRetCode = ClsConstants.p_RET_CODE_SUCCESS;
            bool boolRetVal = true;
            //args = new string[10];
            //args[0] = "10.82.18.167,14331";
            //args[1] = "fabncdv1stage";
            //args[2] = "";
            //args[3] = "";
            //args[4] = "C:\\AmolS";
            //args[5] = "DAILY";
            //args[6] = "bcbsnc_member_prod_daily";
            //args[7] = "BCBSNC";
            //args[8] = "1260";
            //args[9] = "T";

            try
            {
                // Checking if all the parameters are received
                if (args.Length < ClsConstants.p_VALUE_TEN || args.Length > ClsConstants.p_VALUE_TEN)
                {
                    objConsoleLogger.Write(ClsConstants.p_LOG_PARAM_NOT_VALID);
                    intRetCode = ClsConstants.p_RET_CODE_FAIL;
                }
                else
                {
                    objConsoleLogger.Write(ClsConstants.p_LOG_MTM_STARTED);
                    objConsoleLogger.Write(ClsConstants.p_LOG_PARAM_COUNT + args.Length.ToString());
                    // Getting the values of the input parameters
                    strDbServerLocation = args[ClsConstants.p_VALUE_ZERO].ToString().Trim();
                    strStageDbName = args[ClsConstants.p_VALUE_ONE].ToString().Trim();
                    strUserName = args[ClsConstants.p_VALUE_TWO].ToString().Trim();
                    strPassword = args[ClsConstants.p_VALUE_THREE].ToString().Trim();
                    strFrequency = args[ClsConstants.p_VALUE_FIVE].ToString().Trim();
                    strOutputDir = args[ClsConstants.p_VALUE_FOUR].ToString().Trim();
                    strFileName = args[ClsConstants.p_VALUE_SIX].ToString().Trim();
                    strSenderId = args[ClsConstants.p_VALUE_SEVEN].ToString().Trim();
                    strReceiverId = args[ClsConstants.p_VALUE_EIGHT].ToString().Trim();
                    strENV = args[ClsConstants.p_VALUE_NINE].ToString().Trim();

                    // Checking the input parameter values
                    if (string.IsNullOrEmpty(strDbServerLocation) || string.IsNullOrEmpty(strStageDbName) || string.IsNullOrEmpty(strUserName)
                        || string.IsNullOrEmpty(strPassword) || string.IsNullOrEmpty(strFrequency) || string.IsNullOrEmpty(strOutputDir)
                        || string.IsNullOrEmpty(strFileName) || string.IsNullOrEmpty(strSenderId) || string.IsNullOrEmpty(strReceiverId)
                        || string.IsNullOrEmpty(strENV))
                    {
                        objConsoleLogger.Write(ClsConstants.p_LOG_PARAM_NOT_IN_FORMAT);
                        intRetCode = ClsConstants.p_RET_CODE_FAIL;
                    }

                    // Writing a log on command prompt
                    objConsoleLogger.Write(ClsConstants.p_LOG_DB_SERVER_LOC + strDbServerLocation);
                    objConsoleLogger.Write(ClsConstants.p_LOG_DB_NAME + strStageDbName);
                    objConsoleLogger.Write(ClsConstants.p_LOG_IN_DIR + strFrequency);
                    objConsoleLogger.Write(ClsConstants.p_LOG_OUTPUT_DIR + strOutputDir);
                    objConsoleLogger.Write(ClsConstants.p_LOG_FILE_NAME + strFileName);
                    objConsoleLogger.Write(ClsConstants.p_LOG_SENDER_ID + strSenderId);
                    objConsoleLogger.Write(ClsConstants.p_LOG_RECEIVER_ID + strReceiverId);
                    objConsoleLogger.Write(ClsConstants.p_LOG_ENVIRONMENT + strENV);

                    if (intRetCode == ClsConstants.p_RET_CODE_SUCCESS)
                    {
                        // Performing the QNXT Valencia Membership Extract application operations
                        ClsMagellanMemberExtract objExtractTableManager = new ClsMagellanMemberExtract(objConsoleLogger, strDbServerLocation, strStageDbName, strUserName, strPassword);

                        // Executing Control File Manager program
                        boolRetVal = objExtractTableManager.ExecuteInterface(strOutputDir, strFrequency, strFileName, strSenderId, strReceiverId, strENV);

                        if (!boolRetVal)
                        {
                            intRetCode = 8;
                            // Program completed with error
                            objConsoleLogger.Write(ClsConstants.p_LOG_COMPLETED_WITH_ERROR + intRetCode);
                        }
                        intRetCode = 0;
                        objConsoleLogger.Write(ClsConstants.p_LOG_COMPLETED_SUCCESS + intRetCode);
                    }
                }
            }
            catch (Exception ex)
            {
                objConsoleLogger.WriteErr(ex.Message + Environment.NewLine + ex.StackTrace);
                intRetCode = ClsConstants.p_RET_CODE_FAIL;
            }
            return (intRetCode);
        }
    }
}
