/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzt_magellan_member_extr') IS NOT NULL
BEGIN
    DROP TABLE dbo.tpzt_magellan_member_extr
    IF OBJECT_ID('dbo.tpzt_magellan_member_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_magellan_member_extr >>>'
    ELSE
        PRINT '<<< DROPPED TABLE dbo.tpzt_magellan_member_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/
/****************************************************************
**   NAME                  : tpzt_magellan_member_extr
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the changed records for Magellan Daily Member Extract..
**
** REVISION HISTORY        :
**
** VERSION     DATE        DEVELOPER         DESCRIPTION
** -------- ----------   -------------    ------------------
**   1.0    03/10/2014   Amol Sangar       Initial Version
****************************************************************/
CREATE TABLE dbo.tpzt_magellan_member_extr
(
    ISA13                                 VARCHAR(100),        
    GS06                                  VARCHAR(100),
    SE02                                  VARCHAR(100),
    MEME_CK                               INT,   
    MEME_REL                              VARCHAR(1), 
    [2000_INS02_F_RELATION]               VARCHAR(2),
    [2000_INS01_IS_SUBSCRIBER]            VARCHAR(1),
    [2000_INS03]                          VARCHAR(3)              DEFAULT         '030',
    [2000_REF02_F_SUBSCRIBER_ID]          VARCHAR(11),
    [2000_REF02_F_GROUP_ID]               VARCHAR(8),
    [2100A_NM103_F_LAST_NAME]             VARCHAR(35),
    [2100A_NM104_F_FIRST_NAME]            VARCHAR(15),
    [2100A_NM105_F_MIDDLE_INIT]           VARCHAR(1),
    [2100A_N301_F_ADDRESS_1]              VARCHAR(40),
    [2100A_N302_F_ADDRESS_2]              VARCHAR(40),
    [2100A_N401_F_CITY]                   VARCHAR(19),
    [2100A_N402_F_STATE]                  VARCHAR(2),
    [2100A_N403_F_ZIP]                    VARCHAR(11),
    [2100A_DMG02_F_BIRTH_DATE]            VARCHAR(8),
    [2100A_DMG03_F_GENDER]                VARCHAR(1),
    [2300_HD01]                           VARCHAR(3)              DEFAULT         '030',
    [2300_HD03]                           VARCHAR(2)              DEFAULT         'AK',
    [2300_HD04_F_CSPI_ID]                 VARCHAR(8),
    [2300_DTP03_F_FROM_DATE]              VARCHAR(8), 
    [2300_DTP03_F_TERM_DATE]              VARCHAR(8), 
    [2300_DTP03_F_GROUP_FROM_DATE]        VARCHAR(8), 
    [2300_DTP03_F_GROUP_TERM_DATE]        VARCHAR(8) 
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_magellan_member_extr') IS NOT NULL
    PRINT '<<< CREATED TABLE dbo.tpzt_magellan_member_extr >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE dbo.tpzt_magellan_member_extr >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/