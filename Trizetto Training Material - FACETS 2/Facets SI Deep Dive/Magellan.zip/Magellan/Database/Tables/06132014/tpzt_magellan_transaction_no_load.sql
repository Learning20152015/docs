/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzt_magellan_transaction_no_load') IS NOT NULL
BEGIN
    DROP TABLE dbo.tpzt_magellan_transaction_no_load
    IF OBJECT_ID('dbo.tpzt_magellan_transaction_no_load') IS NOT NULL
        PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_magellan_transaction_no_load >>>'
    ELSE
        PRINT '<<< DROPPED TABLE dbo.tpzt_magellan_transaction_no_load >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/
/****************************************************************
**   NAME                  : tpzt_magellan_transaction_no_load
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Custom
**
**   FUNCTION              : This table is used to hold the Last Transaction Number
**
** REVISION HISTORY        :
**
** VERSION     DATE        DEVELOPER         DESCRIPTION
** -------- ----------   -------------    ------------------
**   1.0    03/10/2014   Amol Sangar       Initial Version
****************************************************************/
CREATE TABLE dbo.tpzt_magellan_transaction_no_load
(
  ISA13                  VARCHAR(100),
  GS06                   VARCHAR(100),
  SE02                   VARCHAR(100),
  RUNDATE                DATETIME

)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_magellan_transaction_no_load') IS NOT NULL
    PRINT '<<< CREATED TABLE dbo.tpzt_magellan_transaction_no_load >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE dbo.tpzt_magellan_transaction_no_load >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/