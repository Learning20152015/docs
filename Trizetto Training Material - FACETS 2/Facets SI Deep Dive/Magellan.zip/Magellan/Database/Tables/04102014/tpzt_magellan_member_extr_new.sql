/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzt_magellan_member_extr_new') IS NOT NULL
BEGIN
    DROP TABLE dbo.tpzt_magellan_member_extr_new
    IF OBJECT_ID('dbo.tpzt_magellan_member_extr_new') IS NOT NULL
        PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_magellan_member_extr_new >>>'
    ELSE
        PRINT '<<< DROPPED TABLE dbo.tpzt_magellan_member_extr_new >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/
/****************************************************************
**   NAME                  : tpzt_magellan_member_extr_new
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the present day's records for Magellan Daily Member Extract.
**
** REVISION HISTORY        :
**
** VERSION     DATE        DEVELOPER         DESCRIPTION
** -------- ----------   -------------    ------------------
**   1.0    03/19/2014   Amol Sangar      Initial Version
****************************************************************/
CREATE TABLE dbo.tpzt_magellan_member_extr_new
(
    FAMILY_ID                               varchar(9)                     NULL,     
    GROUP_ID                                varchar(8)                     NULL,
    RELATION                                varchar(1)                     NULL,
    CSPD_CAT                                varchar(1)                     NULL,
    MEST_TYPE                               varchar(1)                     NULL,
    MEHD_TYPE                               varchar(1)                     NULL,
    LAST_NAME                               varchar(35)                    NULL,
    FIRST_NAME                              varchar(15)                    NULL,
    MIDDLE_INIT                             varchar(1)                     NULL,
    TITLE                                   varchar(10)                    NULL,    
    SSN                                     varchar(9)                     NULL,
    PHONE                                   varchar(11)                    NULL,
    ADDRESS_1                               varchar(40)                    NULL,    
    ADDRESS_2                               varchar(40)                    NULL,
    CITY                                    varchar(19)                    NULL,
    MEME_STATE                              varchar(2)                     NULL,
    ZIP                                     varchar(11)                    NULL,    
    COUNTRY_CODE                            varchar(4)                     NULL,
    M_ADDRESS_1                             varchar(40)                    NULL,    
    M_ADDRESS_2                             varchar(40)                    NULL,
    M_CITY                                  varchar(19)                    NULL,
    M_MEME_STATE                            varchar(2)                     NULL,
    M_ZIP                                   varchar(11)                    NULL,    
    M_COUNTRY_CODE                          varchar(4)                     NULL,
    M_TYPE_CODE                             varchar(4)                     NULL,
    BIRTH_DATE                              decimal(8)                     NULL,
    GENDER                                  varchar(1)                     NULL,    
    CSPI_ID                                 varchar(8)                     NULL, 
    MEPE_FI                                 varchar(1)                     NULL,
    FROM_DATE                               decimal(8)                     NULL, 
    TERM_DATE                               decimal(8)                     NULL,
    MEME_CK                                 int                            NULL
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_magellan_member_extr_new') IS NOT NULL
    PRINT '<<< CREATED TABLE dbo.tpzt_magellan_member_extr_new >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE dbo.tpzt_magellan_member_extr_new >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

