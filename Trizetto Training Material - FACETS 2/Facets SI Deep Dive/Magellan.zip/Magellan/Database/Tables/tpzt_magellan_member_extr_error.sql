/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzt_magellan_member_extr_error') IS NOT NULL
BEGIN
    DROP TABLE dbo.tpzt_magellan_member_extr_error
    IF OBJECT_ID('dbo.tpzt_magellan_member_extr_error') IS NOT NULL
        PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_magellan_member_extr_error >>>'
    ELSE
        PRINT '<<< DROPPED TABLE dbo.tpzt_magellan_member_extr_error >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/
/****************************************************************
**   NAME                  : tpzt_magellan_member_extr_error
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the present day's records for Magellan Daily Member Extract.
**
** REVISION HISTORY        :
**
** VERSION     DATE        DEVELOPER         DESCRIPTION
** -------- ----------   -------------    ------------------
**   1.0    06/03/2014   Amol Sangar      Initial Version
**   1.1    06/13/2014   Amol Sangar      Replaces CSPI_ID with PDBC_PFX(PRODUCT_CODE) column
****************************************************************/
CREATE TABLE dbo.tpzt_magellan_member_extr_error
(
    MEME_CK                                 INT                            NULL,
    IS_SUBSCRIBER                           VARCHAR(1)                     NULL,
    FAMILY_ID                               VARCHAR(11)                    NULL,     
    GROUP_ID                                VARCHAR(8)                     NULL,
    MEME_REL                                VARCHAR(1)                     NULL,
    RELATION                                VARCHAR(2)                     NULL,
    LAST_NAME                               VARCHAR(35)                    NULL,
    FIRST_NAME                              VARCHAR(15)                    NULL,
    MIDDLE_INIT                             VARCHAR(1)                     NULL,
    ADDRESS_1                               VARCHAR(40)                    NULL,    
    ADDRESS_2                               VARCHAR(40)                    NULL,
    CITY                                    VARCHAR(19)                    NULL,
    MEME_STATE                              VARCHAR(2)                     NULL,
    ZIP                                     VARCHAR(11)                    NULL,    
    BIRTH_DATE                              VARCHAR(8)                     NULL,
    GENDER                                  VARCHAR(1)                     NULL,
	PRODUCT_CODE                            VARCHAR(4)                     NULL,
    FROM_DATE                               VARCHAR(8)                     NULL, 
    TERM_DATE                               VARCHAR(8)                     NULL,
    GROUP_FROM_DATE                         VARCHAR(8)                     NULL, 
    GROUP_TERM_DATE                         VARCHAR(8)                     NULL,
	ERROR_DESCRIPTION						VARCHAR(200)               
    
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_magellan_member_extr_error') IS NOT NULL
    PRINT '<<< CREATED TABLE dbo.tpzt_magellan_member_extr_error >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE dbo.tpzt_magellan_member_extr_error >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

