/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzt_magellan_member_extr_old') IS NOT NULL
BEGIN
    DROP TABLE dbo.tpzt_magellan_member_extr_old
    IF OBJECT_ID('dbo.tpzt_magellan_member_extr_old') IS NOT NULL
        PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_magellan_member_extr_old >>>'
    ELSE
        PRINT '<<< DROPPED TABLE dbo.tpzt_magellan_member_extr_old >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/
/****************************************************************
**   NAME                  : tpzt_magellan_member_extr_old
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the present day's records for Magellan Daily Member Extract.
**
** REVISION HISTORY        :
**
** VERSION     DATE        DEVELOPER         DESCRIPTION
** -------- ----------   -------------    ------------------
**   1.0    03/19/2014   Amol Sangar      Initial Version
****************************************************************/
CREATE TABLE dbo.tpzt_magellan_member_extr_old
(
    MEME_CK                                 INT                            NULL,
    IS_SUBSCRIBER							varchar(1)					   NULL,
    FAMILY_ID                               varchar(11)                     NULL,     
    GROUP_ID                                varchar(8)                     NULL,
    MEME_REL                                varchar(1)                     NULL,
    RELATION                                varchar(2)                     NULL,
    LAST_NAME                               varchar(35)                    NULL,
    FIRST_NAME                              varchar(15)                    NULL,
    MIDDLE_INIT                             varchar(1)                     NULL,
    ADDRESS_1                               varchar(40)                    NULL,    
    ADDRESS_2                               varchar(40)                    NULL,
    CITY                                    varchar(19)                    NULL,
    MEME_STATE                              varchar(2)                     NULL,
    ZIP                                     varchar(11)                    NULL,    
    BIRTH_DATE                              decimal(8)                     NULL,
    GENDER                                  varchar(1)                     NULL,   
    CSPI_ID                                 varchar(8)                     NULL, 
    PDPD_ID                                 varchar(8)                     NULL,
    FROM_DATE                               varchar(8)                     NULL, 
    TERM_DATE                               varchar(8)                     NULL,
    GROUP_FROM_DATE                         varchar(8)                     NULL, 
    GROUP_TERM_DATE                         varchar(8)                     NULL
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_magellan_member_extr_old') IS NOT NULL
    PRINT '<<< CREATED TABLE dbo.tpzt_magellan_member_extr_old >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE dbo.tpzt_magellan_member_extr_old >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
