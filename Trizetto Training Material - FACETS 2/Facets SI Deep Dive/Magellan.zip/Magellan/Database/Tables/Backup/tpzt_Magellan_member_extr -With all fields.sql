/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzt_magellan_member_extr') IS NOT NULL
BEGIN
    DROP TABLE dbo.tpzt_magellan_member_extr
    IF OBJECT_ID('dbo.tpzt_magellan_member_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_magellan_member_extr >>>'
    ELSE
        PRINT '<<< DROPPED TABLE dbo.tpzt_magellan_member_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/
/****************************************************************
**   NAME                  : tpzt_magellan_member_extr
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the changed records for Magellan Daily Member Extract..
**
** REVISION HISTORY        :
**
** VERSION     DATE        DEVELOPER         DESCRIPTION
** -------- ----------   -------------    ------------------
**   1.0    03/10/2014   Amol Sangar       Initial Version
****************************************************************/
CREATE TABLE dbo.tpzt_magellan_member_extr
(
    MEME_CK					  INT,
--ISA Segment
    ISA                           VARCHAR(3)              DEFAULT         'ISA',
    ISA01                         VARCHAR(2)              DEFAULT         '00',
    ISA02                         VARCHAR(1)              DEFAULT         SPACE(1),
    ISA03                         VARCHAR(2)              DEFAULT         '00',
    ISA04                         VARCHAR(1)              DEFAULT         SPACE(1),
    ISA05                         VARCHAR(2)              DEFAULT         'ZZ',
    ISA06                         VARCHAR(6)              DEFAULT         'BCBSNC',
    ISA07                         VARCHAR(2)              DEFAULT         '33',
    ISA08                         VARCHAR(5)              DEFAULT         '01260',
    ISA09_DATE                    VARCHAR(6),
    ISA10_TIME                    VARCHAR(4),
    ISA11                         VARCHAR(1)              DEFAULT         '^',
    ISA12                         VARCHAR(5)              DEFAULT         '00501',
    ISA13                         VARCHAR(20)             DEFAULT         '100000000',
    ISA14                         VARCHAR(1)              DEFAULT         '0',
    ISA15                         VARCHAR(1)              DEFAULT         'T',
    ISA16                         VARCHAR(1)              DEFAULT         '|',
--GS Segment
    GS01                          VARCHAR(2)              DEFAULT         'BE',
    GS02                          VARCHAR(6)              DEFAULT         'BCBSNC',
    GS03                          VARCHAR(4)              DEFAULT         '1260',
    GS04_DATE                     VARCHAR(6),
    GS05_TIME                     VARCHAR(4),
    GS06                          VARCHAR(3)              DEFAULT         '101',
    GS07                          VARCHAR(1)              DEFAULT         'X',
    GS08                          VARCHAR(12)             DEFAULT         '005010X220A1',
--ST Segment                      
    ST01                          VARCHAR(3)              DEFAULT         '834',
    ST02                          VARCHAR(20),--Check this
    ST03                          VARCHAR(12)             DEFAULT         '005010X220A1', 
--BGN Segment                     
    BGN01                         VARCHAR(1)              DEFAULT         '0',
    BGN02                         VARCHAR(20),             
    BGN03_DATE                    VARCHAR(8),
    BGN04_TIME                    VARCHAR(4),
    BGN08                         VARCHAR(1)              DEFAULT         '2',
--1000A Segment
    [1000A_N1]                    VARCHAR(2)              DEFAULT         'N1',
    [1000A_N101]                  VARCHAR(2)              DEFAULT         'P5',
    [1000A_N102]                  VARCHAR(20),--Sponsor name
    [1000A_N103]                  VARCHAR(2)              DEFAULT         'ZZ',
    [1000A_N104]                  VARCHAR(4)              DEFAULT         '9999',
--1000B Segment
    [1000B_N101]                  VARCHAR(2)              DEFAULT         'N1',
    [1000B_N102]                  VARCHAR(3)              DEFAULT         'MBH',
    [1000B_N103]                  VARCHAR(2)              DEFAULT         'FI',
    [1000B_N104]                  VARCHAR(9)              DEFAULT         '522135463',
--2000 Segment
    [2000_INS01]                  VARCHAR(1)              DEFAULT         'Y',
    [2000_INS02_F_RELATION]       VARCHAR(2),--MEME_REL
    [2000_INS03]                  VARCHAR(3)              DEFAULT         '001',
    [2000_INS05]                  VARCHAR(1)              DEFAULT         'A',
    [2000_INS06_F_CSPD_CAT]       VARCHAR(1),--CSPD_CAT
    [2000_INS08_F_CSPD_CAT]       VARCHAR(2),--CSPD_CAT
    [2000_INS09_F_MEST_TYPE]      VARCHAR(1),--MEST_TYPE
    [2000_INS10_F_MEHD_TYPE]      VARCHAR(1),--MEHD_TYPE
--2000/REF01/SUBSCRIBER
    [2000_REF01_SUBSCRIBER]       VARCHAR(2)              DEFAULT         '0F',
    [2000_REF02_F_SUBSCRIBER_ID]  VARCHAR(9),
--2000/REF01/GROUP
    [2000_REF01_GROUP]            VARCHAR(2)              DEFAULT         '1L',
    [2000_REF02_F_GROUP_ID]       VARCHAR(8),
--2100A/NM
    [2100A_NM101]                 VARCHAR(2)              DEFAULT         'IL',
    [2100A_NM102]                 VARCHAR(1)              DEFAULT         '1',
    [2100A_NM103_F_LAST_NAME]     VARCHAR(35),--MEME_LAST_NAME
    [2100A_NM104_F_FIRST_NAME]    VARCHAR(15),--MEME_FIRST_NAME
    [2100A_NM105_F_MIDDLE_INIT]   VARCHAR(1),--MEME_MID_INIT
    [2100A_NM106]                 VARCHAR(10),
    [2100A_NM107_F_TITLE]         VARCHAR(10),--MEME_TITLE
    [2100A_NM108]                 VARCHAR(2)              DEFAULT         '34',
    [2100A_NM109_F_SSN]           VARCHAR(9),--MEME_SSN,
--2100A/PER
    [2100A_PER01]                 VARCHAR(2)              DEFAULT         'IP',
    [2100A_PER03]                 VARCHAR(20),
    [2100A_PER04_F_PHONE]         VARCHAR(20),--SBAD_PHONE
--2100A/N3
    [2100A_N301_F_ADDRESS_1]      VARCHAR(40),--SBAD_ADDR1
    [2100A_N302_F_ADDRESS_2]      VARCHAR(40),--SBAD_ADDR2
--2100A/N4
    [2100A_N401_F_CITY]           VARCHAR(19),--SBAD_CITY
    [2100A_N402_F_STATE]          VARCHAR(2),--SBAD_STATE
    [2100A_N403_F_ZIP]            VARCHAR(11),--SBAD_ZIP
    [2100A_N404_F_COUNTRY_CODE]   VARCHAR(4),--SBAD_CTRY_CD
--2100A/DMG
    [2100A_DMG01]                 VARCHAR(2)              DEFAULT         'D8',
    [2100A_DMG02_F_BIRTH_DATE]    VARCHAR(8),--MEME_BIRTH_DT
    [2100A_DMG03_F_GENDER]        VARCHAR(1),--MEME_SEX 
--2100C
    [2100C_NM101]                 VARCHAR(2)              DEFAULT         '31',
    [2100C_NM102]                 VARCHAR(1)              DEFAULT         '1',
    [2100C_N301]                  VARCHAR(40),
    [2100C_N302]                  VARCHAR(40),
    [2100C_N401]                  VARCHAR(19),
    [2100C_N402]                  VARCHAR(2),
    [2100C_N403]                  VARCHAR(11),
    [2100C_N404]                  VARCHAR(4),
--2300/HD
    [2300_HD01]                   VARCHAR(3)              DEFAULT         '030',
    [2300_HD03]                   VARCHAR(2)              DEFAULT         'AK',
    [2300_HD04_F_CSPI_ID]         VARCHAR(8),--CSPI_ID 
    [2300_HD05_F_MEPE_FI]         VARCHAR(3),--MEPE_FI
--2300/DTP
    [2300_DTP01]                  VARCHAR(3)              DEFAULT         '348',
    [2300_DTP02]                  VARCHAR(2)              DEFAULT         'D8',
    [2300_DTP03_F_FROM_DATE]      VARCHAR(8) ,--MEPE_EFF_DT
--SE Segment
    SE01                          VARCHAR(3)              DEFAULT         'ESA',
    SE02                          VARCHAR(8),
--GE Segment                      
    GE01                          VARCHAR(3),
    GE02                          VARCHAR(3),
--IEA Segment                     
    IEA01                         VARCHAR(3)              DEFAULT         'ISA',
    IEA02                         VARCHAR(3),
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_magellan_member_extr') IS NOT NULL
    PRINT '<<< CREATED TABLE dbo.tpzt_magellan_member_extr >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE dbo.tpzt_magellan_member_extr >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/