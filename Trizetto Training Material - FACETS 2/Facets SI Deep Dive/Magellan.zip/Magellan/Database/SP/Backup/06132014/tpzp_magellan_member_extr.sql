/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_magellan_member_extr') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.tpzp_magellan_member_extr
    IF OBJECT_ID('dbo.tpzp_magellan_member_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_magellan_member_extr >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_magellan_member_extr >>>'
END
GO

/****************************************************************  
** END MAINTENANCE WRAPPER.                                    **  
****************************************************************/  
  
CREATE PROCEDURE [dbo].[tpzp_magellan_member_extr]  
  
/****************************************************************  
**   NAME                  :    tpzp_magellan_member_extr  
**  
**  
**   PVCS LOCATION         :      
**  
**   FUNCTION              :    The scope of this stored procedure is to extract membership/eligibility xml   
                                file from Facets for NC Plan and send it to Magellan. Extract all the Members who have  
                                active eligibility and Mental Health or Substance Abuse benefits.  
**  
**   PARAMETERS            :  
**                   INPUT :    @pRunFreq  
**                  OUTPUT :      
**  
**   RETURN CODES          :    0 on success  
**  
**   TABLES REFERENCED     :  
**                FACETS   :    CMC_SBSB_SUBSC,CMC_GRGR_GROUP,CMC_MEME_MEMBER,CMC_SBAD_ADDR,CMC_MEPE_PRCS_ELIG,CMC_PDDS_PROD_DESC,CMC_CSPI_CS_PLAN  
**                FACETSXC :    N/A  
**                CUSTOM   :    tpzt_magellan_transaction_no_load   
**                STAGE    :    tpzt_magellan_member_extr_old,tpzt_magellan_member_extr_new,tpzt_magellan_member_extr  
**  
**   PROCEDURES REFERENCED :    N/A  
**                  FACETS :    N/A  
**                  CUSTOM :    N/A  
**  
**   STANDARD LOGGING PROCS:    harcore.dbo.harsp_gen_util_job_hdr_lgr  
**                              harcore.dbo.harsp_gen_util_job_ftr_lgr  
**                              harcore.dbo.harsp_gen_util_step_hdr_lgr  
**                              harcore.dbo.harsp_gen_util_step_ftr_lgr  
**  
** REVISION HISTORY        :  
**  VERSION    DATE        DEVELOPER        DESCRIPTION  
** -------- ----------   --------------  -------------------  
**    1.0   03/11/2014   Amol Sangar      Initial version  
**    1.1   03/11/2014   Amol Sangar      CR  
**    1.2   04/25/2014   Amol Sangar      Adding Revision History  
**    1.3   05/05/2014   Amol Sangar      Changed High End dates to 12312199  
**    1.4   05/20/2014   Amol Sangar      Validate FROM_DATE,GROUP TERM_DATE and FROM_DATE  
**    1.5   05/29/2014   Amol Sangar      REPLACE - from ZIP as per updated BRD 
**    1.6   06/03/2014   Amol Sangar      Insert invalid records in error table and select valid records 
**    1.7   06/04/2014   Amol Sangar      Validate City Length 
**    1.8   06/09/2014   Amol Sangar      Refactor of code-Seperate out select 
****************************************************************/  
  
(  
    @pRunFreq       VARCHAR(10)  
)  
  
AS  
  
BEGIN  
  
  
   /****************************************************************  
   **          DECLARE LOCAL VARIABLES                            **  
   ****************************************************************/  
   DECLARE @lnRetCd                INT              -- Proc return code  
   DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field  
   DECLARE @lnCurrentStep          INT              -- Current Step Number  
   DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time  
   DECLARE @lnTotalSteps           INT              -- Total Steps In Proc  
   DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name  
   DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name  
   DECLARE @lvcDBName              VARCHAR(32)      -- DB Name  
   DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version  
   DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name  
   DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time  
   DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step  
   DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time  
   DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time  
   DECLARE @lnISA13                BIGINT           -- To hold ISA13 Unique Number  
   DECLARE @lnGS06                 BIGINT           -- To hold GS06 Unique Number  
   DECLARE @lnSE02                 BIGINT           -- To hold SE02 Unique Number  
     
  /****************************************************************  
   **          INITIALIZE  VARIABLES                              **  
   ****************************************************************/  
    SELECT  @lnRetCd          = 0,  
            @lvcMsg           = NULL,  
            @lnCurrentStep    = 0,  
            @lnTotalSteps     = CASE WHEN @pRunFreq = 'DAILY'  
                                     THEN 19  
                                     WHEN @pRunFreq = 'QUARTERLY'  
                                     THEN 11  
                                END,  
            @ldtStepEndTime   = NULL,  
            @lvcVersionNum    = '1.0'  
     
    SELECT  @lvcServerName          = @@SERVERNAME,  
            @lvcDBName              = DB_NAME(),  
            @lvcUser                = USER_NAME(),  
            @lvcObjectName          = OBJECT_NAME(@@PROCID),  
            @ldtProcessStartTime    = GETDATE()  
        
   /****************************************************************  
   **               BEGIN PROCESS                                 **  
   *****************************************************************/  
      
    /**************  PRINT JOB HEADER DATA *************************/  
      
   EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr  
        @pchObjectName        = @lvcObjectName,  
        @pdtProcessStartTime  = @ldtProcessStartTime,  
        @pchServerName        = @lvcServerName,  
        @pchDBName            = @lvcDBName,  
        @pchUserName          = @lvcUser,  
        @pchVersionNum        = @lvcVersionNum  
        
   /**************  PRINT STEP 1  HEADER DATA *************************/  
   /********** STEP 1 Populating Last Transaction Number from tpzt_magellan_transaction_no_load for Magellan Member Extract **********/  
    
    SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Populating Last Transaction Number from tpzt_magellan_transaction_no_load for Magellan Member Extract'  
  
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg   
    /************* STEP 1 Populating Last Transaction Number from tpzt_magellan_transaction_no_load for Magellan Member Extract *************/  
     
   SELECT @lnISA13 = CONVERT(BIGINT,MAX(ISA13)) FROM fabncdv1custom.dbo.tpzt_magellan_transaction_no_load  
   SELECT @lnGS06 = CONVERT(BIGINT,MAX(GS06)) FROM fabncdv1custom.dbo.tpzt_magellan_transaction_no_load  
   SELECT @lnSE02 = CONVERT(BIGINT,MAX(SE02)) FROM fabncdv1custom.dbo.tpzt_magellan_transaction_no_load     
     
   IF @lnISA13 IS NULL OR @lnGS06 IS NULL OR @lnSE02 IS NULL  
   BEGIN  
        SET @lnISA13 = 1  
        SET @lnGS06 = 101  
        SET @lnSE02 = 1101  
          
   END  
   ELSE  
   BEGIN  
        SET @lnISA13 = @lnISA13 + 1  
        SET @lnGS06 = @lnGS06 + 1  
        SET @lnSE02 = @lnSE02 + 1  
   END  
      
/************* Error Checking for Populating Last Transaction Number from tpzt_magellan_transaction_no_load for Magellan Member Extract *************/  
          
            SELECT @lnRetCd    = @@ERROR,  
                @lnRowsProcessed = @@ROWCOUNT  
  
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Populating Last Transaction Number from tpzt_magellan_transaction_no_load for Magellan Member Extract FAILED.'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
    /************* STEP 1(a) Truncate stage table tpzt_magellan_member_extr_old *************/  
    IF UPPER(@pRunFreq) = 'DAILY'  
        BEGIN  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_magellan_member_extr_old.'  
  
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
       
            /************* STEP 1(a) Truncate stage table tpzt_magellan_member_extr_old *************/  
              
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr_old  
              
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr_old *************/  
          
            SELECT @lnRetCd    = @@ERROR,  
                @lnRowsProcessed = @@ROWCOUNT  
  
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Truncating stage table tpzt_magellan_member_extr_old FAILED.'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
          
            /************* STEP 1(b) Inserting data into stage table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Inserting data into Staging table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new.'  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
              
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr_old  
            (  
                MEME_CK,  
                IS_SUBSCRIBER,  
                FAMILY_ID,     
                GROUP_ID,  
                MEME_REL,      
                RELATION,   
                LAST_NAME,     
                FIRST_NAME,    
                MIDDLE_INIT,  
                ADDRESS_1,     
                ADDRESS_2,     
                CITY,          
                MEME_STATE,    
                ZIP,  
                BIRTH_DATE,   
                GENDER,  
                CSPI_ID,       
                FROM_DATE,     
                TERM_DATE,  
                GROUP_FROM_DATE,  
                GROUP_TERM_DATE,
                ISVALID  
                )  
            SELECT  
                MEME_CK,  
                IS_SUBSCRIBER,  
                FAMILY_ID,     
                GROUP_ID,  
                MEME_REL,      
                RELATION,   
                LAST_NAME,     
                FIRST_NAME,    
                MIDDLE_INIT,  
                ADDRESS_1,     
                ADDRESS_2,     
                CITY,          
                MEME_STATE,    
                ZIP,  
                BIRTH_DATE,   
                GENDER,  
                CSPI_ID,      
                FROM_DATE,     
                TERM_DATE,  
                GROUP_FROM_DATE,  
                GROUP_TERM_DATE,
                ISVALID  
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new                            
              
            /************* Error Checking for Inserting data into stage table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new *************/  
              
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Inserting data into stage table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new FAILED.'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
      
            /************* STEP 1(c) Truncate stage table tpzt_magellan_member_extr_new *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_magellan_member_extr_new.'  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
              
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr_new  
              
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr_new *************/  
              
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Truncating stage table tpzt_magellan_member_extr_new FAILED.'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
                               
            /************* STEP 1(d) Populating the stage table tpzt_magellan_member_extr_new *************/    
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Populating the Staging table tpzt_magellan_member_extr_new with DAILY records.'  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
              
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr_new  
            (    
                MEME_CK,  
                IS_SUBSCRIBER,  
                FAMILY_ID,     
                GROUP_ID,  
                MEME_REL,      
                RELATION,  
                LAST_NAME,     
                FIRST_NAME,    
                MIDDLE_INIT,  
                ADDRESS_1,     
                ADDRESS_2,     
                CITY,          
                MEME_STATE,    
                ZIP,  
                BIRTH_DATE,  
                GENDER,    
                CSPI_ID,      
                FROM_DATE,     
                TERM_DATE,  
                GROUP_FROM_DATE,  
                GROUP_TERM_DATE  
            )  
            SELECT  
                meme.MEME_CK,  
                CASE   
                        WHEN [MEME_REL]='M' THEN 'Y'  
                        ELSE 'N'  
                END AS IS_SUBSCRIBER,      
                CONCAT(RIGHT('000000000'+ CAST(sbsb.SBSB_ID AS VARCHAR(9)),9),RIGHT('00' + CAST(meme.MEME_SFX AS VARCHAR(2)),2)) AS SBSB_ID,          
                grgr.GRGR_ID,          
                meme.MEME_REL,  
                CASE   
                        WHEN [MEME_REL]='M' THEN '18'   
                        WHEN [MEME_REL]='H' OR [MEME_REL]='W' THEN '01'    
                        WHEN [MEME_REL]='S' OR [MEME_REL]='D' THEN '19'    
                        ELSE '23'   
                END [2000_INS02_F_RELATION],  
                meme.MEME_LAST_NAME,      
                meme.MEME_FIRST_NAME,  
                meme.MEME_MID_INIT,        
                sbad.SBAD_ADDR1,          
                sbad.SBAD_ADDR2,          
                sbad.SBAD_CITY,          
                sbad.SBAD_STATE,          
                LTRIM(RTRIM(REPLACE(sbad.SBAD_ZIP, '-', ''))) AS ZIP,   
                CONVERT(VARCHAR(8),meme.MEME_BIRTH_DT,112) AS MEME_BIRTH_DT,      
                meme.MEME_SEX,  
                mepe.CSPI_ID,  
                CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112)  AS MEPE_EFF_DT,                 
                CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112)  AS MEPE_TERM_DT,  
                CONVERT(VARCHAR(8),grgr.GRGR_ORIG_EFF_DT,112) AS GRGR_ORIG_EFF_DT,   
                CASE   
                    WHEN CONVERT(VARCHAR(8),grgr.GRGR_TERM_DT,112) ='99991231'  
                    THEN '21991231'  
                    ELSE    
                    CONVERT(VARCHAR(8),grgr.GRGR_TERM_DT,112)   
                END AS GRGR_TERM_DT                
                --CONVERT(VARCHAR(8),grgr.GRGR_TERM_DT,112)  AS GRGR_TERM_DT  
            FROM    fabncdv1.dbo.CMC_SBSB_SUBSC sbsb  
                    INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr  
                        ON sbsb.GRGR_CK=grgr.GRGR_CK  
                    INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme  
                        ON meme.SBSB_CK=sbsb.SBSB_CK  
                    INNER JOIN fabncdv1.dbo.CMC_SBAD_ADDR sbad  
                        ON sbsb.SBSB_CK=sbad.SBSB_CK  
                           AND sbad.GRGR_CK=grgr.GRGR_CK  
                    INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe  
                        ON mepe.MEME_CK=meme.MEME_CK  
                           AND mepe.GRGR_CK=grgr.GRGR_CK    
                    WHERE  
                            grgr.GRGR_MCTR_TYPE = 'COMM'  
                        AND mepe.CSPD_CAT ='M'  
                        AND mepe.MEPE_ELIG_IND='Y'  
                        AND sbad.SBAD_TYPE = meme.SBAD_TYPE_MAIL  
                        AND mepe.MEPE_TERM_DT >= CONVERT(VARCHAR(8),GETDATE(),112)  
                         
            /************* Error Checking for Populating the stage table tpzt_magellan_member_extr_new with DAILY records *************/  
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Populating the Staging table tpzt_magellan_member_extr_new with DAILY records FAILED. '  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
         
         /************* STEP 1(d) Populating the stage table tpzt_magellan_member_extr_new *************/    
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Validating the records for required fields in DAILY process. '  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg 
         /************* STEP 1(e) Validating the records for required fields in DAILY process *************/    
            UPDATE extr
            SET    extr.ISVALID = 'Y'
            FROM   fabncdv1stage.dbo.tpzt_magellan_member_extr_new extr
            WHERE  extr.ISVALID = 'N'
            AND    (ISNULL(LTRIM(RTRIM(extr.IS_SUBSCRIBER)), '') <> '' 
            AND     ISNULL(LTRIM(RTRIM(extr.MEME_REL)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.FAMILY_ID)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.GROUP_FROM_DATE)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.GROUP_TERM_DATE)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.LAST_NAME)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.FIRST_NAME)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.ADDRESS_1)), '') <> ''
            AND     (ISNULL(LTRIM(RTRIM(extr.CITY)), '') <> '' AND LEN(LTRIM(RTRIM(extr.CITY))) >= 2)
            AND     (ISNULL(LTRIM(RTRIM(extr.MEME_STATE)), '') <> '' AND LEN(LTRIM(RTRIM(extr.MEME_STATE))) = 2)
            AND     (ISNULL(LTRIM(RTRIM(extr.ZIP)), '') <> '' OR ISNUMERIC(LTRIM(RTRIM(extr.ZIP))) = 1)
            AND     ISNULL(LTRIM(RTRIM(extr.BIRTH_DATE)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.GENDER)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.CSPI_ID)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.FROM_DATE)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.TERM_DATE)), '') <> '')

                         
            /************* Error Checking for Validating the records for required fields in DAILY process *************/  
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Validating the records for required fields in DAILY process '  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END
         
            /************* STEP 1(f) DELETE stage table tpzt_magellan_member_extr_new records which has FROM_DATE=TERM_DATE *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': DELETE stage table tpzt_magellan_member_extr_new records which has FROM_DATE=TERM_DATE'  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
              
            DELETE FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new  
                        WHERE FROM_DATE = TERM_DATE  
               
            /************* Error Checking for records which has FROM_DATE=TERM_DATE *************/  
              
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : DELETE stage table tpzt_magellan_member_extr_new records which has FROM_DATE=TERM_DATE FAILED'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END   
                  
            /************* STEP 1(g) Truncate stage table tpzt_magellan_member_extr *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Truncate stage table tpzt_magellan_member_extr.'  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
              
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr  
              
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr *************/  
              
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Truncating stage table tpzt_magellan_member_extr FAILED.'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
              
              
            /************* STEP 1(h) Populate the stage table tpzt_magellan_member_extr with Daily Records  *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Populate the stage table tpzt_magellan_member_extr with Daily Records. '  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
              
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr  
            (  
                ISA13,  
                GS06,  
                SE02,  
                MEME_CK,  
                [2000_INS01_IS_SUBSCRIBER],  
                MEME_REL,  
                [2000_INS02_F_RELATION],  
                [2000_INS03],  
                [2000_REF02_F_SUBSCRIBER_ID],  
                [2000_REF02_F_GROUP_ID]  ,  
                [2100A_NM103_F_LAST_NAME],     
                [2100A_NM104_F_FIRST_NAME],    
                [2100A_NM105_F_MIDDLE_INIT],   
                [2100A_N301_F_ADDRESS_1],    
                [2100A_N302_F_ADDRESS_2],    
                [2100A_N401_F_CITY],           
                [2100A_N402_F_STATE],          
                [2100A_N403_F_ZIP],          
                [2100A_DMG02_F_BIRTH_DATE],     
                [2100A_DMG03_F_GENDER],  
                [2300_HD01],    
                [2300_HD04_F_CSPI_ID],   
                [2300_DTP03_F_FROM_DATE],  
                [2300_DTP03_F_TERM_DATE],         
                [2300_DTP03_F_GROUP_FROM_DATE],   
                [2300_DTP03_F_GROUP_TERM_DATE]  
             )  
             SELECT  
                RIGHT('000000000' + CONVERT(VARCHAR,@lnISA13), 9),  
                RIGHT('00' + CONVERT(VARCHAR, @lnGS06), 3),  
                RIGHT('000' + CONVERT(VARCHAR, @lnSE02), 4),  
                curr.MEME_CK,  
                curr.IS_SUBSCRIBER,  
                curr.MEME_REL,  
                curr.RELATION,  
                '',  
                curr.FAMILY_ID,                 
                curr.GROUP_ID,  
                curr.LAST_NAME,                 
                curr.FIRST_NAME,  
                curr.MIDDLE_INIT,  
                curr.ADDRESS_1,                 
                curr.ADDRESS_2,                
                curr.CITY,                      
                curr.MEME_STATE,                
                curr.ZIP,    
                CASE   
                    WHEN curr.BIRTH_DATE =0  
                    THEN '00000000'  
                    ELSE    
                    CONVERT(VARCHAR(8),curr.BIRTH_DATE,112)  
                END AS BIRTH_DATE,  
                curr.GENDER,  
                '',                    
                curr.CSPI_ID,                   
                CASE   
                    WHEN curr.FROM_DATE =0  
                    THEN '00000000'  
                    ELSE    
                    CONVERT(VARCHAR(8),curr.FROM_DATE ,112)  
                END AS FROM_DATE,  
                CASE   
                    WHEN curr.TERM_DATE =0  
                    THEN '21991231'  
                    ELSE    
                    CONVERT(VARCHAR(8),curr.TERM_DATE,112)  
                END AS TERM_DATE,  
                CASE   
                    WHEN curr.GROUP_FROM_DATE =0  
                    THEN '00000000'  
                    ELSE    
                    CONVERT(VARCHAR(8),curr.GROUP_FROM_DATE,112)  
                END AS GROUP_FROM_DATE,  
                CASE   
                    WHEN curr.GROUP_TERM_DATE =0  
                    THEN '21991231'  
                    ELSE    
                    CONVERT(VARCHAR(8),curr.GROUP_TERM_DATE ,112)  
                END AS GROUP_TERM_DATE  
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new curr  
            WHERE curr.ISVALID = 'Y'      
            EXCEPT  
                  
            SELECT  
                RIGHT('000000000' + CONVERT(VARCHAR,@lnISA13), 9),  
                RIGHT('00' + CONVERT(VARCHAR, @lnGS06), 3),  
                RIGHT('000' + CONVERT(VARCHAR, @lnSE02), 4),  
                prev.MEME_CK,  
                prev.IS_SUBSCRIBER,  
                prev.MEME_REL,  
                prev.RELATION,  
                '',  
                prev.FAMILY_ID,                 
                prev.GROUP_ID,  
                prev.LAST_NAME,                 
                prev.FIRST_NAME,  
                prev.MIDDLE_INIT,  
                prev.ADDRESS_1,                 
                prev.ADDRESS_2,                
                prev.CITY,                      
                prev.MEME_STATE,                
                prev.ZIP,    
                CASE   
                    WHEN prev.BIRTH_DATE =0  
                    THEN '00000000'  
                    ELSE   
                    CONVERT(VARCHAR(8), prev.BIRTH_DATE,112)  
                END AS BIRTH_DATE,  
                prev.GENDER,   
                '',                   
                prev.CSPI_ID,                   
                CASE   
                    WHEN prev.FROM_DATE =0  
                    THEN '00000000'  
                    ELSE    
                    CONVERT(VARCHAR(8),prev.FROM_DATE,112)  
                END AS FROM_DATE,  
                CASE   
                    WHEN prev.TERM_DATE =0  
                    THEN '21991231'  
                    ELSE    
                    CONVERT(VARCHAR(8),prev.TERM_DATE,112)  
                END AS TERM_DATE,  
                CASE   
                    WHEN prev.GROUP_FROM_DATE =0  
                    THEN '00000000'  
                    ELSE    
                    CONVERT(VARCHAR(8),prev.GROUP_FROM_DATE,112)  
                END AS GROUP_FROM_DATE,  
                CASE   
                    WHEN prev.GROUP_TERM_DATE =0  
                    THEN '21991231'  
                    ELSE    
                    CONVERT(VARCHAR(8),prev.GROUP_TERM_DATE,112)  
                END AS GROUP_TERM_DATE  
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev 
            WHERE prev.ISVALID = 'Y' 
              
            /************* Error Checking for Populate the stage table tpzt_magellan_member_extr with Daily Records *************/  
              
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Populate the stage table tpzt_magellan_member_extr with Daily Records FAILED.'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
             
           /************* STEP 1(i) Update tpzt_magellan_member_extr_new stage table for changed TERM date *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Update tpzt_magellan_member_extr_new stage table for changed TERM date.  '  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
                  
            UPDATE curr  
                        SET [2000_INS03]='024',[2300_HD01] = '024'  
                        FROM fabncdv1stage.dbo.tpzt_magellan_member_extr curr  
                        WHERE   EXISTS (SELECT 1 FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev  
                                           WHERE     curr.MEME_CK=prev.MEME_CK  
                                                 AND curr.[2300_HD04_F_CSPI_ID]= prev.CSPI_ID   
                                           )  
                                AND NOT EXISTS (SELECT 1 FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev  
                                          WHERE      curr.MEME_CK=prev.MEME_CK  
                                                 AND curr.[2300_DTP03_F_TERM_DATE] = prev.TERM_DATE  
                                               )  
                                  
            /************* Error Checking for Update tpzt_magellan_member_extr_new stage table for changed TERM date  *************/  
              
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Update tpzt_magellan_member_extr_new stage table for  changed TERM date FAILED.'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
                  
            
            /************* STEP 1(j) Update stage table Update tpzt_magellan_member_extr_new stage table for changed  records *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Update tpzt_magellan_member_extr_new stage table for changed  records. '  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
             
            UPDATE curr  
                        SET [2000_INS03]='001',[2300_HD01] = '001'  
                        FROM fabncdv1stage.dbo.tpzt_magellan_member_extr curr  
                        WHERE  EXISTS(SELECT 1 FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev  
                                            WHERE     curr.MEME_CK= prev.MEME_CK   
                                                 AND curr.[2300_HD04_F_CSPI_ID]= prev.CSPI_ID   
                                                 AND curr.[2300_DTP03_F_FROM_DATE] = prev.FROM_DATE  
                                                 AND curr.[2300_DTP03_F_TERM_DATE] = prev.TERM_DATE  
                                      )  
                         AND NOT EXISTS (SELECT 1 FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev  
                                          WHERE   
                                                    curr.[2000_INS02_F_RELATION] = prev.RELATION   
                                                AND curr.[2100A_NM103_F_LAST_NAME] = prev.LAST_NAME    
                                                AND curr.[2100A_NM104_F_FIRST_NAME] =  prev.FIRST_NAME  
                                                AND curr.[2100A_NM105_F_MIDDLE_INIT] = prev.MIDDLE_INIT  
                                                AND curr.[2100A_N301_F_ADDRESS_1]= prev.ADDRESS_1    
                                                AND curr.[2100A_N302_F_ADDRESS_2]= prev.ADDRESS_2  
                                                AND curr.[2100A_N401_F_CITY]=  prev.CITY      
                                                AND curr.[2100A_N402_F_STATE]=prev.MEME_STATE    
                                                AND curr.[2100A_N403_F_ZIP]= prev.ZIP        
                                                AND curr.[2100A_DMG02_F_BIRTH_DATE] = prev.BIRTH_DATE   
                                                AND curr.[2100A_DMG03_F_GENDER]=prev.GENDER  
            AND curr.[2300_DTP03_F_GROUP_FROM_DATE] = prev.GROUP_FROM_DATE  
            AND curr.[2300_DTP03_F_GROUP_TERM_DATE] = prev.GROUP_TERM_DATE  
                                            )  
                                  
            /************* Error Checking for Update tpzt_magellan_member_extr_new stage table for changed records *************/  
              
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Update tpzt_magellan_member_extr_new stage table for changed records FAILED.'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
                                     
            /************* STEP 1(k) Update tpzt_magellan_member_extr_new stage table for new added records *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Update tpzt_magellan_member_extr_new stage table for new added records.  '  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
             
            UPDATE curr  
                        SET [2000_INS03]='021',[2300_HD01] = '021'  
                        FROM fabncdv1stage.dbo.tpzt_magellan_member_extr curr  
                        WHERE  NOT EXISTS (SELECT 1 FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev  
                                           WHERE curr.MEME_CK=prev.MEME_CK  
                                           )  
                                 
            /************* Error Checking for Update tpzt_magellan_member_extr_new stage table for new added records  *************/  
              
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Update tpzt_magellan_member_extr_new stage table for new added records  FAILED.'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
              
            /************* STEP 1(l) Update tpzt_magellan_member_extr_new stage table for new added records,for changed CSPI_ID *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Update tpzt_magellan_member_extr_new stage table for new added records ,for changed CSPI_ID.  '  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg    = @lvcMsg  
              
            UPDATE curr  
                        SET [2000_INS03]='021',[2300_HD01] = '021'  
                        FROM fabncdv1stage.dbo.tpzt_magellan_member_extr curr  
                        WHERE   EXISTS (SELECT 1 FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev  
                                           WHERE curr.MEME_CK=prev.MEME_CK  
                                            )  
                                AND NOT EXISTS (SELECT 1 FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev  
                                          WHERE   
                                                    curr.[2300_HD04_F_CSPI_ID]= prev.CSPI_ID    
            AND curr.[2300_DTP03_F_FROM_DATE] = prev.FROM_DATE    
                                                AND curr.MEME_CK= prev.MEME_CK    
                                                )  
                                  
            /************* Error Checking for Update tpzt_magellan_member_extr_new stage table for new added records,for changed CSPI_ID  *************/  
              
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Update tpzt_magellan_member_extr_new stage table for new added records,for changed CSPI_ID FAILED.'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END            
              
                
            /************* STEP 1(m) Populate the stage table tpzt_magellan_member_extr with Terminated Records  *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Populate the stage table tpzt_magellan_member_extr with Terminated Records. '  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
              
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr  
            (  
                ISA13,  
                GS06,  
                SE02,  
                MEME_CK,  
                [2000_INS01_IS_SUBSCRIBER],  
                MEME_REL,  
                [2000_INS02_F_RELATION],  
                [2000_INS03],  
                [2000_REF02_F_SUBSCRIBER_ID],  
                [2000_REF02_F_GROUP_ID]  ,  
                [2100A_NM103_F_LAST_NAME],     
                [2100A_NM104_F_FIRST_NAME],    
                [2100A_NM105_F_MIDDLE_INIT],   
                [2100A_N301_F_ADDRESS_1],    
                [2100A_N302_F_ADDRESS_2],    
                [2100A_N401_F_CITY],           
                [2100A_N402_F_STATE],          
                [2100A_N403_F_ZIP],          
                [2100A_DMG02_F_BIRTH_DATE],     
                [2100A_DMG03_F_GENDER],  
                [2300_HD01],    
                [2300_HD04_F_CSPI_ID],   
                [2300_DTP03_F_FROM_DATE],  
                [2300_DTP03_F_TERM_DATE],         
                [2300_DTP03_F_GROUP_FROM_DATE],   
                [2300_DTP03_F_GROUP_TERM_DATE]  
            )  
            SELECT  
                RIGHT('000000000' + CONVERT(VARCHAR,@lnISA13), 9),  
                RIGHT('00' + CONVERT(VARCHAR, @lnGS06), 3),  
                RIGHT('000' + CONVERT(VARCHAR, @lnSE02), 4),  
                meme.MEME_CK,  
                CASE   
                        WHEN meme.[MEME_REL]='M' THEN 'Y'  
                        ELSE 'N'  
                END AS IS_SUBSCRIBER,   
                meme.MEME_REL,    
                CASE   
                        WHEN meme.[MEME_REL]='M' THEN '18'   
                        WHEN meme.[MEME_REL]='H' OR meme.[MEME_REL]='W' THEN '01'    
                        WHEN meme.[MEME_REL]='S' OR meme.[MEME_REL]='D' THEN '19'    
                        ELSE '23'   
                END [2000_INS02_F_RELATION],  
                '024' AS [2300_HD01],   
                CONCAT(RIGHT('000000000'+ CAST(sbsb.SBSB_ID AS VARCHAR(9)),9),RIGHT('00' + CAST(meme.MEME_SFX AS VARCHAR(2)),2)) AS SBSB_ID,          
                grgr.GRGR_ID,          
                meme.MEME_LAST_NAME,      
                meme.MEME_FIRST_NAME,  
                meme.MEME_MID_INIT,        
                sbad.SBAD_ADDR1,          
                sbad.SBAD_ADDR2,          
                sbad.SBAD_CITY,          
                sbad.SBAD_STATE,          
                LTRIM(RTRIM(REPLACE(sbad.SBAD_ZIP, '-', ''))) AS ZIP,   
                CONVERT(VARCHAR(8),meme.MEME_BIRTH_DT,112) AS MEME_BIRTH_DT,      
                meme.MEME_SEX,  
                '024' AS [2300_HD01],  
                prev.CSPI_ID,   
                CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112)  AS MEPE_EFF_DT,                 
                CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112)  AS MEPE_TERM_DT,  
                CONVERT(VARCHAR(8),grgr.GRGR_ORIG_EFF_DT,112)  AS GRGR_ORIG_EFF_DT,   
                CASE   
                    WHEN CONVERT(VARCHAR(8),grgr.GRGR_TERM_DT,112) ='99991231'  
                    THEN '21991231'  
                    ELSE    
                    CONVERT(VARCHAR(8),grgr.GRGR_TERM_DT,112)   
                END AS GRGR_TERM_DT                  
                --CONVERT(VARCHAR(8),grgr.GRGR_TERM_DT,112)  AS GRGR_TERM_DT              
            FROM    
                fabncdv1.dbo.CMC_GRGR_GROUP grgr     
                INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg    
                        ON sgsg.GRGR_CK = grgr.GRGR_CK        
                INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb     
                        ON sbsb.GRGR_CK = grgr.GRGR_CK     
                INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme    
                        ON meme.SBSB_CK = sbsb.SBSB_CK    
                INNER JOIN fabncdv1.dbo.CMC_SBAD_ADDR sbad    
                        ON sbsb.SBSB_CK = sbad.SBSB_CK    
                       AND meme.SBAD_TYPE_HOME = sbad.SBAD_TYPE    
                INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe    
                        ON meme.MEME_CK = mepe.MEME_CK    
                INNER JOIN fabncdv1.dbo.CMC_PDDS_PROD_DESC pdds    
                        ON mepe.PDPD_ID = pdds.PDPD_ID    
                INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi    
                        ON  cspi.GRGR_CK = mepe.GRGR_CK    
                        AND cspi.CSPI_ID = mepe.CSPI_ID    
                        AND cspi.CSPD_CAT = mepe.CSPD_CAT     
                        AND cspi.CSCS_ID = mepe.CSCS_ID  
                INNER JOIN fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev  
                        ON prev.MEME_CK = mepe.MEME_CK    
                WHERE  CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) IN (SELECT DISTINCT prev.FROM_DATE     
                                    FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev WHERE prev.MEME_CK = mepe.MEME_CK)    
                    AND (CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112)  NOT IN ( SELECT DISTINCT curr.FROM_DATE     
                                FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new curr WHERE curr.MEME_CK = mepe.MEME_CK)   
                        OR prev.CSPI_ID  NOT IN ( SELECT DISTINCT curr.CSPI_ID     
                                    FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new curr WHERE curr.MEME_CK = mepe.MEME_CK))                        
                    AND mepe.CSPD_CAT = 'M'   
                    AND grgr.GRGR_MCTR_TYPE = 'COMM'   
                    AND sbad.SBAD_TYPE = meme.SBAD_TYPE_MAIL  
                    AND (ISNULL(LTRIM(RTRIM(meme.[MEME_REL])), '') <> '' 
            AND     (ISNULL(LTRIM(RTRIM(sbsb.SBSB_ID)), '') <> '' AND ISNULL(LTRIM(RTRIM(meme.MEME_SFX)), '') <> '')
            AND     ISNULL(LTRIM(RTRIM(grgr.GRGR_ORIG_EFF_DT)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(grgr.GRGR_TERM_DT)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(meme.MEME_LAST_NAME)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(meme.MEME_FIRST_NAME)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(sbad.SBAD_ADDR1)), '') <> ''
            AND     (ISNULL(LTRIM(RTRIM(sbad.SBAD_CITY)), '') <> '' AND LEN(LTRIM(RTRIM(sbad.SBAD_CITY))) >= 2)
            AND     (ISNULL(LTRIM(RTRIM(sbad.SBAD_STATE)), '') <> '' AND LEN(LTRIM(RTRIM(sbad.SBAD_STATE))) = 2)
            AND     (ISNULL(LTRIM(RTRIM(sbad.SBAD_ZIP)), '') <> '' AND ISNUMERIC(LTRIM(RTRIM(sbad.SBAD_ZIP))) = 1)
            AND     ISNULL(LTRIM(RTRIM(meme.MEME_BIRTH_DT)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(meme.MEME_SEX)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(cspi.CSPI_ID)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(mepe.MEPE_EFF_DT)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(mepe.MEPE_TERM_DT)), '') <> '')
  
  
            /************* Error Checking for Populate the stage table tpzt_magellan_member_extr with Terminated Records *************/  
              
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Populate the stage table tpzt_magellan_member_extr with Terminated Records FAILED.'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
               
            
            /**************  PRINT STEP 1 FOOTER DATA *************************/  
  
            SELECT @ldtStepEndTime = GETDATE()  
  
            EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr  
                @pdtStepStartTime    = @ldtStepStartTime,  
                @pdtStepEndTime      = @ldtStepEndTime,  
                @pdtProcessStartTime = @ldtProcessStartTime,  
                @pnRowCount          = @lnRowsProcessed  
       
        END    
      
   /**************  PRINT STEP 2  HEADER DATA *************************/  
   /********** STEP 2 Populate stage table tpzt_magellan_member_extr for Magellan Quarterly Member Extract **********/  
      
    IF UPPER(@pRunFreq) = 'QUARTERLY'  
        BEGIN  
            
            /************* STEP 2(a) Truncate stage table tpzt_magellan_member_extr_new *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_magellan_member_extr_new.'  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
              
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr_new  
              
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr_new *************/  
              
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Truncating stage table tpzt_magellan_member_extr_new FAILED.'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
          
                                  
            /************* STEP 2(b) Populating the stage table tpzt_magellan_member_extr_new *************/    
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Populating the Staging table tpzt_magellan_member_extr_new with Quarterly records.'  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
              
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr_new  
            (    
                MEME_CK,  
                IS_SUBSCRIBER,  
                FAMILY_ID,     
                GROUP_ID,  
                MEME_REL,      
                RELATION,  
                LAST_NAME,     
                FIRST_NAME,    
                MIDDLE_INIT,  
                ADDRESS_1,     
                ADDRESS_2,     
                CITY,          
                MEME_STATE,    
                ZIP,  
                BIRTH_DATE,  
                GENDER,    
                CSPI_ID,      
                FROM_DATE,     
                TERM_DATE,  
                GROUP_FROM_DATE,  
                GROUP_TERM_DATE  
            )  
            SELECT  
                meme.MEME_CK,  
                CASE   
                        WHEN [MEME_REL]='M' THEN 'Y'  
                        ELSE 'N'  
                END AS IS_SUBSCRIBER,      
                CONCAT(RIGHT('000000000'+ CAST(sbsb.SBSB_ID AS VARCHAR(9)),9),RIGHT('00' + CAST(meme.MEME_SFX AS VARCHAR(2)),2)) AS SBSB_ID,          
                grgr.GRGR_ID,          
                meme.MEME_REL,  
                CASE   
                        WHEN [MEME_REL]='M' THEN '18'   
                        WHEN [MEME_REL]='H' OR [MEME_REL]='W' THEN '01'    
                        WHEN [MEME_REL]='S' OR [MEME_REL]='D' THEN '19'    
                        ELSE '23'   
                END [2000_INS02_F_RELATION],  
                meme.MEME_LAST_NAME,      
                meme.MEME_FIRST_NAME,  
                meme.MEME_MID_INIT,        
                sbad.SBAD_ADDR1,          
                sbad.SBAD_ADDR2,          
                sbad.SBAD_CITY,          
                sbad.SBAD_STATE,          
                LTRIM(RTRIM(REPLACE(sbad.SBAD_ZIP, '-', ''))) AS ZIP,   
                CONVERT(VARCHAR(8),meme.MEME_BIRTH_DT,112) AS MEME_BIRTH_DT,      
                meme.MEME_SEX,  
                mepe.CSPI_ID,  
                CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112)  AS MEPE_EFF_DT,                 
                CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112)  AS MEPE_TERM_DT,  
                CONVERT(VARCHAR(8),grgr.GRGR_ORIG_EFF_DT,112)  AS GRGR_ORIG_EFF_DT,    
                CASE   
                    WHEN CONVERT(VARCHAR(8),grgr.GRGR_TERM_DT,112) ='99991231'  
                    THEN '21991231'  
                    ELSE    
                    CONVERT(VARCHAR(8),grgr.GRGR_TERM_DT,112)   
                END AS GRGR_TERM_DT                 
                --CONVERT(VARCHAR(8),grgr.GRGR_TERM_DT,112)  AS GRGR_TERM_DT  
            FROM   fabncdv1.dbo.CMC_SBSB_SUBSC sbsb  
                    INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr  
                        ON sbsb.GRGR_CK=grgr.GRGR_CK  
                    INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme  
                        ON meme.SBSB_CK=sbsb.SBSB_CK  
                    INNER JOIN fabncdv1.dbo.CMC_SBAD_ADDR sbad  
                        ON sbsb.SBSB_CK=sbad.SBSB_CK  
                           AND sbad.GRGR_CK=grgr.GRGR_CK  
                    INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe  
                        ON mepe.MEME_CK=meme.MEME_CK  
                           AND mepe.GRGR_CK=grgr.GRGR_CK    
                    WHERE  
                            grgr.GRGR_MCTR_TYPE = 'COMM'  
                        AND mepe.CSPD_CAT ='M'  
                        AND mepe.MEPE_ELIG_IND='Y'  
                        AND sbad.SBAD_TYPE = meme.SBAD_TYPE_MAIL  
                        AND mepe.MEPE_TERM_DT >= CONVERT(VARCHAR(8),GETDATE(),112)  
                          
            /************* Error Checking for Populating the Staging table tpzt_magellan_member_extr_new with Quarterly records *************/  
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Populating the Staging table tpzt_magellan_member_extr_new with Quarterly records FAILED. '  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
                
           /************* STEP 1(d) Populating the stage table tpzt_magellan_member_extr_new *************/    
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Validating the records for required fields in QUARTERLY process. '  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg 
         /************* STEP 1(e) Validating the records for required fields in DAILY process *************/    
            UPDATE extr
            SET    extr.ISVALID = 'Y'
            FROM   fabncdv1stage.dbo.tpzt_magellan_member_extr_new extr
            WHERE  extr.ISVALID = 'N'
            AND     (ISNULL(LTRIM(RTRIM(extr.IS_SUBSCRIBER)), '') <> '' 
            AND     ISNULL(LTRIM(RTRIM(extr.MEME_REL)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.FAMILY_ID)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.GROUP_FROM_DATE)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.GROUP_TERM_DATE)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.LAST_NAME)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.FIRST_NAME)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.ADDRESS_1)), '') <> ''
            AND     (ISNULL(LTRIM(RTRIM(extr.CITY)), '') <> '' AND LEN(LTRIM(RTRIM(extr.CITY))) >= 2)
            AND     (ISNULL(LTRIM(RTRIM(extr.MEME_STATE)), '') <> '' AND LEN(LTRIM(RTRIM(extr.MEME_STATE))) = 2)
            AND     (ISNULL(LTRIM(RTRIM(extr.ZIP)), '') <> '' AND ISNUMERIC(LTRIM(RTRIM(extr.ZIP))) = 1)
            AND     ISNULL(LTRIM(RTRIM(extr.BIRTH_DATE)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.GENDER)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.CSPI_ID)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.FROM_DATE)), '') <> ''
            AND     ISNULL(LTRIM(RTRIM(extr.TERM_DATE)), '') <> '')

                         
            /************* Error Checking for Validating the records for required fields in DAILY process *************/  
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Validating the records for required fields in QUARTERLY process FAILED'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END
          
            /************* STEP 2(c) Truncate stage table tpzt_magellan_member_extr *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Truncating stage table tpzt_magellan_member_extr for Quarterly records. '  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg = @lvcMsg  
              
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr  
              
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr *************/  
              
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Truncating stage table tpzt_magellan_member_extr FAILED. '  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
              
            /************* STEP 2(d) Populate the stage table tpzt_magellan_member_extr with Quarterly Records *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Populate stage table tpzt_magellan_member_extr for Quarterly records. '  
      
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
                  
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr  
            (  
                ISA13,  
                GS06,  
                SE02,  
                MEME_CK,  
                [2000_INS01_IS_SUBSCRIBER],  
                MEME_REL,  
                [2000_INS02_F_RELATION],  
                [2000_INS03],  
                [2000_REF02_F_SUBSCRIBER_ID],  
                [2000_REF02_F_GROUP_ID]  ,  
                [2100A_NM103_F_LAST_NAME],     
                [2100A_NM104_F_FIRST_NAME],    
                [2100A_NM105_F_MIDDLE_INIT],   
                [2100A_N301_F_ADDRESS_1],    
                [2100A_N302_F_ADDRESS_2],    
                [2100A_N401_F_CITY],           
                [2100A_N402_F_STATE],          
                [2100A_N403_F_ZIP],          
                [2100A_DMG02_F_BIRTH_DATE],     
                [2100A_DMG03_F_GENDER],  
                [2300_HD01],    
                [2300_HD04_F_CSPI_ID],  
                [2300_DTP03_F_FROM_DATE],  
                [2300_DTP03_F_TERM_DATE],         
                [2300_DTP03_F_GROUP_FROM_DATE],   
                [2300_DTP03_F_GROUP_TERM_DATE]  
            )  
            SELECT  
                RIGHT('000000000' + CONVERT(VARCHAR,@lnISA13), 9),  
                RIGHT('00' + CONVERT(VARCHAR, @lnGS06), 3),  
                RIGHT('000' + CONVERT(VARCHAR, @lnSE02), 4),  
                curr.MEME_CK,  
                curr.IS_SUBSCRIBER,  
                curr.MEME_REL,  
                curr.RELATION,  
                '030' AS [2300_HD01],  
                curr.FAMILY_ID,                 
                curr.GROUP_ID,  
                curr.LAST_NAME,                 
                curr.FIRST_NAME,  
                curr.MIDDLE_INIT,  
                curr.ADDRESS_1,                 
                curr.ADDRESS_2,                
                curr.CITY,                      
                curr.MEME_STATE,                
                curr.ZIP,    
                CASE   
                    WHEN curr.BIRTH_DATE =0  
                    THEN '00000000'  
                    ELSE    
                    CONVERT(VARCHAR(8),curr.BIRTH_DATE ,112)  
                END AS BIRTH_DATE,  
                curr.GENDER,  
                '030' AS [2300_HD01],                    
                curr.CSPI_ID,                   
                CASE   
                    WHEN curr.FROM_DATE =0  
                    THEN '00000000'  
                    ELSE    
                    CONVERT(VARCHAR(8),curr.FROM_DATE ,112)  
                END AS FROM_DATE,  
                CASE   
                    WHEN curr.TERM_DATE =0  
                    THEN '21991231'  
                    ELSE    
                    CONVERT(VARCHAR(8),curr.TERM_DATE ,112)  
                END AS TERM_DATE,  
                CASE   
                    WHEN curr.GROUP_FROM_DATE =0  
                    THEN '00000000'  
                    ELSE    
                    CONVERT(VARCHAR(8),curr.GROUP_FROM_DATE ,112)  
                END AS GROUP_FROM_DATE,  
                CASE   
                    WHEN curr.GROUP_TERM_DATE =0  
                    THEN '21991231'  
                    ELSE    
                    CONVERT(VARCHAR(8),curr.GROUP_TERM_DATE ,112)  
                END AS GROUP_TERM_DATE  
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new curr
            WHERE curr.ISVALID = 'Y'  
              
            /************* Error Checking for Populate the stage table tpzt_magellan_member_extr with Quarterly Records *************/  
              
            SELECT @lnRetCd    = @@ERROR,  
            @lnRowsProcessed = @@ROWCOUNT  
      
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Populate the stage table tpzt_magellan_member_extr with Quarterly Records FAILED.'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
            END  
             
           /**************  PRINT STEP 2 FOOTER DATA *************************/  
  
            SELECT @ldtStepEndTime = GETDATE()  
  
            EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr  
             @pdtStepStartTime    = @ldtStepStartTime,  
             @pdtStepEndTime      = @ldtStepEndTime,  
             @pdtProcessStartTime = @ldtProcessStartTime,  
             @pnRowCount          = @lnRowsProcessed  
            
        END  
    
                /**************  PRINT STEP 3  HEADER DATA *************************/  
                /********** STEP 3 Insert stage table tpzt_magellan_transaction_no_load for Magellan Member Extract **********/  
   BEGIN  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Inserting stage table tpzt_magellan_transaction_no_load.'  
  
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
       
          
            /************* STEP 3 Inserting stage table tpzt_magellan_transaction_no_load *************/  
              
            IF @lnRowsProcessed > 0  
            BEGIN  
                SELECT @lnISA13 = CONVERT(BIGINT, MAX(ISA13)) FROM fabncdv1stage.dbo.tpzt_magellan_member_extr  
                  
                INSERT INTO fabncdv1custom.dbo.tpzt_magellan_transaction_no_load  
                VALUES(RIGHT('000000000' + CONVERT(VARCHAR,@lnISA13), 9),RIGHT('00' + CONVERT(VARCHAR,@lnGS06), 3),RIGHT('000' + CONVERT(VARCHAR,@lnSE02) , 4), GETDATE())  
            END  
              
            /************* Error Checking for Inserting stage table tpzt_magellan_transaction_no_load *************/  
          
            SELECT @lnRetCd    = @@ERROR,  
                @lnRowsProcessed = @@ROWCOUNT  
  
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Inserting stage table tpzt_magellan_transaction_no_load FAILED'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
                /**************  PRINT STEP 3 FOOTER DATA *************************/  
  
            SELECT @ldtStepEndTime = GETDATE()  
  
            EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr  
             @pdtStepStartTime    = @ldtStepStartTime,  
             @pdtStepEndTime      = @ldtStepEndTime,  
             @pdtProcessStartTime = @ldtProcessStartTime,  
             @pnRowCount          = @lnRowsProcessed  
   END   
   
 /**************  PRINT STEP 4  HEADER DATA *************************/  
                /********** STEP 4 Insert stage table tpzt_magellan_member_extr_new into stage table tpzt_magellan_member_extr_error for Magellan Member Extract **********/  
        BEGIN  
            /************* STEP 4(a) Truncate stage table tpzt_magellan_member_extr_error *************/ 
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_magellan_member_extr_error.'  
  
           EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
       
              
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr_error  
              
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr_error *************/  
          
            SELECT @lnRetCd    = @@ERROR,  
                @lnRowsProcessed = @@ROWCOUNT  
  
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Truncating stage table tpzt_magellan_member_extr_error FAILED.'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END 

            /************* STEP 4(b) Inserting stage table tpzt_magellan_member_extr_error with invalid records *************/                 
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Inserting stage table tpzt_magellan_member_extr_error with invalid records.'  
  
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
           
           INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr_error  
            (    
                MEME_CK,  
                IS_SUBSCRIBER,  
                FAMILY_ID,     
                GROUP_ID,  
                MEME_REL,      
                RELATION,  
                LAST_NAME,     
                FIRST_NAME,    
                MIDDLE_INIT,  
                ADDRESS_1,     
                ADDRESS_2,     
                CITY,          
                MEME_STATE,    
                ZIP,  
                BIRTH_DATE,  
                GENDER,    
                CSPI_ID,      
                FROM_DATE,     
                TERM_DATE,  
                GROUP_FROM_DATE,  
                GROUP_TERM_DATE  
            )  
            SELECT
                curr.MEME_CK,  
                curr.IS_SUBSCRIBER,  
                curr.FAMILY_ID,     
                curr.GROUP_ID,  
                curr.MEME_REL,      
                curr.RELATION,  
                curr.LAST_NAME,     
                curr.FIRST_NAME,    
                curr.MIDDLE_INIT,  
                curr.ADDRESS_1,     
                curr.ADDRESS_2,     
                curr.CITY,          
                curr.MEME_STATE,    
                curr.ZIP,  
                curr.BIRTH_DATE,  
                curr.GENDER,    
                curr.CSPI_ID,      
                curr.FROM_DATE,     
                curr.TERM_DATE,  
                curr.GROUP_FROM_DATE,  
                curr.GROUP_TERM_DATE
                FROM tpzt_magellan_member_extr_new curr
                WHERE ISVALID='N'
            
            SELECT @lnRowsProcessed=COUNT(*) FROM  tpzt_magellan_member_extr_error

            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Count of invalid records in tpzt_magellan_member_extr_error table = '+CONVERT(VARCHAR(10),@lnRowsProcessed)
  
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg
            /************* Error Checking for Inserting stage table tpzt_magellan_member_extr_error with invalid records *************/  
          
            SELECT @lnRetCd    = @@ERROR,  
                @lnRowsProcessed = @@ROWCOUNT  
  
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Inserting stage table tpzt_magellan_member_extr_error with invalid records FAILED'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
         
           /************* STEP 4(c) Updating stage table tpzt_magellan_member_extr_error with invalid records *************/                 
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Updating stage table tpzt_magellan_member_extr_error with invalid records.'  
  
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  


            UPDATE err
            SET    ERROR_DESCRIPTION = CASE 
                                            WHEN ISNULL(LTRIM(RTRIM(err.IS_SUBSCRIBER)), '') = '' THEN 'Subscriber or Member is not defined'
                                            WHEN ISNULL(LTRIM(RTRIM(err.MEME_REL)), '') = '' THEN 'Member Relation is not defined'
                                            WHEN ISNULL(LTRIM(RTRIM(err.FAMILY_ID)), '') = '' THEN 'Subscriber ID is blank'
                                            WHEN ISNULL(LTRIM(RTRIM(err.GROUP_FROM_DATE)), '') = '' THEN 'Group Effective Date is blank.'
                                            WHEN ISNULL(LTRIM(RTRIM(err.GROUP_TERM_DATE)), '') = '' THEN 'Group Termination Date is blank.'
                                            WHEN ISNULL(LTRIM(RTRIM(err.LAST_NAME)), '') = '' THEN 'Last Name is is not defined'
                                            WHEN ISNULL(LTRIM(RTRIM(err.FIRST_NAME)), '') = '' THEN 'First Name is not defined'
                                            WHEN ISNULL(LTRIM(RTRIM(err.ADDRESS_1)), '') = '' THEN 'Address is not defined'
                                            WHEN ISNULL(LTRIM(RTRIM(err.CITY)), '') = '' THEN 'City is not defined'
                                            WHEN LEN(LTRIM(RTRIM(err.CITY))) < 2 THEN 'City character length should be greater than or equal to 2'
                                            WHEN ISNULL(LTRIM(RTRIM(err.MEME_STATE)), '') = '' THEN 'State is not defined'
                                            WHEN LEN(LTRIM(RTRIM(err.MEME_STATE))) <> 2 THEN 'State character length should be 2'
                                            WHEN ISNULL(LTRIM(RTRIM(err.ZIP)), '') = ''  THEN 'Zip Code is not defined'
                                            WHEN ISNUMERIC(LTRIM(RTRIM(err.ZIP))) <> 1 THEN 'Zip Code should be numeric only'
                                            WHEN ISNULL(LTRIM(RTRIM(err.BIRTH_DATE)), '') = '' THEN 'Birth Date is not defined'
                                            WHEN ISNULL(LTRIM(RTRIM(err.GENDER)), '') = '' THEN 'Gender is not defined'
                                            WHEN ISNULL(LTRIM(RTRIM(err.CSPI_ID)), '') = '' THEN 'Plan ID is not defined'
                                            WHEN ISNULL(LTRIM(RTRIM(err.FROM_DATE)), '') = '' THEN 'Effective Date is not defined'
                                            WHEN ISNULL(LTRIM(RTRIM(err.TERM_DATE)), '') = '' THEN 'Termination Date is not defined'
                                            ELSE ''
                                        END
            FROM   fabncdv1stage.dbo.tpzt_magellan_member_extr_error err
             
            /************* Error Checking for Updating ERROR_DESCRIPTION column for stage table tpzt_magellan_member_extr_error with invalid records *************/  
          
            SELECT @lnRetCd    = @@ERROR,  
                @lnRowsProcessed = @@ROWCOUNT  
  
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Updating stage table tpzt_magellan_member_extr_error with invalid records FAILED'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
          /**************  PRINT STEP 4 FOOTER DATA *************************/  
  
            SELECT @ldtStepEndTime = GETDATE()  
  
            EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr  
             @pdtStepStartTime    = @ldtStepStartTime,  
             @pdtStepEndTime      = @ldtStepEndTime,  
             @pdtProcessStartTime = @ldtProcessStartTime,  
             @pnRowCount          = @lnRowsProcessed  
   END          
          
END  
 GO
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_magellan_member_extr') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.tpzp_magellan_member_extr >>>'
ELSE
   PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_magellan_member_extr >>>'
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/  