/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_magellan_member_select_extr') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.tpzp_magellan_member_select_extr
    IF OBJECT_ID('dbo.tpzp_magellan_member_select_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_magellan_member_select_extr >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_magellan_member_select_extr >>>'
END
GO

/****************************************************************  
** END MAINTENANCE WRAPPER.                                    **  
****************************************************************/  
  
CREATE PROCEDURE [dbo].[tpzp_magellan_member_select_extr]  
  
/****************************************************************  
**   NAME                  :    tpzp_magellan_member_select_extr  
**  
**  
**   PVCS LOCATION         :      
**  
**   FUNCTION              :    The scope of this stored procedure is to extract membership/eligibility xml   
                                file from Facets for NC Plan and send it to Magellan. Extract all the Members who have  
                                active eligibility and Mental Health or Substance Abuse benefits.  
**  
**   PARAMETERS            :  
**                   INPUT :    @pRunFreq  
**                  OUTPUT :      
**  
**   RETURN CODES          :    0 on success  
**  
**   TABLES REFERENCED     :  
**                FACETS   :    N/A  
**                FACETSXC :    N/A  
**                CUSTOM   :    N/A   
**                STAGE    :    tpzt_magellan_member_extr  
**  
**   PROCEDURES REFERENCED :    N/A  
**                  FACETS :    N/A  
**                  CUSTOM :    N/A  
**  
**   STANDARD LOGGING PROCS:    harcore.dbo.harsp_gen_util_job_hdr_lgr  
**                              harcore.dbo.harsp_gen_util_job_ftr_lgr  
**                              harcore.dbo.harsp_gen_util_step_hdr_lgr  
**                              harcore.dbo.harsp_gen_util_step_ftr_lgr  
**  
** REVISION HISTORY        :  
**  VERSION    DATE        DEVELOPER        DESCRIPTION  
** -------- ----------   --------------  -------------------  
**    1.0   06/09/2014   Amol Sangar      Initial version  
****************************************************************/  

AS  
  
BEGIN  
  
  
   /****************************************************************  
   **          DECLARE LOCAL VARIABLES                            **  
   ****************************************************************/  
   DECLARE @lnRetCd                INT              -- Proc return code  
   DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field  
   DECLARE @lnCurrentStep          INT              -- Current Step Number  
   DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time  
   DECLARE @lnTotalSteps           INT              -- Total Steps In Proc  
   DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name  
   DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name  
   DECLARE @lvcDBName              VARCHAR(32)      -- DB Name  
   DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version  
   DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name  
   DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time  
   DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step  
   DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time  
   DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time  
   DECLARE @lnISA13                BIGINT           -- To hold ISA13 Unique Number  
   DECLARE @lnGS06                 BIGINT           -- To hold GS06 Unique Number  
   DECLARE @lnSE02                 BIGINT           -- To hold SE02 Unique Number  
     
  /****************************************************************  
   **          INITIALIZE  VARIABLES                              **  
   ****************************************************************/  
    SELECT  @lnRetCd          = 0,  
            @lvcMsg           = NULL,  
            @lnCurrentStep    = 0,  
            @lnTotalSteps     = 1,  
            @ldtStepEndTime   = NULL,  
            @lvcVersionNum    = '1.0'  
     
    SELECT  @lvcServerName          = @@SERVERNAME,  
            @lvcDBName              = DB_NAME(),  
            @lvcUser                = USER_NAME(),  
            @lvcObjectName          = OBJECT_NAME(@@PROCID),  
            @ldtProcessStartTime    = GETDATE()  
        
   /****************************************************************  
   **               BEGIN PROCESS                                 **  
   *****************************************************************/  
      
    /**************  PRINT JOB HEADER DATA *************************/  
      
   EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr  
        @pchObjectName        = @lvcObjectName,  
        @pdtProcessStartTime  = @ldtProcessStartTime,  
        @pchServerName        = @lvcServerName,  
        @pchDBName            = @lvcDBName,  
        @pchUserName          = @lvcUser,  
        @pchVersionNum        = @lvcVersionNum  
      
     
   /**************  PRINT STEP 1  HEADER DATA *************************/  
   /********** STEP 1 Select stage table tpzt_magellan_member_extr for Magellan Member Extract **********/  
        BEGIN  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Selecting Staging table tpzt_magellan_member_extr.'  
  
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg  
       
          
            /************* STEP 1 Selecting Staging table tpzt_magellan_member_extr *************/  
              
            SELECT     
                ISA13,  
                GS06,  
                SE02,  
                [2000_INS01_IS_SUBSCRIBER],  
                MEME_REL,  
                [2000_INS02_F_RELATION],  
                [2000_INS03],  
                [2000_REF02_F_SUBSCRIBER_ID],  
                [2000_REF02_F_GROUP_ID],  
                [2100A_NM103_F_LAST_NAME],  
                [2100A_NM104_F_FIRST_NAME],  
                [2100A_NM105_F_MIDDLE_INIT],  
                [2100A_N301_F_ADDRESS_1],  
                [2100A_N302_F_ADDRESS_2],  
                [2100A_N401_F_CITY],  
                [2100A_N402_F_STATE],  
                [2100A_N403_F_ZIP],  
                [2100A_DMG02_F_BIRTH_DATE],  
                [2100A_DMG03_F_GENDER],  
                [2300_HD01],  
                [2300_HD03],  
                [2300_HD04_F_CSPI_ID],  
                [2300_DTP03_F_FROM_DATE],  
                [2300_DTP03_F_TERM_DATE],         
                [2300_DTP03_F_GROUP_FROM_DATE],   
                [2300_DTP03_F_GROUP_TERM_DATE]   
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr  
            ORDER BY [2000_REF02_F_SUBSCRIBER_ID], [2300_DTP03_F_FROM_DATE]  
             
              
            /************* Error Checking for Selecting Staging table tpzt_magellan_member_extr *************/  
          
            SELECT @lnRetCd    = @@ERROR,  
                @lnRowsProcessed = @@ROWCOUNT  
  
            IF @lnRetCd <> 0  
                BEGIN  
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                    + ' : Selecting Staging table tpzt_magellan_member_extr FAILED'  
                    + ' RETURNCODE: '  
                    + CONVERT(CHAR(6),@lnRetCd)  
                    PRINT  @lvcMsg  
                    RETURN @lnRetCd  
                END  
                /**************  PRINT STEP 1 FOOTER DATA *************************/  
  
            SELECT @ldtStepEndTime = GETDATE()  
  
            EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr  
             @pdtStepStartTime    = @ldtStepStartTime,  
             @pdtStepEndTime      = @ldtStepEndTime,  
             @pdtProcessStartTime = @ldtProcessStartTime,  
             @pnRowCount          = @lnRowsProcessed  
        END  
         
          
END  
 GO
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_magellan_member_select_extr') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.tpzp_magellan_member_select_extr >>>'
ELSE
   PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_magellan_member_select_extr >>>'
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/  