/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_magellan_member_extr') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.tpzp_magellan_member_extr
    IF OBJECT_ID('dbo.tpzp_magellan_member_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_magellan_member_extr >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_magellan_member_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/

CREATE PROCEDURE [dbo].[tpzp_magellan_member_extr]

/****************************************************************
**   NAME                  :    tpzp_magellan_member_extr
**
**
**   PVCS LOCATION         :    
**
**   FUNCTION              :    The scope of this stored procedure is to extract membership/eligibility xml 
                                file from Facets for NC Plan and send it to Magellan. Extract all the Members who have
                                active eligibility and Mental Health or Substance Abuse benefits.
**
**   PARAMETERS            :
**                   INPUT :    @pRunFreq
**                  OUTPUT :    
**
**   RETURN CODES          :    0 on success
**
**   TABLES REFERENCED     :
**                FACETS   :    CMC_MEST_STUDENT,CMC_MEHD_HANDICAP,CMC_MEME_MEMBER,CMC_GRGR_GROUP
**                FACETSXC :    N/A
**                CUSTOM   :    
**                STAGE    :    fabncdv1stage.dbo.tpzt_comm_elig_extr
**
**   PROCEDURES REFERENCED :    N/A
**                  FACETS :    N/A
**                  CUSTOM :    N/A
**
**   STANDARD LOGGING PROCS:    harcore.dbo.harsp_gen_util_job_hdr_lgr
**                              harcore.dbo.harsp_gen_util_job_ftr_lgr
**                              harcore.dbo.harsp_gen_util_step_hdr_lgr
**                              harcore.dbo.harsp_gen_util_step_ftr_lgr
**
** REVISION HISTORY        :
**  VERSION    DATE        DEVELOPER        DESCRIPTION
** -------- ----------   --------------  -------------------
**    1.0   03/11/2014   Amol Sangar      Initial version

****************************************************************/

(
    @pRunFreq       VARCHAR(10)
)

AS

BEGIN


   /****************************************************************
   **          DECLARE LOCAL VARIABLES                            **
   ****************************************************************/
   DECLARE @lnRetCd                INT              -- Proc return code
   DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field
   DECLARE @lnCurrentStep          INT              -- Current Step Number
   DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time
   DECLARE @lnTotalSteps           INT              -- Total Steps In Proc
   DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name
   DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name
   DECLARE @lvcDBName              VARCHAR(32)      -- DB Name
   DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version
   DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name
   DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time
   DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step
   DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time
   DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
   
  /****************************************************************
   **          INITIALIZE  VARIABLES                              **
   ****************************************************************/
    SELECT  @lnRetCd          = 0,
            @lvcMsg           = NULL,
            @lnCurrentStep    = 0,
            @lnTotalSteps     = CASE WHEN @pRunFreq = 'DAILY'
                                     THEN 11
                                     WHEN @pRunFreq = 'QUARTERLY'
                                     THEN 5
                                END,
            @ldtStepEndTime   = NULL,
            @lvcVersionNum    = '1.0'
   
    SELECT  @lvcServerName          = @@SERVERNAME,
            @lvcDBName              = DB_NAME(),
            @lvcUser                = USER_NAME(),
            @lvcObjectName          = OBJECT_NAME(@@PROCID),
            @ldtProcessStartTime    = GETDATE()
      
   /****************************************************************
   **               BEGIN PROCESS                                 **
   *****************************************************************/
    
    /**************  PRINT JOB HEADER DATA *************************/
    
    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr
        @pchObjectName        = @lvcObjectName,
        @pdtProcessStartTime  = @ldtProcessStartTime,
        @pchServerName        = @lvcServerName,
        @pchDBName            = @lvcDBName,
        @pchUserName          = @lvcUser,
        @pchVersionNum        = @lvcVersionNum
      
   
   /**************  PRINT STEP 1  HEADER DATA *************************/
   /********** STEP 1 Populate Staging table tpzt_magellan_member_extr for Magellan Member Extract **********/
   
    IF UPPER(@pRunFreq) = 'DAILY'
        BEGIN
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_magellan_member_extr_old for Magellan Member Extract'

            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
     
        
            /************* STEP 1(a) Truncate stage table tpzt_magellan_member_extr_old *************/
            
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr_old
            
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr_old *************/
        
            SELECT @lnRetCd    = @@ERROR,
                @lnRowsProcessed = @@ROWCOUNT

            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Truncating stage table tpzt_magellan_member_extr_old FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
        
            /************* STEP 1(b) Inserting data into stage table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Inserting data into Staging table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new for Magellan Member Extract'
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr_old
            (
                FAMILY_ID,   
                GROUP_ID,    
                RELATION,   
                CSPD_CAT,
                MEST_TYPE,
                MEHD_TYPE,
                LAST_NAME,   
                FIRST_NAME,  
                MIDDLE_INIT, 
                TITLE,       
                SSN,         
                PHONE,
                ADDRESS_1,   
                ADDRESS_2,   
                CITY,        
                MEME_STATE,  
                ZIP,         
                COUNTRY_CODE,
                M_ADDRESS_1,    
                M_ADDRESS_2,    
                M_CITY,         
                M_MEME_STATE,   
                M_ZIP,          
                M_COUNTRY_CODE,
                M_TYPE_CODE,
                BIRTH_DATE,  
                GENDER,
                CSPI_ID,      
                MEPE_FI,     
                FROM_DATE,   
                TERM_DATE,
                MEME_CK                                   
            )
            SELECT
                FAMILY_ID,   
                GROUP_ID,    
                RELATION,   
                CSPD_CAT,
                MEST_TYPE,
                MEHD_TYPE,    
                LAST_NAME,   
                FIRST_NAME,  
                MIDDLE_INIT, 
                TITLE,       
                SSN,         
                PHONE,
                ADDRESS_1,   
                ADDRESS_2,   
                CITY,        
                MEME_STATE,  
                ZIP,         
                COUNTRY_CODE,
                M_ADDRESS_1,    
                M_ADDRESS_2,    
                M_CITY,         
                M_MEME_STATE,   
                M_ZIP,          
                M_COUNTRY_CODE,
                M_TYPE_CODE,
                BIRTH_DATE,  
                GENDER,
                CSPI_ID,      
                MEPE_FI,     
                FROM_DATE,   
                TERM_DATE,
                MEME_CK
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new                          
            
            /************* Error Checking for Inserting data into stage table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Inserting data into stage table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
    
            /************* STEP 1(c) Truncate stage table tpzt_magellan_member_extr_new *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_magellan_member_extr_new'
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr_new
            
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr_new *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Truncating stage table tpzt_magellan_member_extr_new FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
        
                                
            /************* STEP 1(d) Populating the stage table tpzt_magellan_member_extr_new *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Populating the Staging table tpzt_magellan_member_extr_new with new records'
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr_new
            (  
                FAMILY_ID,   
                GROUP_ID,    
                RELATION,   
                CSPD_CAT,
                MEST_TYPE,
                MEHD_TYPE,    
                LAST_NAME,   
                FIRST_NAME,  
                MIDDLE_INIT, 
                TITLE,       
                SSN,         
                PHONE,
                ADDRESS_1,   
                ADDRESS_2,   
                CITY,        
                MEME_STATE,  
                ZIP,         
                COUNTRY_CODE,
                M_ADDRESS_1,    
                M_ADDRESS_2,    
                M_CITY,         
                M_MEME_STATE,   
                M_ZIP,          
                M_COUNTRY_CODE,
                M_TYPE_CODE,  
                BIRTH_DATE,  
                GENDER,
                CSPI_ID,      
                MEPE_FI,     
                FROM_DATE,   
                TERM_DATE,
                MEME_CK
            )
           SELECT
                DISTINCT 
                elig.SBSB_ID,        
                elig.GRGR_ID,        
                elig.MEME_REL,        
                elig.CSPD_CAT,
                '',
                '',        
                elig.MEME_LAST_NAME,    
                elig.MEME_FIRST_NAME,
                elig.MEME_MID_INIT,    
                meme.MEME_TITLE,        
                elig.MEME_SSN,        
                elig.SBAD_PHONE,        
                elig.SBAD_ADDR1,        
                elig.SBAD_ADDR2,        
                elig.SBAD_CITY,        
                elig.SBAD_STATE,        
                elig.SBAD_ZIP,        
                elig.SBAD_CTRY_CD,
                sbad.SBAD_ADDR1,        
                sbad.SBAD_ADDR2,        
                sbad.SBAD_CITY,        
                sbad.SBAD_STATE,        
                sbad.SBAD_ZIP,        
                sbad.SBAD_CTRY_CD,
                '021',
                CAST(convert(varchar,elig.MEME_BIRTH_DT,112) AS DECIMAL(8)) AS MEME_BIRTH_DT,    
                elig.MEME_SEX,
                CASE 
                WHEN elig.CSPD_CAT ='M' then elig.CSPI_ID         
                ELSE ''
                END AS CSPI_ID,        
                elig.MEPE_FI, 
                CAST(convert(varchar,elig.MEPE_EFF_DT,112) AS DECIMAL(8)) AS MEPE_EFF_DT,               
                CAST(convert(varchar,elig.MEPE_TERM_DT,112) AS DECIMAL(8)) AS MEPE_TERM_DT,
                meme.MEME_CK          
            FROM tpzt_comm_elig_extr elig
            INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr
                ON elig.GRGR_CK=grgr.GRGR_CK
            INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme
                ON elig.MEME_CK=meme.MEME_CK
            INNER JOIN fabncdv1.dbo.CMC_SBAD_ADDR sbad
                ON elig.SBSB_CK=sbad.SBSB_CK
            WHERE 
                grgr.GRGR_MCTR_TYPE = 'COMM'
                AND elig.CSPD_CAT ='M'
                AND sbad.SBAD_TYPE = meme.SBAD_TYPE_MAIL
                AND GETDATE() BETWEEN elig.MEPE_EFF_DT AND elig.MEPE_TERM_DT 
                
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr_new with terminated records *************/
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Populating the stage table tpzt_magellan_member_extr_new '
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
                
                 /************* STEP 1(e) Updating stage tpzt_magellan_member_extr to get Student Status Code 2000/INS09  *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Updating stage tpzt_magellan_member_extr to get Student Status Code 2000/INS09  '
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
                
                UPDATE curr
                    SET curr.MEST_TYPE = stud.MEST_TYPE
                FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new curr 
                    INNER JOIN fabncdv1.dbo.CMC_MEST_STUDENT stud
                    ON stud.MEME_CK=curr.MEME_CK
                WHERE
                    GETDATE() BETWEEN stud.MEST_EFF_DT AND stud.MEST_TERM_DT 
                                  
                /************* Error Checking for Updating stage tpzt_magellan_member_extr to get Student Status Code 2000/INS09 *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Updating stage tpzt_magellan_member_extr to get Student Status Code 2000/INS09  FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
                    /************* STEP 1(f) Updating stage table tpzt_magellan_member_extr to get Handicap Indicator 2000/INS10*************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Updating stage table tpzt_magellan_member_extr to get Handicap Indicator 2000/INS10 '
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
                
                UPDATE curr
                        SET  curr.MEHD_TYPE = mehd.MEHD_TYPE
                FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new curr 
                    INNER JOIN fabncdv1.dbo.CMC_MEHD_HANDICAP mehd
                ON mehd.MEME_CK=curr.MEME_CK
                WHERE
                    GETDATE() BETWEEN mehd.MEHD_EFF_DT AND mehd.MEHD_TERM_DT 
                                  
                /************* Error Checking for Updating stage table tpzt_magellan_member_extr to get Handicap Indicator 2000/INS10 *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Updating stage table tpzt_magellan_member_extr to get Handicap Indicator 2000/INS10 FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
                   
                /************* STEP 1(g) Update stage table for changed  records *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Update stage table for changed records '
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
                IF (SELECT COUNT(1) FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old) > 0
                BEGIN
                    UPDATE curr
                SET M_TYPE_CODE = '001'
                FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new curr
                WHERE  NOT EXISTS (SELECT 1 FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev
                                  WHERE  curr.MEME_CK=prev.MEME_CK
                                        AND curr.FAMILY_ID=prev.FAMILY_ID    
                                        AND curr.GROUP_ID=prev.GROUP_ID   
                                        AND curr.RELATION=prev.RELATION 
                                        AND curr.CSPD_CAT=prev.CSPD_CAT
                                        AND curr.MEST_TYPE=prev.MEST_TYPE
                                        AND curr.MEHD_TYPE=prev.MEHD_TYPE  
                                        AND curr.LAST_NAME= prev.LAST_NAME  
                                        AND curr.FIRST_NAME=  prev.FIRST_NAME
                                        AND curr.MIDDLE_INIT= prev.MIDDLE_INIT
                                        AND curr.TITLE=   prev.TITLE  
                                        AND curr.SSN= prev.SSN      
                                        AND curr.PHONE=prev.PHONE
                                        AND curr.ADDRESS_1= prev.ADDRESS_1  
                                        AND curr.ADDRESS_2= prev.ADDRESS_2
                                        AND curr.CITY=  prev.CITY    
                                        AND curr.MEME_STATE=prev.MEME_STATE  
                                        AND curr.ZIP= prev.ZIP      
                                        AND curr.COUNTRY_CODE=prev.COUNTRY_CODE
                                        AND curr.M_ADDRESS_1=prev.M_ADDRESS_1 
                                        AND curr.M_ADDRESS_2= prev.M_ADDRESS_2
                                        AND curr.M_CITY=  prev.M_CITY    
                                        AND curr.M_MEME_STATE=prev.M_MEME_STATE 
                                        AND curr.M_ZIP=  prev.M_ZIP       
                                        AND curr.M_COUNTRY_CODE=prev.M_COUNTRY_CODE
                                        AND curr.M_TYPE_CODE= prev.M_TYPE_CODE
                                        AND curr.BIRTH_DATE= prev.BIRTH_DATE 
                                        AND curr.GENDER=prev.GENDER
                                        AND curr.CSPI_ID= prev.CSPI_ID     
                                        AND curr.MEPE_FI=  prev.MEPE_FI   
                                        AND curr.FROM_DATE=  prev.FROM_DATE
                                        AND curr.TERM_DATE=prev.TERM_DATE
                                        
                                 )
                END                  
                /************* Error Checking for Update stage table for changed records *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Truncating stage table tpzt_magellan_member_extr FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
            
            /************* STEP 1(h) Truncate stage table tpzt_magellan_member_extr *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Truncate stage table tpzt_magellan_member_extr'
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr
            
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Truncating stage table tpzt_magellan_member_extr FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
            
            
            /************* STEP 1(i) Populate the stage table tpzt_magellan_member_extr with Daily Records  *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Populate the stage table tpzt_magellan_member_extr with Daily Records '
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr
            (
                [2000_INS02_F_RELATION],
                [2000_INS06_F_CSPD_CAT],
                [2000_INS08_F_CSPD_CAT],  
                [2000_INS09_F_MEST_TYPE], 
                [2000_INS10_F_MEHD_TYPE],
                [2000_REF02_F_SUBSCRIBER_ID],
                [2000_REF02_F_GROUP_ID]  ,
                [2100A_NM103_F_LAST_NAME],   
                [2100A_NM104_F_FIRST_NAME],  
                [2100A_NM105_F_MIDDLE_INIT], 
                [2100A_NM107_F_TITLE],    
                [2100A_NM109_F_SSN],  
                [2100A_PER04_F_PHONE],   
                [2100A_N301_F_ADDRESS_1],  
                [2100A_N302_F_ADDRESS_2],  
                [2100A_N401_F_CITY],         
                [2100A_N402_F_STATE],        
                [2100A_N403_F_ZIP],          
                [2100A_N404_F_COUNTRY_CODE],
                [2100C_N301_F_ADDRESS_1],   
                [2100C_N302_F_ADDRESS_2],   
                [2100C_N401_F_CITY],        
                [2100C_N402_F_STATE],       
                [2100C_N403_F_ZIP],                          
                [2100C_N404_F_COUNTRY_CODE],
                [2300_HD01],               
                [2100A_DMG02_F_BIRTH_DATE],   
                [2100A_DMG03_F_GENDER],       
                [2300_HD04_F_CSPI_ID],     
                [2300_HD05_F_MEPE_FI],     
                [2300_DTP03_F_FROM_DATE]
            )
            SELECT
                curr.RELATION,
                curr.CSPD_CAT,
                curr.CSPD_CAT,
                curr.MEST_TYPE,               
                curr.MEHD_TYPE,
                curr.FAMILY_ID,               
                curr.GROUP_ID,
                curr.LAST_NAME,               
                curr.FIRST_NAME,
                curr.MIDDLE_INIT,
                curr.TITLE,       
                curr.SSN,
                curr.PHONE,
                curr.ADDRESS_1,               
                curr.ADDRESS_2,              
                curr.CITY,                    
                curr.MEME_STATE,              
                curr.ZIP,                     
                curr.COUNTRY_CODE,
                curr.M_ADDRESS_1,   
                curr.M_ADDRESS_2,   
                curr.M_CITY,        
                curr.M_MEME_STATE,  
                curr.M_ZIP ,        
                curr.M_COUNTRY_CODE,
                curr.M_TYPE_CODE,
                CASE 
                    WHEN curr.BIRTH_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(curr.BIRTH_DATE AS VARCHAR(8))
                END AS BIRTH_DATE,
                curr.GENDER,                  
                curr.CSPI_ID,                 
                curr.MEPE_FI,                 
                CASE 
                    WHEN curr.FROM_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(curr.FROM_DATE AS VARCHAR(8))
                END AS FROM_DATE
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new curr
                
            EXCEPT
                
            SELECT 
                prev.RELATION,
                prev.CSPD_CAT,
                prev.CSPD_CAT,
                prev.MEST_TYPE,               
                prev.MEHD_TYPE,
                prev.FAMILY_ID,               
                prev.GROUP_ID,
                prev.LAST_NAME,               
                prev.FIRST_NAME,
                prev.MIDDLE_INIT,
                prev.TITLE,       
                prev.SSN,
                prev.PHONE,
                prev.ADDRESS_1,               
                prev.ADDRESS_2,              
                prev.CITY,                    
                prev.MEME_STATE,              
                prev.ZIP,                     
                prev.COUNTRY_CODE,
                prev.M_ADDRESS_1,   
                prev.M_ADDRESS_2,   
                prev.M_CITY,        
                prev.M_MEME_STATE,  
                prev.M_ZIP ,        
                prev.M_COUNTRY_CODE,
                prev.M_TYPE_CODE,                
                CASE 
                    WHEN prev.BIRTH_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(prev.BIRTH_DATE AS VARCHAR(8))
                END AS BIRTH_DATE,
                prev.GENDER,                  
                prev.CSPI_ID,                 
                prev.MEPE_FI,                 
                CASE 
                    WHEN prev.FROM_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(prev.FROM_DATE AS VARCHAR(8))
                END AS FROM_DATE
            FROM 
            fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev
            
            /************* Error Checking for Populate the stage table tpzt_magellan_member_extr with Daily Records *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Populate the stage table tpzt_magellan_member_extr with Daily Records FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
                
                 
            /************* STEP 1(j) Populate the stage table tpzt_magellan_member_extr with Terminated Records  *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Populate the stage table tpzt_magellan_member_extr with Terminated Records '
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
             INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr
            (
                [2000_INS02_F_RELATION],
                [2000_INS06_F_CSPD_CAT],
                [2000_INS08_F_CSPD_CAT],  
                [2000_INS09_F_MEST_TYPE], 
                [2000_INS10_F_MEHD_TYPE],
                [2000_REF02_F_SUBSCRIBER_ID],
                [2000_REF02_F_GROUP_ID]  ,
                [2100A_NM103_F_LAST_NAME],   
                [2100A_NM104_F_FIRST_NAME],  
                [2100A_NM105_F_MIDDLE_INIT], 
                [2100A_NM107_F_TITLE],    
                [2100A_NM109_F_SSN],  
                [2100A_PER04_F_PHONE],   
                [2100A_N301_F_ADDRESS_1],  
                [2100A_N302_F_ADDRESS_2],  
                [2100A_N401_F_CITY],         
                [2100A_N402_F_STATE],        
                [2100A_N403_F_ZIP],          
                [2100A_N404_F_COUNTRY_CODE],
                [2100C_N301_F_ADDRESS_1],   
                [2100C_N302_F_ADDRESS_2],   
                [2100C_N401_F_CITY],        
                [2100C_N402_F_STATE],       
                [2100C_N403_F_ZIP],                          
                [2100C_N404_F_COUNTRY_CODE],
                [2300_HD01],               
                [2100A_DMG02_F_BIRTH_DATE],   
                [2100A_DMG03_F_GENDER],       
                [2300_HD04_F_CSPI_ID],     
                [2300_HD05_F_MEPE_FI],     
                [2300_DTP03_F_FROM_DATE]
            )
            SELECT 
                meme.MEME_REL,        
                mepe.CSPD_CAT,
                mepe.CSPD_CAT,
                stud.MEST_TYPE,
                mehd.MEHD_TYPE, 
                sbsb.SBSB_ID,        
                grgr.GRGR_ID,        
                meme.MEME_LAST_NAME,    
                meme.MEME_FIRST_NAME,
                meme.MEME_MID_INIT,    
                meme.MEME_TITLE,        
                meme.MEME_SSN,        
                sbad.SBAD_PHONE,        
                sbad.SBAD_ADDR1,        
                sbad.SBAD_ADDR2,        
                sbad.SBAD_CITY,        
                sbad.SBAD_STATE,        
                sbad.SBAD_ZIP,        
                sbad.SBAD_CTRY_CD,
                sbad.SBAD_ADDR1,        
                sbad.SBAD_ADDR2,        
                sbad.SBAD_CITY,        
                sbad.SBAD_STATE,        
                sbad.SBAD_ZIP,        
                sbad.SBAD_CTRY_CD,
                '024',
                CAST(convert(varchar,meme.MEME_BIRTH_DT,112) AS DECIMAL(8)) AS MEME_BIRTH_DT,    
                meme.MEME_SEX,
                CASE 
                WHEN mepe.CSPD_CAT ='M' then mepe.CSPI_ID         
                ELSE ''
                END AS CSPI_ID,        
                mepe.MEPE_FI, 
                CAST(convert(varchar,mepe.MEPE_EFF_DT,112) AS DECIMAL(8)) AS MEPE_EFF_DT              
             FROM  
                fabncdv1.dbo.CMC_GRGR_GROUP grgr   
                INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg  
                        ON sgsg.GRGR_CK = grgr.GRGR_CK      
                INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb   
                        ON sbsb.GRGR_CK = grgr.GRGR_CK   
                INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme  
                        ON meme.SBSB_CK = sbsb.SBSB_CK  
                INNER JOIN fabncdv1.dbo.CMC_SBAD_ADDR sbad  
                        ON sbsb.SBSB_CK = sbad.SBSB_CK  
                       AND meme.SBAD_TYPE_HOME = sbad.SBAD_TYPE  
                INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe  
                        ON meme.MEME_CK = mepe.MEME_CK  
                INNER JOIN fabncdv1.dbo.CMC_PDDS_PROD_DESC pdds  
                        ON mepe.PDPD_ID = pdds.PDPD_ID  
                INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi  
                        ON  cspi.GRGR_CK = mepe.GRGR_CK  
                        AND cspi.CSPI_ID = mepe.CSPI_ID  
                        AND cspi.CSPD_CAT = mepe.CSPD_CAT   
                        AND cspi.CSCS_ID = mepe.CSCS_ID  
                LEFT JOIN fabncdv1.dbo.CMC_MEST_STUDENT stud
                        ON stud.MEME_CK=meme.MEME_CK
                        --AND GETDATE() BETWEEN stud.MEST_EFF_DT AND stud.MEST_TERM_DT
                LEFT JOIN fabncdv1.dbo.CMC_MEHD_HANDICAP mehd
                        ON mehd.MEME_CK=meme.MEME_CK
                        --AND GETDATE() BETWEEN mehd.MEHD_EFF_DT AND mehd.MEHD_TERM_DT
                WHERE meme.MEME_CK IN ( SELECT DISTINCT prev.MEME_CK   
                                    FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev )  
                    AND CAST(CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) AS DECIMAL(8)) IN (SELECT DISTINCT prev.FROM_DATE   
                                    FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev WHERE prev.MEME_CK = mepe.MEME_CK)  
                    AND CAST(CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) AS DECIMAL(8)) NOT IN ( SELECT DISTINCT curr.FROM_DATE   
                                    FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new curr WHERE curr.MEME_CK = mepe.MEME_CK)                      
                    AND mepe.CSPD_CAT = 'M' 
                    AND grgr.GRGR_MCTR_TYPE = 'COMM' 
                    AND sbad.SBAD_TYPE = meme.SBAD_TYPE_MAIL
         /************* Error Checking for Populate the stage table tpzt_magellan_member_extr with Terminated Records *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Populate the stage table tpzt_magellan_member_extr with Terminated Records FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
                /**************  PRINT STEP 1 FOOTER DATA *************************/

            SELECT @ldtStepEndTime = GETDATE()

            EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
                @pdtStepStartTime    = @ldtStepStartTime,
                @pdtStepEndTime      = @ldtStepEndTime,
                @pdtProcessStartTime = @ldtProcessStartTime,
                @pnRowCount          = @lnRowsProcessed
     
        END  
    
   /**************  PRINT STEP 2  HEADER DATA *************************/
   /********** STEP 2 Populate stage table tpzt_magellan_member_extr for Magellan Quarterly Member Extract **********/
    
    IF UPPER(@pRunFreq) = 'QUARTERLY'
        BEGIN
        
            /************* STEP 2(a) Truncate stage table tpzt_magellan_member_extr *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Truncating stage table tpzt_magellan_member_extr for Magellan Quarterly Member Extract'
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr
            
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Truncating stage table tpzt_magellan_member_extr FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
            
            
            /************* STEP 2(b) Populate the stage table tpzt_magellan_member_extr with Quarterly Records *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Populate stage table tpzt_magellan_member_extr for Magellan Quarterly Member Extract'
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
                
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr
            (
                MEME_CK,
                [2000_INS02_F_RELATION],
                [2000_INS06_F_CSPD_CAT],
                [2000_INS08_F_CSPD_CAT],  
                [2000_INS09_F_MEST_TYPE], 
                [2000_INS10_F_MEHD_TYPE],
                [2000_REF02_F_SUBSCRIBER_ID],
                [2000_REF02_F_GROUP_ID]  ,
                [2100A_NM103_F_LAST_NAME],   
                [2100A_NM104_F_FIRST_NAME],  
                [2100A_NM105_F_MIDDLE_INIT], 
                [2100A_NM107_F_TITLE],    
                [2100A_NM109_F_SSN],  
                [2100A_PER04_F_PHONE],   
                [2100A_N301_F_ADDRESS_1],  
                [2100A_N302_F_ADDRESS_2],  
                [2100A_N401_F_CITY],         
                [2100A_N402_F_STATE],        
                [2100A_N403_F_ZIP],          
                [2100A_N404_F_COUNTRY_CODE],
                [2100C_N301_F_ADDRESS_1],   
                [2100C_N302_F_ADDRESS_2],   
                [2100C_N401_F_CITY],        
                [2100C_N402_F_STATE],       
                [2100C_N403_F_ZIP],                          
                [2100C_N404_F_COUNTRY_CODE],
                [2100A_DMG02_F_BIRTH_DATE],   
                [2100A_DMG03_F_GENDER],       
                [2300_HD04_F_CSPI_ID],     
                [2300_HD05_F_MEPE_FI],     
                [2300_DTP03_F_FROM_DATE]
            )
            SELECT
                DISTINCT
                elig.MEME_CK,
                elig.MEME_REL,
                elig.CSPD_CAT,
                elig.CSPD_CAT,
                '',
                '',  
                elig.SBSB_ID,        
                elig.GRGR_ID,        
                elig.MEME_LAST_NAME,    
                elig.MEME_FIRST_NAME,
                elig.MEME_MID_INIT,    
                meme.MEME_TITLE,        
                elig.MEME_SSN,        
                elig.SBAD_PHONE,        
                elig.SBAD_ADDR1,        
                elig.SBAD_ADDR2,        
                elig.SBAD_CITY,        
                elig.SBAD_STATE,        
                elig.SBAD_ZIP,        
                elig.SBAD_CTRY_CD,
                sbad.SBAD_ADDR1,        
                sbad.SBAD_ADDR2,        
                sbad.SBAD_CITY,        
                sbad.SBAD_STATE,        
                sbad.SBAD_ZIP,        
                sbad.SBAD_CTRY_CD,
                CAST(convert(varchar,elig.MEME_BIRTH_DT,112) AS DECIMAL(8)) AS MEME_BIRTH_DT,    
                elig.MEME_SEX,
                CASE 
                WHEN elig.CSPD_CAT ='M' then elig.CSPI_ID         
                ELSE ''
                END AS CSPD_CAT,        
                elig.MEPE_FI, 
                CAST(convert(varchar,elig.MEPE_EFF_DT,112) AS DECIMAL(8)) AS MEPE_EFF_DT
            FROM tpzt_comm_elig_extr elig
            INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr
                ON elig.GRGR_CK=grgr.GRGR_CK
            INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme
                ON elig.MEME_CK=meme.MEME_CK
            INNER JOIN fabncdv1.dbo.CMC_SBAD_ADDR sbad
                ON elig.SBSB_CK=sbad.SBSB_CK
            WHERE 
                grgr.GRGR_MCTR_TYPE = 'COMM'
                AND elig.CSPD_CAT ='M'
                AND sbad.SBAD_TYPE = meme.SBAD_TYPE_MAIL                
                AND GETDATE() BETWEEN elig.MEPE_EFF_DT AND elig.MEPE_TERM_DT
            
            
            
            /************* Error Checking for Populate the stage table tpzt_magellan_member_extr with Quarterly Records *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Populate the stage table tpzt_magellan_member_extr with Quarterly Records FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
            END
            
              
                 /************* STEP 2(c) Updating stage tpzt_magellan_member_extr to get Student Status Code 2000/INS09  *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Updating stage tpzt_magellan_member_extr to get Student Status Code 2000/INS09  '
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
                
                UPDATE extr
                    SET [2000_INS09_F_MEST_TYPE] = stud.MEST_TYPE
                FROM fabncdv1stage.dbo.tpzt_magellan_member_extr extr 
                    INNER JOIN fabncdv1.dbo.CMC_MEST_STUDENT stud
                    ON stud.MEME_CK=extr.MEME_CK
                WHERE
                    GETDATE() BETWEEN stud.MEST_EFF_DT AND stud.MEST_TERM_DT 
                                  
                /************* Error Checking for Updating stage tpzt_magellan_member_extr to get Student Status Code 2000/INS09 *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Updating stage tpzt_magellan_member_extr to get Student Status Code 2000/INS09  FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
                    /************* STEP 2(d) Updating stage table tpzt_magellan_member_extr to get Handicap Indicator 2000/INS10*************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Updating stage table tpzt_magellan_member_extr to get Handicap Indicator 2000/INS10 '
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
                
                UPDATE extr
                        SET [2000_INS10_F_MEHD_TYPE] = mehd.MEHD_TYPE
                FROM fabncdv1stage.dbo.tpzt_magellan_member_extr extr 
                    INNER JOIN fabncdv1.dbo.CMC_MEHD_HANDICAP mehd
                ON mehd.MEME_CK=extr.MEME_CK
                WHERE
                    GETDATE() BETWEEN mehd.MEHD_EFF_DT AND mehd.MEHD_TERM_DT 
                                  
                /************* Error Checking for Updating stage table tpzt_magellan_member_extr to get Handicap Indicator 2000/INS10 *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Updating stage table tpzt_magellan_member_extr to get Handicap Indicator 2000/INS10 FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
                   
           /**************  PRINT STEP 2 FOOTER DATA *************************/

           SELECT @ldtStepEndTime = GETDATE()

           EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
             @pdtStepStartTime    = @ldtStepStartTime,
             @pdtStepEndTime      = @ldtStepEndTime,
             @pdtProcessStartTime = @ldtProcessStartTime,
             @pnRowCount          = @lnRowsProcessed
          
        END
   
   
   /**************  PRINT STEP 3  HEADER DATA *************************/
   /********** STEP 3 Select stage table tpzt_magellan_member_extr for Magellan Member Extract **********/
   BEGIN
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Selecting Staging table tpzt_magellan_member_extr for Magellan Member Extract'

            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
     
        
            /************* STEP 1 Selecting Staging table tpzt_magellan_member_extr *************/
            
           SELECT DISTINCT
                    CASE 
                        WHEN [2000_INS02_F_RELATION]='M' THEN 'Y'
                        ELSE 'N'
                    END AS [2000_INS01],
                    CASE 
                        WHEN [2000_INS02_F_RELATION]='M' THEN '18' 
                        WHEN [2000_INS02_F_RELATION]='H' OR [2000_INS02_F_RELATION]='W' THEN '01'  
                        WHEN [2000_INS02_F_RELATION]='S' OR [2000_INS02_F_RELATION]='D' THEN '19'  
                        ELSE '23' 
                    END [2000_INS02_F_RELATION],
                    [2000_INS03],
                    CASE
                        WHEN [2000_INS06_F_CSPD_CAT] <> 'D' AND DATEDIFF(YEAR,[2100A_DMG02_F_BIRTH_DATE],GETDATE()) >= 65 
                            AND [2000_INS02_F_RELATION]='M' THEN 'D' 
                        ELSE ''
                    END AS  [2000_INS06_F_CSPD_CAT],
                    CASE
                        WHEN [2000_INS08_F_CSPD_CAT] <> 'D' AND DATEDIFF(YEAR,[2100A_DMG02_F_BIRTH_DATE],GETDATE()) >= 65 AND [2000_INS02_F_RELATION]='M' THEN 'AC'
                        WHEN DATEDIFF(YEAR,[2100A_DMG02_F_BIRTH_DATE],GETDATE()) < 65 AND [2000_INS02_F_RELATION]='M' THEN 'FT'
                        WHEN [2000_INS02_F_RELATION]<>'M' THEN ''
                    END AS [2000_INS08_F_CSPD_CAT],
                    CASE 
                        WHEN [2000_INS09_F_MEST_TYPE] IS NULL OR [2000_INS09_F_MEST_TYPE]='' THEN 'N'
                        WHEN [2000_INS09_F_MEST_TYPE]= 'F' THEN 'F'
                        WHEN [2000_INS09_F_MEST_TYPE]= 'P' THEN 'P'
                        END AS [2000_INS09_F_MEST_TYPE],
                    CASE
                        WHEN [2000_INS10_F_MEHD_TYPE] IS NULL OR [2000_INS10_F_MEHD_TYPE]='' THEN 'N'
                        WHEN [2000_INS10_F_MEHD_TYPE]= 'P' THEN 'Y'
                    END AS [2000_INS10_F_MEHD_TYPE],
                    [2000_REF02_F_SUBSCRIBER_ID],
                    [2000_REF02_F_GROUP_ID],
                    [2100A_NM103_F_LAST_NAME],
                    [2100A_NM104_F_FIRST_NAME],
                    [2100A_NM105_F_MIDDLE_INIT],
                    [2100A_NM106],
                    [2100A_NM107_F_TITLE],
                    [2100A_NM109_F_SSN],
                    [2100A_PER04_F_PHONE],
                    [2100A_N301_F_ADDRESS_1],
                    [2100A_N302_F_ADDRESS_2],
                    [2100A_N401_F_CITY],
                    [2100A_N402_F_STATE],
                    [2100A_N403_F_ZIP],
                    [2100A_N404_F_COUNTRY_CODE],
                    [2100C_N301_F_ADDRESS_1],   
                    [2100C_N302_F_ADDRESS_2],   
                    [2100C_N401_F_CITY],        
                    [2100C_N402_F_STATE],       
                    [2100C_N403_F_ZIP],          
                    [2100C_N404_F_COUNTRY_CODE],
                    [2100A_DMG01],
                    [2100A_DMG02_F_BIRTH_DATE],
                    [2100A_DMG03_F_GENDER],
                    [2300_HD01],
                    [2300_HD03],
                    [2300_HD04_F_CSPI_ID],
                    CASE
                        WHEN [2300_HD05_F_MEPE_FI]='A' THEN 'FAM'
                        ELSE 'IND'
                    END AS [2300_HD05_F_MEPE_FI],
                    [2300_DTP01],
                    [2300_DTP02],
                    [2300_DTP03_F_FROM_DATE]
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr
            ORDER BY [2000_REF02_F_SUBSCRIBER_ID],[2000_INS01] DESC
           
            
            /************* Error Checking for Selecting Staging table tpzt_magellan_member_extr *************/
        
            SELECT @lnRetCd    = @@ERROR,
                @lnRowsProcessed = @@ROWCOUNT

            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Selecting Staging table tpzt_magellan_member_extr FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
                /**************  PRINT STEP 4 FOOTER DATA *************************/

           SELECT @ldtStepEndTime = GETDATE()

           EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
             @pdtStepStartTime    = @ldtStepStartTime,
             @pdtStepEndTime      = @ldtStepEndTime,
             @pdtProcessStartTime = @ldtProcessStartTime,
             @pnRowCount          = @lnRowsProcessed
   END 
        
END
GO
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_magellan_member_extr') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.tpzp_magellan_member_extr >>>'
ELSE
   PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_magellan_member_extr >>>'
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/ 