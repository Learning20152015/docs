/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_magellan_member_extr') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.tpzp_magellan_member_extr
    IF OBJECT_ID('dbo.tpzp_magellan_member_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_magellan_member_extr >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_magellan_member_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/

CREATE PROCEDURE [dbo].[tpzp_magellan_member_extr]

/****************************************************************
**   NAME                  :    tpzp_magellan_member_extr
**
**
**   PVCS LOCATION         :    
**
**   FUNCTION              :    The scope of this stored procedure is to extract membership/eligibility xml 
                                file from Facets for NC Plan and send it to Magellan. Extract all the Members who have
                                active eligibility and Mental Health or Substance Abuse benefits.
**
**   PARAMETERS            :
**                   INPUT :    @pRunFreq
**                  OUTPUT :    
**
**   RETURN CODES          :    0 on success
**
**   TABLES REFERENCED     :
**                FACETS   :    CMC_MEST_STUDENT,CMC_MEHD_HANDICAP,CMC_MEME_MEMBER,CMC_GRGR_GROUP
**                FACETSXC :    N/A
**                CUSTOM   :    
**                STAGE    :    fabncdv1stage.dbo.tpzt_comm_elig_extr
**
**   PROCEDURES REFERENCED :    N/A
**                  FACETS :    N/A
**                  CUSTOM :    N/A
**
**   STANDARD LOGGING PROCS:    fabncdv1stage.dbo.harsp_gen_util_job_hdr_lgr
**                              fabncdv1stage.dbo.harsp_gen_util_job_ftr_lgr
**                              fabncdv1stage.dbo.harsp_gen_util_step_hdr_lgr
**                              fabncdv1stage.dbo.harsp_gen_util_step_ftr_lgr
**
** REVISION HISTORY        :
**  VERSION    DATE        DEVELOPER        DESCRIPTION
** -------- ----------   --------------  -------------------
**    1.0   03/11/2014   Amol Sangar      Initial version

****************************************************************/

(
    @pRunFreq       VARCHAR(10)
)

AS

BEGIN


   /****************************************************************
   **          DECLARE LOCAL VARIABLES                            **
   ****************************************************************/
   DECLARE @lnRetCd                INT              -- Proc return code
   DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field
   DECLARE @lnCurrentStep          INT              -- Current Step Number
   DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time
   DECLARE @lnTotalSteps           INT              -- Total Steps In Proc
   DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name
   DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name
   DECLARE @lvcDBName              VARCHAR(32)      -- DB Name
   DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version
   DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name
   DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time
   DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step
   DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time
   DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
   
  /****************************************************************
   **          INITIALIZE  VARIABLES                              **
   ****************************************************************/
    SELECT  @lnRetCd          = 0,
            @lvcMsg           = NULL,
            @lnCurrentStep    = 0,
            @lnTotalSteps     = CASE WHEN @pRunFreq = 'DAILY'
                                     THEN 7
                                     WHEN @pRunFreq = 'QUARTERLY'
                                     THEN 3
                                END,
            @ldtStepEndTime   = NULL,
            @lvcVersionNum    = '1.0'
   
    SELECT  @lvcServerName          = @@SERVERNAME,
            @lvcDBName              = DB_NAME(),
            @lvcUser                = USER_NAME(),
            @lvcObjectName          = OBJECT_NAME(@@PROCID),
            @ldtProcessStartTime    = GETDATE()
      
   /****************************************************************
   **               BEGIN PROCESS                                 **
   *****************************************************************/
    
    /**************  PRINT JOB HEADER DATA *************************/
    
    EXEC fabncdv1stage.dbo.harsp_gen_util_job_hdr_lgr
        @pchObjectName        = @lvcObjectName,
        @pdtProcessStartTime  = @ldtProcessStartTime,
        @pchServerName        = @lvcServerName,
        @pchDBName            = @lvcDBName,
        @pchUserName          = @lvcUser,
        @pchVersionNum        = @lvcVersionNum
      
   
   /**************  PRINT STEP 1  HEADER DATA *************************/
   /********** STEP 1 Populate Staging table tpzt_magellan_member_extr for Magellan Member Extract **********/
   
    IF UPPER(@pRunFreq) = 'DAILY'
        BEGIN
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_magellan_member_extr_old for Magellan Member Extract'

            EXEC fabncdv1stage.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
     
        
            /************* STEP 1(a) Truncate stage table tpzt_magellan_member_extr_old *************/
            
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr_old
            
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr_old *************/
        
            SELECT @lnRetCd    = @@ERROR,
                @lnRowsProcessed = @@ROWCOUNT

            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Truncating stage table tpzt_magellan_member_extr_old FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
        
            /************* STEP 1(b) Inserting data into stage table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Inserting data into Staging table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new for Magellan Member Extract'
    
            EXEC fabncdv1stage.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr_old
            (
                FAMILY_ID,   
                GROUP_ID,    
                RELATION,   
                CSPD_CAT,
                MEST_TYPE,
                MEHD_TYPE,
                LAST_NAME,   
                FIRST_NAME,  
                MIDDLE_INIT, 
                TITLE,       
                SSN,         
                PHONE,
                ADDRESS_1,   
                ADDRESS_2,   
                CITY,        
                MEME_STATE,  
                ZIP,         
                COUNTRY_CODE,
                BIRTH_DATE,  
                GENDER,
                CSPI_ID,      
                MEPE_FI,     
                FROM_DATE,   
                TERM_DATE                                   
            )
            SELECT
                FAMILY_ID,   
                GROUP_ID,    
                RELATION,   
                CSPD_CAT,
                MEST_TYPE,
                MEHD_TYPE,    
                LAST_NAME,   
                FIRST_NAME,  
                MIDDLE_INIT, 
                TITLE,       
                SSN,         
                PHONE,
                ADDRESS_1,   
                ADDRESS_2,   
                CITY,        
                MEME_STATE,  
                ZIP,         
                COUNTRY_CODE,
                BIRTH_DATE,  
                GENDER,
                CSPI_ID,      
                MEPE_FI,     
                FROM_DATE,   
                TERM_DATE 
            FROM    fabncdv1stage.dbo.tpzt_magellan_member_extr_new                          
            
            /************* Error Checking for Inserting data into stage table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Inserting data into stage table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
    
            /************* STEP 1(c) Truncate stage table tpzt_magellan_member_extr_new *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_magellan_member_extr_new'
    
            EXEC fabncdv1stage.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr_new
            
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr_new *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Truncating stage table tpzt_magellan_member_extr_new FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
        
                                
            /************* STEP 1(d) Populating the stage table tpzt_magellan_member_extr_new *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Populating the Staging table tpzt_magellan_member_extr_new'
    
            EXEC fabncdv1stage.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr_new
            (
                FAMILY_ID,   
                GROUP_ID,    
                RELATION,   
                CSPD_CAT,
                MEST_TYPE,
                MEHD_TYPE,    
                LAST_NAME,   
                FIRST_NAME,  
                MIDDLE_INIT, 
                TITLE,       
                SSN,         
                PHONE,
                ADDRESS_1,   
                ADDRESS_2,   
                CITY,        
                MEME_STATE,  
                ZIP,         
                COUNTRY_CODE,
                BIRTH_DATE,  
                GENDER,
                CSPI_ID,      
                MEPE_FI,     
                FROM_DATE,   
                TERM_DATE
            )
           SELECT
                DISTINCT 
                elig.SBSB_ID,        
                elig.GRGR_ID,        
                elig.MEME_REL,        
                elig.CSPD_CAT,
                STUD.MEST_TYPE,
                MEHD.MEHD_TYPE,        
                elig.MEME_LAST_NAME,    
                elig.MEME_FIRST_NAME,
                elig.MEME_MID_INIT,    
                MEME.MEME_TITLE,        
                elig.MEME_SSN,        
                elig.SBAD_PHONE,        
                elig.SBAD_ADDR1,        
                elig.SBAD_ADDR2,        
                elig.SBAD_CITY,        
                elig.SBAD_STATE,        
                elig.SBAD_ZIP,        
                elig.SBAD_CTRY_CD,
                CAST(convert(varchar,elig.MEME_BIRTH_DT,112) AS DECIMAL(8)) AS MEME_BIRTH_DT,    
                elig.MEME_SEX,
                CASE 
                WHEN elig.CSPD_CAT ='M' then elig.CSPI_ID         
                ELSE ''
                END AS CSPD_CAT,        
                elig.MEPE_FI, 
                CAST(convert(varchar,elig.MEPE_EFF_DT,112) AS DECIMAL(8)) AS MEPE_EFF_DT,               
                CAST(convert(varchar,elig.MEPE_TERM_DT,112) AS DECIMAL(8)) AS MEPE_TERM_DT            
            FROM tpzt_comm_elig_extr elig
            INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP GRGR
                ON elig.GRGR_CK=GRGR.GRGR_CK
            INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER MEME
                ON elig.MEME_CK=MEME.MEME_CK
            LEFT JOIN fabncdv1.dbo.CMC_MEST_STUDENT STUD
            ON STUD.MEME_CK=elig.MEME_CK
            AND GETDATE() BETWEEN STUD.MEST_EFF_DT AND STUD.MEST_TERM_DT
            LEFT JOIN fabncdv1.dbo.CMC_MEHD_HANDICAP MEHD
            ON MEHD.MEME_CK=elig.MEME_CK
            AND GETDATE() BETWEEN MEHD.MEHD_EFF_DT AND MEHD.MEHD_TERM_DT
            WHERE 
                GRGR.GRGR_MCTR_TYPE = 'COMM' 
            AND GETDATE() BETWEEN elig.MEPE_EFF_DT AND elig.MEPE_TERM_DT
            
                
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr_new *************/
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Populating the stage table tpzt_magellan_member_extr_new '
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
    
            /************* STEP 1(e) Truncate stage table tpzt_magellan_member_extr *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Truncate stage table tpzt_magellan_member_extr'
    
            EXEC fabncdv1stage.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr
            
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Truncating stage table tpzt_magellan_member_extr FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
            
            
            /************* STEP 1(f) Populate the stage table tpzt_magellan_member_extr with Daily Records  *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Populate the stage table tpzt_magellan_member_extr with Daily Records '
    
            EXEC fabncdv1stage.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr
            (
				[2000_INS02_F_RELATION],
				[2000_INS06_F_CSPD_CAT],
				[2000_INS08_F_CSPD_CAT],  
				[2000_INS09_F_MEST_TYPE], 
				[2000_INS10_F_MEHD_TYPE],
				[2000_REF02_F_SUBSCRIBER_ID],
				[2000_REF02_F_GROUP_ID]  ,
				[2100A_NM103_F_LAST_NAME],   
				[2100A_NM104_F_FIRST_NAME],  
				[2100A_NM105_F_MIDDLE_INIT], 
				[2100A_NM107_F_TITLE],    
				[2100A_NM109_F_SSN],  
				[2100A_PER04_F_PHONE],   
				[2100A_N301_F_ADDRESS_1],  
				[2100A_N302_F_ADDRESS_2],  
				[2100A_N401_F_CITY],         
				[2100A_N402_F_STATE],        
				[2100A_N403_F_ZIP],          
				[2100A_N404_F_COUNTRY_CODE], 
				[2100A_DMG02_F_BIRTH_DATE],   
				[2100A_DMG03_F_GENDER],       
				[2300_HD04_F_CSPI_ID],     
				[2300_HD05_F_MEPE_FI],     
				[2300_DTP03_F_FROM_DATE]  
            )
            SELECT
                curr.RELATION,
                curr.CSPD_CAT,
                curr.CSPD_CAT,
                curr.MEST_TYPE,               
                curr.MEHD_TYPE,
                curr.FAMILY_ID,               
                curr.GROUP_ID,
                curr.LAST_NAME,               
                curr.FIRST_NAME,
                curr.MIDDLE_INIT,
                curr.TITLE,       
                curr.SSN,
                curr.PHONE,
                curr.ADDRESS_1,               
                curr.ADDRESS_2,              
                curr.CITY,                    
                curr.MEME_STATE,              
                curr.ZIP,                     
                curr.COUNTRY_CODE,            
                CASE 
                    WHEN curr.BIRTH_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(curr.BIRTH_DATE AS VARCHAR(8))
                END AS BIRTH_DATE,
                curr.GENDER,                  
                curr.CSPI_ID,                 
                curr.MEPE_FI,                 
                CASE 
                    WHEN curr.FROM_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(curr.FROM_DATE AS VARCHAR(8))
                END AS FROM_DATE            
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new curr
                
            EXCEPT
                
            SELECT 
                prev.RELATION,
                prev.CSPD_CAT,
                prev.CSPD_CAT,
                prev.MEST_TYPE,               
                prev.MEHD_TYPE,
                prev.FAMILY_ID,               
                prev.GROUP_ID,
                prev.LAST_NAME,               
                prev.FIRST_NAME,
                prev.MIDDLE_INIT,
                prev.TITLE,       
                prev.SSN,
                prev.PHONE,
                prev.ADDRESS_1,               
                prev.ADDRESS_2,              
                prev.CITY,                    
                prev.MEME_STATE,              
                prev.ZIP,                     
                prev.COUNTRY_CODE,            
                CASE 
                    WHEN prev.BIRTH_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(prev.BIRTH_DATE AS VARCHAR(8))
                END AS BIRTH_DATE,
                prev.GENDER,                  
                prev.CSPI_ID,                 
                prev.MEPE_FI,                 
                CASE 
                    WHEN prev.FROM_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(prev.FROM_DATE AS VARCHAR(8))
                END AS FROM_DATE          
            FROM 
            fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev
            
            /************* Error Checking for Populate the stage table tpzt_magellan_member_extr with Daily Records *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Populate the stage table tpzt_magellan_member_extr with Daily Records FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
              
                /**************  PRINT STEP 1 FOOTER DATA *************************/

            SELECT @ldtStepEndTime = GETDATE()

            EXEC fabncdv1stage.dbo.harsp_gen_util_step_ftr_lgr
                @pdtStepStartTime    = @ldtStepStartTime,
                @pdtStepEndTime      = @ldtStepEndTime,
                @pdtProcessStartTime = @ldtProcessStartTime,
                @pnRowCount          = @lnRowsProcessed
     
        END  
    
   /**************  PRINT STEP 2  HEADER DATA *************************/
   /********** STEP 2 Populate stage table tpzt_magellan_member_extr for Magellan Quarterly Member Extract **********/
    
    IF UPPER(@pRunFreq) = 'QUARTERLY'
        BEGIN
        
            /************* STEP 2(a) Truncate stage table tpzt_magellan_member_extr *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Truncating stage table tpzt_magellan_member_extr for Magellan Quarterly Member Extract'
    
            EXEC fabncdv1stage.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr
            
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Truncating stage table tpzt_magellan_member_extr FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
            
            
            /************* STEP 2(b) Populate the stage table tpzt_magellan_member_extr with Quarterly Records *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Populate stage table tpzt_magellan_member_extr for Magellan Quarterly Member Extract'
    
            EXEC fabncdv1stage.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
                
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr
            (
				[2000_INS02_F_RELATION],
				[2000_INS06_F_CSPD_CAT],
				[2000_INS08_F_CSPD_CAT],  
				[2000_INS09_F_MEST_TYPE], 
				[2000_INS10_F_MEHD_TYPE],
				[2000_REF02_F_SUBSCRIBER_ID],
				[2000_REF02_F_GROUP_ID]  ,
				[2100A_NM103_F_LAST_NAME],   
				[2100A_NM104_F_FIRST_NAME],  
				[2100A_NM105_F_MIDDLE_INIT], 
				[2100A_NM107_F_TITLE],    
				[2100A_NM109_F_SSN],  
				[2100A_PER04_F_PHONE],   
				[2100A_N301_F_ADDRESS_1],  
				[2100A_N302_F_ADDRESS_2],  
				[2100A_N401_F_CITY],         
				[2100A_N402_F_STATE],        
				[2100A_N403_F_ZIP],          
				[2100A_N404_F_COUNTRY_CODE], 
				[2100A_DMG02_F_BIRTH_DATE],   
				[2100A_DMG03_F_GENDER],       
				[2300_HD04_F_CSPI_ID],     
				[2300_HD05_F_MEPE_FI],     
				[2300_DTP03_F_FROM_DATE]  
            )
            SELECT
                DISTINCT
                elig.MEME_REL,
                elig.CSPD_CAT,
                elig.CSPD_CAT,
                STUD.MEST_TYPE,
                MEHD.MEHD_TYPE,  
                elig.SBSB_ID,        
                elig.GRGR_ID,        
                elig.MEME_LAST_NAME,    
                elig.MEME_FIRST_NAME,
                elig.MEME_MID_INIT,    
                MEME.MEME_TITLE,        
                elig.MEME_SSN,        
                elig.SBAD_PHONE,        
                elig.SBAD_ADDR1,        
                elig.SBAD_ADDR2,        
                elig.SBAD_CITY,        
                elig.SBAD_STATE,        
                elig.SBAD_ZIP,        
                elig.SBAD_CTRY_CD,
                CAST(convert(varchar,elig.MEME_BIRTH_DT,112) AS DECIMAL(8)) AS MEME_BIRTH_DT,    
                elig.MEME_SEX,
                CASE 
                WHEN elig.CSPD_CAT ='M' then elig.CSPI_ID         
                ELSE ''
                END AS CSPD_CAT,        
                elig.MEPE_FI, 
                CAST(convert(varchar,elig.MEPE_EFF_DT,112) AS DECIMAL(8)) AS MEPE_EFF_DT               
            FROM tpzt_comm_elig_extr elig
            INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP GRGR
                ON elig.GRGR_CK=GRGR.GRGR_CK
            INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER MEME
                ON elig.MEME_CK=MEME.MEME_CK
            LEFT JOIN fabncdv1.dbo.CMC_MEST_STUDENT STUD
            ON STUD.MEME_CK=elig.MEME_CK
            AND GETDATE() BETWEEN STUD.MEST_EFF_DT AND STUD.MEST_TERM_DT
            LEFT JOIN fabncdv1.dbo.CMC_MEHD_HANDICAP MEHD
            ON MEHD.MEME_CK=elig.MEME_CK
            AND GETDATE() BETWEEN MEHD.MEHD_EFF_DT AND MEHD.MEHD_TERM_DT
            WHERE 
                GRGR.GRGR_MCTR_TYPE = 'COMM' 
            AND GETDATE() BETWEEN elig.MEPE_EFF_DT AND elig.MEPE_TERM_DT
            
            
            /************* Error Checking for Populate the stage table tpzt_magellan_member_extr with Quarterly Records *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Populate the stage table tpzt_magellan_member_extr with Quarterly Records FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
            END
            
            
           /**************  PRINT STEP 2 FOOTER DATA *************************/

           SELECT @ldtStepEndTime = GETDATE()

           EXEC fabncdv1stage.dbo.harsp_gen_util_step_ftr_lgr
             @pdtStepStartTime    = @ldtStepStartTime,
             @pdtStepEndTime      = @ldtStepEndTime,
             @pdtProcessStartTime = @ldtProcessStartTime,
             @pnRowCount          = @lnRowsProcessed
          
        END
   
   /**************  PRINT STEP 3  HEADER DATA *************************/
   /********** STEP 3 Update/Insert stage table tpzt_magellan_hippa_ControlNumber for Magellan Quarterly Member Extract **********/
   
   BEGIN
            
		   IF EXISTS (SELECT CONTROLNUMBER FROM tpzt_magellan_hippa_ControlNumber)
			   BEGIN
					SELECT @lnCurrentStep    = @lnCurrentStep + 1,
						@ldtStepStartTime = GETDATE(),
						@lvcMsg = @lvcObjectName + ': Updating Staging table tpzt_magellan_hippa_ControlNumber for Magellan Member Extract'

					EXEC fabncdv1stage.dbo.harsp_gen_util_step_hdr_lgr
						@pnStepNumber     = @lnCurrentStep,
						@pdtStepStartTime = @ldtStepStartTime,
						@pnTotalSteps     = @lnTotalSteps,
						@pchStepMsg       = @lvcMsg 
						
                /************* STEP 1 Updateing Staging table tpzt_magellan_hippa_ControlNumber *************/
                
						UPDATE tpzt_magellan_hippa_ControlNumber SET CONTROLNUMBER=CONTROLNUMBER + 1
						
            /************* Error Checking for Selecting Staging table tpzt_magellan_member_extr *************/
        
					SELECT @lnRetCd    = @@ERROR,
						@lnRowsProcessed = @@ROWCOUNT

					IF @lnRetCd <> 0
						BEGIN
							SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
							+ ' : Updating Staging table tpzt_magellan_hippa_ControlNumber FAILED'
							+ ' RETURNCODE: '
							+ CONVERT(CHAR(6),@lnRetCd)
							PRINT  @lvcMsg
							RETURN @lnRetCd
						END
			   END		
		   ELSE
			   BEGIN
			   		SELECT @lnCurrentStep    = @lnCurrentStep + 1,
						@ldtStepStartTime = GETDATE(),
						@lvcMsg = @lvcObjectName + ': Inserting Staging table tpzt_magellan_hippa_ControlNumber for Magellan Member Extract'

					EXEC fabncdv1stage.dbo.harsp_gen_util_step_hdr_lgr
						@pnStepNumber     = @lnCurrentStep,
						@pdtStepStartTime = @ldtStepStartTime,
						@pnTotalSteps     = @lnTotalSteps,
						@pchStepMsg       = @lvcMsg 
						
				/************* STEP 1 Inserting Staging table tpzt_magellan_hippa_ControlNumber *************/
						
						INSERT INTO tpzt_magellan_hippa_ControlNumber(CONTROLNUMBER) VALUES(100000000)
						
			/************* Error Checking for Selecting Staging table tpzt_magellan_hippa_ControlNumber *************/
        
					SELECT @lnRetCd    = @@ERROR,
						@lnRowsProcessed = @@ROWCOUNT

					IF @lnRetCd <> 0
						BEGIN
							SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
							+ ' : Inserting Staging table tpzt_magellan_hippa_ControlNumber FAILED'
							+ ' RETURNCODE: '
							+ CONVERT(CHAR(6),@lnRetCd)
							PRINT  @lvcMsg
							RETURN @lnRetCd
						END
			   END
   
   
   /**************  PRINT STEP 3 FOOTER DATA *************************/

           SELECT @ldtStepEndTime = GETDATE()

           EXEC fabncdv1stage.dbo.harsp_gen_util_step_ftr_lgr
             @pdtStepStartTime    = @ldtStepStartTime,
             @pdtStepEndTime      = @ldtStepEndTime,
             @pdtProcessStartTime = @ldtProcessStartTime,
             @pnRowCount          = @lnRowsProcessed
             
    END
   /**************  PRINT STEP 4  HEADER DATA *************************/
   /********** STEP 4 Select stage table tpzt_magellan_member_extr for Magellan Member Extract **********/
   BEGIN
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Selecting Staging table tpzt_magellan_member_extr for Magellan Member Extract'

            EXEC fabncdv1stage.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
     
        
            /************* STEP 1 Selecting Staging table tpzt_magellan_member_extr *************/
            
			SELECT TOP 1
                    ST01,
                    ST02,
                    ST03,
                    BGN01,
                    BGN02,
                    CAST(convert(varchar,GETDATE(),112) AS DECIMAL(8)) AS BGN03_DATE,
                    CONVERT(VARCHAR(2), GETDATE(), 108) + SUBSTRING(CONVERT(VARCHAR(5), GETDATE(), 108), 4, CHARINDEX(':', CONVERT(VARCHAR(5), GETDATE(), 108)) - 1) AS BGN04_TIME,
                    BGN08,
                    [1000A_N101],
                    [1000A_N102],
                    [1000A_N103],
                    [1000A_N104],
                    [1000B_N101],
                    [1000B_N102],
                    [1000B_N103],
                    [1000B_N104],
                    [2000_INS01],
                    CASE 
                        WHEN [2000_INS02_F_RELATION]='M' THEN '18' 
                        WHEN [2000_INS02_F_RELATION]='H' OR [2000_INS02_F_RELATION]='W' THEN '01'  
                        WHEN [2000_INS02_F_RELATION]='S' OR [2000_INS02_F_RELATION]='D' THEN '19'  
                        ELSE '23' 
                    END [2000_INS02_F_RELATION],
                    [2000_INS03],
                    [2000_INS05],
                    CASE
                        WHEN [2000_INS06_F_CSPD_CAT] <> 'D' AND DATEDIFF(YEAR,[2100A_DMG02_F_BIRTH_DATE],GETDATE()) >= 65 
                            AND [2000_INS01]='Y' THEN 'D' 
                        ELSE ''
                    END AS  [2000_INS06_F_CSPD_CAT],
                    CASE
                        WHEN [2000_INS08_F_CSPD_CAT] <> 'D' AND DATEDIFF(YEAR,[2100A_DMG02_F_BIRTH_DATE],GETDATE()) >= 65 AND [2000_INS01]='Y' THEN 'AC'
                        WHEN DATEDIFF(YEAR,[2100A_DMG02_F_BIRTH_DATE],GETDATE()) < 65 AND [2000_INS01]='Y' THEN 'FT'
                        WHEN [2000_INS08_F_CSPD_CAT] = 'D' AND [2000_INS01]='Y' THEN 'FT'
                        WHEN [2000_INS01]='N' THEN ''
                    END AS [2000_INS08_F_CSPD_CAT],
                    CASE 
                        WHEN [2000_INS09_F_MEST_TYPE] IS NULL OR [2000_INS09_F_MEST_TYPE]='' THEN 'N'
                        WHEN [2000_INS09_F_MEST_TYPE]= 'F' THEN 'F'
                        WHEN [2000_INS09_F_MEST_TYPE]= 'P' THEN 'P'
                        END AS [2000_INS09_F_MEST_TYPE],
                    CASE
                        WHEN [2000_INS10_F_MEHD_TYPE] IS NULL OR [2000_INS10_F_MEHD_TYPE]='' THEN 'N'
                        WHEN [2000_INS10_F_MEHD_TYPE]= 'P' THEN 'Y'
                    END AS [2000_INS10_F_MEHD_TYPE],
                    [2000_REF01_SUBSCRIBER],
                    [2000_REF02_F_SUBSCRIBER_ID],
                    [2000_REF01_GROUP],
                    [2000_REF02_F_GROUP_ID],
                    [2100A_NM101],
                    [2100A_NM102],
                    [2100A_NM103_F_LAST_NAME],
                    [2100A_NM104_F_FIRST_NAME],
                    [2100A_NM105_F_MIDDLE_INIT],
                    [2100A_NM107_F_TITLE],
                    [2100A_NM108],
                    [2100A_NM109_F_SSN],
                    [2100A_PER01],
                    [2100A_PER03],
                    [2100A_PER04_F_PHONE],
                    [2100A_N301_F_ADDRESS_1],
                    [2100A_N302_F_ADDRESS_2],
                    [2100A_N401_F_CITY],
                    [2100A_N402_F_STATE],
                    [2100A_N403_F_ZIP],
                    [2100A_N404_F_COUNTRY_CODE],
                    [2100A_DMG01],
                    [2100A_DMG02_F_BIRTH_DATE],
                    [2100A_DMG03_F_GENDER],
                    [2300_HD01],
                    [2300_HD03],
                    [2300_HD04_F_CSPI_ID],
                    CASE
                        WHEN [2300_HD05_F_MEPE_FI]='A' THEN 'FAM'
                        ELSE 'IND'
                    END AS [2300_HD05_F_MEPE_FI],
                    [2300_DTP01],
                    [2300_DTP02],
                    [2300_DTP03_F_FROM_DATE],
                    SE01,
                    SE02
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr
            
            /************* Error Checking for Selecting Staging table tpzt_magellan_member_extr *************/
        
            SELECT @lnRetCd    = @@ERROR,
                @lnRowsProcessed = @@ROWCOUNT

            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Selecting Staging table tpzt_magellan_member_extr FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
                /**************  PRINT STEP 4 FOOTER DATA *************************/

           SELECT @ldtStepEndTime = GETDATE()

           EXEC fabncdv1stage.dbo.harsp_gen_util_step_ftr_lgr
             @pdtStepStartTime    = @ldtStepStartTime,
             @pdtStepEndTime      = @ldtStepEndTime,
             @pdtProcessStartTime = @ldtProcessStartTime,
             @pnRowCount          = @lnRowsProcessed
   END 
        
END
GO
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_magellan_member_extr') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.tpzp_magellan_member_extr >>>'
ELSE
   PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_magellan_member_extr >>>'
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/ 