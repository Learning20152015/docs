/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_magellan_member_extr') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.tpzp_magellan_member_extr
    IF OBJECT_ID('dbo.tpzp_magellan_member_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_magellan_member_extr >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_magellan_member_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/

CREATE PROCEDURE [dbo].[tpzp_magellan_member_extr]

/****************************************************************
**   NAME                  :    tpzp_magellan_member_extr
**
**
**   PVCS LOCATION         :    
**
**   FUNCTION              :    The scope of this stored procedure is to extract membership/eligibility xml 
                                file from Facets for NC Plan and send it to Magellan. Extract all the Members who have
                                active eligibility and Mental Health or Substance Abuse benefits.
**
**   PARAMETERS            :
**                   INPUT :    @pRunFreq
**                  OUTPUT :    
**
**   RETURN CODES          :    0 on success
**
**   TABLES REFERENCED     :
**                FACETS   :    CMC_SBSB_SUBSC,CMC_GRGR_GROUP,CMC_MEME_MEMBER,CMC_SBAD_ADDR,CMC_MEPE_PRCS_ELIG,CMC_PDDS_PROD_DESC,CMC_CSPI_CS_PLAN
**                FACETSXC :    N/A
**                CUSTOM   :    
**                STAGE    :   
**
**   PROCEDURES REFERENCED :    N/A
**                  FACETS :    N/A
**                  CUSTOM :    N/A
**
**   STANDARD LOGGING PROCS:    harcore.dbo.harsp_gen_util_job_hdr_lgr
**                              harcore.dbo.harsp_gen_util_job_ftr_lgr
**                              harcore.dbo.harsp_gen_util_step_hdr_lgr
**                              harcore.dbo.harsp_gen_util_step_ftr_lgr
**
** REVISION HISTORY        :
**  VERSION    DATE        DEVELOPER        DESCRIPTION
** -------- ----------   --------------  -------------------
**    1.0   03/11/2014   Amol Sangar      Initial version

****************************************************************/

(
    @pRunFreq       VARCHAR(10)
)

AS

BEGIN


   /****************************************************************
   **          DECLARE LOCAL VARIABLES                            **
   ****************************************************************/
   DECLARE @lnRetCd                INT              -- Proc return code
   DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field
   DECLARE @lnCurrentStep          INT              -- Current Step Number
   DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time
   DECLARE @lnTotalSteps           INT              -- Total Steps In Proc
   DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name
   DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name
   DECLARE @lvcDBName              VARCHAR(32)      -- DB Name
   DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version
   DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name
   DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time
   DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step
   DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time
   DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
   
  /****************************************************************
   **          INITIALIZE  VARIABLES                              **
   ****************************************************************/
    SELECT  @lnRetCd          = 0,
            @lvcMsg           = NULL,
            @lnCurrentStep    = 0,
            @lnTotalSteps     = CASE WHEN @pRunFreq = 'DAILY'
                                     THEN 10
                                     WHEN @pRunFreq = 'QUARTERLY'
                                     THEN 7
                                END,
            @ldtStepEndTime   = NULL,
            @lvcVersionNum    = '1.0'
   
    SELECT  @lvcServerName          = @@SERVERNAME,
            @lvcDBName              = DB_NAME(),
            @lvcUser                = USER_NAME(),
            @lvcObjectName          = OBJECT_NAME(@@PROCID),
            @ldtProcessStartTime    = GETDATE()
      
   /****************************************************************
   **               BEGIN PROCESS                                 **
   *****************************************************************/
    
    /**************  PRINT JOB HEADER DATA *************************/
    
    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr
        @pchObjectName        = @lvcObjectName,
        @pdtProcessStartTime  = @ldtProcessStartTime,
        @pchServerName        = @lvcServerName,
        @pchDBName            = @lvcDBName,
        @pchUserName          = @lvcUser,
        @pchVersionNum        = @lvcVersionNum
      
   
   /**************  PRINT STEP 1  HEADER DATA *************************/
   /********** STEP 1 Populate Staging table tpzt_magellan_member_extr for Magellan Member Extract **********/
   
    IF UPPER(@pRunFreq) = 'DAILY'
        BEGIN
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_magellan_member_extr_old.'

            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
     
        
            /************* STEP 1(a) Truncate stage table tpzt_magellan_member_extr_old *************/
            
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr_old
            
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr_old *************/
        
            SELECT @lnRetCd    = @@ERROR,
                @lnRowsProcessed = @@ROWCOUNT

            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Truncating stage table tpzt_magellan_member_extr_old FAILED.'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
        
            /************* STEP 1(b) Inserting data into stage table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Inserting data into Staging table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new.'
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr_old
            (
                MEME_CK,
                IS_SUBSCRIBER,
                FAMILY_ID,   
                GROUP_ID,
                MEME_REL,    
                RELATION, 
                LAST_NAME,   
                FIRST_NAME,  
                MIDDLE_INIT,
                ADDRESS_1,   
                ADDRESS_2,   
                CITY,        
                MEME_STATE,  
                ZIP,
                BIRTH_DATE, 
                GENDER,
                CSPI_ID,
                PDPD_ID,     
                FROM_DATE,   
                TERM_DATE,
                GROUP_FROM_DATE,
                GROUP_TERM_DATE
                )
            SELECT
                MEME_CK,
                IS_SUBSCRIBER,
                FAMILY_ID,   
                GROUP_ID,
                MEME_REL,    
                RELATION, 
                LAST_NAME,   
                FIRST_NAME,  
                MIDDLE_INIT,
                ADDRESS_1,   
                ADDRESS_2,   
                CITY,        
                MEME_STATE,  
                ZIP,
                BIRTH_DATE, 
                GENDER,
                CSPI_ID,
                PDPD_ID,     
                FROM_DATE,   
                TERM_DATE,
                GROUP_FROM_DATE,
                GROUP_TERM_DATE
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new                          
            
            /************* Error Checking for Inserting data into stage table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Inserting data into stage table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new FAILED.'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
    
            /************* STEP 1(c) Truncate stage table tpzt_magellan_member_extr_new *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_magellan_member_extr_new.'
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr_new
            
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr_new *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Truncating stage table tpzt_magellan_member_extr_new FAILED.'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
                             
            /************* STEP 1(d) Populating the stage table tpzt_magellan_member_extr_new *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Populating the Staging table tpzt_magellan_member_extr_new with DAILY records.'
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr_new
            (  
                MEME_CK,
                IS_SUBSCRIBER,
                FAMILY_ID,   
                GROUP_ID,
                MEME_REL,    
                RELATION,
                LAST_NAME,   
                FIRST_NAME,  
                MIDDLE_INIT,
                ADDRESS_1,   
                ADDRESS_2,   
                CITY,        
                MEME_STATE,  
                ZIP,
                BIRTH_DATE,
                GENDER,  
                CSPI_ID, 
                PDPD_ID,    
                FROM_DATE,   
                TERM_DATE,
                GROUP_FROM_DATE,
                GROUP_TERM_DATE
            )
            SELECT
                meme.MEME_CK,
                CASE 
                        WHEN [MEME_REL]='M' THEN 'Y'
                        ELSE 'N'
                END AS IS_SUBSCRIBER,    
                CONCAT(RIGHT('000000000'+ CAST(sbsb.SBSB_ID AS VARCHAR(9)),9),RIGHT('00' + CAST(meme.MEME_SFX AS VARCHAR(2)),2)) AS SBSB_ID,        
                grgr.GRGR_ID,        
                meme.MEME_REL,
                CASE 
                        WHEN [MEME_REL]='M' THEN '18' 
                        WHEN [MEME_REL]='H' OR [MEME_REL]='W' THEN '01'  
                        WHEN [MEME_REL]='S' OR [MEME_REL]='D' THEN '19'  
                        ELSE '23' 
                END [2000_INS02_F_RELATION],
                meme.MEME_LAST_NAME,    
                meme.MEME_FIRST_NAME,
                meme.MEME_MID_INIT,      
                sbad.SBAD_ADDR1,        
                sbad.SBAD_ADDR2,        
                sbad.SBAD_CITY,        
                sbad.SBAD_STATE,        
                sbad.SBAD_ZIP, 
                CAST(convert(varchar,meme.MEME_BIRTH_DT,112) AS DECIMAL(8)) AS MEME_BIRTH_DT,    
                meme.MEME_SEX,
                mepe.CSPI_ID,
                mepe.PDPD_ID, 
                CAST(convert(varchar,mepe.MEPE_EFF_DT,112) AS DECIMAL(8)) AS MEPE_EFF_DT,               
                CAST(convert(varchar,mepe.MEPE_TERM_DT,112) AS DECIMAL(8)) AS MEPE_TERM_DT,
                CAST(convert(varchar,grgr.GRGR_ORIG_EFF_DT,112) AS DECIMAL(8)) AS GRGR_ORIG_EFF_DT,               
                CAST(convert(varchar,grgr.GRGR_TERM_DT,112) AS DECIMAL(8)) AS GRGR_TERM_DT
             FROM   fabncdv1.dbo.CMC_SBSB_SUBSC sbsb
                    INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr
                        ON sbsb.GRGR_CK=grgr.GRGR_CK
                    INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme
                        ON meme.SBSB_CK=sbsb.SBSB_CK
                    INNER JOIN fabncdv1.dbo.CMC_SBAD_ADDR sbad
                        ON sbsb.SBSB_CK=sbad.SBSB_CK
                           AND sbad.GRGR_CK=grgr.GRGR_CK
                    INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe
                        ON mepe.MEME_CK=meme.MEME_CK
                           AND mepe.GRGR_CK=grgr.GRGR_CK  
                    WHERE
                        grgr.GRGR_MCTR_TYPE = 'COMM'
                        AND mepe.CSPD_CAT ='M'
                        AND mepe.MEPE_ELIG_IND='Y'
                        AND sbad.SBAD_TYPE = meme.SBAD_TYPE_MAIL
                        AND GETDATE() BETWEEN mepe.MEPE_EFF_DT AND mepe.MEPE_TERM_DT 
                        ORDER BY sbsb.SBSB_ID,meme.MEME_SFX    
                
            /************* Error Checking for Populating the stage table tpzt_magellan_member_extr_new with DAILY records *************/
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Populating the stage table tpzt_magellan_member_extr_new with DAILY records. '
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
       
            
            /************* STEP 1(e) Truncate stage table tpzt_magellan_member_extr *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Truncate stage table tpzt_magellan_member_extr.'
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr
            
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Truncating stage table tpzt_magellan_member_extr FAILED.'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
            
            
            /************* STEP 1(f) Populate the stage table tpzt_magellan_member_extr with Daily Records  *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Populate the stage table tpzt_magellan_member_extr with Daily Records. '
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr
            (
                MEME_CK,
                [2000_INS01_IS_SUBSCRIBER],
                MEME_REL,
                [2000_INS02_F_RELATION],
                [2000_INS03],
                [2000_REF02_F_SUBSCRIBER_ID],
                [2000_REF02_F_GROUP_ID]  ,
                [2100A_NM103_F_LAST_NAME],   
                [2100A_NM104_F_FIRST_NAME],  
                [2100A_NM105_F_MIDDLE_INIT], 
                [2100A_N301_F_ADDRESS_1],  
                [2100A_N302_F_ADDRESS_2],  
                [2100A_N401_F_CITY],         
                [2100A_N402_F_STATE],        
                [2100A_N403_F_ZIP],        
                [2100A_DMG02_F_BIRTH_DATE],   
                [2100A_DMG03_F_GENDER],
                [2300_HD01],  
                [2300_HD04_F_CSPI_ID], 
                PDPD_ID,     
                [2300_DTP03_F_FROM_DATE],
                [2300_DTP03_F_TERM_DATE],       
                [2300_DTP03_F_GROUP_FROM_DATE], 
                [2300_DTP03_F_GROUP_TERM_DATE]
             )
             SELECT
                curr.MEME_CK,
                curr.IS_SUBSCRIBER,
                curr.MEME_REL,
                curr.RELATION,
                '',
                curr.FAMILY_ID,               
                curr.GROUP_ID,
                curr.LAST_NAME,               
                curr.FIRST_NAME,
                curr.MIDDLE_INIT,
                curr.ADDRESS_1,               
                curr.ADDRESS_2,              
                curr.CITY,                    
                curr.MEME_STATE,              
                curr.ZIP,  
                CASE 
                    WHEN curr.BIRTH_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(curr.BIRTH_DATE AS VARCHAR(8))
                END AS BIRTH_DATE,
                curr.GENDER,
                '',                  
                curr.CSPI_ID,  
                curr.PDPD_ID,                 
                CASE 
                    WHEN curr.FROM_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(curr.FROM_DATE AS VARCHAR(8))
                END AS FROM_DATE,
                CASE 
                    WHEN curr.TERM_DATE =0
                    THEN '12312199'
                    ELSE  
                    CAST(curr.TERM_DATE AS VARCHAR(8))
                END AS TERM_DATE,
                CASE 
                    WHEN curr.GROUP_FROM_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(curr.GROUP_FROM_DATE AS VARCHAR(8))
                END AS GROUP_FROM_DATE,
                CASE 
                    WHEN curr.GROUP_TERM_DATE =0
                    THEN '12312199'
                    ELSE  
                    CAST(curr.GROUP_TERM_DATE AS VARCHAR(8))
                END AS GROUP_TERM_DATE
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new curr
                
            EXCEPT
                
             SELECT
                prev.MEME_CK,
                prev.IS_SUBSCRIBER,
                prev.MEME_REL,
                prev.RELATION,
                '',
				prev.FAMILY_ID,               
                prev.GROUP_ID,
                prev.LAST_NAME,               
                prev.FIRST_NAME,
                prev.MIDDLE_INIT,
                prev.ADDRESS_1,               
                prev.ADDRESS_2,              
                prev.CITY,                    
                prev.MEME_STATE,              
                prev.ZIP,  
                CASE 
                    WHEN prev.BIRTH_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(prev.BIRTH_DATE AS VARCHAR(8))
                END AS BIRTH_DATE,
                prev.GENDER, 
                '',                 
                prev.CSPI_ID,   
                prev.PDPD_ID,                 
                CASE 
                    WHEN prev.FROM_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(prev.FROM_DATE AS VARCHAR(8))
                END AS FROM_DATE,
                CASE 
                    WHEN prev.TERM_DATE =0
                    THEN '12312199'
                    ELSE  
                    CAST(prev.TERM_DATE AS VARCHAR(8))
                END AS TERM_DATE,
                CASE 
                    WHEN prev.GROUP_FROM_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(prev.GROUP_FROM_DATE AS VARCHAR(8))
                END AS GROUP_FROM_DATE,
                CASE 
                    WHEN prev.GROUP_TERM_DATE =0
                    THEN '12312199'
                    ELSE  
                    CAST(prev.GROUP_TERM_DATE AS VARCHAR(8))
                END AS GROUP_TERM_DATE
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev
            
            /************* Error Checking for Populate the stage table tpzt_magellan_member_extr with Daily Records *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Populate the stage table tpzt_magellan_member_extr with Daily Records FAILED.'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
                
                    
                /************* STEP 1(g) Update tpzt_magellan_member_extr_new stage table for new added records *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Update tpzt_magellan_member_extr_new stage table for new added records.  '
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
                
                IF (SELECT COUNT(1) FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old) > 0
                BEGIN
                    UPDATE curr
                        SET [2000_INS03]='021',[2300_HD01] = '021'
                        FROM fabncdv1stage.dbo.tpzt_magellan_member_extr curr
                        WHERE  NOT EXISTS (SELECT 1 FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev
                                           WHERE curr.MEME_CK=prev.MEME_CK
                                           )
                END                  
                /************* Error Checking for Update tpzt_magellan_member_extr_new stage table for new added records  *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Update tpzt_magellan_member_extr_new stage table for new added records  FAILED.'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
                       
                /************* STEP 1(h) Update stage table Update tpzt_magellan_member_extr_new stage table for changed  records *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Update tpzt_magellan_member_extr_new stage table for changed  records. '
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
                
            IF (SELECT COUNT(1) FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old) > 0
            
                BEGIN
                    UPDATE curr
                        SET [2000_INS03]='001',[2300_HD01] = '001'
                        FROM fabncdv1stage.dbo.tpzt_magellan_member_extr curr
                        WHERE  EXISTS(SELECT 1 FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev
                                            WHERE curr.MEME_CK= prev.MEME_CK 
                                                 AND curr.PDPD_ID = prev.PDPD_ID  
                                                 AND curr.[2300_DTP03_F_FROM_DATE] = prev.FROM_DATE
                                                 AND curr.[2300_DTP03_F_TERM_DATE] = prev.TERM_DATE
                                      )
                         AND NOT EXISTS (SELECT 1 FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev
                                          WHERE 
                                                curr.[2000_INS02_F_RELATION] = prev.RELATION 
                                                AND curr.[2100A_NM103_F_LAST_NAME] = prev.LAST_NAME  
                                                AND curr.[2100A_NM104_F_FIRST_NAME] =  prev.FIRST_NAME
                                                AND curr.[2100A_NM105_F_MIDDLE_INIT] = prev.MIDDLE_INIT
                                                AND curr.[2100A_N301_F_ADDRESS_1]= prev.ADDRESS_1  
                                                AND curr.[2100A_N302_F_ADDRESS_2]= prev.ADDRESS_2
                                                AND curr.[2100A_N401_F_CITY]=  prev.CITY    
                                                AND curr.[2100A_N402_F_STATE]=prev.MEME_STATE  
                                                AND curr.[2100A_N403_F_ZIP]= prev.ZIP      
                                                AND curr.[2100A_DMG02_F_BIRTH_DATE] = prev.BIRTH_DATE 
                                                AND curr.[2100A_DMG03_F_GENDER]=prev.GENDER
                                                AND curr.[2300_HD04_F_CSPI_ID]= prev.CSPI_ID 
                                               )
                END                  
                /************* Error Checking for Update tpzt_magellan_member_extr_new stage table for changed records *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Update tpzt_magellan_member_extr_new stage table for changed records FAILED.'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
                    
            /************* STEP 1(i) Populate the stage table tpzt_magellan_member_extr with Terminated Records  *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Populate the stage table tpzt_magellan_member_extr with Terminated Records. '
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
             INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr
            (
                MEME_CK,
                [2000_INS01_IS_SUBSCRIBER],
                MEME_REL,
                [2000_INS02_F_RELATION],
                [2000_INS03],
                [2000_REF02_F_SUBSCRIBER_ID],
                [2000_REF02_F_GROUP_ID]  ,
                [2100A_NM103_F_LAST_NAME],   
                [2100A_NM104_F_FIRST_NAME],  
                [2100A_NM105_F_MIDDLE_INIT], 
                [2100A_N301_F_ADDRESS_1],  
                [2100A_N302_F_ADDRESS_2],  
                [2100A_N401_F_CITY],         
                [2100A_N402_F_STATE],        
                [2100A_N403_F_ZIP],        
                [2100A_DMG02_F_BIRTH_DATE],   
                [2100A_DMG03_F_GENDER],
                [2300_HD01],  
                [2300_HD04_F_CSPI_ID], 
                PDPD_ID,     
                [2300_DTP03_F_FROM_DATE],
                [2300_DTP03_F_TERM_DATE],       
                [2300_DTP03_F_GROUP_FROM_DATE], 
                [2300_DTP03_F_GROUP_TERM_DATE]
            )
            SELECT
                meme.MEME_CK,
                CASE 
                        WHEN [MEME_REL]='M' THEN 'Y'
                        ELSE 'N'
                END AS IS_SUBSCRIBER, 
                meme.MEME_REL,  
                CASE 
                        WHEN [MEME_REL]='M' THEN '18' 
                        WHEN [MEME_REL]='H' OR [MEME_REL]='W' THEN '01'  
                        WHEN [MEME_REL]='S' OR [MEME_REL]='D' THEN '19'  
                        ELSE '23' 
                END [2000_INS02_F_RELATION],
                '024' AS [2300_HD01], 
                CONCAT(RIGHT('000000000'+ CAST(sbsb.SBSB_ID AS VARCHAR(9)),9),RIGHT('00' + CAST(meme.MEME_SFX AS VARCHAR(2)),2)) AS SBSB_ID,        
                grgr.GRGR_ID,        
                meme.MEME_LAST_NAME,    
                meme.MEME_FIRST_NAME,
                meme.MEME_MID_INIT,      
                sbad.SBAD_ADDR1,        
                sbad.SBAD_ADDR2,        
                sbad.SBAD_CITY,        
                sbad.SBAD_STATE,        
                sbad.SBAD_ZIP, 
                CAST(convert(varchar,meme.MEME_BIRTH_DT,112) AS DECIMAL(8)) AS MEME_BIRTH_DT,    
                meme.MEME_SEX,
                '024' AS [2300_HD01],
                mepe.CSPI_ID, 
                mepe.PDPD_ID, 
                CAST(convert(varchar,mepe.MEPE_EFF_DT,112) AS DECIMAL(8)) AS MEPE_EFF_DT,               
                CAST(convert(varchar,mepe.MEPE_TERM_DT,112) AS DECIMAL(8)) AS MEPE_TERM_DT,
                CAST(convert(varchar,grgr.GRGR_ORIG_EFF_DT,112) AS DECIMAL(8)) AS GRGR_ORIG_EFF_DT,               
                CAST(convert(varchar,grgr.GRGR_TERM_DT,112) AS DECIMAL(8)) AS GRGR_TERM_DT            
             FROM  
                fabncdv1.dbo.CMC_GRGR_GROUP grgr   
                INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg  
                        ON sgsg.GRGR_CK = grgr.GRGR_CK      
                INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb   
                        ON sbsb.GRGR_CK = grgr.GRGR_CK   
                INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme  
                        ON meme.SBSB_CK = sbsb.SBSB_CK  
                INNER JOIN fabncdv1.dbo.CMC_SBAD_ADDR sbad  
                        ON sbsb.SBSB_CK = sbad.SBSB_CK  
                       AND meme.SBAD_TYPE_HOME = sbad.SBAD_TYPE  
                INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe  
                        ON meme.MEME_CK = mepe.MEME_CK  
                INNER JOIN fabncdv1.dbo.CMC_PDDS_PROD_DESC pdds  
                        ON mepe.PDPD_ID = pdds.PDPD_ID  
                INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi  
                        ON  cspi.GRGR_CK = mepe.GRGR_CK  
                        AND cspi.CSPI_ID = mepe.CSPI_ID  
                        AND cspi.CSPD_CAT = mepe.CSPD_CAT   
                        AND cspi.CSCS_ID = mepe.CSCS_ID 
                WHERE meme.MEME_CK IN ( SELECT DISTINCT prev.MEME_CK   
                                    FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev )  
                    AND CAST(CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) AS DECIMAL(8)) IN (SELECT DISTINCT prev.FROM_DATE   
                                    FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_old prev WHERE prev.MEME_CK = mepe.MEME_CK)  
                    AND CAST(CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) AS DECIMAL(8)) NOT IN ( SELECT DISTINCT curr.FROM_DATE   
                                    FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new curr WHERE curr.MEME_CK = mepe.MEME_CK)                      
                    AND mepe.CSPD_CAT = 'M' 
                    AND grgr.GRGR_MCTR_TYPE = 'COMM' 
                    AND sbad.SBAD_TYPE = meme.SBAD_TYPE_MAIL
         /************* Error Checking for Populate the stage table tpzt_magellan_member_extr with Terminated Records *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Populate the stage table tpzt_magellan_member_extr with Terminated Records FAILED.'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
                /**************  PRINT STEP 1 FOOTER DATA *************************/

            SELECT @ldtStepEndTime = GETDATE()

            EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
                @pdtStepStartTime    = @ldtStepStartTime,
                @pdtStepEndTime      = @ldtStepEndTime,
                @pdtProcessStartTime = @ldtProcessStartTime,
                @pnRowCount          = @lnRowsProcessed
     
        END  
    
   /**************  PRINT STEP 2  HEADER DATA *************************/
   /********** STEP 2 Populate stage table tpzt_magellan_member_extr for Magellan Quarterly Member Extract **********/
    
    IF UPPER(@pRunFreq) = 'QUARTERLY'
        BEGIN
              SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_magellan_member_extr_old.'

            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
     
        
            /************* STEP 2(a) Truncate stage table tpzt_magellan_member_extr_old *************/
            
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr_old
            
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr_old *************/
        
            SELECT @lnRetCd    = @@ERROR,
                @lnRowsProcessed = @@ROWCOUNT

            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Truncating stage table tpzt_magellan_member_extr_old FAILED.'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
        
            /************* STEP 2(b) Inserting data into stage table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Inserting data into Staging table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new.'
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr_old
            (
                MEME_CK,
                IS_SUBSCRIBER,
                FAMILY_ID,   
                GROUP_ID,
                MEME_REL,    
                RELATION, 
                LAST_NAME,   
                FIRST_NAME,  
                MIDDLE_INIT,
                ADDRESS_1,   
                ADDRESS_2,   
                CITY,        
                MEME_STATE,  
                ZIP,
                BIRTH_DATE,  
                GENDER,
                CSPI_ID,  
                PDPD_ID,     
                FROM_DATE,   
                TERM_DATE,
                GROUP_FROM_DATE,
                GROUP_TERM_DATE
                )
            SELECT
                MEME_CK,
                IS_SUBSCRIBER,
                FAMILY_ID,   
                GROUP_ID,
                MEME_REL,    
                RELATION, 
                LAST_NAME,   
                FIRST_NAME,  
                MIDDLE_INIT,
                ADDRESS_1,   
                ADDRESS_2,   
                CITY,        
                MEME_STATE,  
                ZIP,
                BIRTH_DATE, 
                GENDER,
                CSPI_ID, 
                PDPD_ID,     
                FROM_DATE,   
                TERM_DATE,
                GROUP_FROM_DATE,
                GROUP_TERM_DATE
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new                          
            
            /************* Error Checking for Inserting data into stage table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Inserting data into stage table tpzt_magellan_member_extr_old from stage table tpzt_magellan_member_extr_new FAILED.'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
    
            /************* STEP 2(c) Truncate stage table tpzt_magellan_member_extr_new *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_magellan_member_extr_new.'
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr_new
            
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr_new *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Truncating stage table tpzt_magellan_member_extr_new FAILED.'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
        
                                
            /************* STEP 2(d) Populating the stage table tpzt_magellan_member_extr_new *************/  
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Populating the Staging table tpzt_magellan_member_extr_new with Quarterly records.'
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr_new
            (  
                MEME_CK,
                IS_SUBSCRIBER,
                FAMILY_ID,   
                GROUP_ID,
                MEME_REL,    
                RELATION,
                LAST_NAME,   
                FIRST_NAME,  
                MIDDLE_INIT,
                ADDRESS_1,   
                ADDRESS_2,   
                CITY,        
                MEME_STATE,  
                ZIP,
                BIRTH_DATE,
                GENDER,  
                CSPI_ID, 
                PDPD_ID,    
                FROM_DATE,   
                TERM_DATE,
                GROUP_FROM_DATE,
                GROUP_TERM_DATE
            )
            SELECT
                meme.MEME_CK,
                CASE 
                        WHEN [MEME_REL]='M' THEN 'Y'
                        ELSE 'N'
                END AS IS_SUBSCRIBER,    
                CONCAT(RIGHT('000000000'+ CAST(sbsb.SBSB_ID AS VARCHAR(9)),9),RIGHT('00' + CAST(meme.MEME_SFX AS VARCHAR(2)),2)) AS SBSB_ID,        
                grgr.GRGR_ID,        
                meme.MEME_REL,
                CASE 
                        WHEN [MEME_REL]='M' THEN '18' 
                        WHEN [MEME_REL]='H' OR [MEME_REL]='W' THEN '01'  
                        WHEN [MEME_REL]='S' OR [MEME_REL]='D' THEN '19'  
                        ELSE '23' 
                END [2000_INS02_F_RELATION],
                meme.MEME_LAST_NAME,    
                meme.MEME_FIRST_NAME,
                meme.MEME_MID_INIT,      
                sbad.SBAD_ADDR1,        
                sbad.SBAD_ADDR2,        
                sbad.SBAD_CITY,        
                sbad.SBAD_STATE,        
                sbad.SBAD_ZIP, 
                CAST(convert(varchar,meme.MEME_BIRTH_DT,112) AS DECIMAL(8)) AS MEME_BIRTH_DT,    
                meme.MEME_SEX,
                mepe.CSPI_ID,
                mepe.PDPD_ID, 
                CAST(convert(varchar,mepe.MEPE_EFF_DT,112) AS DECIMAL(8)) AS MEPE_EFF_DT,               
                CAST(convert(varchar,mepe.MEPE_TERM_DT,112) AS DECIMAL(8)) AS MEPE_TERM_DT,
                CAST(convert(varchar,grgr.GRGR_ORIG_EFF_DT,112) AS DECIMAL(8)) AS GRGR_ORIG_EFF_DT,               
                CAST(convert(varchar,grgr.GRGR_TERM_DT,112) AS DECIMAL(8)) AS GRGR_TERM_DT
             FROM   fabncdv1.dbo.CMC_SBSB_SUBSC sbsb
                    INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr
                        ON sbsb.GRGR_CK=grgr.GRGR_CK
                    INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme
                        ON meme.SBSB_CK=sbsb.SBSB_CK
                    INNER JOIN fabncdv1.dbo.CMC_SBAD_ADDR sbad
                        ON sbsb.SBSB_CK=sbad.SBSB_CK
                           AND sbad.GRGR_CK=grgr.GRGR_CK
                    INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe
                        ON mepe.MEME_CK=meme.MEME_CK
                           AND mepe.GRGR_CK=grgr.GRGR_CK  
                    WHERE
                        grgr.GRGR_MCTR_TYPE = 'COMM'
                        AND mepe.CSPD_CAT ='M'
                        AND mepe.MEPE_ELIG_IND='Y'
                        AND sbad.SBAD_TYPE = meme.SBAD_TYPE_MAIL
                        AND GETDATE() BETWEEN mepe.MEPE_EFF_DT AND mepe.MEPE_TERM_DT 
                        ORDER BY sbsb.SBSB_ID,meme.MEME_SFX  
                
            /************* Error Checking for Populating the Staging table tpzt_magellan_member_extr_new with Quarterly records *************/
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Populating the Staging table tpzt_magellan_member_extr_new with Quarterly records FAILED. '
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
        
            /************* STEP 2(e) Truncate stage table tpzt_magellan_member_extr *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Truncating stage table tpzt_magellan_member_extr for Quarterly records. '
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
            
            TRUNCATE TABLE fabncdv1stage.dbo.tpzt_magellan_member_extr
            
            /************* Error Checking for Truncating stage table tpzt_magellan_member_extr *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Truncating stage table tpzt_magellan_member_extr FAILED. '
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
            
            /************* STEP 2(f) Populate the stage table tpzt_magellan_member_extr with Quarterly Records *************/
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Populate stage table tpzt_magellan_member_extr for Quarterly records. '
    
            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
                
            INSERT INTO fabncdv1stage.dbo.tpzt_magellan_member_extr
            (
                MEME_CK,
                [2000_INS01_IS_SUBSCRIBER],
                MEME_REL,
                [2000_INS02_F_RELATION],
                [2000_INS03],
                [2000_REF02_F_SUBSCRIBER_ID],
                [2000_REF02_F_GROUP_ID]  ,
                [2100A_NM103_F_LAST_NAME],   
                [2100A_NM104_F_FIRST_NAME],  
                [2100A_NM105_F_MIDDLE_INIT], 
                [2100A_N301_F_ADDRESS_1],  
                [2100A_N302_F_ADDRESS_2],  
                [2100A_N401_F_CITY],         
                [2100A_N402_F_STATE],        
                [2100A_N403_F_ZIP],        
                [2100A_DMG02_F_BIRTH_DATE],   
                [2100A_DMG03_F_GENDER],
                [2300_HD01],  
                [2300_HD04_F_CSPI_ID],
                PDPD_ID,     
                [2300_DTP03_F_FROM_DATE],
                [2300_DTP03_F_TERM_DATE],       
                [2300_DTP03_F_GROUP_FROM_DATE], 
                [2300_DTP03_F_GROUP_TERM_DATE]
            )
             SELECT
                curr.MEME_CK,
                curr.IS_SUBSCRIBER,
                curr.MEME_REL,
                curr.RELATION,
                '030' AS [2300_HD01],
                curr.FAMILY_ID,               
                curr.GROUP_ID,
                curr.LAST_NAME,               
                curr.FIRST_NAME,
                curr.MIDDLE_INIT,
                curr.ADDRESS_1,               
                curr.ADDRESS_2,              
                curr.CITY,                    
                curr.MEME_STATE,              
                curr.ZIP,  
                CASE 
                    WHEN curr.BIRTH_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(curr.BIRTH_DATE AS VARCHAR(8))
                END AS BIRTH_DATE,
                curr.GENDER,
                '030' AS [2300_HD01],                  
                curr.CSPI_ID,    
                curr.PDPD_ID,                 
                CASE 
                    WHEN curr.FROM_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(curr.FROM_DATE AS VARCHAR(8))
                END AS FROM_DATE,
                CASE 
                    WHEN curr.TERM_DATE =0
                    THEN '12312199'
                    ELSE  
                    CAST(curr.TERM_DATE AS VARCHAR(8))
                END AS TERM_DATE,
                CASE 
                    WHEN curr.GROUP_FROM_DATE =0
                    THEN '00000000'
                    ELSE  
                    CAST(curr.GROUP_FROM_DATE AS VARCHAR(8))
                END AS GROUP_FROM_DATE,
                CASE 
                    WHEN curr.GROUP_TERM_DATE =0
                    THEN '12312199'
                    ELSE  
                    CAST(curr.GROUP_TERM_DATE AS VARCHAR(8))
                END AS GROUP_TERM_DATE
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr_new curr
            
            /************* Error Checking for Populate the stage table tpzt_magellan_member_extr with Quarterly Records *************/
            
            SELECT @lnRetCd    = @@ERROR,
            @lnRowsProcessed = @@ROWCOUNT
    
            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Populate the stage table tpzt_magellan_member_extr with Quarterly Records FAILED.'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
            END
           
           /**************  PRINT STEP 2 FOOTER DATA *************************/

           SELECT @ldtStepEndTime = GETDATE()

           EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
             @pdtStepStartTime    = @ldtStepStartTime,
             @pdtStepEndTime      = @ldtStepEndTime,
             @pdtProcessStartTime = @ldtProcessStartTime,
             @pnRowCount          = @lnRowsProcessed
          
        END
   
   
   /**************  PRINT STEP 3  HEADER DATA *************************/
   /********** STEP 3 Select stage table tpzt_magellan_member_extr for Magellan Member Extract **********/
   BEGIN
            SELECT @lnCurrentStep    = @lnCurrentStep + 1,
                @ldtStepStartTime = GETDATE(),
                @lvcMsg = @lvcObjectName + ': Selecting Staging table tpzt_magellan_member_extr.'

            EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
                @pnStepNumber     = @lnCurrentStep,
                @pdtStepStartTime = @ldtStepStartTime,
                @pnTotalSteps     = @lnTotalSteps,
                @pchStepMsg       = @lvcMsg
     
        
            /************* STEP 1 Selecting Staging table tpzt_magellan_member_extr *************/
            
           SELECT   
					[2000_INS01_IS_SUBSCRIBER],
                    MEME_REL,
                    [2000_INS02_F_RELATION],
                    [2000_INS03],
                    [2000_REF02_F_SUBSCRIBER_ID],
                    [2000_REF02_F_GROUP_ID],
                    [2100A_NM103_F_LAST_NAME],
                    [2100A_NM104_F_FIRST_NAME],
                    [2100A_NM105_F_MIDDLE_INIT],
                    [2100A_N301_F_ADDRESS_1],
                    [2100A_N302_F_ADDRESS_2],
                    [2100A_N401_F_CITY],
                    [2100A_N402_F_STATE],
                    [2100A_N403_F_ZIP],
                    [2100A_DMG02_F_BIRTH_DATE],
                    [2100A_DMG03_F_GENDER],
                    [2300_HD01],
                    [2300_HD03],
                    [2300_HD04_F_CSPI_ID],
                    [2300_DTP03_F_FROM_DATE],
                    [2300_DTP03_F_TERM_DATE],       
                    [2300_DTP03_F_GROUP_FROM_DATE], 
                    [2300_DTP03_F_GROUP_TERM_DATE] 
            FROM fabncdv1stage.dbo.tpzt_magellan_member_extr
            ORDER BY [2000_REF02_F_SUBSCRIBER_ID]
           
            
            /************* Error Checking for Selecting Staging table tpzt_magellan_member_extr *************/
        
            SELECT @lnRetCd    = @@ERROR,
                @lnRowsProcessed = @@ROWCOUNT

            IF @lnRetCd <> 0
                BEGIN
                    SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                    + ' : Selecting Staging table tpzt_magellan_member_extr FAILED'
                    + ' RETURNCODE: '
                    + CONVERT(CHAR(6),@lnRetCd)
                    PRINT  @lvcMsg
                    RETURN @lnRetCd
                END
                /**************  PRINT STEP 4 FOOTER DATA *************************/

           SELECT @ldtStepEndTime = GETDATE()

           EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
             @pdtStepStartTime    = @ldtStepStartTime,
             @pdtStepEndTime      = @ldtStepEndTime,
             @pdtProcessStartTime = @ldtProcessStartTime,
             @pnRowCount          = @lnRowsProcessed
   END 
        
END
GO
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_magellan_member_extr') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.tpzp_magellan_member_extr >>>'
ELSE
   PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_magellan_member_extr >>>'
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/ 