/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_usable_meme_extr') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.tpzp_usable_meme_extr
    IF OBJECT_ID('dbo.tpzp_usable_meme_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_usable_meme_extr >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_usable_meme_extr >>>'
END
GO
/****************************************************************  
** END MAINTENANCE WRAPPER.                                    **  
****************************************************************/  
  
CREATE PROCEDURE [dbo].[tpzp_usable_meme_extr]  
  
/****************************************************************  
**   NAME                  :   dbo.tpzp_usable_meme_extr 
**  
**  
**   PVCS LOCATION         :   Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Stored Procedures\Stage
**  
**   FUNCTION              :            : For MONTHLY:
**                           STEP 1: Truncate staging table fabncdv1stage.dbo.tpzt_usable_meme_extr
**                           STEP 2: Populating stage table fabncdv1stage.dbo.tpzt_usable_meme_extr with the monthly record
**                           
**                           
**                              
**  
**   PARAMETERS            :  
**                   INPUT :     
**                  OUTPUT :      
**  
**   RETURN CODES          :   0 on success  
**  
**   TABLES REFERENCED     :  
**                FACETS   : 
**                           fabncdv1.dbo.CMC_CSPI_CS_PLAN
**                           fabncdv1.dbo.CMC_GRGR_GROUP
**                           fabncdv1.dbo.CMC_SBSB_SUBSC   
**                FACETSXC :    N/A  
**                CUSTOM   :    N/A 
**                STAGE    : fabncdv1stage.dbo.tpzp_usable_meme_extr
**                           fabncdv1stage.dbo.tpzt_vend_ext_common_cw
**                                                         
**  
**   PROCEDURES REFERENCED :    N/A  
**                  FACETS :    N/A  
**                  CUSTOM :    N/A  
**  
**   STANDARD LOGGING PROCS:    harcore.dbo.harsp_gen_util_job_hdr_lgr  
**                              harcore.dbo.harsp_gen_util_job_ftr_lgr  
**                              harcore.dbo.harsp_gen_util_step_hdr_lgr  
**                              harcore.dbo.harsp_gen_util_step_ftr_lgr  
**  
** REVISION HISTORY        :  
** VERSION  DATE         DEVELOPER       DESCRIPTION  
** -------  ----------   -------------   -------------------  
** 1.0      08/05/2014   Shekhar Kadam    Initial version
 
****************************************************************/  

AS  
BEGIN 
  
   /****************************************************************  
   **          DECLARE LOCAL VARIABLES                            **  
   ****************************************************************/  
   DECLARE @lnRetCd                INT              -- Proc return code  
   DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field  
   DECLARE @lnCurrentStep          INT              -- Current Step Number  
   DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time  
   DECLARE @lnTotalSteps           INT              -- Total Steps In Proc  
   DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name  
   DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name  
   DECLARE @lvcDBName              VARCHAR(32)      -- DB Name  
   DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version  
   DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name  
   DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time  
   DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step  
   DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time  
   DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
   DECLARE @ldtLastRunDate         DATETIME         -- LastRunDate
                 
   
   /****************************************************************  
   **          INITIALIZE  VARIABLES                              **  
   ****************************************************************/  
    SELECT  @lnRetCd          = 0,  
            @lvcMsg           = NULL,  
            @lnCurrentStep    = 0,  
            @lnTotalSteps     = 2,  
            @ldtStepEndTime   = NULL,  
            @lvcVersionNum    = '1.0'  
     
    SELECT  @lvcServerName          = @@SERVERNAME,  
            @lvcDBName              = DB_NAME(),  
            @lvcUser                = USER_NAME(),  
            @lvcObjectName          = OBJECT_NAME(@@PROCID),  
            @ldtProcessStartTime    = GETDATE() 
              
        
    /****************************************************************  
   **               BEGIN PROCESS                                 **  
   *****************************************************************/  
      
    /**************  PRINT JOB HEADER DATA *************************/  
      
    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr  
        @pchObjectName        = @lvcObjectName,  
        @pdtProcessStartTime  = @ldtProcessStartTime,  
        @pchServerName        = @lvcServerName,  
        @pchDBName            = @lvcDBName,  
        @pchUserName          = @lvcUser,  
        @pchVersionNum        = @lvcVersionNum  
 
    /**************  PRINT STEP 1 HEADER DATA *************************/

         SELECT @lnCurrentStep = @lnCurrentStep + 1,
         @ldtStepStartTime    = GETDATE(),
         @lvcMsg              = @lvcObjectName + ': Truncate Staging table tpzp_usable_meme_extr'

          EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
          @pnStepNumber       = @lnCurrentStep,
          @pdtStepStartTime   = @ldtStepStartTime,
          @pnTotalSteps       = @lnTotalSteps,
          @pchStepMsg         = @lvcMsg  
         
    /********** STEP 1 Truncate staging table tpzt_usable_meme_extr**********/

    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_usable_meme_extr
           
    /************* Error Checking for Truncate Statement*************/          
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  
  
        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Truncate Staging table tpzt_usable_meme_extr_old FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END
            
    /**************  PRINT STEP 1 FOOTER DATA *************************/

         SELECT @ldtStepEndTime    = GETDATE()
         
         EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
          @pdtStepStartTime       = @ldtStepStartTime,
          @pdtStepEndTime         = @ldtStepEndTime,
          @pdtProcessStartTime    = @ldtProcessStartTime,
          @pnRowCount             = @lnRowsProcessed
         

    /**************  PRINT STEP 2 HEADER DATA *************************/

         SELECT @lnCurrentStep = @lnCurrentStep + 1,
         @ldtStepStartTime    = GETDATE(),
         @lvcMsg              = @lvcObjectName + ': Populating the Staging table tpzt_usable_meme_extr with the previous days record'
         
         EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
          @pnStepNumber       = @lnCurrentStep,
          @pdtStepStartTime   = @ldtStepStartTime,
          @pnTotalSteps       = @lnTotalSteps,
          @pchStepMsg         = @lvcMsg
          
    /************* STEP 2 Populating the Staging table tpzt_usable_meme_extr with the previous days record *************/  
          
       INSERT INTO fabncdv1stage.dbo.tpzt_usable_meme_extr
        (
				GRPNUM       ,
				METIND       ,
				MEMBNO       ,
				LSTNAM       ,
				FSTNAM       ,
				MIDNAM       ,
				BTHDAT       ,
				SEXCOD       ,
				SSN          ,
				SALARY       ,
				CLSCOD       ,
				LIFMTHPRM    ,
				ADDMTHPRM    ,
				DLIMTHPRM    ,
				WDBMTHPRM    ,
				LTDMTHPRM    ,
				SLIMTHPRM    ,
				SADMTHPRM    ,
				VLIFMTHPRM	,
				VADDMTHPRM   ,
				VSTDMTHPRM   ,
				VLTDMTHPRM	,
				CARCOD       ,
				LIFACTVOL    ,
				LIFRPERUT    ,
				LIFRATSRC    ,
				ADDACTVOL    ,
				ADDRPERUT    ,
				ADDRATSRC    ,
				DLIACTVOL    ,
				DLIRPERUT    ,
				DLIRATSRC    ,
				WDBACTVOL    ,
				WDBRPERUT    ,
				WDBRATSRC    ,
				LTDACTVOL    ,
				LTDRPERUT    ,
				LTDRATSRC    ,
				SLIACTVOL    ,
				SLIRPERUT    ,
				SLIRATSRC    ,
				SADACTVOL    ,
				SADRPERUT    ,
				SADRATSRC    ,
				VLIFACTVOL   ,
				VLIFRPERUT   ,
				VLIFRATSRC	,
				VADDACTVOL   ,
				VADDRPERUT	,
				VADDRATSRC	,
				VSTDACTVOL	,
				VSTDRPERUT	,
				VSTDRATSRC	,
				VLTDACTVOL	,
				VLTDRPERUT	,
				VLTDRATSRC	,
				PDTHRU       ,
				HIRDAT       ,
				AGE          ,
				ACCTNO       ,
				CLSEFFDAT    ,
				CLSEXPDAT    ,
				LIFEFFDAT    ,
				LIFEXPDAT    ,
				LIFREASCD    ,
				LIFLSTCHG    ,
				ADDEFFDAT    ,
				ADDEXPDAT    ,
				ADDREASCD    ,
				ADDLSTCHG    ,
				DLIEFFDAT    ,
				DLIEXPDAT    ,
				DLIREASCD    ,
				DLILSTCHG    ,
				WDBEFFDAT    ,
				WDBEXPDAT    ,
				WDBREASCD    ,
				WDBLSTCHG    ,
				LTDEFFDAT    ,
				LTDEXPDAT    ,
				LTDREASCD    ,
				LTDLSTCHG    ,
				SLIEFFDAT    ,
				SLIEXPDAT    ,
				SLIREASCD    ,
				SLILSTCHG    ,
				SADEFFDAT    ,
				SADEXPDAT    ,
				SADREASCD    ,
				SADLSTCHG    ,
				VLIFEFFDAT	,
				VLIFDEXPDAT	,
				VLIFREASCD	,
				VLIFLSTCHG	,
				VADDEFFDAT	,
				VADDDEXPDAT	,
				VADDREASCD	,
				VADDLSTCHG	,
				VSTDEFFDAT	,
				VSTDDEXPDAT	,
				VSTDREASCD	,
				VSTDLSTCHG	,
				VLTDEFFDAT	,
				VLTDDEXPDAT	,
				VLTDREASCD	,
				VLTDLSTCHG	
        )
      SELECT DISTINCT
        GRPNUM = CAST(LEFT(ISNULL(LTRIM(RTRIM(grgr.GRGR_ID)),''),8)AS CHAR(8)), --LEFT(SUBSTRING(LTRIM(RTRIM(grgr.GRGR_ID)),1,8) + SPACE(8),8),                      -- To be verified since power has 6 bytes
        METIND = space(1),
        MEMBNO = CAST(LEFT(ISNULL(LTRIM(RTRIM(sbsb.SBSB_ID)),''),12)AS CHAR(12)) , --LEFT(SUBSTRING(LTRIM(RTRIM(sbsb.SBSB_ID)),1,12) + SPACE(12),12), 
        LSTNAM = LEFT(SUBSTRING(LTRIM(RTRIM(comm.MEME_LAST_NAME)),1,15) + SPACE(15),15),
        FSTNAM = LEFT(SUBSTRING(LTRIM(RTRIM(comm.MEME_FIRST_NAME)),1,10) + SPACE(10),10),
        MIDNAM = LEFT(SUBSTRING(LTRIM(RTRIM(comm.MEME_MID_INIT)),1,1) + SPACE(1),1),
        BTHDAT = CAST(SUBSTRING(CONVERT(VARCHAR,comm.MEME_BIRTH_DT,112),1,1)+ SUBSTRING(convert(VARCHAR,comm.MEME_BIRTH_DT,112),3,6) AS varchar(7)), 
        SEXCOD = CAST(LEFT(ISNULL(LTRIM(RTRIM(comm.MEME_SEX)),''),1)AS CHAR(1)),
        SSN	   = CAST(LEFT(ISNULL(LTRIM(RTRIM(comm.MEME_SSN)),''),9)AS CHAR(9)),
        SALARY = RIGHT(REPLICATE('0', 9) + CAST(sbsa.SBSA_SAL_AMT AS VARCHAR) ,9),  --LIFMTHPRM = 'CNX', --CONVERT(VARCHAR(9),sbsa.SBSA_SAL_AMT),
        
        CLSCOD = CONVERT(VARCHAR(4),cspi.CSCS_ID),
        LIFMTHPRM = RIGHT(REPLICATE('0', 6) + CAST(CAST('3.50' AS NUMERIC(6,2)) AS VARCHAR) ,6),  --LIFMTHPRM = 'CNX',
        ADDMTHPRM = RIGHT(REPLICATE('0', 6) + CAST(CAST('.50' AS NUMERIC(6,2)) AS VARCHAR) ,6), --ADDMTHPRM = 'CNX',
        ADDMTHPRM = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.00' AS NUMERIC(6,2)) AS VARCHAR) ,6), --DLIMTHPRM ='CNX',
        ADDMTHPRM = RIGHT(REPLICATE('0', 6) + CAST(CAST('8.70' AS NUMERIC(6,2)) AS VARCHAR) ,6), --WDBMTHPRM ='CNX',
        ADDMTHPRM = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.00' AS NUMERIC(6,2)) AS VARCHAR) ,6), --LTDMTHPRM ='CNX',
        ADDMTHPRM = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.00' AS NUMERIC(6,2)) AS VARCHAR) ,6), --SLIMTHPRM ='CNX',
        ADDMTHPRM = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.00' AS NUMERIC(6,2)) AS VARCHAR) ,6), --SADMTHPRM ='CNX',
        VLIFMTHPRM = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.00' AS NUMERIC(6,2)) AS VARCHAR) ,6), --VOLUNTARY LIFE RATE
        VADDMTHPRM = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.00' AS NUMERIC(6,2)) AS VARCHAR) ,6), --VOLUNTARY ADD RATE
        VSTDMTHPRM = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.00' AS NUMERIC(6,2)) AS VARCHAR) ,6), --VOLUNTARY STD RATE
        VLTDMTHPRM = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.00' AS NUMERIC(6,2)) AS VARCHAR) ,6), --VOLUNTARY LID RATE
        CARCOD ='U ',
        LIFACTVOL = RIGHT(REPLICATE('0', 12) + CAST(CAST('10000.0000' AS NUMERIC(12,4)) AS VARCHAR) ,12), --LEFT(SUBSTRING(LTRIM(RTRIM(cspi.cspi_ID)),1,11) + SPACE(11),11),
		LIFRPERUT = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.35' AS NUMERIC(6,2)) AS VARCHAR) ,6), --'CNX',
		LIFRATSRC = 'C ',
		ADDACTVOL = RIGHT(REPLICATE('0', 12) + CAST(CAST('10000.0000' AS NUMERIC(12,4)) AS VARCHAR) ,12), --'CNX',
		ADDRPERUT = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.35' AS NUMERIC(6,2)) AS VARCHAR) ,6), --'CNX',
		ADDRATSRC = 'C ',
		DLIACTVOL = RIGHT(REPLICATE('0', 12) + CAST(CAST('10000.0000' AS NUMERIC(12,4)) AS VARCHAR) ,12), --'CNX', --'CNX',
		DLIRPERUT = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.35' AS NUMERIC(6,2)) AS VARCHAR) ,6), --'CNX',
		DLIRATSRC = 'C ',
		WDBACTVOL = RIGHT(REPLICATE('0', 12) + CAST(CAST('10000.0000' AS NUMERIC(12,4)) AS VARCHAR) ,12), --'CNX',
		WDBRPERUT = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.35' AS NUMERIC(6,2)) AS VARCHAR) ,6),  --'CNX',
		WDBRATSRC = 'C ',
		LTDACTVOL = RIGHT(REPLICATE('0', 12) + CAST(CAST('10000.0000' AS NUMERIC(12,4)) AS VARCHAR) ,12), --'CNX',
		LTDRPERUT = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.35' AS NUMERIC(6,2)) AS VARCHAR) ,6),  --'CNX',
		LTDRATSRC ='C ',
		SLIACTVOL = RIGHT(REPLICATE('0', 12) + CAST(CAST('10000.0000' AS NUMERIC(12,4)) AS VARCHAR) ,12), --'CNX',
		SLIRPERUT = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.35' AS NUMERIC(6,2)) AS VARCHAR) ,6),  --'CNX',
		SLIRATSRC ='C ',
		SADACTVOL = RIGHT(REPLICATE('0', 12) + CAST(CAST('10000.0000' AS NUMERIC(12,4)) AS VARCHAR) ,12), --'CNX',
		SADRPERUT = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.35' AS NUMERIC(6,2)) AS VARCHAR) ,6),  --'CNX',
		SADRATSRC ='C ',
		VLIFACTVOL = RIGHT(REPLICATE('0', 12) + CAST(CAST('10000.0000' AS NUMERIC(12,4)) AS VARCHAR) ,12), --'CNX',--BENEFIT AMOUNT FOR VOLUNTARY LIFE
        VLIFRPERUT = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.35' AS NUMERIC(6,2)) AS VARCHAR) ,6),  --'CNX',--BENEFIT RATE PER UNIT VOLUNTARY LIFE 
		VLIFRATSRC = 'C', --RATE METHOD FOR VOLUNTARY LIFE
		VADDACTVOL = RIGHT(REPLICATE('0', 12) + CAST(CAST('10000.0000' AS NUMERIC(12,4)) AS VARCHAR) ,12),--BENEFIT AMOUNT FOR VOLUNTARY ADD
		VADDRPERUT = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.35' AS NUMERIC(6,2)) AS VARCHAR) ,6),--BENEFIT RATE PER UNIT VOLUNTARY ADD
		VADDRATSRC = 'C ', --RATE METHOD FOR VOLUNTARY ADD
		VSTDACTVOL = RIGHT(REPLICATE('0', 12) + CAST(CAST('10000.0000' AS NUMERIC(12,4)) AS VARCHAR) ,12),--BENEFIT AMOUNT FOR VOLUNTARY STD
		VSTDRPERUT = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.35' AS NUMERIC(6,2)) AS VARCHAR) ,6), --BENEFIT RATE PER UNIT VOLUNTARY STD
		VSTDRATSRC = 'C ', --RATE METHOD FOR VOLUNTARY STD
		VLTDACTVOL = RIGHT(REPLICATE('0', 12) + CAST(CAST('10000.0000' AS NUMERIC(12,4)) AS VARCHAR) ,12),--BENEFIT AMOUNT FOR VOLUNTARY LTD
		VLTDRPERUT = RIGHT(REPLICATE('0', 6) + CAST(CAST('0.35' AS NUMERIC(6,2)) AS VARCHAR) ,6),--BENEFIT RATE PER UNIT VOLUNTARY LTD
		VLTDRATSRC = 'C ', --RATE METHOD FOR VOLUNTARY LTD
		PDTHRU =	CAST(SUBSTRING(CONVERT(VARCHAR,GETDATE(),112),1,1)+ SUBSTRING(CONVERT(VARCHAR,GETDATE(),112),3,6) AS DECIMAL(7)),--CONVERT(VARCHAR(7),GETDATE(),112),
		HIRDAT =	CAST(SUBSTRING(CONVERT(VARCHAR,sbsb.SBSB_HIRE_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,sbsb.SBSB_HIRE_DT,112),3,6) AS DECIMAL(7)),--CONVERT(VARCHAR(7),sbsb.SBSB_HIRE_DT,112), 
		AGE = '049' , --'CNX'
		ACCTNO = LEFT(SUBSTRING(LTRIM(RTRIM('000004A')),1,1) + SPACE(10),10), --'CNX',
		CLSEFFDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_EFF_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_EFF_DT,112),3,6) AS DECIMAL(7)), --'CNX',
		CLSEXPDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		LIFEFFDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		LIFEXPDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		LIFREASCD = SPACE(4),--'CNX',
		LIFLSTCHG = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		ADDEFFDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		ADDEXPDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		ADDREASCD = SPACE(4),--'CNX',
		ADDLSTCHG = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		DLIEFFDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		DLIEXPDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		DLIREASCD = SPACE(4),--'CNX',
		DLILSTCHG = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		WDBEFFDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		WDBEXPDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		WDBREASCD = SPACE(4),--'CNX',
		WDBLSTCHG = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		LTDEFFDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		LTDEXPDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		LTDREASCD = SPACE(4),--'CNX',
		LTDLSTCHG = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		SLIEFFDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		SLIEXPDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		SLIREASCD = SPACE(4),--'CNX',
		SLILSTCHG = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		SADEFFDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		SADEXPDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX',
		SADREASCD = SPACE(4),--'CNX',
		SADLSTCHG = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--'CNX'
		VLIFEFFDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)), --VOLUNTARY LIFE EFFECTIVE DATE
		VLIFDEXPDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--VOLUNTARY LIFE EXPIRATION DATE
		VLIFREASCD = SPACE(4),--VOLUNTARY LIFE TERMINATION REASON
		VLIFLSTCHG = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--VOLUNTARY LIFE LAST CHANGE DATE
		VADDEFFDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--VOLUNTARY ADD EFFECTIVE DATE
		VADDDEXPDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--VOLUNTARY ADD  EXPIRATION DATE
		VADDREASCD = SPACE(4), --VOLUNTARY ADD TERMINATION REASON
		VADDLSTCHG = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--VOLUNTARY ADD LAST CHANGE DATE
		VSTDEFFDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--VOLUNTARY STD EFFECTIVE DATE
		VSTDDEXPDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--VOLUNTARY STD EXPIRATION DATE
		VSTDREASCD = SPACE(4), --VOLUNTARY STD TERMINATION REASON
		VSTDLSTCHG = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--VOLUNTARY STD LAST CHANGE DATE
		VLTDEFFDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--VOLUNTARY LTD EFFECTIVE DATE
		VLTDDEXPDAT = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)),--VOLUNTARY LTD EXPIRATION DATE
		VLTDREASCD = SPACE(4),--VOLUNTARY LTD TERMINATION REASON
		VLTDLSTCHG = CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7))--VOLUNTARY LTD LAST CHANGE DATE

		FROM    fabncdv1stage.dbo.tpzt_comm_elig_extr comm
		INNER JOIN fabncdv1.dbo.CMC_SBSA_SALARY sbsa
		     ON comm.SBSB_CK = sbsa.SBSB_CK
		     --AND comm.SBSA_EFF_DT = sbsa.SBSA_EFF_DT
		INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr
		    ON  comm.GRGR_CK = grgr.GRGR_CK
	    INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb
 		    ON  comm.SBSB_CK = sbsb.SBSB_CK
 		INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi 
            ON cspi.GRGR_CK = comm.GRGR_CK  
            AND cspi.CSPD_CAT=comm.CSPD_CAT 
            AND cspi.CSPI_ID = comm.CSPI_ID
         
 		    --WHERE cspi.cspi_TERM_DT >= DATEADD(DD,1,CONVERT (VARCHAR(12),@ldtLastRunDate,110))
 		    --AND cspi.cspi_TERM_DT  > cspi.cspi_EFF_DT
			        
    /********** Error Checking for insert statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Populating data in stage table fabncdv1stage.dbo.tpzt_usable_meme_extr with present days record FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END
       /**************  PRINT STEP 2 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed  
END         
    
    /**************  PRINT JOB FOOTER DATA ****************************/  
  
   SELECT @ldtProcessEndTime = GETDATE() 
    
   EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr  
     @pchObjectName         = @lvcObjectName,  
     @pdtProcessStartTime   = @ldtProcessStartTime,  
     @pdtProcessEndTime     = @ldtProcessEndTime  
   RETURN  @lnRetCd 
  
GO
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_usable_meme_extr') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.tpzp_usable_meme_extr >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_usable_meme_extr>>>'
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/ 

                             
       
       
   
        
          
        
        
        
     
          
        
        
        
     