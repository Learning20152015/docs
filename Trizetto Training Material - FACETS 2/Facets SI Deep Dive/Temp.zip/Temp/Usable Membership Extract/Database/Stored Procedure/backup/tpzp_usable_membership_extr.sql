/***************************************************************
  BEGIN MAINTENANCE WRAPPER.
***************************************************************/

IF OBJECT_ID('dbo.tpzp_usable_membership_extr') IS NOT NULL
BEGIN
  DROP PROCEDURE dbo.tpzp_usable_membership_extr

  IF OBJECT_ID('dbo.tpzp_usable_membership_extr') IS NOT NULL
    PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_usable_membership_extr >>>'
  ELSE
    PRINT '<<< DROPPED PROCEDURE dbo.tpzp_usable_membership_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
***************************************************************/

CREATE PROCEDURE [dbo].[tpzp_usable_membership_extr]

/****************************************************************
**   NAME                  : dbo.tpzp_usable_membership_extr
**
**
**   PVCS LOCATION         : 
**
**   FUNCTION              : STEP 1 Truncating stage table fabncua1stage.dbo.tpzt_usable_membership_extr_new
**                           STEP 2 Obtaining Last Run Date from the custom table tpzt_last_rundate
**                           STEP 3 Populating stage table fabncua1stage.dbo.tpzt_usable_membership_extr_new with present days record
**                           STEP 4 Update staging table tpzt_usable_membership_extr_new for PDTHRU Column
**                           STEP 5 Update staging table tpzt_usable_membership_extr_new for EFF dates
**                           STEP 6 Update staging table tpzt_usable_membership_extr_new for EXP dates
**                           STEP 7 Updating stage table for monthly rates for various products
**                           STEP 8 Truncate Staging table tpzt_usable_membership_error
**                           STEP 9 Insert error records in staging table tpzt_usable_membership_error
**                           STEP 10 Truncating stage table fabncua1stage.dbo.tpzt_usable_membership_extr
**                           STEP 11 Inserting updated records in stage table fabncua1stage.dbo.tpzt_usable_membership_extr
**                           STEP 12 Updating LAST_RUN_DATE in table tpzt_last_rundate
**
**   PARAMETERS            :
**                   INPUT :
**                  OUTPUT :
**
**   RETURN CODES          : 0 on success
**
**   TABLES REFERENCED     :
**                FACETS   : fabncua1.dbo.CMC_SBSA_SALARY
**                           fabncua1.dbo.CMC_CSPI_CS_PLAN
**                           fabncua1.dbo.CMC_SBSR_SB_RATE
**                           fabncua1.dbo.CMC_SBCS_CLASS
**
**                FACETSXC : N/A
**                CUSTOM   : fabncua1custom.dbo.tpzt_last_rundate
**                           fabncua1custom.dbo.tpzt_usable_vltd
**                           fabncua1custom.dbo.tpzt_usable_vstd
**                           fabncua1custom.dbo.tpzt_usable_vadd
**                           fabncua1custom.dbo.tpzt_usable_vl
**                           fabncua1custom.dbo.tpzt_usable_ltd
**                           fabncua1custom.dbo.tpzt_usable_wdb
**                           fabncua1custom.dbo.tpzt_usable_dl
**                           fabncua1custom.dbo.tpzt_usable_gtl_add
**                STAGE    : 
**
**   PROCEDURES REFERENCED :
**                  FACETS :
**                  CUSTOM :
**   STANDARD LOGGING PROCS:
**                           harcore.dbo.harsp_gen_util_job_hdr_lgr
**                           harcore.dbo.harsp_gen_util_job_ftr_lgr
**                           harcore.dbo.harsp_gen_util_step_hdr_lgr
**                           harcore.dbo.harsp_gen_util_step_ftr_lgr
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0      08/20/2014    Ghazala Ameen      Initial Version
** 1.1      08/26/2014    Shekhar Kadam      Date format is updated from cyymmdd to ccyymmdd and field position is updated
** 1.2      08/27/2014    Ghazala Ameen      Updated field length
** 1.3      09/01/2014    Ghazala Ameen      Updated for EFFECTIVE, EXPIRY Dates
** 1.4      09/10/2014    Ghazala Ameen      Updated selection criteria for 12 months contion 
										     and updated monthly rates for various products
****************************************************************/
AS

BEGIN



/****************************************************************
**          DECLARE LOCAL VARIABLES                            **
****************************************************************/

    DECLARE @lnRetCd                INT              -- Proc return code
    DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time
    DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
    DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time
    DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time
    DECLARE @lnCurrentStep          INT              -- Current Step Number
    DECLARE @lnTotalSteps           INT              -- Total Steps In Proc
    DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field
    DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name
    DECLARE @lvcDBName              VARCHAR(32)      -- DB Name
    DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version
    DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name
    DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name
    DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step
    DECLARE @ldtLastRunDt           DATETIME         -- Last run date
    DECLARE @ldtCurrentDate         DATETIME         -- Current date

DECLARE @EffDate TABLE
    (
        GRGR_ID      VARCHAR(8),
        MEME_REL     VARCHAR(1),
        A            VARCHAR(8),
        B            VARCHAR(8),
        E            VARCHAR(8),
        K            VARCHAR(8),
        L            VARCHAR(8),
        S            VARCHAR(8),
        T            VARCHAR(8),
        X            VARCHAR(8),
        Y            VARCHAR(8),
        Z            VARCHAR(8),
        J            VARCHAR(8)
    )
    
    
    DECLARE @TermDate TABLE
    (
        GRGR_ID      VARCHAR(8),
        MEME_REL     VARCHAR(1),
        A            VARCHAR(8),
        B            VARCHAR(8),
        E            VARCHAR(8),
        K            VARCHAR(8),
        L            VARCHAR(8),
        S            VARCHAR(8),
        T            VARCHAR(8),
        X            VARCHAR(8),
        Y            VARCHAR(8),
        Z            VARCHAR(8),
        J            VARCHAR(8)
    )
 
	--DECLARE @RateAmt TABLE
 --   ( 
	--	CSPD_CAT		VARCHAR(1),
	--	GRGR_ID			VARCHAR(8),
	--	CSCS_ID			VARCHAR(4),
	--	SGSG_CK			VARCHAR(50),
	--	GRPNUM			VARCHAR(8),
	--	MEMBNO			VARCHAR(12),
	--	LIFMTHPRM		VARCHAR(20),
	--	ADDMTHPRM		VARCHAR(20),
	--	DLIMTHPRM		VARCHAR(20),
	--	WDBMTHPRM		VARCHAR(20),
	--	LTDMTHPRM		VARCHAR(20),
	--	SLIMTHPRM		VARCHAR(20),
	--	SADMTHPRM		VARCHAR(20),
	--	VSTDMTHPRM		VARCHAR(20),
	--	VLTDMTHPRM		VARCHAR(20),
	--	LIFACTVOL		VARCHAR(20),
	--	LIFRPERUT		VARCHAR(20),
	--	LIFRATSRC		VARCHAR(20),
	--	ADDACTVOL		VARCHAR(20),
	--	ADDRPERUT		VARCHAR(20),
	--	ADDRATSRC		VARCHAR(20),
	--	DLIACTVOL		VARCHAR(20),
	--	DLIRPERUT		VARCHAR(20),
	--	DLIRATSRC		VARCHAR(20),
	--	WDBACTVOL		VARCHAR(20),
	--	WDBRPERUT		VARCHAR(20),
	--	WDBRATSRC		VARCHAR(20),
	--	LTDACTVOL		VARCHAR(20),
	--	LTDRPERUT		VARCHAR(20),
	--	LTDRATSRC		VARCHAR(20),
	--	SLIACTVOL		VARCHAR(20),
	--	SLIRPERUT		VARCHAR(20),
	--	SLIRATSRC		VARCHAR(20),
	--	SADACTVOL		VARCHAR(20),
	--	SADRPERUT		VARCHAR(20),
	--	SADRATSRC		VARCHAR(20),
	--	VSTDACTVOL		VARCHAR(20),
	--	VSTDRPERUT		VARCHAR(20),
	--	VSTDRATSRC		VARCHAR(20),
	--	VLTDACTVOL		VARCHAR(20),
	--	VLTDRPERUT		VARCHAR(20),
	--	VLTDRATSRC		VARCHAR(20)
	--)

/****************************************************************
**          INITIALIZE  VARIABLES                              **
****************************************************************/



	DECLARE @CommnTable TABLE
    (
		MEME_CK			int,
		SBSB_CK			int,
		GRGR_CK			int,
		SGSG_CK			int,
		GRGR_ID			varchar(8),
        CSCS_ID			varchar(4),
        CSPI_ID			varchar(8),
        CSPD_CAT		varchar(1),
        MEMBNO			varchar(12),
        MEME_REL		varchar(1)
	)    
	

DECLARE @SBSRATE TABLE
    (
        GRGR_ID      VARCHAR(8),
        MEME_REL     VARCHAR(1),
        A            VARCHAR(8),
        --B            VARCHAR(8),
        E            VARCHAR(8),
        K            VARCHAR(8),
        L            VARCHAR(8),
        S            VARCHAR(8),
        T            VARCHAR(8),
        X            VARCHAR(8),
        Y            VARCHAR(8),
       -- Z            VARCHAR(8),
        J            VARCHAR(8)
    )
 
 DECLARE @SBSRATES_SUB TABLE
    (
        GRGR_ID      VARCHAR(8),
        MEME_REL     VARCHAR(1),
        B            VARCHAR(8),
        Z            VARCHAR(8)
        
    )   

 DECLARE @SBSRATES_DEP TABLE
    (
        GRGR_ID      VARCHAR(8),
        MEME_REL     VARCHAR(1),
        B            VARCHAR(8),
        Z            VARCHAR(8)
        
    )  


/****************************************************************
**          INITIALIZE  VARIABLES                              **
****************************************************************/
    

    SELECT @lnRetCd        = 0,
      @lvcMsg              = NULL,
      @lnCurrentStep       = 0,  
      @lnTotalSteps        = 11,
      @ldtStepEndTime      = NULL,
      @lvcVersionNum       = '1.4'

    SELECT @lvcServerName  = @@SERVERNAME,
      @lvcDBName           = DB_NAME(),
      @lvcUser             = USER_NAME(),
      @lvcObjectName       = OBJECT_NAME(@@PROCID),
      @ldtProcessStartTime = GETDATE(),
      @ldtCurrentDate      = CONVERT(VARCHAR (10), GETDATE(), 101)

/****************************************************************
**               BEGIN PROCESS                                 **
*****************************************************************/

/**************  PRINT JOB HEADER DATA *************************/

    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr
      @pchObjectName        = @lvcObjectName,
      @pdtProcessStartTime  = @ldtProcessStartTime,
      @pchServerName        = @lvcServerName,
      @pchDBName            = @lvcDBName,
      @pchUserName          = @lvcUser,
      @pchVersionNum        = @lvcVersionNum

/**************  PRINT STEP 1 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': fetching Last run date'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 1 fetching Last run date **********/
	
 SELECT @ldtLastRunDt =  LAST_RUN_DATE
    FROM fabncua1custom.dbo.tpzt_last_rundate
    WHERE INTERFACE_IDENTIFIER  = 'VE9006'
      AND INTERFACE_DESCRIPTION = 'USABLE_MEMBERSHIP'


/********** Error Checking for truncate statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Fetching Last run date FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 1 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed


/**************  PRINT STEP 2 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Fetching the data into common table'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 2 Fetching the data into common table  **********/

insert into @CommnTable
					(
						 MEME_CK,
						 SBSB_CK,
						 GRGR_CK,
						 SGSG_CK,
						 GRGR_ID,	
						 CSCS_ID,	
						 CSPI_ID,
						 CSPD_CAT,	
						 MEMBNO	,
						 MEME_REL
					 )
SELECT DISTINCT
		MEME_CK			=  meme.MEME_CK,
		SBSB_CK			= sbsb.SBSB_CK,
		GRGR_CK			=  grgr.GRGR_CK,
		SGSG_CK         =  sgsg.SGSG_CK,
        GRGR_ID			=  grgr.GRGR_ID,
        CSCS_ID			=  mepe.CSCS_ID,
        CSPI_ID         =  cspi.CSPI_ID,
        CSPD_CAT		=  cspi.CSPD_CAT,
        MEMBNO			=  sbsb.SBSB_ID,
        MEME_REL		=  meme.MEME_REL
 FROM  
		fabncua1.dbo.CMC_GRGR_GROUP grgr 
        INNER JOIN fabncua1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK    
        INNER JOIN fabncua1.dbo.CMC_SBSB_SUBSC sbsb ON sbsb.GRGR_CK = grgr.GRGR_CK 
        INNER JOIN fabncua1.dbo.CMC_MEME_MEMBER meme ON meme.SBSB_CK = sbsb.SBSB_CK
		INNER JOIN fabncua1.dbo.CMC_CSPI_CS_PLAN cspi ON cspi.GRGR_CK = grgr.GRGR_CK
		INNER JOIN fabncua1..CMC_SBCS_CLASS sbcs ON sbcs.SBSB_CK = sbsb.SBSB_CK
												AND sbcs.GRGR_CK = grgr.GRGR_CK
		INNER JOIN fabncua1.dbo.CMC_MEPE_PRCS_ELIG mepe ON meme.MEME_CK = mepe.MEME_CK
												AND sgsg.SGSG_CK = mepe.SGSG_CK
		LEFT JOIN fabncua1..CMC_SBSA_SALARY sbsa ON sbsb.SBSB_CK = sbsa.SBSB_CK
												AND grgr.GRGR_CK = sbsa.GRGR_CK
         
    WHERE cspi.CSPD_CAT IN ('X','Y','L','A','S','T','Z','B','E','K','J') 
        AND (cspi.CSPI_TERM_DT >= DATEADD(dd,1,@ldtLastRunDt)
        --AND (cspi.CSPI_TERM_DT >= DATEADD(dd,1,'2014-10-06 04:31:54.257')
        OR cspi.CSPI_TERM_DT > cspi.CSPI_EFF_DT
        OR CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112) > DATEADD(mm,-12,CONVERT(VARCHAR(8),GETDATE(),112)))
        

/********** Error Fetching the data into common table  ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Fetching the data into common table  FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 2 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount			  = @lnRowsProcessed



/**************  PRINT STEP 3 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Fetching the data into common table'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 3 Fetching the data into common table  **********/

TRUNCATE TABLE fabncua1stage.dbo.tpzt_usable_membership_extr_new  

/********** Error Fetching the data into common table  ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Fetching the data into common table FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 3 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount			  = @lnRowsProcessed



/**************  PRINT STEP 4 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': inserting data into membership table  '

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 4 inserting data into membership table   **********/

INSERT INTO fabncua1stage.dbo.tpzt_usable_membership_extr_new  
      (
        GRGR_ID,
        --GRGR_ID_OLD,
        CSCS_ID,
        --CSCS_ID_OLD,
        --CSPI_ID,
        SGSG_CK,
        GRPNUM,
		METIND,
        MEMBNO,
        LSTNAM,
        FSTNAM,
        MIDNAM,
        BTHDAT,
        SEXCOD,
        SSN   ,
        SALARY,
        CLSCOD,
		PDTHRU,
        HIRDAT,
        AGE   ,
        ACCTNO,
        CLSEFFDAT,
        CLSEXPDAT
      )   
   SELECT DISTINCT
        GRGR_ID       = LEFT(ISNULL(LTRIM(RTRIM(grgr.GRGR_ID)),'') + SPACE(8),8),
        CSCS_ID       = LEFT(ISNULL(LTRIM(RTRIM(mepe.CSCS_ID)),'') + SPACE(4),4),
        SGSG_CK       =  sgsg.SGSG_CK,
        GRPNUM        =  LEFT(ISNULL(LTRIM(RTRIM(grgr.GRGR_ID)),'') + SPACE(8),8),
		METIND		  = 'Y',
        MEMBNO        =  LEFT(ISNULL(LTRIM(RTRIM(sbsb.SBSB_ID)),'') + SPACE(12),12),
        LSTNAM        =  LEFT(SUBSTRING(LTRIM(RTRIM(ISNULL(meme.MEME_LAST_NAME,''))),1,15) + SPACE(15),15),
        FSTNAM        =  LEFT(SUBSTRING(LTRIM(RTRIM(ISNULL(meme.MEME_FIRST_NAME,''))),1,10) + SPACE(10),10),
        MIDNAM        =  LEFT(ISNULL(LTRIM(RTRIM(meme.MEME_MID_INIT)),'') + SPACE(1),1),
        BTHDAT        =  ISNULL(CONVERT(VARCHAR(8),meme.MEME_BIRTH_DT,112),'00000000'),
        SEXCOD        =  LEFT(ISNULL(LTRIM(RTRIM(meme.MEME_SEX)),'') + SPACE(1),1),
        SSN           =  LEFT(ISNULL(LTRIM(RTRIM(meme.MEME_SSN)),'') + SPACE(9),9),
        SALARY        =  RIGHT(REPLICATE('0', 9) + CAST(CAST(ISNULL(sbsa.SBSA_SAL_AMT,'0')AS NUMERIC(9,0)) AS VARCHAR(9)) ,9),
        CLSCOD        =  LEFT(ISNULL(LTRIM(RTRIM(mepe.CSCS_ID)),'') + SPACE(4),4),
		PDTHRU        =  ISNULL(CONVERT(VARCHAR(8),grgr.GRGR_ORIG_EFF_DT,112),'00000000'),
        HIRDAT        =  ISNULL(CONVERT(VARCHAR(8),sbsb.SBSB_HIRE_DT,112),'00000000'),
        AGE           =  RIGHT(REPLICATE('0',3) + CAST(ISNULL(DATEDIFF(yy, CONVERT(VARCHAR(8),meme.MEME_BIRTH_DT,112), CONVERT(VARCHAR(8),GETDATE(),112)),'   ')AS VARCHAR) ,3),
        ACCTNO        =  LEFT(SUBSTRING(LTRIM(RTRIM(ISNULL(sgsg.SGSG_ID,''))),1,10) + SPACE(10),10),
        CLSEFFDAT     =  ISNULL(CONVERT(VARCHAR(8),sbcs.SBCS_EFF_DT,112),'00000000'),
        CLSEXPDAT     =  ISNULL(CONVERT(VARCHAR(8),sbcs.SBCS_TERM_DT,112),'00000000')
		
		
    FROM  
		fabncua1.dbo.CMC_GRGR_GROUP grgr 
        INNER JOIN fabncua1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK    
        INNER JOIN fabncua1.dbo.CMC_SBSB_SUBSC sbsb ON sbsb.GRGR_CK = grgr.GRGR_CK 
        INNER JOIN fabncua1.dbo.CMC_MEME_MEMBER meme ON meme.SBSB_CK = sbsb.SBSB_CK
		INNER JOIN fabncua1.dbo.CMC_CSPI_CS_PLAN cspi ON cspi.GRGR_CK = grgr.GRGR_CK
		INNER JOIN fabncua1..CMC_SBCS_CLASS sbcs ON sbcs.SBSB_CK = sbsb.SBSB_CK
												AND sbcs.GRGR_CK = grgr.GRGR_CK
		INNER JOIN fabncua1.dbo.CMC_MEPE_PRCS_ELIG mepe ON meme.MEME_CK = mepe.MEME_CK
												AND sgsg.SGSG_CK = mepe.SGSG_CK
		LEFT JOIN fabncua1..CMC_SBSA_SALARY sbsa ON sbsb.SBSB_CK = sbsa.SBSB_CK
												AND grgr.GRGR_CK = sbsa.GRGR_CK
		--LEFT join fabncua1..CMC_SBSR_SB_RATE sbsr on sbsr.SBSB_CK = sbsb.SBSB_CK
         
    WHERE cspi.CSPD_CAT IN ('X','Y','L','A','S','T','Z','B','E','K','J') 
        AND (cspi.CSPI_TERM_DT >= DATEADD(dd,1,@ldtLastRunDt)
       -- AND (cspi.CSPI_TERM_DT >= DATEADD(dd,1,'2014-10-06 04:31:54.257')
        OR cspi.CSPI_TERM_DT > cspi.CSPI_EFF_DT
        OR CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112) > DATEADD(mm,-12,CONVERT(VARCHAR(8),GETDATE(),112)))


/********** Error inserting data into membership table   ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : inserting data into membership table  FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 4 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount			  = @lnRowsProcessed
      
---------------------sbsr rate--------------------------------------------------------------------------------------------------------------------------------------------

/**************  PRINT STEP 5 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ':updating rate field for all the product list '

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 5 updating rate field for all the product list  **********/


INSERT INTO @SBSRATE 
        SELECT GRGR_ID,MEME_REL, A = ISNULL(A,'00000000'),
								 E =ISNULL(E,'00000000'),
								 K =ISNULL(K,'00000000'),
								 L =ISNULL(L,'00000000'),
								 S=ISNULL(S,'00000000'),
								 T=ISNULL(T,'00000000'),
								 X=ISNULL(X,'00000000'),
								 Y=ISNULL(Y,'00000000'),
								 J =ISNULL(J,'00000000')
        FROM
           (
                SELECT DISTINCT
							GRGR_ID = comm.GRGR_ID,  
							CSPDCAT =comm.CSPD_CAT, 
							MEME_REL = comm.MEME_REL,
							SBSR_RATE = ISNULL(sbsr.SBSR_PREM_SB,0)
                FROM  @CommnTable comm   
							left  join fabncua1.dbo.CMC_SBSR_SB_RATE sbsr on  comm.SBSB_CK = sbsr.SBSB_CK 
																		   and comm.CSPI_ID= sbsr.PDPD_ID
				where  comm.CSPD_CAT IN ('X','Y','L','A','S','T','E','K','J')    
				and comm.MEME_REL ='M'
            )d
            pivot
            (
				max(SBSR_RATE)
				for CSPDCAT in (A,E,K,L,S,T,X,Y,J)
            ) AS piv

--select * from @SBSRATE

 UPDATE extr
    SET LIFMTHPRM = L, ADDMTHPRM = A, DLIMTHPRM = T, WDBMTHPRM = X, LTDMTHPRM = Y , SLIMTHPRM = S, SADMTHPRM = E,
         VSTDMTHPRM = K, VLTDMTHPRM = J
    FROM fabncua1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @SBSRATE SBSR 
    ON SBSR.GRGR_ID = extr.GRGR_ID
    
    

INSERT INTO @SBSRATES_SUB 
        SELECT GRGR_ID,MEME_REL, 
				B = ISNULL(B,'00000000'),
				Z = ISNULL(Z,'00000000')
        FROM
           (
                SELECT DISTINCT
                GRGR_ID = comm.GRGR_ID,  
                CSPDCAT =comm.CSPD_CAT, 
                MEME_REL = comm.MEME_REL,
                SBSR_RATE = isnull(sbsr.SBSR_PREM_SB,0)
             
                FROM  @CommnTable comm   
							left  join fabncua1.dbo.CMC_SBSR_SB_RATE sbsr on  comm.SBSB_CK = sbsr.SBSB_CK 
																			and comm.CSPI_ID = sbsr.PDPD_ID
				where  comm.CSPD_CAT IN ('B','Z')    
				and comm.MEME_REL = 'M'
            )d
            pivot
            (
				max(SBSR_RATE)
				for CSPDCAT in (B,Z)
            ) AS piv
            

    UPDATE extr
    SET VLIFMTHPRM = Z,VADDMTHPRM = B
    FROM fabncua1stage.dbo.tpzt_usable_membership_extr_new extr
     INNER JOIN @SBSRATES_SUB SBSR      ON SBSR.GRGR_ID = extr.GRGR_ID

  
  
INSERT INTO @SBSRATES_DEP 
                 SELECT GRGR_ID,MEME_REL, 
				B = ISNULL(B,'00000000'),
				Z = ISNULL(Z,'00000000')
        FROM
           (
                SELECT DISTINCT
							GRGR_ID = comm.GRGR_ID,  
							CSPDCAT =comm.CSPD_CAT, 
							MEME_REL = comm.MEME_REL,
							SBSR_RATE = isnull(sbsr.SBSR_PREM_SB,0)
                FROM  @CommnTable comm   
							left  join fabncua1.dbo.CMC_SBSR_SB_RATE sbsr on  comm.SBSB_CK = sbsr.SBSB_CK 
																			and comm.CSPI_ID = sbsr.PDPD_ID
				where  comm.CSPD_CAT IN ('B','Z')    
				and  comm.MEME_REL IN ('S','D','H','W')   
            )d
            pivot
            (
				max(SBSR_RATE)
				for CSPDCAT in (B,Z)
            ) AS piv
  
  


    UPDATE extr
    SET VLIFCHMTHPRM = Z,VADDCHMTHPRM = B
    FROM fabncua1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @SBSRATES_DEP SBSR ON SBSR.GRGR_ID = extr.GRGR_ID
    AND SBSR.MEME_REL IN ('S','D')
    
    
     UPDATE extr
    SET VLIFSPMTHPRM = Z,VADDSPMTHPRM = B
    FROM fabncua1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @SBSRATES_DEP SBSR ON SBSR.GRGR_ID = extr.GRGR_ID
    AND SBSR.MEME_REL IN ('H','W')          


/********** Error updating rate field for all the product list   ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Updating rate field for all the product list FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 5 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount			  = @lnRowsProcessed
      

---------------------sbsr rate END --------------------------------------------------------------------------------------------------------------------------------------------

/**************  PRINT STEP 6 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': updating Paid Thru Date '

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 6 updating Paid Thru Date  **********/

          
     UPDATE  new
     SET new.PDTHRU = ISNULL(CONVERT(VARCHAR(8), blbe.BLBL_END_DT,112),'00000000')
     FROM fabncua1stage.dbo.tpzt_usable_membership_extr_new new
       JOIN
           ( SELECT blei.BLEI_CK,blei.BLEI_BILL_LEVEL_CK, MAX(blbl.BLBL_END_DT) AS BLBL_END_DT 
                    FROM fabncua1.dbo.CMC_BLBL_BILL_SUMM blbl
                            inner join fabncua1.dbo.CMC_BLEI_ENTY_INFO blei on blei.BLEI_CK = blbl.BLEI_CK
                            
                 WHERE  blbl.BLBL_PAID_STS in (2,3)
                 GROUP BY blei.BLEI_CK,blei.BLEI_BILL_LEVEL_CK) as blbe
                 ON blbe.BLEI_BILL_LEVEL_CK = new.SGSG_CK


/********** Error  updating Paid Thru Date  ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : updating Paid Thru Date FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 6 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount			  = @lnRowsProcessed
      


/**************  PRINT STEP 7 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': updating the effective date  '

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 7 updating the effective date **********/

INSERT INTO @EffDate 
        SELECT GRGR_ID,MEME_REL, A = ISNULL(A,'00000000'),B = ISNULL(B,'00000000'),E =ISNULL(E,'00000000'),K =ISNULL(K,'00000000'),L =ISNULL(L,'00000000'),S=ISNULL(S,'00000000'),T=ISNULL(T,'00000000'),X=ISNULL(X,'00000000'),Y=ISNULL(Y,'00000000'),Z=ISNULL(Z,'00000000'),J =ISNULL(J,'00000000')
        FROM
                (
                SELECT DISTINCT
                GRGR_ID = comm.GRGR_ID,  
                CSPDCAT =comm.CSPD_CAT,
                MEME_REL = comm.MEME_REL,
                DATEt     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(mepe1.MEPE_EFF_DT),112)    
                                                FROM  fabncua1.dbo.CMC_MEPE_PRCS_ELIG mepe1
                                                     WHERE comm.SGSG_CK = mepe1.SGSG_CK
                                                     AND comm.GRGR_CK = mepe1.GRGR_CK  
                                                     AND  comm.CSPD_CAT IN ('X','Y','L','A','S','T','Z','B','E','K','J')   
                                                     AND  mepe1.MEPE_ELIG_IND = 'Y'    
                                             ),'00000000')
                FROM  @CommnTable comm    
            )d
            pivot
            (
            max(DATEt)
            for CSPDCAT in (A,B,E,K,L,S,T,X,Y,Z,J)
            ) AS piv
            

 UPDATE extr
    SET LIFEFFDAT = L, ADDEFFDAT = A, DLIEFFDAT = T, WDBEFFDAT = X, LTDEFFDAT = Y , SLIEFFDAT = S, SADEFFDAT = E,
         VSTDEFFDAT = K, VLTDEFFDAT = J
    FROM fabncua1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @EffDate EFDT --CTE
    ON EFDT.GRGR_ID = extr.GRGR_ID
    
    UPDATE extr
    SET VLIFEFFDAT = Z,VADDEFFDAT = B
    FROM fabncua1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @EffDate EFDT --CTE
    ON  EFDT.GRGR_ID = extr.GRGR_ID
    AND EFDT.MEME_REL = 'M'

    UPDATE extr
    SET VLIFEFFDAT_SPOUSE = Z,VADDSPEFFDAT = B
    FROM fabncua1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @EffDate EFTE -- CTE
    ON EFTE.GRGR_ID = extr.GRGR_ID
    AND EFTE.MEME_REL IN ('H','W')

    UPDATE extr
    SET VLIFEFFDAT_CHILD = Z,VADDCHEFFDAT = B
    FROM fabncua1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @EffDate EFTE  --CTE
    ON EFTE.GRGR_ID = extr.GRGR_ID
    AND EFTE.MEME_REL IN ('S','D')          
    



 INSERT INTO @TermDate
    SELECT GRGR_ID,MEME_REL,A = ISNULL(A,'00000000'),B = ISNULL(B,'00000000'),E =ISNULL(E,'00000000'),K =ISNULL(K,'00000000'),L =ISNULL(L,'00000000'),S=ISNULL(S,'00000000'),T=ISNULL(T,'00000000'),X=ISNULL(X,'00000000'),Y=ISNULL(Y,'00000000'),Z=ISNULL(Z,'00000000'),J =ISNULL(J,'00000000')
        FROM
                (
                SELECT DISTINCT
                GRGR_ID = comm.GRGR_ID,  
                CSPDCAT =comm.CSPD_CAT,
                MEME_REL = comm.MEME_REL,
                DATEt     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(mepe1.MEPE_TERM_DT),112)    
                                                 FROM  fabncua1.dbo.CMC_MEPE_PRCS_ELIG mepe1
                                                     WHERE comm.SGSG_CK = mepe1.SGSG_CK
                                                     AND comm.GRGR_CK = mepe1.GRGR_CK  
													 AND mepe1.MEME_CK = comm.MEME_CK   
                                                     AND  comm.CSPD_CAT IN ('X','Y','L','A','S','T','Z','B','E','K','J')   
                                                     AND  mepe1.MEPE_ELIG_IND = 'Y'    
                                             ),'00000000')
                                   
                FROM  @CommnTable comm   
            )d
            pivot
            (
            max(DATEt)
            for CSPDCAT in (A,B,E,K,L,S,T,X,Y,Z,J)
            ) AS piv
        
    UPDATE extr
    SET LIFEXPDAT = L, ADDEXPDAT = A, DLIEXPDAT = T, WDBEXPDAT = X, LTDEXPDAT = Y , SLIEXPDAT = S, SADEXPDAT = E,
         VSTDDEXPDAT = K, VLTDDEXPDAT = J
    FROM fabncua1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @TermDate TEDT--CTE
    ON TEDT.GRGR_ID = extr.GRGR_ID

    UPDATE extr
    SET VLIFDEXPDAT = Z,VADDEXPDAT = B
    FROM fabncua1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @TermDate TEDT --CTE
    ON TEDT.GRGR_ID = extr.GRGR_ID
    AND TEDT.MEME_REL = 'M'

    UPDATE extr
    SET VLIFDEXPDAT_SPOUSE = Z,VADDSPEXPDAT = B
    FROM fabncua1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @TermDate TEDT --CTE
    ON TEDT.GRGR_ID = extr.GRGR_ID
    AND TEDT.MEME_REL IN ('H','W')

    UPDATE extr
    SET VLIFDEXPDAT_CHILD = Z,VADDCHEXPDAT = B
    FROM fabncua1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @TermDate TEDT 
    ON TEDT.GRGR_ID = extr.GRGR_ID
    AND TEDT.MEME_REL IN ('S','D')


/********** Error updating the effective date   ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : updating the effective date FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 7 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount			  = @lnRowsProcessed


/**************  PRINT STEP 8 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Update Benefit Amount, Benefit Rate per Unit and Rate Methods for Life '

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 8 update Benefit Amount, Benefit Rate per Unit and Rate Methods for Life  **********/


update new
	set	new.LIFACTVOL = (select distinct isnull(gtl.BENEFIT_AMOUNT,0) 
							from fabncua1custom.dbo.tpzt_usable_gtl_add gtl 
								where  gtl.GRGR_ID = new.GRGR_ID  
								and substring(gtl.CSPI_ID,2,1) = 'L'
						),
		new.LIFRPERUT = (select distinct isnull(gtl.BENEFIT_RATE_PER_UNIT,0) 
							from fabncua1custom.dbo.tpzt_usable_gtl_add gtl 
								where  gtl.GRGR_ID = new.GRGR_ID  
								and substring(gtl.CSPI_ID,2,1) = 'L'
						), 
		new.LIFRATSRC = (select distinct isnull(gtl.BENEFIT_TYPE,'') 
							from fabncua1custom.dbo.tpzt_usable_gtl_add gtl 
								where  gtl.GRGR_ID = new.GRGR_ID  
								and substring(gtl.CSPI_ID,2,1) = 'L'
						),
						
		new.ADDACTVOL = (select distinct isnull(gtl.BENEFIT_AMOUNT,0) 
							from fabncua1custom.dbo.tpzt_usable_gtl_add gtl 
								where  gtl.GRGR_ID = new.GRGR_ID  
								and substring(gtl.CSPI_ID,2,1) = 'A'
						), 
		new.ADDRPERUT = (select distinct isnull(gtl.BENEFIT_RATE_PER_UNIT,0) 
							from fabncua1custom.dbo.tpzt_usable_gtl_add gtl 
								where  gtl.GRGR_ID = new.GRGR_ID  
								and substring(gtl.CSPI_ID,2,1) = 'A'
						),
		new.ADDRATSRC = (select distinct isnull(gtl.BENEFIT_TYPE ,'')
							from fabncua1custom.dbo.tpzt_usable_gtl_add gtl 
								where  gtl.GRGR_ID = new.GRGR_ID  
								and substring(gtl.CSPI_ID,2,1) = 'A'
						),
	   
	    new.DLIACTVOL	=  (select distinct isnull(dl.[PLAN],0)
							from fabncua1custom.dbo.tpzt_usable_dl dl
								where dl.GRGR_ID = new.GRGR_ID  
								and substring(dl.CSPI_ID,2,1) = 'T'
						),
		new.DLIRPERUT =  (select distinct isnull(dl.BENEFIT_RATE_PER_UNIT,0)
							from fabncua1custom.dbo.tpzt_usable_dl dl
								where dl.GRGR_ID = new.GRGR_ID  
								and substring(dl.CSPI_ID,2,1) = 'T'
						),
		new.DLIRATSRC  = (select distinct 'C'
							from fabncua1custom.dbo.tpzt_usable_dl dl
								where dl.GRGR_ID = new.GRGR_ID  
								and substring(dl.CSPI_ID,2,1) = 'T'
						),
		new.WDBACTVOL	= (select distinct isnull(wdb.BENEFIT_AMOUNT,0)
							from fabncua1custom.dbo.tpzt_usable_wdb wdb
								where wdb.GRGR_ID = new.GRGR_ID  
								and substring(wdb.CSPI_ID,2,1) = 'X'
						),
		new.WDBRPERUT	= (select distinct isnull(wdb.BENEFIT_PERCENTAGE,0)
							from fabncua1custom.dbo.tpzt_usable_wdb wdb
								where wdb.GRGR_ID = new.GRGR_ID  
								and substring(wdb.CSPI_ID,2,1) = 'X'
						),
		new.WDBRATSRC	= (select distinct case when isnull(upper(wdb.BENEFIT_TYPE),'') = 'FLAT'
													then 'F'
												when isnull(upper(wdb.BENEFIT_TYPE),'') = 'SALARY'
													then 'S'
												else ''
											end
												
							from fabncua1custom.dbo.tpzt_usable_wdb wdb
								where wdb.GRGR_ID = new.GRGR_ID  
								and substring(wdb.CSPI_ID,2,1) = 'X'
						),
	 
	    new.LTDACTVOL	= (select distinct isnull(ltd.MONTHLY_MAXIMUM,0)
							from fabncua1custom.dbo.tpzt_usable_ltd ltd
								where ltd.GRGR_ID = new.GRGR_ID  
								and substring(ltd.CSPI_ID,2,1) = 'Y'
						),
		new.LTDRPERUT	= (select distinct isnull(ltd.BENEFIT_RATE_PER_UNIT,0)
							from fabncua1custom.dbo.tpzt_usable_ltd ltd
								where ltd.GRGR_ID = new.GRGR_ID  
								and substring(ltd.CSPI_ID,2,1) = 'Y'
						),
		new.LTDRATSRC	= (select distinct 'S'
							from fabncua1custom.dbo.tpzt_usable_ltd ltd
								where ltd.GRGR_ID = new.GRGR_ID  
								and substring(ltd.CSPI_ID,2,1) = 'Y'
						),
		
		new.SLIACTVOL	= (select distinct sli.BENEFIT_AMOUNT
							from fabncua1custom.dbo.tpzt_usable_sli sli
								where sli.GRGR_ID = new.GRGR_ID  
								and substring(sli.CSPI_ID,2,1) = 'S'
						),
		new.SLIRPERUT	=  (select distinct sli.BENEFIT_RATE_PER_UNIT
							from fabncua1custom.dbo.tpzt_usable_sli sli
								where sli.GRGR_ID = new.GRGR_ID  
								and substring(sli.CSPI_ID,2,1) = 'S'
						),
		new.SLIRATSRC	=  (select distinct sli.BENEFIT_TYPE
							from fabncua1custom.dbo.tpzt_usable_sli sli
								where sli.GRGR_ID = new.GRGR_ID  
								and substring(sli.CSPI_ID,2,1) = 'S'
						),
		
		new.SADACTVOL	= (select distinct sad.BENEFIT_AMOUNT
							from fabncua1custom.dbo.tpzt_usable_sad sad
								where sad.GRGR_ID = new.GRGR_ID  
								and substring(sad.CSPI_ID,2,1) = 'E'
						),
		new.SADRPERUT	= (select distinct sad.BENEFIT_RATE_PER_UNIT
							from fabncua1custom.dbo.tpzt_usable_sad sad
								where sad.GRGR_ID = new.GRGR_ID  
								and substring(sad.CSPI_ID,2,1) = 'E'
						),
		new.SADRATSRC	= (select distinct sad.BENEFIT_TYPE
							from fabncua1custom.dbo.tpzt_usable_sad sad
								where sad.GRGR_ID = new.GRGR_ID  
								and substring(sad.CSPI_ID,2,1) = 'E'
						),
		
		new.VLIFACTVOL	= (select distinct vl.BENEFIT_AMOUNT
							from fabncua1custom.dbo.tpzt_usable_vl vl
								where vl.GRGR_ID = new.GRGR_ID  
								and substring(vl.CSPI_ID,2,1) = 'Z'
						),
		new.VLIFRPERUT	= (select distinct vl.BENEFIT_RATE_PER_UNIT
							from fabncua1custom.dbo.tpzt_usable_vl vl
								where vl.GRGR_ID = new.GRGR_ID  
								and substring(vl.CSPI_ID,2,1) = 'Z'
						),
		new.VLIFRATSRC	= (select distinct case when vl.BENEFIT_AMOUNT <> 0
										then  'F'
									when isnull(vl.TIMES_SALARY,'') <> ''
										then 'S'
								end
							from fabncua1custom.dbo.tpzt_usable_vl vl
								where vl.GRGR_ID = new.GRGR_ID  
								and substring(vl.CSPI_ID,2,1) = 'Z'
						),

		new.VLIFSPACTVOL	= (select distinct vl.SPOUSE_AMOUNT
							from fabncua1custom.dbo.tpzt_usable_vl vl
								where vl.GRGR_ID = new.GRGR_ID  
								and substring(vl.CSPI_ID,2,1) = 'Z'
						),
		new.VLIFSPRPERUT	= (select distinct vl.BENEFIT_RATE_PER_UNIT
							from fabncua1custom.dbo.tpzt_usable_vl vl
								where vl.GRGR_ID = new.GRGR_ID  
								and substring(vl.CSPI_ID,2,1) = 'Z'
						),
		new.VLIFSPRATSRC	= (select distinct case when vl.BENEFIT_AMOUNT <> 0
										then  'F'
									when isnull(vl.TIMES_SALARY,'') <> ''
										then 'S'
								end
							from fabncua1custom.dbo.tpzt_usable_vl vl
								where vl.GRGR_ID = new.GRGR_ID  
								and substring(vl.CSPI_ID,2,1) = 'Z'
						),

		new.VLIFCHACTVOL = (select distinct vl.DEPENDANT_CHILD_COVERAGE
							from fabncua1custom.dbo.tpzt_usable_vl vl
								where vl.GRGR_ID = new.GRGR_ID  
								and substring(vl.CSPI_ID,2,1) = 'Z'
						),
		new.VLIFCHRPERUT = (select distinct vl.BENEFIT_RATE_PER_UNIT
							from fabncua1custom.dbo.tpzt_usable_vl vl
								where vl.GRGR_ID = new.GRGR_ID  
								and substring(vl.CSPI_ID,2,1) = 'Z'
						), 
		new.VLIFCHRATSRC = (select distinct case when vl.BENEFIT_AMOUNT <> 0
										then  'F'
									when isnull(vl.TIMES_SALARY,'') <> ''
										then 'S'
								end
							from fabncua1custom.dbo.tpzt_usable_vl vl
								where vl.GRGR_ID = new.GRGR_ID  
								and substring(vl.CSPI_ID,2,1) = 'Z'
						),
						
		new.VADDACTVOL	= (select distinct vadd.BENEFIT_AMOUNT
							from fabncua1custom.dbo.tpzt_usable_vadd vadd
								where vadd.GRGR_ID = new.GRGR_ID  
								and substring(vadd.CSPI_ID,2,1) = 'B'
						),
		new.VADDRPERUT	= (select distinct vadd.BENEFIT_RATE_PER_UNIT
							from fabncua1custom.dbo.tpzt_usable_vadd vadd
								where vadd.GRGR_ID = new.GRGR_ID  
								and substring(vadd.CSPI_ID,2,1) = 'B'
						),
		new.VADDRATSRC	= (select distinct case when vadd.BENEFIT_AMOUNT <> 0
										then  'F'
									when isnull(vadd.TIMES_SALARY,'') <> ''
										then 'S'
								end
							from fabncua1custom.dbo.tpzt_usable_vadd vadd
								where vadd.GRGR_ID = new.GRGR_ID  
								and substring(vadd.CSPI_ID,2,1) = 'B'
						),
						
		
		new.VADDSPACTVOL	= (select distinct vadd.SPOUSE_AMOUNT
							from fabncua1custom.dbo.tpzt_usable_vadd vadd
								where vadd.GRGR_ID = new.GRGR_ID  
								and substring(vadd.CSPI_ID,2,1) = 'B'
						),
		new.VADDSPRPERUT	= (select distinct vadd.BENEFIT_RATE_PER_UNIT
							from fabncua1custom.dbo.tpzt_usable_vadd vadd
								where vadd.GRGR_ID = new.GRGR_ID  
								and substring(vadd.CSPI_ID,2,1) = 'B'
						),
		new.VADDSPRATSRC	= (select distinct case when vadd.BENEFIT_AMOUNT <> 0
										then  'F'
									when isnull(vadd.TIMES_SALARY,'') <> ''
										then 'S'
								end
							from fabncua1custom.dbo.tpzt_usable_vadd vadd
								where vadd.GRGR_ID = new.GRGR_ID  
								and substring(vadd.CSPI_ID,2,1) = 'B'
						),
		new.VADDCHACTVOL	= (select distinct vadd.DEP_CHILD_COVERAGE
							from fabncua1custom.dbo.tpzt_usable_vadd vadd
								where vadd.GRGR_ID = new.GRGR_ID  
								and substring(vadd.CSPI_ID,2,1) = 'B'
						),
		new.VADDCHRPERUT	= (select distinct vadd.BENEFIT_RATE_PER_UNIT
							from fabncua1custom.dbo.tpzt_usable_vadd vadd
								where vadd.GRGR_ID = new.GRGR_ID  
								and substring(vadd.CSPI_ID,2,1) = 'B'
						),
		new.VADDCHRATSRC	= (select distinct case when vadd.BENEFIT_AMOUNT <> 0
										then  'F'
									when isnull(vadd.TIMES_SALARY,'') <> ''
										then 'S'
								end
							from fabncua1custom.dbo.tpzt_usable_vadd vadd
								where vadd.GRGR_ID = new.GRGR_ID  
								and substring(vadd.CSPI_ID,2,1) = 'B'
						),

		new.VSTDACTVOL	= (select distinct vstd.MAX_WEEKLY_BENEFIT
							from fabncua1custom.dbo.tpzt_usable_vstd vstd
								where vstd.GRGR_ID = new.GRGR_ID  
								and substring(vstd.CSPI_ID,2,1) = 'K'
						),
		new.VSTDRPERUT	= (select distinct vstd.BENEFIT_RATE_PER_UNIT
							from fabncua1custom.dbo.tpzt_usable_vstd vstd
								where vstd.GRGR_ID = new.GRGR_ID  
								and substring(vstd.CSPI_ID,2,1) = 'K'
						),
		new.VSTDRATSRC	= (select distinct case when isnull(upper(vstd.BENEFIT_TYPE),'')= 'FLAT'
													then 'F'
												when isnull(upper(vstd.BENEFIT_TYPE),'')= 'SALARY'
													then 'S'
											end
							from fabncua1custom.dbo.tpzt_usable_vstd vstd
								where vstd.GRGR_ID = new.GRGR_ID  
								and substring(vstd.CSPI_ID,2,1) = 'K'
						),
		new.VLTDACTVOL	=  (select distinct vltd.MAXIMUM_AMOUNT
							from fabncua1custom.dbo.tpzt_usable_vltd vltd
								where vltd.GRGR_ID = new.GRGR_ID  
								and substring(vltd.CSPI_ID,2,1) = 'Y'
						),
		new.VLTDRPERUT	= (select distinct vltd.BENEFIT_RATE_PER_UNIT
							from fabncua1custom.dbo.tpzt_usable_vltd vltd
								where vltd.GRGR_ID = new.GRGR_ID  
								and substring(vltd.CSPI_ID,2,1) = 'Y'
						),
		new.VLTDRATSRC	= (select distinct vltd.BENEFIT_TYPE
							from fabncua1custom.dbo.tpzt_usable_vltd vltd
								where vltd.GRGR_ID = new.GRGR_ID  
								and substring(vltd.CSPI_ID,2,1) = 'Y'
						)
 from fabncua1stage.dbo.tpzt_usable_membership_extr_new new
 

/********** Error Update Benefit Amount, Benefit Rate per Unit and Rate Methods for Life  ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Update Benefit Amount, Benefit Rate per Unit and Rate Methods for Life FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 5 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount			  = @lnRowsProcessed

/**************  PRINT STEP 6 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime      = GETDATE(),
      @lvcMsg                = @lvcObjectName + ': Updating LAST_RUN_DATE in table tpzt_last_rundate'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 6 Updating LAST_RUN_DATE in table tpzt_last_rundate **********/
   
     UPDATE fabncua1custom.dbo.tpzt_last_rundate
      SET LAST_RUN_DATE = GETDATE()
      WHERE INTERFACE_IDENTIFIER  = 'VE9006'
      AND INTERFACE_DESCRIPTION   = 'USABLE_MEMBERSHIP'
      
/********** Error checking for Updating LAST_RUN_DATE in table tpzt_last_rundate ***********/
    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT

    IF @lnRetCd <> 0
    BEGIN
      SELECT @lvcMsg = CONVERT(CHAR(26),GETDATE(), 109)
        + ' : Updating LAST_RUN_DATE in table tpzt_last_rundate FAILED'
        + ' RETURNCODE: '
        + CONVERT(CHAR(6),@lnRetCd)
      PRINT    @lvcMsg
      RETURN    @lnRetCd
    END

/**************  PRINT STEP 6 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed

/**************  PRINT JOB FOOTER DATA ****************************/

    SELECT @ldtProcessEndTime = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr
      @pchObjectName          = @lvcObjectName,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pdtProcessEndTime      = @ldtProcessEndTime
    RETURN  @lnRetCd
END
GO
/****************************************************************
 BEGIN MAINTENANCE WRAPPER:
*****************************************************************/
IF OBJECT_ID('dbo.tpzp_usable_membership_extr') IS NOT NULL
  PRINT '<<< CREATED PROCEDURE dbo.tpzp_usable_membership_extr >>>'
       
ELSE
  PRINT '<<<ERROR CREATING PROCEDURE dbo.tpzp_usable_membership_extr >>>'
GO

/****************************************************************
 END MAINTENANCE WRAPPER:
*****************************************************************/

--select * from fabncua1stage.dbo.tpzt_usable_membership_extr_new new
--where new.GRGR_ID ='14149261' '14149274'






