/***************************************************************
  BEGIN MAINTENANCE WRAPPER.
***************************************************************/

IF OBJECT_ID('dbo.tpzp_usable_membership_extr') IS NOT NULL
BEGIN
  DROP PROCEDURE dbo.tpzp_usable_membership_extr

  IF OBJECT_ID('dbo.tpzp_usable_membership_extr') IS NOT NULL
    PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_usable_membership_extr >>>'
  ELSE
    PRINT '<<< DROPPED PROCEDURE dbo.tpzp_usable_membership_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
***************************************************************/

CREATE PROCEDURE [dbo].[tpzp_usable_membership_extr]

/****************************************************************
**   NAME                  : dbo.tpzp_usable_membership_extr
**
**
**   PVCS LOCATION         : 
**
**   FUNCTION              : STEP 1 Truncate staging table tpzt_usable_membership_extr_old
**                           STEP 2 Populating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr_old with the previous days record
**                           STEP 3 Truncating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr_new
**                           STEP 4 Obtaining Last Run Date from the custom table tpzt_last_rundate
**                           STEP 5 Populating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr_new with present days record
**                           STEP 6 Update staging table tpzt_usable_membership_extr_new for PDTHRU Column
**                           STEP 7 Truncate Staging table tpzt_usable_membership_error
**                           STEP 8 Insert error records in staging table tpzt_usable_membership_error
**                           STEP 9 Truncating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr
**                           STEP 10 Inserting updated records in stage table fabncdv1stage.dbo.tpzt_usable_membership_extr
**                           STEP 11 Updating LAST_RUN_DATE in table tpzt_last_rundate
**
**   PARAMETERS            :
**                   INPUT :
**                  OUTPUT :
**
**   RETURN CODES          : 0 on success
**
**   TABLES REFERENCED     :
**                FACETS   : fabncdv1.dbo.CMC_SBSA_SALARY
**                           fabncdv1.dbo.CMC_CSPI_CS_PLAN
**                           fabncdv1.dbo.CMC_SBSR_SB_RATE
**                           fabncdv1.dbo.CMC_SBCS_CLASS
**
**                FACETSXC : N/A
**                CUSTOM   : fabncdv1custom.dbo.tpzt_last_rundate
**                STAGE    : fabncdv1stage.dbo.tpzt_comm_elig_extr
**                           fabncdv1stage.dbo.tpzt_usable_vltd
**                           fabncdv1stage.dbo.tpzt_usable_vstd
**                           fabncdv1stage.dbo.tpzt_usable_vadd
**                           fabncdv1stage.dbo.tpzt_usable_vl
**                           fabncdv1stage.dbo.tpzt_usable_ltd
**                           fabncdv1stage.dbo.tpzt_usable_wdb
**                           fabncdv1stage.dbo.tpzt_usable_dl
**                           fabncdv1stage.dbo.tpzt_usable_gtl_add
**
**   PROCEDURES REFERENCED :
**                  FACETS :
**                  CUSTOM :
**   STANDARD LOGGING PROCS:
**                           harcore.dbo.harsp_gen_util_job_hdr_lgr
**                           harcore.dbo.harsp_gen_util_job_ftr_lgr
**                           harcore.dbo.harsp_gen_util_step_hdr_lgr
**                           harcore.dbo.harsp_gen_util_step_ftr_lgr
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0      08/20/2014    Ghazala Ameen      Initial Version
** 1.1      08/26/2014    Shekhar Kadam      Date format is updated from cyymmdd to ccyymmdd and field position is updated
****************************************************************/
AS

BEGIN

/****************************************************************
**          DECLARE LOCAL VARIABLES                            **
****************************************************************/

    DECLARE @lnRetCd                INT              -- Proc return code
    DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time
    DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
    DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time
    DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time
    DECLARE @lnCurrentStep          INT              -- Current Step Number
    DECLARE @lnTotalSteps           INT              -- Total Steps In Proc
    DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field
    DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name
    DECLARE @lvcDBName              VARCHAR(32)      -- DB Name
    DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version
    DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name
    DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name
    DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step
    DECLARE @ldtLastRunDt           DATETIME         -- Last run date
    DECLARE @ldtCurrentDate         DATETIME         -- Current date

/****************************************************************
**          INITIALIZE  VARIABLES                              **
****************************************************************/

    SELECT @lnRetCd        = 0,
      @lvcMsg              = NULL,
      @lnCurrentStep       = 0,  
      @lnTotalSteps        = 11,
      @ldtStepEndTime      = NULL,
      @lvcVersionNum       = '1.0'

    SELECT @lvcServerName  = @@SERVERNAME,
      @lvcDBName           = DB_NAME(),
      @lvcUser             = USER_NAME(),
      @lvcObjectName       = OBJECT_NAME(@@PROCID),
      @ldtProcessStartTime = GETDATE(),
      @ldtCurrentDate      = CONVERT(VARCHAR (10), GETDATE(), 101)

/****************************************************************
**               BEGIN PROCESS                                 **
*****************************************************************/

/**************  PRINT JOB HEADER DATA *************************/

    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr
      @pchObjectName        = @lvcObjectName,
      @pdtProcessStartTime  = @ldtProcessStartTime,
      @pchServerName        = @lvcServerName,
      @pchDBName            = @lvcDBName,
      @pchUserName          = @lvcUser,
      @pchVersionNum        = @lvcVersionNum

/**************  PRINT STEP 1 HEADER DATA *************************/

/**************  PRINT STEP 1 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Truncating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr_new'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 1 Truncating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr_new **********/

    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_usable_membership_extr_new
               
/********** Error Checking for truncate statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Truncating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr_new FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 1 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed

/**************  PRINT STEP 2 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg           = @lvcObjectName + ': Obtaining Last Run Date from the custom table tpzt_last_rundate'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 2 Obtaining Last Run Date from the custom table tpzt_last_rundate **************/

    SELECT @ldtLastRunDt =  LAST_RUN_DATE
    FROM fabncdv1custom.dbo.tpzt_last_rundate
    WHERE INTERFACE_IDENTIFIER  = 'VE9006'
      AND INTERFACE_DESCRIPTION = 'USABLE_MEMBERSHIP'

    /************* Error Checking for Obtaining Last Run Date from the custom table tpzt_last_rundate *************/

    SELECT @lnRetCd         = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Obtaining Last Run Date from the custom table tpzt_last_rundate FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 2 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed

/**************  PRINT STEP 3 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Populating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr_new with present days record'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 3 Populating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr_new with present days record **********/

    INSERT INTO fabncdv1stage.dbo.tpzt_usable_membership_extr_new  
      (
		GRGR_ID           ,
		--GRGR_ID_OLD       ,
        CSCS_ID           ,
        --CSCS_ID_OLD       ,
        CSPI_ID           ,
		SGSG_CK			  ,
        GRPNUM            ,
        MEMBNO            ,
        LSTNAM            ,
        FSTNAM            ,
        MIDNAM            ,
        BTHDAT            ,
        SEXCOD            ,
        SSN               ,
        SALARY            ,
        CLSCOD            ,
        LIFMTHPRM         ,
        ADDMTHPRM         ,
        DLIMTHPRM         ,
        WDBMTHPRM         ,
        LTDMTHPRM         ,
        SLIMTHPRM         ,
        SADMTHPRM         ,
        VLIFMTHPRM        ,
        VLIFSPMTHPRM      ,
        VLIFCHMTHPRM      ,
        VADDMTHPRM        ,
        VADDSPMTHPRM      ,
        VADDCHMTHPRM      ,
        VSTDMTHPRM        ,
        VLTDMTHPRM        ,
        LIFACTVOL         ,
        LIFRPERUT         ,
        LIFRATSRC         ,
        ADDACTVOL         ,
        ADDRPERUT         ,
        ADDRATSRC         ,
        DLIACTVOL         ,
        DLIRPERUT         ,
        DLIRATSRC         ,
        WDBACTVOL         ,
        WDBRPERUT         ,
        WDBRATSRC         ,
        LTDACTVOL         ,
        LTDRPERUT         ,
        LTDRATSRC         ,
        SLIACTVOL         ,
        SLIRPERUT         ,
        SLIRATSRC         ,
        SADACTVOL         ,
        SADRPERUT         ,
        SADRATSRC         ,
        VLIFACTVOL        ,
        VLIFRPERUT        ,
        VLIFRATSRC        ,
        VLIFSPACTVOL      ,
        VLIFSPRPERUT      ,
        VLIFSPRATSRC      ,
        VLIFCHACTVOL      ,
        VLIFCHRPERUT      ,
        VLIFCHRATSRC      ,
        VADDACTVOL        ,
        VADDRPERUT        ,
        VADDRATSRC        ,
        VADDSPACTVOL      ,
        VADDSPRPERUT      ,
        VADDSPRATSRC      ,
        VADDCHACTVOL      ,
        VADDCHRPERUT      ,
        VADDCHRATSRC      ,
        VSTDACTVOL        ,
        VSTDRPERUT        ,
        VSTDRATSRC        ,
        VLTDACTVOL        ,
        VLTDRPERUT        ,
        VLTDRATSRC        ,
        PDTHRU            ,
        HIRDAT            ,
        AGE               ,
        ACCTNO            ,
        CLSEFFDAT         ,
        CLSEXPDAT         ,
        LIFEFFDAT         ,
        LIFEXPDAT         ,
        LIFREASCD         ,
        LIFLSTCHG         ,
        ADDEFFDAT         ,
        ADDEXPDAT         ,
        ADDREASCD         ,
        ADDLSTCHG         ,
        DLIEFFDAT         ,
        DLIEXPDAT         ,
        DLIREASCD         ,
        DLILSTCHG         ,
        WDBEFFDAT         ,
        WDBEXPDAT         ,
        WDBREASCD         ,
        WDBLSTCHG         ,
        LTDEFFDAT         ,
        LTDEXPDAT         ,
        LTDREASCD         ,
        LTDLSTCHG         ,
        SLIEFFDAT         ,
        SLIEXPDAT         ,
        SLIREASCD         ,
        SLILSTCHG         ,
        SADEFFDAT         ,
        SADEXPDAT         ,
        SADREASCD         ,
        SADLSTCHG         ,
        VLIFEFFDAT        ,
        VLIFDEXPDAT       ,
        VLIFREASCD        ,
        VLIFLSTCHG        ,
        VLIFEFFDAT_SPOUSE ,
        VLIFDEXPDAT_SPOUSE,
        VLIFREASCD_SPOUSE ,
        VLIFLSTCHG_SPOUSE ,
        VLIFEFFDAT_CHILD  ,
        VLIFDEXPDAT_CHILD ,
        VLIFREASCD_CHILD  ,
        VLIFLSTCHG_CHILD  ,
        VADDEFFDAT        ,
        VADDEXPDAT        ,
        VADDREASCD        ,
        VADDLSTCHG        ,
        VADDSPEFFDAT      ,
        VADDSPEXPDAT      ,
        VADDSPREASCD      ,
        VADDSPLSTCHG      ,
        VADDCHEFFDAT      ,
        VADDCHEXPDAT      ,
        VADDCHREASCD      ,
        VADDCHLSTCHG      ,
        VSTDEFFDAT        ,
        VSTDDEXPDAT       ,
        VSTDREASCD        ,
        VSTDLSTCHG        ,
        VLTDEFFDAT        ,
        VLTDDEXPDAT       ,
        VLTDREASCD        ,
        VLTDLSTCHG        
      )   
   SELECT DISTINCT
        GRGR_ID       = LEFT(ISNULL(LTRIM(RTRIM(comm.GRGR_ID)),'') + SPACE(8),8),
		--GRGR_ID_OLD   = ISNULL((SELECT old.GRPNUM FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_old old WHERE old.GRGR_ID = comm.GRGR_ID),''),
		CSCS_ID       = LEFT(ISNULL(LTRIM(RTRIM(comm.CSCS_ID)),'') + SPACE(4),4),
		--CSCS_ID_OLD   = ISNULL((SELECT old.CSCS_ID FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_old old WHERE old.CSCS_ID = comm.CSCS_ID),''),
		CSPI_ID    	  =  LEFT(ISNULL(LTRIM(RTRIM(comm.CSPI_ID)),'') + SPACE(8),8),
		SGSG_CK		  =  comm.SGSG_CK,
        GRPNUM        =  LEFT(ISNULL(LTRIM(RTRIM(comm.GRGR_ID)),'') + SPACE(8),8),
        MEMBNO        =  LEFT(ISNULL(LTRIM(RTRIM(comm.SBSB_ID)),'') + SPACE(12),12),
        LSTNAM        =  LEFT(SUBSTRING(LTRIM(RTRIM(ISNULL(comm.MEME_LAST_NAME,''))),1,15) + SPACE(15),15),
        FSTNAM        =  LEFT(SUBSTRING(LTRIM(RTRIM(ISNULL(comm.MEME_FIRST_NAME,''))),1,10) + SPACE(10),10),
        MIDNAM        =  LEFT(ISNULL(LTRIM(RTRIM(comm.MEME_MID_INIT)),'') + SPACE(1),1),
        BTHDAT        =  ISNULL(CONVERT(VARCHAR(8),comm.MEME_BIRTH_DT,112),'00000000'),
        SEXCOD        =  LEFT(ISNULL(LTRIM(RTRIM(comm.MEME_SEX)),'') + SPACE(1),1),
        SSN           =  LEFT(ISNULL(LTRIM(RTRIM(comm.MEME_SSN)),'') + SPACE(9),9),
        SALARY        =  RIGHT(REPLICATE('0', 9) + CAST(sbsa.SBSA_SAL_AMT AS VARCHAR) ,9),
        CLSCOD        =  LEFT(ISNULL(LTRIM(RTRIM(comm.CSCS_ID)),'') + SPACE(4),4),
        LIFMTHPRM     =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT ISNULL(sbsr1.SBSR_PREM_SB,'0')
                             FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
                                 WHERE sbsr.SBSB_CK  = comm.SBSB_CK  
                                 AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
                                 AND  cspi.CSPD_CAT = 'L'
                         ),'0')AS NUMERIC(6,2)) AS VARCHAR) ,6),
        ADDMTHPRM     =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT ISNULL(sbsr1.SBSR_PREM_SB,'0') 
                             FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
                                 WHERE sbsr.SBSB_CK  = comm.SBSB_CK
                                 AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
                                 AND  cspi.CSPD_CAT = 'A'
                         ),'0')AS NUMERIC(6,2)) AS VARCHAR) ,6),
        DLIMTHPRM     =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT ISNULL(sbsr1.SBSR_PREM_SB,'0') 
                             FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
                                 WHERE sbsr.SBSB_CK  = comm.SBSB_CK
                                 AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
                                 AND  cspi.CSPD_CAT = 'T'
                         ),'0')AS NUMERIC(6,2)) AS VARCHAR) ,6),
        WDBMTHPRM     =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT ISNULL(sbsr1.SBSR_PREM_SB,'0') 
                             FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
                                 WHERE sbsr.SBSB_CK  = comm.SBSB_CK 
                                 AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
                                 AND  cspi.CSPD_CAT = 'X'
                         ),'0')AS NUMERIC(6,2)) AS VARCHAR) ,6),
        LTDMTHPRM     =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT ISNULL(sbsr1.SBSR_PREM_SB,'0') 
                             FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
                                 WHERE sbsr.SBSB_CK  = comm.SBSB_CK
                                 AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
                                 AND  cspi.CSPD_CAT = 'Y'
                         ),'0')AS NUMERIC(6,2)) AS VARCHAR) ,6),
        SLIMTHPRM     =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT ISNULL(sbsr1.SBSR_PREM_SB,'0') 
                             FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
                                 WHERE sbsr.SBSB_CK  = comm.SBSB_CK
                                 AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
                                 AND  cspi.CSPD_CAT = 'S'
                         ),'0')AS NUMERIC(6,2)) AS VARCHAR) ,6),
                         
        SADMTHPRM     =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT ISNULL(sbsr1.SBSR_PREM_SB,'0')
                           FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
                             WHERE sbsr.SBSB_CK  = comm.SBSB_CK
                             AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
                             AND  cspi.CSPD_CAT = 'E'    
                          ),'0')AS NUMERIC(6,2)) AS VARCHAR) ,6),
                          
        VLIFMTHPRM    =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT ISNULL(sbsr1.SBSR_PREM_SB,'0') 
                                 FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
                                     WHERE sbsr.SBSB_CK  = comm.SBSB_CK
                                     AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'Z'
                                     AND  comm.MEME_REL = 'M'
                             ),'0')AS NUMERIC(6,2)) AS VARCHAR) ,6),
                             
        VLIFSPMTHPRM  =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT ISNULL(sbsr1.SBSR_PREM_SB,'0') 
                                 FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
                                     WHERE sbsr.SBSB_CK  = comm.SBSB_CK
                                     AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'Z'
                                     AND  comm.MEME_REL IN('H','W')
                             ),'0')AS NUMERIC(6,2)) AS VARCHAR) ,6),
                             
        VLIFCHMTHPRM  =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT ISNULL(sbsr1.SBSR_PREM_SB,'0') 
                                 FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
                                     WHERE sbsr.SBSB_CK  = comm.SBSB_CK
                                     AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'Z'
                                     AND  comm.MEME_REL IN('S','D')
                             ),'0')AS NUMERIC(6,2)) AS VARCHAR) ,6),
        VADDMTHPRM    =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT ISNULL(sbsr1.SBSR_PREM_SB,'0') 
                                 FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
                                     WHERE sbsr.SBSB_CK  = comm.SBSB_CK
                                     AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'B'
                                     AND  comm.MEME_REL = 'M'
                             ),'0')AS NUMERIC(6,2)) AS VARCHAR) ,6),
        VADDSPMTHPRM  =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT ISNULL(sbsr1.SBSR_PREM_SB,'0') 
                                 FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
                                     WHERE sbsr.SBSB_CK  = SBSB_CK
                                     AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'B'
                                     AND  comm.MEME_REL IN('H','W')
                             ),'000.00')AS NUMERIC(6,2)) AS VARCHAR) ,6),
        VADDCHMTHPRM  =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT ISNULL(sbsr1.SBSR_PREM_SB,'0') 
                                 FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
                                     WHERE sbsr.SBSB_CK  = SBSB_CK
                                     AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'B'
                                     AND  comm.MEME_REL IN('S','D')
                             ),'0')AS NUMERIC(6,2)) AS VARCHAR) ,6),
        VSTDMTHPRM    =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT ISNULL(sbsr1.SBSR_PREM_SB,'0') 
                                 FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
                                     WHERE sbsr.SBSB_CK  = comm.SBSB_CK
                                    AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'K'
                             ),'0')AS NUMERIC(6,2)) AS VARCHAR) ,6),
        VLTDMTHPRM    =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT ISNULL(sbsr1.SBSR_PREM_SB,'0') 
                                 FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
                                     WHERE sbsr.SBSB_CK  = comm.SBSB_CK
                                    AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'J'
                             ),'0')AS NUMERIC(6,2)) AS VARCHAR) ,6),
                             
                             
        LIFACTVOL     =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT gtl.BENEFIT_AMOUNT 
                          FROM fabncdv1stage.dbo.tpzt_usable_gtl_add gtl
                          WHERE gtl.GRGR_ID = comm.GRGR_ID
                          AND gtl.CSCS_ID = cspi.CSCS_ID
                          AND gtl.CSPI_ID = 'L'),'000.00')AS NUMERIC(6,2)) AS VARCHAR) ,6),
                          
        LIFRPERUT     = '000.06',
        
        LIFRATSRC     =  ISNULL((SELECT LEFT(ISNULL(LTRIM(RTRIM(gtl.BENEFIT_TYPE )),'') + SPACE(2),2) --gtl.BENEFIT_TYPE 
                          FROM fabncdv1stage.dbo.tpzt_usable_gtl_add gtl
                          WHERE gtl.GRGR_ID = comm.GRGR_ID 
                          AND gtl.CSCS_ID = cspi.CSCS_ID
                          AND gtl.CSPI_ID = 'L'),'  '),
                          
        ADDACTVOL     =  RIGHT(REPLICATE('0', 12) + CAST(CAST(ISNULL((SELECT gtl.BENEFIT_AMOUNT 
                          FROM fabncdv1stage.dbo.tpzt_usable_gtl_add gtl
                          WHERE gtl.GRGR_ID = comm.GRGR_ID
                          AND gtl.CSCS_ID = cspi.CSCS_ID
                          AND gtl.CSPI_ID = 'A'),'000.00')AS NUMERIC(12,4)) AS VARCHAR) ,12),
                          
        ADDRPERUT     =  '000.06',
        ADDRATSRC     =  ISNULL((SELECT LEFT(ISNULL(LTRIM(RTRIM(gtl.BENEFIT_TYPE )),'') + SPACE(2),2)
                          FROM fabncdv1stage.dbo.tpzt_usable_gtl_add gtl
                          WHERE gtl.GRGR_ID = comm.GRGR_ID 
                          AND gtl.CSCS_ID = cspi.CSCS_ID
                          AND gtl.CSPI_ID = 'A'),'  '),
                          
        DLIACTVOL     =  RIGHT(REPLICATE('0', 12) + CAST(CAST(ISNULL((SELECT usabledl.[PLAN]
                          FROM fabncdv1stage.dbo.tpzt_usable_dl usabledl
                          WHERE usabledl.GRGR_ID = comm.GRGR_ID 
                          AND usabledl.CSCS_ID = cspi.CSCS_ID
                          AND usabledl.CSPI_ID = 'T'),'000.00') AS NUMERIC(12,4)) AS VARCHAR) ,12),
        DLIRPERUT     =  '000.06',
        DLIRATSRC     =  'C',
        
        WDBACTVOL     =  RIGHT(REPLICATE('0', 12) + CAST(CAST(ISNULL((SELECT usablewdb.BENEFIT_AMOUNT
                          FROM fabncdv1stage.dbo.tpzt_usable_wdb usablewdb
                          WHERE usablewdb.GRGR_ID = comm.GRGR_ID 
                          AND usablewdb.CSCS_ID = cspi.CSCS_ID
                          AND usablewdb.CSPI_ID = 'X'),'000.00') AS NUMERIC(12,4)) AS VARCHAR) ,12),
                          
        WDBRPERUT     =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT usablewdb.BENEFIT_PERCENTAGE
                          FROM fabncdv1stage.dbo.tpzt_usable_wdb usablewdb
                          WHERE usablewdb.GRGR_ID = comm.GRGR_ID 
                          AND usablewdb.CSCS_ID = cspi.CSCS_ID
                          AND usablewdb.CSPI_ID = 'X'),'000.58') AS NUMERIC(6,2)) AS VARCHAR) ,6),
                          
        WDBRATSRC     =  ISNULL((SELECT LEFT(ISNULL(LTRIM(RTRIM(usablewdb.BENEFIT_TYPE )),'') + SPACE(2),2) --usablewdb.BENEFIT_TYPE
                          FROM fabncdv1stage.dbo.tpzt_usable_wdb usablewdb
                          WHERE usablewdb.GRGR_ID = comm.GRGR_ID 
                          AND usablewdb.CSCS_ID = cspi.CSCS_ID
                          AND usablewdb.CSPI_ID = 'X'),'  ') ,
                          
        LTDACTVOL     =  RIGHT(REPLICATE('0', 12) + CAST(CAST(ISNULL((SELECT usableltd.MONTHLY_MAXIMUM
                          FROM fabncdv1stage.dbo.tpzt_usable_ltd usableltd
                          WHERE usableltd.GRGR_ID = comm.GRGR_ID 
                          AND usableltd.CSCS_ID = cspi.CSCS_ID
                          AND usableltd.CSPI_ID = 'Y'),'000.00')AS NUMERIC(12,4)) AS VARCHAR) ,12),
                          
        LTDRPERUT     =  '000.06',
        LTDRATSRC     =  'S',
        
        SLIACTVOL     =  RIGHT(REPLICATE('0', 12) + CAST(CAST(ISNULL((SELECT usablesl.BENEFIT_AMOUNT
                          FROM fabncdv1stage.dbo.tpzt_usable_sl usablesl
                          WHERE usablesl.GRGR_ID = comm.GRGR_ID 
                          AND usablesl.CSCS_ID = cspi.CSCS_ID
                          AND usablesl.CSPI_ID = 'S'),'000.00')AS NUMERIC(12,4)) AS VARCHAR) ,12),
                          
        SLIRPERUT     =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT usablesl.BENEFIT_PERCENTAGE
                           FROM fabncdv1stage.dbo.tpzt_usable_sl usablesl
                          WHERE usablesl.GRGR_ID = comm.GRGR_ID 
                          AND usablesl.CSCS_ID = cspi.CSCS_ID
                          AND usablesl.CSPI_ID = 'S'),'000.00')AS NUMERIC(6,2)) AS VARCHAR) ,6),
                          
        SLIRATSRC     =  ISNULL((SELECT LEFT(ISNULL(LTRIM(RTRIM(usablesl.BENEFIT_TYPE)),'') + SPACE(2),2) --usablesl.BENEFIT_TYPE
                           FROM fabncdv1stage.dbo.tpzt_usable_sl usablesl
                          WHERE usablesl.GRGR_ID = comm.GRGR_ID 
                          AND usablesl.CSCS_ID = cspi.CSCS_ID
                          AND usablesl.CSPI_ID = 'S'),'  '),
                          
        SADACTVOL     =  RIGHT(REPLICATE('0', 12) + CAST(CAST(ISNULL((SELECT usablesa.BENEFIT_AMOUNT
                          FROM fabncdv1stage.dbo.tpzt_usable_sa usablesa
                          WHERE usablesa.GRGR_ID = comm.GRGR_ID 
                          AND usablesa.CSCS_ID = cspi.CSCS_ID
                          AND usablesa.CSPI_ID = 'E'),'000.00')AS NUMERIC(12,4)) AS VARCHAR) ,12),
                          
        SADRPERUT     =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT usablesa.BENEFIT_PERCENTAGE
                          FROM fabncdv1stage.dbo.tpzt_usable_sa usablesa
                          WHERE usablesa.GRGR_ID = comm.GRGR_ID 
                          AND usablesa.CSCS_ID = cspi.CSCS_ID
                          AND usablesa.CSPI_ID = 'E'),'000.00')AS NUMERIC(6,2)) AS VARCHAR) ,6),
                          
        SADRATSRC     =   ISNULL((SELECT LEFT(ISNULL(LTRIM(RTRIM(usablesa.BENEFIT_TYPE)),'') + SPACE(2),2) --usablesa.BENEFIT_TYPE
                          FROM fabncdv1stage.dbo.tpzt_usable_sa usablesa
                          WHERE usablesa.GRGR_ID = comm.GRGR_ID 
                          AND usablesa.CSCS_ID = cspi.CSCS_ID
                          AND usablesa.CSPI_ID = 'E'),'  '),
                          
        VLIFACTVOL    =  RIGHT(REPLICATE('0', 12) + CAST(CAST(ISNULL((SELECT usablevl.BENEFIT_AMOUNT
                          FROM fabncdv1stage.dbo.tpzt_usable_vl usablevl
                          WHERE usablevl.GRGR_ID = comm.GRGR_ID 
                          AND usablevl.CSCS_ID = cspi.CSCS_ID
                          AND usablevl.CSPI_ID = 'Z'
                          AND comm.MEME_REL = 'M'),'0000000.0000')AS NUMERIC(12,4)) AS VARCHAR) ,12),
                          
        VLIFRPERUT    =  '000.06',
        VLIFRATSRC    =  '  ',
        VLIFSPACTVOL  =  RIGHT(REPLICATE('0', 12) + CAST(CAST(ISNULL((SELECT usablevl.SPOUSE_AMOUNT
                          FROM fabncdv1stage.dbo.tpzt_usable_vl usablevl
                          WHERE usablevl.GRGR_ID = comm.GRGR_ID 
                          AND usablevl.CSCS_ID = cspi.CSCS_ID
                          AND usablevl.CSPI_ID = 'Z'
                          AND comm.MEME_REL IN('H','W')),'0000000.0000')AS NUMERIC(12,4)) AS VARCHAR) ,12),
                          
        VLIFSPRPERUT  =  '000.06',
        VLIFSPRATSRC  =  '  ',
        VLIFCHACTVOL  =  RIGHT(REPLICATE('0', 12) + CAST(CAST(ISNULL((SELECT usablevl.DEPENDANT_CHILD_COVERAGE
                          FROM fabncdv1stage.dbo.tpzt_usable_vl usablevl
                          WHERE usablevl.GRGR_ID = comm.GRGR_ID 
                          AND usablevl.CSCS_ID = cspi.CSCS_ID
                          AND usablevl.CSPI_ID = 'Z'
                          AND comm.MEME_REL IN('S','D')),'0000000.0000')AS NUMERIC(12,4)) AS VARCHAR) ,12),
        VLIFCHRPERUT  =  '000.06',
        VLIFCHRATSRC  =  '  ',
        VADDACTVOL    =  RIGHT(REPLICATE('0', 12) + CAST(CAST(ISNULL((SELECT usablevadd.BENEFIT_AMOUNT
                          FROM fabncdv1stage.dbo.tpzt_usable_vadd usablevadd
                          WHERE usablevadd.GRGR_ID = comm.GRGR_ID 
                          AND usablevadd.CSCS_ID = cspi.CSCS_ID
                          AND usablevadd.CSPI_ID = 'B'
                          AND comm.MEME_REL = 'M'),'0000000.0000')AS NUMERIC(12,4)) AS VARCHAR) ,12),
        VADDRPERUT    =  '000.06',
        VADDRATSRC    =  '  ',
        VADDSPACTVOL  =  RIGHT(REPLICATE('0', 12) + CAST(CAST(ISNULL((SELECT usablevadd.SPOUSE_AMOUNT
                          FROM fabncdv1stage.dbo.tpzt_usable_vadd usablevadd
                          WHERE usablevadd.GRGR_ID = comm.GRGR_ID 
                          AND usablevadd.CSCS_ID = cspi.CSCS_ID
                          AND usablevadd.CSPI_ID = 'B'
                          AND comm.MEME_REL IN('H','W')),'0000000.0000')AS NUMERIC(12,4)) AS VARCHAR) ,12),
        VADDSPRPERUT  =  '000.06',
        VADDSPRATSRC  =  '  ',
        VADDCHACTVOL  =  RIGHT(REPLICATE('0', 12) + CAST(CAST(ISNULL((SELECT usablevadd.DEP_CHILD_COVERAGE
                          FROM fabncdv1stage.dbo.tpzt_usable_vadd usablevadd
                          WHERE usablevadd.GRGR_ID = comm.GRGR_ID 
                          AND usablevadd.CSCS_ID = cspi.CSCS_ID
                          AND usablevadd.CSPI_ID = 'B'
                          AND comm.MEME_REL IN('S','D')),'0000000.0000')AS NUMERIC(12,4)) AS VARCHAR) ,12),
        VADDCHRPERUT  =  '000.06',
        VADDCHRATSRC  =  '  ',
        VSTDACTVOL    =  '0000000.0000',
        VSTDRPERUT    =  '000.06',
        VSTDRATSRC    =  ISNULL((SELECT LEFT(ISNULL(LTRIM(RTRIM(usablevstd.BENEFIT_TYPE)),'') + SPACE(2),2) --usablevstd.BENEFIT_TYPE
                          FROM fabncdv1stage.dbo.tpzt_usable_vstd usablevstd
                          WHERE usablevstd.GRGR_ID = comm.GRGR_ID 
                          AND usablevstd.CSCS_ID = cspi.CSCS_ID
                          AND usablevstd.CSPI_ID = 'K'),'  '),
        VLTDACTVOL    =  '0000000.0000',
        VLTDRPERUT    =  '000.06',
        VLTDRATSRC    =  ISNULL((SELECT LEFT(ISNULL(LTRIM(RTRIM(usablevltd.BENEFIT_TYPE)),'') + SPACE(2),2) --usablevltd.BENEFIT_TYPE
                          FROM fabncdv1stage.dbo.tpzt_usable_vltd usablevltd
                          WHERE usablevltd.GRGR_ID = comm.GRGR_ID 
                          AND usablevltd.CSCS_ID = cspi.CSCS_ID
                          AND usablevltd.CSPI_ID = 'J'),'  '),
                          
        PDTHRU        =  CONVERT(VARCHAR(8),comm.GRGR_ORIG_EFF_DT,112),
        HIRDAT        =  ISNULL(CONVERT(VARCHAR(8),comm.SBSB_HIRE_DT,112),'00000000'),
        AGE           =  ISNULL(DATEDIFF(yy, CONVERT(VARCHAR(8),comm.MEME_BIRTH_DT,112), CONVERT(VARCHAR(8),GETDATE(),112)),'  '),
        ACCTNO        =  LEFT(SUBSTRING(LTRIM(RTRIM(ISNULL(comm.SGSG_ID,''))),1,10) + SPACE(10),10),
        CLSEFFDAT     =  ISNULL(CONVERT(VARCHAR(8),sbcs.SBCS_EFF_DT,112),'00000000'),
        CLSEXPDAT     =  ISNULL(CONVERT(VARCHAR(8),sbcs.SBCS_TERM_DT,112),'00000000'),
        
        
        LIFEFFDAT     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_EFF_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'L'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        LIFEXPDAT     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_TERM_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'L'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        LIFREASCD     =  '  ',
        LIFLSTCHG     =  '00000000',
        ADDEFFDAT     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_EFF_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'A'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        ADDEXPDAT     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_TERM_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'A'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        ADDREASCD     =  '  ',
        ADDLSTCHG     =  '00000000',
        DLIEFFDAT     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_EFF_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm1.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'T'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        DLIEXPDAT     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_TERM_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'T'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        DLIREASCD     =  '  ',
        DLILSTCHG     =  '00000000',
        WDBEFFDAT     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_EFF_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'X'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        WDBEXPDAT     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_TERM_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'X'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        WDBREASCD     =  '  ',
        WDBLSTCHG     =  '00000000',
        LTDEFFDAT     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_EFF_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'Y'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        LTDEXPDAT     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_TERM_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'Y'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        LTDREASCD     =  '  ',
        LTDLSTCHG     =  '00000000',
        SLIEFFDAT     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_EFF_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'S'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        SLIEXPDAT     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_TERM_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'S'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        SLIREASCD     =  '  ',
        SLILSTCHG     =  '00000000',
        SADEFFDAT     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_EFF_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'E'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        SADEXPDAT     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_TERM_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'E'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        SADREASCD     =  '  ',
        SADLSTCHG     =  '00000000',
        VLIFEFFDAT    =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_EFF_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'Z'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                                     AND  comm.MEME_REL = 'M'
                             ),'00000000'),
        VLIFDEXPDAT   =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_TERM_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'Z'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                                     AND  comm.MEME_REL = 'M'
                             ),'00000000'),
        VLIFREASCD    =  '  ',
        VLIFLSTCHG    =  '00000000',
        VLIFEFFDAT_SPOUSE    =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_EFF_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'Z'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                                     AND  comm.MEME_REL IN('H','W')
                             ),'00000000'),
        VLIFDEXPDAT_SPOUSE   =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_TERM_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'Z'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                                     AND  comm.MEME_REL IN('H','W')
                             ),'00000000'),
        VLIFREASCD_SPOUSE    =  '  ',
        VLIFLSTCHG_SPOUSE    =  '00000000',
        VLIFEFFDAT_CHILD     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_EFF_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'Z'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                                     AND  comm.MEME_REL IN('S','D')
                             ),'00000000'),
        VLIFDEXPDAT_CHILD    =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_TERM_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'Z'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                                     AND  comm.MEME_REL IN('S','D')
                             ),'00000000'),
        VLIFREASCD_CHILD     =  '  ',
        VLIFLSTCHG_CHILD     =  '00000000',
        VADDEFFDAT    =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_EFF_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'B'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                                     AND  comm.MEME_REL ='M'
                             ),'00000000'),
        VADDEXPDAT    =   ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_TERM_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'B'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                                     AND  comm.MEME_REL ='M'
                             ),'00000000'),
        VADDREASCD    =  '  ',
        VADDLSTCHG    =  '00000000',
        VADDSPEFFDAT  =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_EFF_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'B'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                                     AND  comm.MEME_REL IN('H','W')
                             ),'00000000'),
        VADDSPEXPDAT  =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_TERM_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'B'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                                     AND  comm.MEME_REL IN('H','W')
                             ),'00000000'),
        VADDSPREASCD  =  '  ',
        VADDSPLSTCHG  =  '00000000',
        VADDCHEFFDAT  =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_EFF_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'B'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                                     AND  comm.MEME_REL IN('S','D')
                             ),'00000000'),
        VADDCHEXPDAT  =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_TERM_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'B'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                                     AND  comm.MEME_REL IN('S','D')
                             ),'00000000'),
        VADDCHREASCD  =  '  ',
        VADDCHLSTCHG  =  '00000000',
        VSTDEFFDAT    =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_EFF_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'K'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        VSTDDEXPDAT   =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_TERM_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'K'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        VSTDREASCD    =  '  ',
        VSTDLSTCHG    =  '00000000',
        VLTDEFFDAT    =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_EFF_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'J'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        VLTDDEXPDAT   =  ISNULL((SELECT CONVERT(VARCHAR(8),max(comm1.MEPE_TERM_DT),112)
                                 FROM  fabncdv1stage.dbo.tpzt_comm_elig_extr comm1 
                                     WHERE comm1.SBSB_CK = comm.SBSB_CK
                                     AND  cspi.CSPD_CAT = 'J'
                                     AND  comm.MEPE_ELIG_IND = 'Y'
                             ),'00000000'),
        VLTDREASCD    =  '  ',
        VLTDLSTCHG    =  '00000000'
    FROM  
          fabncdv1stage.dbo.tpzt_comm_elig_extr comm 
            INNER JOIN fabncdv1..CMC_SBSA_SALARY sbsa ON comm.SBSB_CK = sbsa.SBSB_CK
                                                      AND comm.GRGR_CK = sbsa.GRGR_CK
            INNER JOIN fabncdv1..CMC_CSPI_CS_PLAN cspi ON cspi.CSPI_ID = comm.CSPI_ID
            INNER JOIN fabncdv1..CMC_SBSR_SB_RATE sbsr ON sbsr.SBSB_CK = comm.SBSB_CK
                                                    AND sbsr.SBSB_CK = sbsa.SBSB_CK
            INNER JOIN fabncdv1..CMC_SBCS_CLASS sbcs ON sbcs.SBSB_CK = comm.SBSB_CK
                                                     AND sbcs.GRGR_CK = comm.GRGR_CK
    WHERE comm.CSPD_CAT IN ('X','Y','L','A','S','T','Z','B','E','K') 
          --AND cspi.CSPI_TERM_DT >= DATEADD(dd,1,'01/01/2014')
		  AND cspi.CSPI_TERM_DT >= DATEADD(dd,1,@ldtLastRunDt)
          AND cspi.CSPI_TERM_DT > cspi.CSPI_EFF_DT
          AND comm.MEPE_TERM_DT BETWEEN GETDATE() AND DATEADD(mm,-12,comm.MEPE_TERM_DT)

/********** Error Checking for insert statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Populating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr_new with present days record FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 3 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed

/**************  PRINT STEP 4  HEADER DATA *************************/  
  
     SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
             @ldtStepStartTime = GETDATE(),  
             @lvcMsg = @lvcObjectName + ': Update staging table tpzt_usable_membership_extr_new for PDTHRU Column '  

     EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
             @pnStepNumber     = @lnCurrentStep,  
             @pdtStepStartTime = @ldtStepStartTime,  
             @pnTotalSteps     = @lnTotalSteps,  
             @pchStepMsg       = @lvcMsg 

                 
/************* STEP 4 Update staging table tpzt_usable_membership_extr_new for PDTHRU Column ***********/  
          
     UPDATE  new
     SET new.PDTHRU = ISNULL(CONVERT(VARCHAR(8), blbe.BLBL_END_DT,112),'00000000')
     FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new new
       JOIN
           ( SELECT blei.BLEI_CK,blei.BLEI_BILL_LEVEL_CK, MAX(blbl.BLBL_END_DT) AS BLBL_END_DT 
                    FROM fabncdv1.dbo.CMC_BLBL_BILL_SUMM blbl
                            inner join fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei on blei.BLEI_CK = blbl.BLEI_CK
                            
                 WHERE  blbl.BLBL_PAID_STS in (2,3)
                 GROUP BY blei.BLEI_CK,blei.BLEI_BILL_LEVEL_CK) as blbe
                 ON blbe.BLEI_BILL_LEVEL_CK = new.SGSG_CK
        
/************* Error Checking for Update staging table tpzt_usable_membership_extr_new for PDTHRU Column *************/  
          
     SELECT @lnRetCd    = @@ERROR,  
     @lnRowsProcessed = @@ROWCOUNT  
     
     IF @lnRetCd <> 0  
         BEGIN  
             SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
             + ' : Update staging table tpzt_usable_membership_extr_new for PDTHRU Column FAILED'  
             + ' RETURNCODE: '  
             + CONVERT(CHAR(6),@lnRetCd)  
             PRINT  @lvcMsg  
             RETURN @lnRetCd  
         END       
          
/**************  PRINT STEP 4 FOOTER DATA *************************/

    SELECT @ldtStepEndTime      = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime       = @ldtStepStartTime,
        @pdtStepEndTime         = @ldtStepEndTime,
        @pdtProcessStartTime    = @ldtProcessStartTime,
        @pnRowCount             = @lnRowsProcessed 

/**************  PRINT STEP 5  HEADER DATA *************************/  
  
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
            @ldtStepStartTime = GETDATE(),  
            @lvcMsg = @lvcObjectName + ': Truncate staging table tpzt_usable_membership_error'  

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
        @pnStepNumber     = @lnCurrentStep,  
        @pdtStepStartTime = @ldtStepStartTime,  
        @pnTotalSteps     = @lnTotalSteps,  
        @pchStepMsg       = @lvcMsg 
                 
/************* STEP 5 Truncate Staging table tpzt_usable_membership_error *************/  
          
   TRUNCATE TABLE fabncdv1stage.dbo.tpzt_usable_membership_error  
          
/************* Error Checking for Truncate Staging table tpzt_usable_membership_error *************/  
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  

        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Truncate Staging table tpzt_usable_membership_error FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END       
          
/**************  PRINT STEP 5 FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed   
   
/**************  PRINT STEP 6  HEADER DATA *************************/  
  
        SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Insert error records in staging table tpzt_usable_membership_error'  

        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg 

                 
/************* STEP 6 Insert error records in staging table tpzt_usable_membership_error *************/  
          
    INSERT INTO fabncdv1stage.dbo.tpzt_usable_membership_error
        (
            GRPNUM ,
            METIND ,
            MEMBNO ,
            LSTNAM ,
            FSTNAM ,
            BTHDAT ,
            SEXCOD ,
            SSN    ,
            CLSCOD ,
            CARCOD ,
            PDTHRU ,
            HIRDAT ,
            AGE    ,
            ACCTNO 
        )
    SELECT DISTINCT 
            GRPNUM = new.GRPNUM ,
            METIND = new.METIND ,
            MEMBNO = new.MEMBNO ,
            LSTNAM = new.LSTNAM ,
            FSTNAM = new.FSTNAM ,
            BTHDAT = new.BTHDAT ,
            SEXCOD = new.SEXCOD ,
            SSN    = new.SSN    ,
            CLSCOD = new.CLSCOD ,
            CARCOD = new.CARCOD ,
            PDTHRU = new.PDTHRU ,
            HIRDAT = new.HIRDAT ,
            AGE    = new.AGE    ,
            ACCTNO = new.ACCTNO 
        FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new new
        WHERE LTRIM(RTRIM(ISNULL(new.GRPNUM,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.METIND,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.MEMBNO,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.LSTNAM,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.FSTNAM,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.BTHDAT,'')))='' 
            OR LTRIM(RTRIM(ISNULL(new.SEXCOD,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.SSN,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.CLSCOD,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.CARCOD,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.PDTHRU,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.HIRDAT,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.AGE,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.ACCTNO,'')))=''
            
/************* Error Checking for Inserting in Staging table tpzt_usable_membership_error  *************/  
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  

        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Inserting error records in staging table tpzt_usable_membership_error FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END       
          
/**************  PRINT STEP 6 FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed   
 
     
/**************  PRINT STEP 7 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Truncating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 7 Truncating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr **********/

   TRUNCATE TABLE fabncdv1stage.dbo.tpzt_usable_membership_extr
               
/********** Error Checking for truncate statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Truncating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 7 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed
      
/**************  PRINT STEP 8 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Inserting updated records in stage table fabncdv1stage.dbo.tpzt_usable_membership_extr'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 8 Inserting updated records in stage table fabncdv1stage.dbo.tpzt_usable_membership_extr **********/

    INSERT INTO fabncdv1stage.dbo.tpzt_usable_membership_extr 
      (
        GRPNUM       ,
        METIND       ,
        MEMBNO       ,
        LSTNAM       ,
        FSTNAM       ,
        MIDNAM       ,
        BTHDAT       ,
        SEXCOD       ,
        SSN          ,
        SALARY       ,
        CLSCOD       ,
        LIFMTHPRM    ,
        ADDMTHPRM    ,
        DLIMTHPRM    ,
        WDBMTHPRM    ,
        LTDMTHPRM    ,
        SLIMTHPRM    ,
        SADMTHPRM    ,
        VLIFMTHPRM   ,
        VLIFSPMTHPRM ,
        VLIFCHMTHPRM ,
        VADDMTHPRM   ,
        VADDSPMTHPRM ,
        VADDCHMTHPRM ,
        VSTDMTHPRM   ,
        VLTDMTHPRM   ,
        CARCOD       ,
        LIFACTVOL    ,
        LIFRPERUT    ,
        LIFRATSRC    ,
        ADDACTVOL    ,
        ADDRPERUT    ,
        ADDRATSRC    ,
        DLIACTVOL    ,
        DLIRPERUT    ,
        DLIRATSRC    ,
        WDBACTVOL    ,
        WDBRPERUT    ,
        WDBRATSRC    ,
        LTDACTVOL    ,
        LTDRPERUT    ,
        LTDRATSRC    ,
        SLIACTVOL    ,
        SLIRPERUT    ,
        SLIRATSRC    ,
        SADACTVOL    ,
        SADRPERUT    ,
        SADRATSRC    ,
        VLIFACTVOL   ,
        VLIFRPERUT   ,
        VLIFRATSRC   ,
        VLIFSPACTVOL ,
        VLIFSPRPERUT ,
        VLIFSPRATSRC ,
        VLIFCHACTVOL ,
        VLIFCHRPERUT ,
        VLIFCHRATSRC ,
        VADDACTVOL   ,
        VADDRPERUT   ,
        VADDRATSRC   ,
        VADDSPACTVOL ,
        VADDSPRPERUT ,
        VADDSPRATSRC ,
        VADDCHACTVOL ,
        VADDCHRPERUT ,
        VADDCHRATSRC ,
        VSTDACTVOL   ,
        VSTDRPERUT   ,
        VSTDRATSRC   ,
        VLTDACTVOL   ,
        VLTDRPERUT   ,
        VLTDRATSRC   ,
        PDTHRU       ,
        HIRDAT       ,
        AGE          ,
        ACCTNO       ,
        CLSEFFDAT    ,
        CLSEXPDAT    ,
        LIFEFFDAT    ,
        LIFEXPDAT    ,
        LIFREASCD    ,
        LIFLSTCHG    ,
        ADDEFFDAT    ,
        ADDEXPDAT    ,
        ADDREASCD    ,
        ADDLSTCHG    ,
        DLIEFFDAT    ,
        DLIEXPDAT    ,
        DLIREASCD    ,
        DLILSTCHG    ,
        WDBEFFDAT    ,
        WDBEXPDAT    ,
        WDBREASCD    ,
        WDBLSTCHG    ,
        LTDEFFDAT    ,
        LTDEXPDAT    ,
        LTDREASCD    ,
        LTDLSTCHG    ,
        SLIEFFDAT    ,
        SLIEXPDAT    ,
        SLIREASCD    ,
        SLILSTCHG    ,
        SADEFFDAT    ,
        SADEXPDAT    ,
        SADREASCD    ,
        SADLSTCHG    ,
        VLIFEFFDAT   ,
        VLIFDEXPDAT  ,
        VLIFREASCD   ,
        VLIFLSTCHG   ,
        VLIFEFFDAT_SPOUSE   ,
        VLIFDEXPDAT_SPOUSE  ,
        VLIFREASCD_SPOUSE   ,
        VLIFLSTCHG_SPOUSE   ,
        VLIFEFFDAT_CHILD    ,
        VLIFDEXPDAT_CHILD   ,
        VLIFREASCD_CHILD    ,
        VLIFLSTCHG_CHILD    ,
        VADDEFFDAT   ,
        VADDEXPDAT   ,
        VADDREASCD   ,
        VADDLSTCHG   ,
        VADDSPEFFDAT ,
        VADDSPEXPDAT ,
        VADDSPREASCD ,
        VADDSPLSTCHG ,
        VADDCHEFFDAT ,
        VADDCHEXPDAT ,
        VADDCHREASCD ,
        VADDCHLSTCHG ,
        VSTDEFFDAT   ,
        VSTDDEXPDAT  ,
        VSTDREASCD   ,
        VSTDLSTCHG   ,
        VLTDEFFDAT   ,
        VLTDDEXPDAT  ,
        VLTDREASCD   ,
        VLTDLSTCHG
      )
    SELECT DISTINCT
        new.GRPNUM       ,
        new.METIND       ,
        new.MEMBNO       ,
        new.LSTNAM       ,
        new.FSTNAM       ,
        new.MIDNAM       ,
        new.BTHDAT       ,
        new.SEXCOD       ,
        new.SSN          ,
        new.SALARY       ,
        new.CLSCOD       ,
        new.LIFMTHPRM    ,
        new.ADDMTHPRM    ,
        new.DLIMTHPRM    ,
        new.WDBMTHPRM    ,
        new.LTDMTHPRM    ,
        new.SLIMTHPRM    ,
        new.SADMTHPRM    ,
        new.VLIFMTHPRM   ,
        new.VLIFSPMTHPRM ,
        new.VLIFCHMTHPRM ,
        new.VADDMTHPRM   ,
        new.VADDSPMTHPRM ,
        new.VADDCHMTHPRM ,
        new.VSTDMTHPRM   ,
        new.VLTDMTHPRM   ,
        new.CARCOD       ,
        new.LIFACTVOL    ,
        new.LIFRPERUT    ,
        new.LIFRATSRC    ,
        new.ADDACTVOL    ,
        new.ADDRPERUT    ,
        new.ADDRATSRC    ,
        new.DLIACTVOL    ,
        new.DLIRPERUT    ,
        new.DLIRATSRC    ,
        new.WDBACTVOL    ,
        new.WDBRPERUT    ,
        new.WDBRATSRC    ,
        new.LTDACTVOL    ,
        new.LTDRPERUT    ,
        new.LTDRATSRC    ,
        new.SLIACTVOL    ,
        new.SLIRPERUT    ,
        new.SLIRATSRC    ,
        new.SADACTVOL    ,
        new.SADRPERUT    ,
        new.SADRATSRC    ,
        new.VLIFACTVOL   ,
        new.VLIFRPERUT   ,
        new.VLIFRATSRC   ,
        new.VLIFSPACTVOL ,
        new.VLIFSPRPERUT ,
        new.VLIFSPRATSRC ,
        new.VLIFCHACTVOL ,
        new.VLIFCHRPERUT ,
        new.VLIFCHRATSRC ,
        new.VADDACTVOL   ,
        new.VADDRPERUT   ,
        new.VADDRATSRC   ,
        new.VADDSPACTVOL ,
        new.VADDSPRPERUT ,
        new.VADDSPRATSRC ,
        new.VADDCHACTVOL ,
        new.VADDCHRPERUT ,
        new.VADDCHRATSRC ,
        new.VSTDACTVOL   ,
        new.VSTDRPERUT   ,
        new.VSTDRATSRC   ,
        new.VLTDACTVOL   ,
        new.VLTDRPERUT   ,
        new.VLTDRATSRC   ,
        new.PDTHRU       ,
        new.HIRDAT       ,
        new.AGE          ,
        new.ACCTNO       ,
        new.CLSEFFDAT    ,
        new.CLSEXPDAT    ,
        new.LIFEFFDAT    ,
        new.LIFEXPDAT    ,
        new.LIFREASCD    ,
        new.LIFLSTCHG    ,
        new.ADDEFFDAT    ,
        new.ADDEXPDAT    ,
        new.ADDREASCD    ,
        new.ADDLSTCHG    ,
        new.DLIEFFDAT    ,
        new.DLIEXPDAT    ,
        new.DLIREASCD    ,
        new.DLILSTCHG    ,
        new.WDBEFFDAT    ,
        new.WDBEXPDAT    ,
        new.WDBREASCD    ,
        new.WDBLSTCHG    ,
        new.LTDEFFDAT    ,
        new.LTDEXPDAT    ,
        new.LTDREASCD    ,
        new.LTDLSTCHG    ,
        new.SLIEFFDAT    ,
        new.SLIEXPDAT    ,
        new.SLIREASCD    ,
        new.SLILSTCHG    ,
        new.SADEFFDAT    ,
        new.SADEXPDAT    ,
        new.SADREASCD    ,
        new.SADLSTCHG    ,
        new.VLIFEFFDAT   ,
        new.VLIFDEXPDAT  ,
        new.VLIFREASCD   ,
        new.VLIFLSTCHG   ,
        new.VLIFEFFDAT_SPOUSE   ,
        new.VLIFDEXPDAT_SPOUSE  ,
        new.VLIFREASCD_SPOUSE   ,
        new.VLIFLSTCHG_SPOUSE   ,
        new.VLIFEFFDAT_CHILD    ,
        new.VLIFDEXPDAT_CHILD   ,
        new.VLIFREASCD_CHILD    ,
        new.VLIFLSTCHG_CHILD    ,
        new.VADDEFFDAT   ,
        new.VADDEXPDAT   ,
        new.VADDREASCD   ,
        new.VADDLSTCHG   ,
        new.VADDSPEFFDAT ,
        new.VADDSPEXPDAT ,
        new.VADDSPREASCD ,
        new.VADDSPLSTCHG ,
        new.VADDCHEFFDAT ,
        new.VADDCHEXPDAT ,
        new.VADDCHREASCD ,
        new.VADDCHLSTCHG ,
        new.VSTDEFFDAT   ,
        new.VSTDDEXPDAT  ,
        new.VSTDREASCD   ,
        new.VSTDLSTCHG   ,
        new.VLTDEFFDAT   ,
        new.VLTDDEXPDAT  ,
        new.VLTDREASCD   ,
        new.VLTDLSTCHG
    FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new new
    WHERE LTRIM(RTRIM(ISNULL(new.GRPNUM,'')))<>''
            AND LTRIM(RTRIM(ISNULL(new.METIND,'')))<>''
            AND LTRIM(RTRIM(ISNULL(new.MEMBNO,'')))<>''
            AND LTRIM(RTRIM(ISNULL(new.LSTNAM,'')))<>''
            AND LTRIM(RTRIM(ISNULL(new.FSTNAM,'')))<>''
            AND LTRIM(RTRIM(ISNULL(new.BTHDAT,'')))<>'' 
            AND LTRIM(RTRIM(ISNULL(new.SEXCOD,'')))<>''
            AND LTRIM(RTRIM(ISNULL(new.SSN,'')))<>''
            AND LTRIM(RTRIM(ISNULL(new.CLSCOD,'')))<>''
            AND LTRIM(RTRIM(ISNULL(new.CARCOD,'')))<>''
            AND LTRIM(RTRIM(ISNULL(new.PDTHRU,'')))<>''
            AND LTRIM(RTRIM(ISNULL(new.HIRDAT,'')))<>''
            AND LTRIM(RTRIM(ISNULL(new.AGE,'')))<>''
            AND LTRIM(RTRIM(ISNULL(new.ACCTNO,'')))<>''
            
/********** Error Checking for insert statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Inserting updated records in stage table fabncdv1stage.dbo.tpzt_usable_membership_extr FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 8 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed

/**************  PRINT STEP 9 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime      = GETDATE(),
      @lvcMsg                = @lvcObjectName + ': Updating LAST_RUN_DATE in table tpzt_last_rundate'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 9 Updating LAST_RUN_DATE in table tpzt_last_rundate **********/
   
     UPDATE fabncdv1custom.dbo.tpzt_last_rundate
      SET LAST_RUN_DATE = GETDATE()
      WHERE INTERFACE_IDENTIFIER  = 'VE9006'
      AND INTERFACE_DESCRIPTION   = 'USABLE_MEMBERSHIP'
      
/********** Error checking for Updating LAST_RUN_DATE in table tpzt_last_rundate ***********/
    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT

    IF @lnRetCd <> 0
    BEGIN
      SELECT @lvcMsg = CONVERT(CHAR(26),GETDATE(), 109)
        + ' : Updating LAST_RUN_DATE in table tpzt_last_rundate FAILED'
        + ' RETURNCODE: '
        + CONVERT(CHAR(6),@lnRetCd)
      PRINT    @lvcMsg
      RETURN    @lnRetCd
    END

/**************  PRINT STEP 9 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed

/**************  PRINT JOB FOOTER DATA ****************************/

    SELECT @ldtProcessEndTime = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr
      @pchObjectName          = @lvcObjectName,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pdtProcessEndTime      = @ldtProcessEndTime
    RETURN  @lnRetCd
END
GO
/****************************************************************
 BEGIN MAINTENANCE WRAPPER:
*****************************************************************/
IF OBJECT_ID('dbo.tpzp_usable_membership_extr') IS NOT NULL
  PRINT '<<< CREATED PROCEDURE dbo.tpzp_usable_membership_extr >>>'
       
ELSE
  PRINT '<<<ERROR CREATING PROCEDURE dbo.tpzp_usable_membership_extr >>>'
GO

/****************************************************************
 END MAINTENANCE WRAPPER:
*****************************************************************/