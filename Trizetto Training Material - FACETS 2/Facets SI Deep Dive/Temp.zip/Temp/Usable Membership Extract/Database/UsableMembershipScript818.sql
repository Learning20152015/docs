 DECLARE @pLastRunDate         DATETIME         -- LastRunDate
 DECLARE @ldtLastJobRunDate         DATETIME         -- LastRunDate

IF (@pLastRunDate = CONVERT(DATETIME, '01/01/1900') OR @pLastRunDate IS NULL)
        BEGIN
            SELECT @ldtLastJobRunDate = CASE WHEN LAST_RUN_DATE = '01/01/1753'
                                             THEN (SELECT DATEADD(WEEK, -1, GETDATE()))
                                             WHEN LAST_RUN_DATE <> '01/01/1753'
                                             THEN LAST_RUN_DATE
                                        END
            FROM fabncdv1custom.dbo.tpzt_last_rundate
            WHERE INTERFACE_IDENTIFIER  = 'VE9006'
              AND INTERFACE_DESCRIPTION = 'USABLE_MEMEBERSHIP'
        END
    ELSE
        BEGIN
            SELECT @ldtLastJobRunDate = @pLastRunDate
        END

--select @ldtLastJobRunDate 

 SELECT DISTINCT
        GRPNUM = CAST(LEFT(ISNULL(LTRIM(RTRIM(comm.GRGR_ID)),''),8)AS CHAR(8)), --LEFT(SUBSTRING(LTRIM(RTRIM(grgr.GRGR_ID)),1,8) + SPACE(8),8),                      -- To be verified since power has 6 bytes
        METIND = space(1),
        MEMBNO = CAST(LEFT(ISNULL(LTRIM(RTRIM(comm.SBSB_ID)),''),12)AS CHAR(12)) , --LEFT(SUBSTRING(LTRIM(RTRIM(sbsb.SBSB_ID)),1,12) + SPACE(12),12), 
        LSTNAM = LEFT(SUBSTRING(LTRIM(RTRIM(comm.MEME_LAST_NAME)),1,15) + SPACE(15),15),
        FSTNAM = LEFT(SUBSTRING(LTRIM(RTRIM(comm.MEME_FIRST_NAME)),1,10) + SPACE(10),10),
        MIDNAM = LEFT(SUBSTRING(LTRIM(RTRIM(comm.MEME_MID_INIT)),1,1) + SPACE(1),1),
        BTHDAT = CAST(SUBSTRING(CONVERT(VARCHAR,comm.MEME_BIRTH_DT,112),1,1)+ SUBSTRING(convert(VARCHAR,comm.MEME_BIRTH_DT,112),3,6) AS varchar(7)), 
        SEXCOD = CAST(LEFT(ISNULL(LTRIM(RTRIM(comm.MEME_SEX)),''),1)AS CHAR(1)),
        SSN	   = CAST(LEFT(ISNULL(LTRIM(RTRIM(comm.MEME_SSN)),''),9)AS CHAR(9)),
        SALARY = RIGHT(REPLICATE('0', 9) + CAST(sbsa.SBSA_SAL_AMT AS VARCHAR) ,9),  --LIFMTHPRM = 'CNX', --CONVERT(VARCHAR(9),sbsa.SBSA_SAL_AMT),
        CLSCOD = CONVERT(VARCHAR(4),comm.CSCS_ID),
        cspi.CSPD_CAT,
        LIFMTHPRM = isnull((SELECT ISNULL(SBSR_PREM_SB,'0') 
						FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
							WHERE sbsr.SBSB_CK  = SBSB_CK  AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
							 AND  cspi.CSPD_CAT = 'L'
					),'0'),
		ADDMTHPRM = isnull((SELECT ISNULL(SBSR_PREM_SB,'0') 
						FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
							WHERE sbsr.SBSB_CK  = SBSB_CK  AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
							 AND  cspi.CSPD_CAT = 'L'
					),'0'),
		DLIMTHPRM = isnull((SELECT ISNULL(SBSR_PREM_SB,'0') 
						FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
							WHERE sbsr.SBSB_CK  = SBSB_CK  AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
							 AND  cspi.CSPD_CAT = 'L'
					),'0'),
		WDBMTHPRM = isnull((SELECT ISNULL(SBSR_PREM_SB,'0') 
						FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
							WHERE sbsr.SBSB_CK  = SBSB_CK  AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
							 AND  cspi.CSPD_CAT = 'L'
					),'0'),
		LTDMTHPRM = isnull((SELECT ISNULL(SBSR_PREM_SB,'0') 
						FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
							WHERE sbsr.SBSB_CK  = SBSB_CK  AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
							 AND  cspi.CSPD_CAT = 'L'
					),'0'),
		SLIMTHPRM = isnull((SELECT ISNULL(SBSR_PREM_SB,'0') 
						FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
							WHERE sbsr.SBSB_CK  = SBSB_CK  AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
							 AND  cspi.CSPD_CAT = 'L'
					),'0'),
		
		SADMTHPRM  = isnull((SELECT ISNULL(SBSR_PREM_SB,'0') 
						FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
							WHERE sbsr.SBSB_CK  = SBSB_CK  AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
							 AND  cspi.CSPD_CAT = 'L'
					),'0'),
		VLIFMTHPRM  = isnull((SELECT ISNULL(SBSR_PREM_SB,'0') 
								FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
									WHERE sbsr.SBSB_CK  = SBSB_CK  AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
									 AND  cspi.CSPD_CAT = 'L'
							),'0'),
		VLIFSPMTHPRM  = isnull((SELECT ISNULL(SBSR_PREM_SB,'0') 
								FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
									WHERE sbsr.SBSB_CK  = SBSB_CK  AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
									 AND  cspi.CSPD_CAT = 'L'
							),'0'),
		VLIFCHMTHPRM  = isnull((SELECT ISNULL(SBSR_PREM_SB,'0') 
								FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
									WHERE sbsr.SBSB_CK  = SBSB_CK  AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
									 AND  cspi.CSPD_CAT = 'L'
							),'0'),
		VADDMTHPRM  = isnull((SELECT ISNULL(SBSR_PREM_SB,'0') 
								FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
									WHERE sbsr.SBSB_CK  = SBSB_CK  AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
									 AND  cspi.CSPD_CAT = 'L'
							),'0'),
		VADDSPMTHPRM  = isnull((SELECT ISNULL(SBSR_PREM_SB,'0') 
								FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
									WHERE sbsr.SBSB_CK  = SBSB_CK  AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
									 AND  cspi.CSPD_CAT = 'L'
							),'0'),
		VADDCHMTHPRM  = isnull((SELECT ISNULL(SBSR_PREM_SB,'0') 
								FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
									WHERE sbsr.SBSB_CK  = SBSB_CK  AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
									 AND  cspi.CSPD_CAT = 'L'
							),'0'),
		VSTDMTHPRM  = isnull((SELECT ISNULL(SBSR_PREM_SB,'0') 
								FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
									WHERE sbsr.SBSB_CK  = SBSB_CK  AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
									 AND  cspi.CSPD_CAT = 'L'
							),'0'),
		VLTDMTHPRM  = isnull((SELECT ISNULL(SBSR_PREM_SB,'0') 
								FROM  fabncdv1..CMC_SBSR_SB_RATE sbsr1 
									WHERE sbsr.SBSB_CK  = SBSB_CK  AND  sbsr1.SBSB_CK = sbsr.SBSB_CK
									 AND  cspi.CSPD_CAT = 'L'
							),'0'),
		CARCOD		= 'U',
		LIFACTVOL	= (select BENEFIT_AMOUNT 
						  from fabncdv1stage.dbo.tpzt_usable_gtl_add gtl
							where gtl.GRGR_ID = comm.GRGR_CK and gtl.CSCS_ID = cspi.CSCS_ID
							  and gtl.CSPI_ID = 'L'   --cspi.CSPI_ID
							  --and g
					  ),   --Benefit Amount for Life
		
		LIFRPERUT	= '.06', --Benefit Rate per Unit - Life
		
		LIFRATSRC	= (select BENEFIT_TYPE 
						  from fabncdv1stage.dbo.tpzt_usable_gtl_add gtl
							where gtl.GRGR_ID = comm.GRGR_CK and gtl.CSCS_ID = cspi.CSCS_ID
							  and gtl.CSPI_ID = 'L' --cspi.CSPI_ID
					  ),
		ADDACTVOL   = (select BENEFIT_AMOUNT 
						  from fabncdv1stage.dbo.tpzt_usable_gtl_add gtl
							where gtl.GRGR_ID = comm.GRGR_CK and gtl.CSCS_ID = cspi.CSCS_ID
							  and gtl.CSPI_ID = 'L'   --cspi.CSPI_ID
							  --and g
					  ),
		
		ADDRPERUT = '.05',
		
		ADDRATSRC	= (select BENEFIT_AMOUNT 
						  from fabncdv1stage.dbo.tpzt_usable_gtl_add gtl
							where gtl.GRGR_ID = comm.GRGR_CK and gtl.CSCS_ID = cspi.CSCS_ID
							  and gtl.CSPI_ID = 'L'   --cspi.CSPI_ID
							  --and g
					  ),
					  
		
		DLIACTVOL = ( select [PLAN] 
						  from fabncdv1stage.dbo.tpzt_usable_dl usdl
							where usdl.GRGR_ID = comm.GRGR_CK and usdl.CSCS_ID = cspi.CSCS_ID
							  and usdl.CSPI_ID = ''  
		
					)
					  
		--cspi.CSPI_TERM_DT 
                
from fabncdv1stage.dbo.tpzt_comm_elig_extr comm 
		inner join fabncdv1..CMC_SBSA_SALARY sbsa ON comm.SBSB_CK = sbsa.SBSB_CK
													AND comm.GRGR_CK = sbsa.GRGR_CK
		inner join fabncdv1..CMC_CSPI_CS_PLAN cspi on cspi.CSPI_ID = comm.CSPI_ID
													--AND comm.SBSA_EFF_DT = sbsa.SBSA_EFF_DT
		inner join fabncdv1..CMC_SBSR_SB_RATE sbsr on sbsr.SBSB_CK = comm.SBSB_CK
													and sbsr.SBSB_CK = sbsa.SBSB_CK

WHERE comm.CSPD_CAT IN ('X','Y','L','A','S','T','Z','B','E','K')
AND comm.MEME_REL = 'M'  --(subsriber only)
AND cspi.CSPI_TERM_DT >= DATEADD(DD,1,CONVERT (VARCHAR(12),@ldtLastJobRunDate,110))
 		    AND cspi.CSPI_TERM_DT  > cspi.CSPI_EFF_DT
--AND comm.MEPE_TERM_DT BETWEEN GETDATE() AND DATEADD(mm,-12,comm.MEPE_TERM_DT)




--select BENEFIT_AMOUNT from fabncdv1stage.dbo.tpzt_usable_gtl_add gtl
--			where gtl.GRGR_ID = comm.GRGR_CK