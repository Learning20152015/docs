/*******************************************************************************************
*                                                                                          *
*  Script Name: Insert_tpzt_last_rundate                                                   *
*                                                                                          *
*  PURPOSE    : Insert rows for Interface last run date into dbo.tpzt_last_rundate         *
*                                                                                          *
*  DATABASE   : Custom                                                                     *
*                                                                                          *
*------------------------------------------------------------------------------------------*
*  REVISION HISTORY                                                                        *
*                                                                                          *
*  Date           Developer              Version   Description of Change                   *
*==========================================================================================*
* 10/18/2013      Sanket Shah      1.0       Initial Version                               *
* 01/21/2014      Ramu/Parul       1.1       Added CCM Interfaces                          *
* 06/04/2014      Divya Anne       1.2       Added ALERE Claims Extract                    *
* 06/10/2014      Divya Anne       1.3       Added AIM Claims Extract                      *
* 07/08/2014      Divya Anne       1.4       Added Health Equity Claims Extract            *
* 08/21/2014      Sameeksha Joshi  1.5       Added Health Equity Eligibility Extract       *
* 08/25/2014      Ghazala Ameen    1.6       Added Usable Membership Extract               *
*******************************************************************************************/

IF OBJECT_ID('dbo.tpzt_last_rundate') IS NOT NULL
BEGIN

    --TRUNCATE TABLE dbo.tpzt_last_rundate

    IF NOT EXISTS ( SELECT 1 FROM dbo.tpzt_last_rundate WHERE INTERFACE_IDENTIFIER = '6064')
    BEGIN
        INSERT INTO dbo.tpzt_last_rundate (INTERFACE_IDENTIFIER, INTERFACE_DESCRIPTION, LAST_RUN_DATE) VALUES ('6064', 'WF_POSITIVE_PAY', GETDATE())
    END

    IF NOT EXISTS ( SELECT 1 FROM dbo.tpzt_last_rundate WHERE INTERFACE_IDENTIFIER = '6072')
    BEGIN
        INSERT INTO dbo.tpzt_last_rundate (INTERFACE_IDENTIFIER, INTERFACE_DESCRIPTION, LAST_RUN_DATE) VALUES ('6072', 'PREMIUM_REFUND', '01/01/1753')
    END

    IF NOT EXISTS ( SELECT 1 FROM dbo.tpzt_last_rundate WHERE INTERFACE_IDENTIFIER = '6009')
    BEGIN
        INSERT INTO dbo.tpzt_last_rundate (INTERFACE_IDENTIFIER, INTERFACE_DESCRIPTION, LAST_RUN_DATE) VALUES ('6009', 'EOB', '01/01/1753')
    END

    IF NOT EXISTS ( SELECT 1 FROM dbo.tpzt_last_rundate WHERE INTERFACE_IDENTIFIER = '6009-1')
    BEGIN
        INSERT INTO dbo.tpzt_last_rundate (INTERFACE_IDENTIFIER, INTERFACE_DESCRIPTION, LAST_RUN_DATE) VALUES ('6009-1', 'EOP', '01/01/1753')
    END

    IF NOT EXISTS ( SELECT 1 FROM dbo.tpzt_last_rundate WHERE INTERFACE_IDENTIFIER = '6089')
    BEGIN
        INSERT INTO dbo.tpzt_last_rundate (INTERFACE_IDENTIFIER, INTERFACE_DESCRIPTION, LAST_RUN_DATE) VALUES ('6089', 'CCM_RECOVERY_INVOICE', '01/01/1753')
    END

    IF NOT EXISTS ( SELECT 1 FROM dbo.tpzt_last_rundate WHERE INTERFACE_IDENTIFIER = '6089-1')
    BEGIN
        INSERT INTO dbo.tpzt_last_rundate (INTERFACE_IDENTIFIER, INTERFACE_DESCRIPTION, LAST_RUN_DATE) VALUES ('6089-1', 'CCM_PREMIUM_INVOICE', '01/01/1753')
    END

    IF NOT EXISTS ( SELECT 1 FROM dbo.tpzt_last_rundate WHERE INTERFACE_IDENTIFIER = '60')
    BEGIN
        INSERT INTO dbo.tpzt_last_rundate (INTERFACE_IDENTIFIER, INTERFACE_DESCRIPTION, LAST_RUN_DATE) VALUES ('60', 'PRIME_MEDICAL_ACCUMULATOR', GETDATE())
    END

    IF NOT EXISTS ( SELECT 1 FROM dbo.tpzt_last_rundate WHERE INTERFACE_IDENTIFIER = 'VE9000')
    BEGIN
        INSERT INTO dbo.tpzt_last_rundate (INTERFACE_IDENTIFIER, INTERFACE_DESCRIPTION, LAST_RUN_DATE) VALUES ('VE9000', 'ALERE_MEDICAL_CLAIMS', '07/01/2014')
    END
    
    IF NOT EXISTS ( SELECT 1 FROM dbo.tpzt_last_rundate WHERE INTERFACE_IDENTIFIER = 'VE9001')
    BEGIN
        INSERT INTO dbo.tpzt_last_rundate (INTERFACE_IDENTIFIER, INTERFACE_DESCRIPTION, LAST_RUN_DATE) VALUES ('VE9001', 'ALERE_PHARMACY_CLAIMS', '07/01/2014')
    END
    
    IF NOT EXISTS ( SELECT 1 FROM dbo.tpzt_last_rundate WHERE INTERFACE_IDENTIFIER = 'VE9002')
    BEGIN
        INSERT INTO dbo.tpzt_last_rundate (INTERFACE_IDENTIFIER, INTERFACE_DESCRIPTION, LAST_RUN_DATE) VALUES ('VE9002', 'AIM_CLAIMS_EXTRACT', '07/01/2014')
    END
    
    IF NOT EXISTS ( SELECT 1 FROM dbo.tpzt_last_rundate WHERE INTERFACE_IDENTIFIER = 'VE9003')
    BEGIN
        INSERT INTO dbo.tpzt_last_rundate (INTERFACE_IDENTIFIER, INTERFACE_DESCRIPTION, LAST_RUN_DATE) VALUES ('VE9003', 'HEQ_MEDICAL_CLAIMS', '07/01/2014')
    END
    
    IF NOT EXISTS ( SELECT 1 FROM dbo.tpzt_last_rundate WHERE INTERFACE_IDENTIFIER = 'VE9004')
    BEGIN
        INSERT INTO dbo.tpzt_last_rundate (INTERFACE_IDENTIFIER, INTERFACE_DESCRIPTION, LAST_RUN_DATE) VALUES ('VE9004', 'HEQ_PHARMACY_CLAIMS', '07/01/2014')
    END
    
    IF NOT EXISTS ( SELECT 1 FROM dbo.tpzt_last_rundate WHERE INTERFACE_IDENTIFIER = 'VE9005')
    BEGIN
        INSERT INTO dbo.tpzt_last_rundate (INTERFACE_IDENTIFIER, INTERFACE_DESCRIPTION, LAST_RUN_DATE) VALUES ('VE9005', 'HEQ_ELIGIBILITY', GETDATE())
    END
	
	IF NOT EXISTS ( SELECT 1 FROM dbo.tpzt_last_rundate WHERE INTERFACE_IDENTIFIER = 'VE9006')
    BEGIN
        INSERT INTO dbo.tpzt_last_rundate (INTERFACE_IDENTIFIER, INTERFACE_DESCRIPTION, LAST_RUN_DATE) VALUES ('VE9006', 'USABLE_MEMBERSHIP', GETDATE())
    END
END
ELSE
    PRINT '<<< Table tpzt_last_rundate does not exist >>>'
GO 