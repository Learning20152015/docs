/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_sa') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_sa
  IF OBJECT_ID('dbo.tpzt_usable_sa') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_sa >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_sa >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_sa
/****************************************************************
**   NAME                  : dbo.tpzt_usable_sa
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : 
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0       07/31/2014   Shekhar Kadam      Intial Version
****************************************************************/
(   
    GRGR_ID             varchar(8) null,
    GRGR_ID_OLD         varchar(8) null,
    CSCS_ID             varchar(4) null,
    CSCS_ID_OLD         varchar(4) null,
    CSPI_ID             varchar(8) null,
    BENEFIT_AMOUNT      money null,
    BENEFIT_PERCENTAGE  varchar(8) null,
    BENEFIT_TYPE        char(1) null
	)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_sa') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_sa >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_sa >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
