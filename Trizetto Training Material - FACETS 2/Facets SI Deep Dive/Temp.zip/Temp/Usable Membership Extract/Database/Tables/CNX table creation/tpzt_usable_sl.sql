/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_sl') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_sl
  IF OBJECT_ID('dbo.tpzt_usable_sl') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_sl >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_sl >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_sl
/****************************************************************
**   NAME                  : dbo.tpzt_usable_sl
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : 
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0       07/31/2014   Shekhar Kadam      Intial Version
** 1.1       09/03/2014   Ghazala Ameen      Updated
****************************************************************/
(   
    GRGR_ID             varchar(8) null,
    GRGR_ID_OLD         varchar(8) null,
    CSCS_ID             varchar(4) null,
    CSCS_ID_OLD         varchar(4) null,
    CSPI_ID             varchar(8) null,
    BENEFIT_AMOUNT      money null,
    BENEFIT_PERCENTAGE  varchar(8) null,
    BENEFIT_TYPE        char(1) null
	)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_sl') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_sl >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_sl >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
