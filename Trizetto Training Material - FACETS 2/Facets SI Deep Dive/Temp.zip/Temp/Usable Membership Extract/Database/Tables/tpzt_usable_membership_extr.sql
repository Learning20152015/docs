/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_membership_extr') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_membership_extr
  IF OBJECT_ID('dbo.tpzt_usable_membership_extr') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_membership_extr >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_membership_extr >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_membership_extr
/****************************************************************
**   NAME                  : dbo.tpzt_usable_membership_extr
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the records related to USAble Weekly Membership Extract.
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0       08/20/2014   Ghazala Ameen      Intial Version
** 1.1       08/26/2014   Ghazala Ameen      Updated the data size of the field
****************************************************************/
(   
	GRPNUM             VARCHAR (8) NULL,
	METIND             VARCHAR (1) NULL,
	MEMBNO             VARCHAR (12) NULL,
	LSTNAM             VARCHAR (15) NULL,
	FSTNAM             VARCHAR (10) NULL,
	MIDNAM             VARCHAR (1) NULL,
	BTHDAT             VARCHAR (8) NULL,
	SEXCOD             VARCHAR (1) NULL,
	SSN                VARCHAR (9) NULL,
	SALARY             VARCHAR (9) NULL,
	CLSCOD             VARCHAR (4) NULL,
	LIFMTHPRM          VARCHAR (6) NULL,
	ADDMTHPRM          VARCHAR (6) NULL,
	DLIMTHPRM          VARCHAR (6) NULL,
	WDBMTHPRM          VARCHAR (6) NULL,
	LTDMTHPRM          VARCHAR (6) NULL,
	SLIMTHPRM          VARCHAR (6) NULL,
	SADMTHPRM          VARCHAR (6) NULL,
	VLIFMTHPRM         VARCHAR (6) NULL,
	VLIFSPMTHPRM       VARCHAR (6) NULL,
	VLIFCHMTHPRM       VARCHAR (6) NULL,
	VADDMTHPRM         VARCHAR (6) NULL,
	VADDSPMTHPRM       VARCHAR (6) NULL,
	VADDCHMTHPRM       VARCHAR (6) NULL,
	VSTDMTHPRM         VARCHAR (6) NULL,
	VLTDMTHPRM         VARCHAR (6) NULL,
	CARCOD             VARCHAR (2) DEFAULT ('U'+space((1))) NULL,
	LIFACTVOL          VARCHAR (12) NULL,
	LIFRPERUT          VARCHAR (6) NULL,
	LIFRATSRC          VARCHAR (2) NULL,
	ADDACTVOL          VARCHAR (12) NULL,
	ADDRPERUT          VARCHAR (6) NULL,
	ADDRATSRC          VARCHAR (2) NULL,
	DLIACTVOL          VARCHAR (12) NULL,
	DLIRPERUT          VARCHAR (6) NULL,
	DLIRATSRC          VARCHAR (2) NULL,
	WDBACTVOL          VARCHAR (12) NULL,
	WDBRPERUT          VARCHAR (6) NULL,
	WDBRATSRC          VARCHAR (2) NULL,
	LTDACTVOL          VARCHAR (12) NULL,
	LTDRPERUT          VARCHAR (6) NULL,
	LTDRATSRC          VARCHAR (2) NULL,
	SLIACTVOL          VARCHAR (12) NULL,
	SLIRPERUT          VARCHAR (6) NULL,
	SLIRATSRC          VARCHAR (2) NULL,
	SADACTVOL          VARCHAR (12) NULL,
	SADRPERUT          VARCHAR (6) NULL,
	SADRATSRC          VARCHAR (2) NULL,
	VLIFACTVOL         VARCHAR (12) NULL,
	VLIFRPERUT         VARCHAR (6) NULL,
	VLIFRATSRC         VARCHAR (2) NULL,
	VLIFSPACTVOL       VARCHAR (12) NULL,
	VLIFSPRPERUT       VARCHAR (6) NULL,
	VLIFSPRATSRC       VARCHAR (2) NULL,
	VLIFCHACTVOL       VARCHAR (12) NULL,
	VLIFCHRPERUT       VARCHAR (6) NULL,
	VLIFCHRATSRC       VARCHAR (2) NULL,
	VADDACTVOL         VARCHAR (12) NULL,
	VADDRPERUT         VARCHAR (6) NULL,
	VADDRATSRC         VARCHAR (2) NULL,
	VADDSPACTVOL       VARCHAR (12) NULL,
	VADDSPRPERUT       VARCHAR (6) NULL,
	VADDSPRATSRC       VARCHAR (2) NULL,
	VADDCHACTVOL       VARCHAR (12) NULL,
	VADDCHRPERUT       VARCHAR (6) NULL,
	VADDCHRATSRC       VARCHAR (2) NULL,
	VSTDACTVOL         VARCHAR (12) NULL,
	VSTDRPERUT         VARCHAR (6) NULL,
	VSTDRATSRC         VARCHAR (2) NULL,
	VLTDACTVOL         VARCHAR (12) NULL,
	VLTDRPERUT         VARCHAR (6) NULL,
	VLTDRATSRC         VARCHAR (2) NULL,
	PDTHRU             VARCHAR (8) NULL,
	HIRDAT             VARCHAR (8) NULL,
	AGE                VARCHAR (3) NULL,
	ACCTNO             VARCHAR (10) NULL,
	CLSEFFDAT          VARCHAR (8) NULL,
	CLSEXPDAT          VARCHAR (8) NULL,
	LIFEFFDAT          VARCHAR (8) NULL,
	LIFEXPDAT          VARCHAR (8) NULL,
	LIFREASCD          VARCHAR (4) NULL,
	LIFLSTCHG          VARCHAR (8) NULL,
	ADDEFFDAT          VARCHAR (8) NULL,
	ADDEXPDAT          VARCHAR (8) NULL,
	ADDREASCD          VARCHAR (4) NULL,
	ADDLSTCHG          VARCHAR (8) NULL,
	DLIEFFDAT          VARCHAR (8) NULL,
	DLIEXPDAT          VARCHAR (8) NULL,
	DLIREASCD          VARCHAR (4) NULL,
	DLILSTCHG          VARCHAR (8) NULL,
	WDBEFFDAT          VARCHAR (8) NULL,
	WDBEXPDAT          VARCHAR (8) NULL,
	WDBREASCD          VARCHAR (4) NULL,
	WDBLSTCHG          VARCHAR (8) NULL,
	LTDEFFDAT          VARCHAR (8) NULL,
	LTDEXPDAT          VARCHAR (8) NULL,
	LTDREASCD          VARCHAR (4) NULL,
	LTDLSTCHG          VARCHAR (8) NULL,
	SLIEFFDAT          VARCHAR (8) NULL,
	SLIEXPDAT          VARCHAR (8) NULL,
	SLIREASCD          VARCHAR (4) NULL,
	SLILSTCHG          VARCHAR (8) NULL,
	SADEFFDAT          VARCHAR (8) NULL,
	SADEXPDAT          VARCHAR (8) NULL,
	SADREASCD          VARCHAR (4) NULL,
	SADLSTCHG          VARCHAR (8) NULL,
	VLIFEFFDAT         VARCHAR (8) NULL,
	VLIFDEXPDAT        VARCHAR (8) NULL,
	VLIFREASCD         VARCHAR (4) NULL,
	VLIFLSTCHG         VARCHAR (8) NULL,
	VLIFEFFDAT_SPOUSE  VARCHAR (8) NULL,
	VLIFDEXPDAT_SPOUSE VARCHAR (8) NULL,
	VLIFREASCD_SPOUSE  VARCHAR (4) NULL,
	VLIFLSTCHG_SPOUSE  VARCHAR (8) NULL,
	VLIFEFFDAT_CHILD   VARCHAR (8) NULL,
	VLIFDEXPDAT_CHILD  VARCHAR (8) NULL,
	VLIFREASCD_CHILD   VARCHAR (4) NULL,
	VLIFLSTCHG_CHILD   VARCHAR (8) NULL,
	VADDEFFDAT         VARCHAR (8) NULL,
	VADDEXPDAT         VARCHAR (8) NULL,
	VADDREASCD         VARCHAR (4) NULL,
	VADDLSTCHG         VARCHAR (8) NULL,
	VADDSPEFFDAT       VARCHAR (8) NULL,
	VADDSPEXPDAT       VARCHAR (8) NULL,
	VADDSPREASCD       VARCHAR (4) NULL,
	VADDSPLSTCHG       VARCHAR (8) NULL,
	VADDCHEFFDAT       VARCHAR (8) NULL,
	VADDCHEXPDAT       VARCHAR (8) NULL,
	VADDCHREASCD       VARCHAR (4) NULL,
	VADDCHLSTCHG       VARCHAR (8) NULL,
	VSTDEFFDAT         VARCHAR (8) NULL,
	VSTDDEXPDAT        VARCHAR (8) NULL,
	VSTDREASCD         VARCHAR (4) NULL,
	VSTDLSTCHG         VARCHAR (8) NULL,
	VLTDEFFDAT         VARCHAR (8) NULL,
	VLTDDEXPDAT        VARCHAR (8) NULL,
	VLTDREASCD         VARCHAR (4) NULL,
	VLTDLSTCHG         VARCHAR (8) NULL
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_membership_extr') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_membership_extr >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_membership_extr >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
