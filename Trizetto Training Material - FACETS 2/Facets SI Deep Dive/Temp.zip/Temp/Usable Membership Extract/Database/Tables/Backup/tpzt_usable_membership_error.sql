/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_membership_error') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_membership_error
  IF OBJECT_ID('dbo.tpzt_usable_membership_error') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_membership_error >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_membership_error >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_membership_error
/****************************************************************
**   NAME                  : dbo.tpzt_usable_membership_error
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the records with invalid or missing data.
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0       08/20/2014   Ghazala Ameen      Intial Version
****************************************************************/
(   
    GRPNUM          VARCHAR(8)        NULL,
    METIND          VARCHAR(1)        NULL,
    MEMBNO          VARCHAR(12)       NULL,
    LSTNAM          VARCHAR(15)       NULL,
    FSTNAM          VARCHAR(10)       NULL,
    BTHDAT          VARCHAR(7)        NULL,
    SEXCOD          VARCHAR(1)        NULL,
    SSN             VARCHAR(9)        NULL,
    CLSCOD          VARCHAR(4)        NULL,
    CARCOD          VARCHAR(2)        NULL,
    PDTHRU          VARCHAR(7)        NULL,
    HIRDAT          VARCHAR(7)        NULL,
    AGE             VARCHAR(3)        NULL,
    ACCTNO          VARCHAR(10)       NULL
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_membership_error') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_membership_error >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_membership_error >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
