/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_meme_extr') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_meme_extr 
  IF OBJECT_ID('dbo.tpzt_usable_meme_extr') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_meme_extr >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_meme_extr >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
/****************************************************************
**   NAME                  : dbo.tpzt_usable_meme_extr
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the records related to Usable Weekly Member Extract 
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0       08/05/2014   Shekhar Kadam     Intial Version
****************************************************************/
CREATE TABLE dbo.tpzt_usable_meme_extr 
(   
       GRPNUM          VARCHAR(8)				    NULL,
        METIND          VARCHAR(1)					NULL,
        MEMBNO          VARCHAR(12)					NULL,
        LSTNAM          VARCHAR(15)					NULL,
        FSTNAM          VARCHAR(10)					NULL,
        MIDNAM          VARCHAR(1)					NULL,
        BTHDAT          VARCHAR(7)					NULL,
        SEXCOD          VARCHAR(1)					NULL,
        SSN             VARCHAR(9)					NULL,
        SALARY          VARCHAR(9)					NULL,
        CLSCOD          VARCHAR(4)					NULL,
        LIFMTHPRM       VARCHAR(6)				NULL,
        ADDMTHPRM       VARCHAR(6)				NULL,
        DLIMTHPRM       VARCHAR(6)				NULL,
        WDBMTHPRM       VARCHAR(6)				NULL,
        LTDMTHPRM       VARCHAR(6)				NULL,
        SLIMTHPRM       VARCHAR(6)				NULL,
        SADMTHPRM       VARCHAR(6)				NULL,
        VLIFMTHPRM		VARCHAR(6)				NULL,--Voluntary Life Rate
        VADDMTHPRM      VARCHAR(6)				NULL,--Voluntary ADD Rate
        VSTDMTHPRM      VARCHAR(6)				NULL,--Voluntary STD Rate
        VLTDMTHPRM		VARCHAR(6)				NULL,--Voluntary LID Rate
        CARCOD          VARCHAR(2)					NULL,
        LIFACTVOL      VARCHAR(12)				NULL,
		LIFRPERUT       VARCHAR(6)				NULL,
		LIFRATSRC       VARCHAR(2)					NULL,
		ADDACTVOL      VARCHAR(12)				NULL,
		ADDRPERUT       VARCHAR(6)				NULL,
		ADDRATSRC       VARCHAR(2)					NULL,
		DLIACTVOL      VARCHAR(12)				NULL,
		DLIRPERUT       VARCHAR(6)				NULL,
		DLIRATSRC       VARCHAR(2)					NULL,
		WDBACTVOL      VARCHAR(12)				NULL,
		WDBRPERUT       VARCHAR(6)				NULL,
		WDBRATSRC       VARCHAR(2)					NULL,
		LTDACTVOL      VARCHAR(12)				NULL,
		LTDRPERUT       VARCHAR(6)				NULL,
		LTDRATSRC       VARCHAR(2)					NULL,
		SLIACTVOL      VARCHAR(12)				NULL,
		SLIRPERUT       VARCHAR(6)				NULL,
		SLIRATSRC       VARCHAR(2)					NULL,
		SADACTVOL      VARCHAR(12)				NULL,
		SADRPERUT       VARCHAR(6)				NULL,
		SADRATSRC       VARCHAR(2)					NULL,
		VLIFACTVOL     VARCHAR(12)				NULL,--Benefit Amount for Voluntary Life
		VLIFRPERUT      VARCHAR(6)				NULL,--Benefit Rate Per Unit Voluntary Life
		VLIFRATSRC		VARCHAR(2)					NULL,--Rate Method for Voluntary Life
		VADDACTVOL     VARCHAR(12)				NULL,--Benefit Amount for Voluntary ADD
		VADDRPERUT		VARCHAR(6)				NULL,--Benefit Rate Per Unit Voluntary ADD
		VADDRATSRC		VARCHAR(2)					NULL,--Rate Method for Voluntary ADD
		VSTDACTVOL		VARCHAR(12)				NULL,--Benefit Amount for Voluntary STD
		VSTDRPERUT		VARCHAR(6)				NULL,--Benefit Rate Per Unit Voluntary STD
		VSTDRATSRC		VARCHAR(2)					NULL,--Rate Method for Voluntary STD
		VLTDACTVOL		VARCHAR(12)				NULL,--Benefit Amount for Voluntary LTD
		VLTDRPERUT		VARCHAR(6)				NULL,--Benefit Rate Per Unit Voluntary LTD
		VLTDRATSRC		VARCHAR(2)					NULL,--Rate Method for Voluntary LTD
		PDTHRU          VARCHAR(7)					NULL,
		HIRDAT          VARCHAR(7)					NULL,
		AGE             VARCHAR(3)					NULL,
		ACCTNO          VARCHAR(10)					NULL,
		CLSEFFDAT       VARCHAR(7)					NULL,
		CLSEXPDAT       VARCHAR(7)					NULL,
		LIFEFFDAT       VARCHAR(7)					NULL,
		LIFEXPDAT       VARCHAR(7)					NULL,
		LIFREASCD       VARCHAR(4)					NULL,
		LIFLSTCHG       VARCHAR(7)					NULL,
		ADDEFFDAT       VARCHAR(7)					NULL,
		ADDEXPDAT       VARCHAR(7)					NULL,
		ADDREASCD       VARCHAR(4)					NULL,
		ADDLSTCHG       VARCHAR(7)					NULL,
		DLIEFFDAT       VARCHAR(7)					NULL,
		DLIEXPDAT       VARCHAR(7)					NULL,
		DLIREASCD       VARCHAR(4)					NULL,
		DLILSTCHG       VARCHAR(7)					NULL,
		WDBEFFDAT       VARCHAR(7)					NULL,
		WDBEXPDAT       VARCHAR(7)					NULL,
		WDBREASCD       VARCHAR(4)					NULL,
		WDBLSTCHG       VARCHAR(7)					NULL,
		LTDEFFDAT       VARCHAR(7)					NULL,
		LTDEXPDAT       VARCHAR(7)					NULL,
		LTDREASCD       VARCHAR(4)					NULL,
		LTDLSTCHG       VARCHAR(7)					NULL,
		SLIEFFDAT       VARCHAR(7)					NULL,
		SLIEXPDAT       VARCHAR(7)					NULL,
		SLIREASCD       VARCHAR(4)					NULL,
		SLILSTCHG       VARCHAR(7)					NULL,
		SADEFFDAT       VARCHAR(7)					NULL,
		SADEXPDAT       VARCHAR(7)					NULL,
		SADREASCD       VARCHAR(4)					NULL,
		SADLSTCHG       VARCHAR(7)					NULL,
		VLIFEFFDAT		VARCHAR(7)					NULL,--Voluntary Life Effective Date
		VLIFDEXPDAT		VARCHAR(7)					NULL,--Voluntary Life Expiration Date
		VLIFREASCD		VARCHAR(4)					NULL,--Voluntary Life Termination Reason
		VLIFLSTCHG		VARCHAR(7)					NULL,--Voluntary Life Last Change Date
		VADDEFFDAT		VARCHAR(7)					NULL,--Voluntary ADD Effective Date
		VADDDEXPDAT		VARCHAR(7)					NULL,--Voluntary ADD  Expiration Date
		VADDREASCD		VARCHAR(4)					NULL,--Voluntary ADD Termination Reason
		VADDLSTCHG		VARCHAR(7)					NULL,--Voluntary ADD Last Change Date
		VSTDEFFDAT		VARCHAR(7)					NULL,--Voluntary STD Effective Date
		VSTDDEXPDAT		VARCHAR(7)					NULL,--Voluntary STD Expiration Date
		VSTDREASCD		VARCHAR(4)					NULL,--Voluntary STD Termination Reason
		VSTDLSTCHG		VARCHAR(7)					NULL,--Voluntary STD Last Change Date 
		VLTDEFFDAT		VARCHAR(7)					NULL,--Voluntary LTD Effective Date   
		VLTDDEXPDAT		VARCHAR(7)					NULL,--Voluntary LTD Expiration Date 
		VLTDREASCD		VARCHAR(4)					NULL,--Voluntary LTD Termination Reason
		VLTDLSTCHG		VARCHAR(7)					NULL,--Voluntary LTD Last Change Date  
		
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_meme_extr') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_meme_extr >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_meme_extr >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

 


