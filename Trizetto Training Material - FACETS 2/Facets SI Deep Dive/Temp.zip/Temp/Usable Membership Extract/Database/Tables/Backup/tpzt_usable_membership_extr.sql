/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_membership_extr') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_membership_extr
  IF OBJECT_ID('dbo.tpzt_usable_membership_extr') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_membership_extr >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_membership_extr >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_membership_extr
/****************************************************************
**   NAME                  : dbo.tpzt_usable_membership_extr
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the records related to USAble Weekly Membership Extract.
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0       08/20/2014   Ghazala Ameen      Intial Version
****************************************************************/
(   
    GRPNUM                  VARCHAR(8)        NULL,
    METIND                  VARCHAR(1)        DEFAULT SPACE(1),
    MEMBNO                  VARCHAR(12)       NULL,
    LSTNAM                  VARCHAR(15)       NULL,
    FSTNAM                  VARCHAR(10)       NULL,
    MIDNAM                  VARCHAR(1)        NULL,
    BTHDAT                  DECIMAL(7,0)      NULL,
    SEXCOD                  VARCHAR(1)        NULL,
    SSN                     VARCHAR(9)        NULL,
    SALARY                  DECIMAL(9,0)      NULL,
    CLSCOD                  VARCHAR(4)        NULL,
    LIFMTHPRM               DECIMAL(6,2)      NULL,
    ADDMTHPRM               DECIMAL(6,2)      NULL,
    DLIMTHPRM               DECIMAL(6,2)      NULL,
    WDBMTHPRM               DECIMAL(6,2)      NULL,
    LTDMTHPRM               DECIMAL(6,2)      NULL,
    SLIMTHPRM               DECIMAL(6,2)      NULL,
    SADMTHPRM               DECIMAL(6,2)      NULL,
    VLIFMTHPRM              DECIMAL(6,2)      NULL,
    VLIFSPMTHPRM            DECIMAL(6,2)      NULL,
    VLIFCHMTHPRM            DECIMAL(6,2)      NULL,
    VADDMTHPRM              DECIMAL(6,2)      NULL,
    VADDSPMTHPRM            DECIMAL(6,2)      NULL,
    VADDCHMTHPRM            DECIMAL(6,2)      NULL,
    VSTDMTHPRM              DECIMAL(6,2)      NULL,
    VLTDMTHPRM              DECIMAL(6,2)      NULL,
    CARCOD                  VARCHAR(2)        DEFAULT 'U' + SPACE(1),
    LIFACTVOL               DECIMAL(12,4)     NULL,
    LIFRPERUT               DECIMAL(6,2)      NULL,
    LIFRATSRC               VARCHAR(2)        NULL,
    ADDACTVOL               DECIMAL(12,4)     NULL,
    ADDRPERUT               DECIMAL(6,2)      NULL,
    ADDRATSRC               VARCHAR(2)        NULL,
    DLIACTVOL               DECIMAL(12,4)     NULL,
    DLIRPERUT               DECIMAL(6,2)      NULL,
    DLIRATSRC               VARCHAR(2)        NULL,
    WDBACTVOL               DECIMAL(12,4)     NULL,
    WDBRPERUT               DECIMAL(6,2)      NULL,
    WDBRATSRC               VARCHAR(2)        NULL,
    LTDACTVOL               DECIMAL(12,4)     NULL,
    LTDRPERUT               DECIMAL(6,2)      NULL,
    LTDRATSRC               VARCHAR(2)        NULL,
    SLIACTVOL               DECIMAL(12,4)     NULL,
    SLIRPERUT               DECIMAL(6,2)      NULL,
    SLIRATSRC               VARCHAR(2)        NULL,
    SADACTVOL               DECIMAL(12,4)     NULL,
    SADRPERUT               DECIMAL(6,2)      NULL,
    SADRATSRC               VARCHAR(2)        NULL,
    VLIFACTVOL              DECIMAL(12,4)     NULL,
    VLIFRPERUT              DECIMAL(6,2)      NULL,
    VLIFRATSRC              VARCHAR(2)        NULL,
    VLIFSPACTVOL            DECIMAL(12,4)     NULL,
    VLIFSPRPERUT            DECIMAL(6,2)      NULL,
    VLIFSPRATSRC            VARCHAR(2)        NULL,
    VLIFCHACTVOL            DECIMAL(12,4)     NULL,
    VLIFCHRPERUT            DECIMAL(6,2)      NULL,
    VLIFCHRATSRC            VARCHAR(2)        NULL,
    VADDACTVOL              DECIMAL(12,4)     NULL,
    VADDRPERUT              DECIMAL(6,2)      NULL,
    VADDRATSRC              VARCHAR(2)        NULL,
    VADDSPACTVOL            DECIMAL(12,4)     NULL,
    VADDSPRPERUT            DECIMAL(6,2)      NULL,
    VADDSPRATSRC            VARCHAR(2)        NULL,
    VADDCHACTVOL            DECIMAL(12,4)     NULL,
    VADDCHRPERUT            DECIMAL(6,2)      NULL,
    VADDCHRATSRC            VARCHAR(2)        NULL,
    VSTDACTVOL              DECIMAL(12,4)     NULL,
    VSTDRPERUT              DECIMAL(6,2)      NULL,
    VSTDRATSRC              VARCHAR(2)        NULL,
    VLTDACTVOL              DECIMAL(12,4)     NULL,
    VLTDRPERUT              DECIMAL(6,2)      NULL,
    VLTDRATSRC              VARCHAR(2)        NULL,
    PDTHRU                  DECIMAL(7,0)      NULL,
    HIRDAT                  DECIMAL(7,0)      NULL,
    AGE                     DECIMAL(3,0)      NULL,
    ACCTNO                  VARCHAR(10)       NULL,
    CLSEFFDAT               DECIMAL(7,0)      NULL,
    CLSEXPDAT               DECIMAL(7,0)      NULL,
    LIFEFFDAT               DECIMAL(7,0)      NULL,
    LIFEXPDAT               DECIMAL(7,0)      NULL,
    LIFREASCD               VARCHAR(4)        NULL,
    LIFLSTCHG               DECIMAL(7,0)      NULL,
    ADDEFFDAT               DECIMAL(7,0)      NULL,
    ADDEXPDAT               DECIMAL(7,0)      NULL,
    ADDREASCD               VARCHAR(4)        NULL,
    ADDLSTCHG               DECIMAL(7,0)      NULL,
    DLIEFFDAT               DECIMAL(7,0)      NULL,
    DLIEXPDAT               DECIMAL(7,0)      NULL,
    DLIREASCD               VARCHAR(4)        NULL,
    DLILSTCHG               DECIMAL(7,0)      NULL,
    WDBEFFDAT               DECIMAL(7,0)      NULL,
    WDBEXPDAT               DECIMAL(7,0)      NULL,
    WDBREASCD               VARCHAR(4)        NULL,
    WDBLSTCHG               DECIMAL(7,0)      NULL,
    LTDEFFDAT               DECIMAL(7,0)      NULL,
    LTDEXPDAT               DECIMAL(7,0)      NULL,
    LTDREASCD               VARCHAR(4)        NULL,
    LTDLSTCHG               DECIMAL(7,0)      NULL,
    SLIEFFDAT               DECIMAL(7,0)      NULL,
    SLIEXPDAT               DECIMAL(7,0)      NULL,
    SLIREASCD               VARCHAR(4)        NULL,
    SLILSTCHG               DECIMAL(7,0)      NULL,
    SADEFFDAT               DECIMAL(7,0)      NULL,
    SADEXPDAT               DECIMAL(7,0)      NULL,
    SADREASCD               VARCHAR(4)        NULL,
    SADLSTCHG               DECIMAL(7,0)      NULL,
    VLIFEFFDAT              DECIMAL(7,0)      NULL,
    VLIFDEXPDAT             DECIMAL(7,0)      NULL,
    VLIFREASCD              VARCHAR(4)        NULL,
    VLIFLSTCHG              DECIMAL(7,0)      NULL,
    VLIFEFFDAT              DECIMAL(7,0)      NULL,
    VLIFDEXPDAT             DECIMAL(7,0)      NULL,
    VLIFREASCD              VARCHAR(4)        NULL,
    VLIFLSTCHG              DECIMAL(7,0)      NULL,
    VLIFEFFDAT              DECIMAL(7,0)      NULL,
    VLIFDEXPDAT             DECIMAL(7,0)      NULL,
    VLIFREASCD              VARCHAR(4)        NULL,
    VLIFLSTCHG              DECIMAL(7,0)      NULL,
    VADDEFFDAT              DECIMAL(7,0)      NULL,
    VADDEXPDAT              DECIMAL(7,0)      NULL,
    VADDREASCD              VARCHAR(4)        NULL,
    VADDLSTCHG              DECIMAL(7,0)      NULL,
    VADDSPEFFDAT            DECIMAL(7,0)      NULL,
    VADDSPEXPDAT            DECIMAL(7,0)      NULL,
    VADDSPREASCD            VARCHAR(4)        NULL,
    VADDSPLSTCHG            DECIMAL(7,0)      NULL,
    VADDCHEFFDAT            DECIMAL(7,0)      NULL,
    VADDCHEXPDAT            DECIMAL(7,0)      NULL,
    VADDCHREASCD            VARCHAR(4)        NULL,
    VADDCHLSTCHG            DECIMAL(7,0)      NULL,
    VSTDEFFDAT              DECIMAL(7,0)      NULL,
    VSTDDEXPDAT             DECIMAL(7,0)      NULL,
    VSTDREASCD              VARCHAR(4)        NULL,
    VSTDLSTCHG              DECIMAL(7,0)      NULL,
    VLTDEFFDAT              DECIMAL(7,0)      NULL,
    VLTDDEXPDAT             DECIMAL(7,0)      NULL,
    VLTDREASCD              VARCHAR(4)        NULL,
    VLTDLSTCHG              DECIMAL(7,0)      NULL
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_membership_extr') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_membership_extr >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_membership_extr >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
