/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_membership_extr_new') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_membership_extr_new
  IF OBJECT_ID('dbo.tpzt_usable_membership_extr_new') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_membership_extr_new >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_membership_extr_new >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_membership_extr_new
/****************************************************************
**   NAME                  : dbo.tpzt_usable_membership_extr_new
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the present day records for USAble Membership Extract.
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0      08/20/2014   Ghazala Ameen       Intial Version
****************************************************************/
(
    GRPNUM                  VARCHAR(8)      NULL,
    MEMBNO                  VARCHAR(12)     NULL,
    LSTNAM                  VARCHAR(15)     NULL,
    FSTNAM                  VARCHAR(10)     NULL,
    MIDNAM                  VARCHAR(1)      NULL,
    BTHDAT                  VARCHAR(7)      NULL,
    SEXCOD                  VARCHAR(1)      NULL,
    SSN                     VARCHAR(9)      NULL,
    SALARY                  VARCHAR(9)      NULL,
    CLSCOD                  VARCHAR(4)      NULL,
    LIFMTHPRM               VARCHAR(6)      NULL,
    ADDMTHPRM               VARCHAR(6)      NULL,
    DLIMTHPRM               VARCHAR(6)      NULL,
    WDBMTHPRM               VARCHAR(6)      NULL,
    LTDMTHPRM               VARCHAR(6)      NULL,
    SLIMTHPRM               VARCHAR(6)      NULL,
    SADMTHPRM               VARCHAR(6)      NULL,
    VLIFMTHPRM              VARCHAR(6)      NULL,
    VLIFSPMTHPRM            VARCHAR(6)      NULL,
    VLIFCHMTHPRM            VARCHAR(6)      NULL,
    VADDMTHPRM              VARCHAR(6)      NULL,
    VADDSPMTHPRM            VARCHAR(6)      NULL,
    VADDCHMTHPRM            VARCHAR(6)      NULL,
    VSTDMTHPRM              VARCHAR(6)      NULL,
    VLTDMTHPRM              VARCHAR(6)      NULL,
    LIFACTVOL               VARCHAR(12)     NULL,
    LIFRPERUT               VARCHAR(6)      NULL,
    LIFRATSRC               VARCHAR(2)      NULL,
    ADDACTVOL               VARCHAR(12)     NULL,
    ADDRPERUT               VARCHAR(6)      NULL,
    ADDRATSRC               VARCHAR(2)      NULL,
    DLIACTVOL               VARCHAR(12)     NULL,
    DLIRPERUT               VARCHAR(6)      NULL,
    DLIRATSRC               VARCHAR(2)      NULL,
    WDBACTVOL               VARCHAR(12)     NULL,
    WDBRPERUT               VARCHAR(6)      NULL,
    WDBRATSRC               VARCHAR(2)      NULL,
    LTDACTVOL               VARCHAR(12)     NULL,
    LTDRPERUT               VARCHAR(6)      NULL,
    LTDRATSRC               VARCHAR(2)      NULL,
    SLIACTVOL               VARCHAR(12)     NULL,
    SLIRPERUT               VARCHAR(6)      NULL,
    SLIRATSRC               VARCHAR(2)      NULL,
    SADACTVOL               VARCHAR(12)     NULL,
    SADRPERUT               VARCHAR(6)      NULL,
    SADRATSRC               VARCHAR(2)      NULL,
    VLIFACTVOL              VARCHAR(12)     NULL,
    VLIFRPERUT              VARCHAR(6)      NULL,
    VLIFRATSRC              VARCHAR(2)      NULL,
    VLIFSPACTVOL            VARCHAR(12)     NULL,
    VLIFSPRPERUT            VARCHAR(6)      NULL,
    VLIFSPRATSRC            VARCHAR(2)      NULL,
    VLIFCHACTVOL            VARCHAR(12)     NULL,
    VLIFCHRPERUT            VARCHAR(6)      NULL,
    VLIFCHRATSRC            VARCHAR(2)      NULL,
    VADDACTVOL              VARCHAR(12)     NULL,
    VADDRPERUT              VARCHAR(6)      NULL,
    VADDRATSRC              VARCHAR(2)      NULL,
    VADDSPACTVOL            VARCHAR(12)     NULL,
    VADDSPRPERUT            VARCHAR(6)      NULL,
    VADDSPRATSRC            VARCHAR(2)      NULL,
    VADDCHACTVOL            VARCHAR(12)     NULL,
    VADDCHRPERUT            VARCHAR(6)      NULL,
    VADDCHRATSRC            VARCHAR(2)      NULL,
    VSTDACTVOL              VARCHAR(12)     NULL,
    VSTDRPERUT              VARCHAR(6)      NULL,
    VSTDRATSRC              VARCHAR(2)      NULL,
    VLTDACTVOL              VARCHAR(12)     NULL,
    VLTDRPERUT              VARCHAR(6)      NULL,
    VLTDRATSRC              VARCHAR(2)      NULL,
    PDTHRU                  VARCHAR(7)      NULL,
    HIRDAT                  VARCHAR(7)      NULL,
    AGE                     VARCHAR(3)      NULL,
    ACCTNO                  VARCHAR(10)     NULL,
    CLSEFFDAT               VARCHAR(7)      NULL,
    CLSEXPDAT               VARCHAR(7)      NULL,
    LIFEFFDAT               VARCHAR(7)      NULL,
    LIFEXPDAT               VARCHAR(7)      NULL,
    LIFREASCD               VARCHAR(4)      NULL,
    LIFLSTCHG               VARCHAR(7)      NULL,
    ADDEFFDAT               VARCHAR(7)      NULL,
    ADDEXPDAT               VARCHAR(7)      NULL,
    ADDREASCD               VARCHAR(4)      NULL,
    ADDLSTCHG               VARCHAR(7)      NULL,
    DLIEFFDAT               VARCHAR(7)      NULL,
    DLIEXPDAT               VARCHAR(7)      NULL,
    DLIREASCD               VARCHAR(4)      NULL,
    DLILSTCHG               VARCHAR(7)      NULL,
    WDBEFFDAT               VARCHAR(7)      NULL,
    WDBEXPDAT               VARCHAR(7)      NULL,
    WDBREASCD               VARCHAR(4)      NULL,
    WDBLSTCHG               VARCHAR(7)      NULL,
    LTDEFFDAT               VARCHAR(7)      NULL,
    LTDEXPDAT               VARCHAR(7)      NULL,
    LTDREASCD               VARCHAR(4)      NULL,
    LTDLSTCHG               VARCHAR(7)      NULL,
    SLIEFFDAT               VARCHAR(7)      NULL,
    SLIEXPDAT               VARCHAR(7)      NULL,
    SLIREASCD               VARCHAR(4)      NULL,
    SLILSTCHG               VARCHAR(7)      NULL,
    SADEFFDAT               VARCHAR(7)      NULL,
    SADEXPDAT               VARCHAR(7)      NULL,
    SADREASCD               VARCHAR(4)      NULL,
    SADLSTCHG               VARCHAR(7)      NULL,
    VLIFEFFDAT              VARCHAR(7)      NULL,
    VLIFDEXPDAT             VARCHAR(7)      NULL,
    VLIFREASCD              VARCHAR(4)      NULL,
    VLIFLSTCHG              VARCHAR(7)      NULL,
    VLIFEFFDAT              VARCHAR(7)      NULL,
    VLIFDEXPDAT             VARCHAR(7)      NULL,
    VLIFREASCD              VARCHAR(4)      NULL,
    VLIFLSTCHG              VARCHAR(7)      NULL,
    VLIFEFFDAT              VARCHAR(7)      NULL,
    VLIFDEXPDAT             VARCHAR(7)      NULL,
    VLIFREASCD              VARCHAR(4)      NULL,
    VLIFLSTCHG              VARCHAR(7)      NULL,
    VADDEFFDAT              VARCHAR(7)      NULL,
    VADDEXPDAT              VARCHAR(7)      NULL,
    VADDREASCD              VARCHAR(4)      NULL,
    VADDLSTCHG              VARCHAR(7)      NULL,
    VADDSPEFFDAT            VARCHAR(7)      NULL,
    VADDSPEXPDAT            VARCHAR(7)      NULL,
    VADDSPREASCD            VARCHAR(4)      NULL,
    VADDSPLSTCHG            VARCHAR(7)      NULL,
    VADDCHEFFDAT            VARCHAR(7)      NULL,
    VADDCHEXPDAT            VARCHAR(7)      NULL,
    VADDCHREASCD            VARCHAR(4)      NULL,
    VADDCHLSTCHG            VARCHAR(7)      NULL,
    VSTDEFFDAT              VARCHAR(7)      NULL,
    VSTDDEXPDAT             VARCHAR(7)      NULL, 
    VSTDREASCD              VARCHAR(4)      NULL,
    VSTDLSTCHG              VARCHAR(7)      NULL,
    VLTDEFFDAT              VARCHAR(7)      NULL,
    VLTDDEXPDAT             VARCHAR(7)      NULL, 
    VLTDREASCD              VARCHAR(4)      NULL,
    VLTDLSTCHG              VARCHAR(7)      NULL 
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_membership_extr_new') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_membership_extr_new >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_membership_extr_new >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
