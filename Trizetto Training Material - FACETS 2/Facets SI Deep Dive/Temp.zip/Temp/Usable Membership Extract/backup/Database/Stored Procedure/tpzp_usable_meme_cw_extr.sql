/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_usable_meme_cw_extr') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.tpzp_usable_meme_cw_extr
    IF OBJECT_ID('dbo.tpzp_usable_meme_cw_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_usable_meme_cw_extr >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_usable_meme_cw_extr >>>'
END
GO
/****************************************************************  
** END MAINTENANCE WRAPPER.                                    **  
****************************************************************/  
  
CREATE PROCEDURE [dbo].[tpzp_usable_meme_cw_extr]  
  
/****************************************************************  
**   NAME                  :   dbo.tpzp_usable_meme_cw_extr 
**  
**  
**   PVCS LOCATION         :   Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Stored Procedures\Stage
**  
**   FUNCTION              :            : For MONTHLY:
**                           STEP 1: Truncate staging table fabncdv1stage.dbo.tpzp_usable_meme_cw_extr
**                           STEP 2: Populating stage table fabncdv1stage.dbo.tpzp_usable_meme_cw_extr with the monthly record
**                           
**                           
**                              
**  
**   PARAMETERS            :  
**                   INPUT :     
**                  OUTPUT :      
**  
**   RETURN CODES          :   0 on success  
**  
**   TABLES REFERENCED     :  
**                FACETS   : 
**                           fabncdv1.dbo.CMC_CSPI_CS_PLAN
**                           fabncdv1.dbo.CMC_GRGR_GROUP
**                           fabncdv1.dbo.CMC_SBSB_SUBSC   
**                FACETSXC :    N/A  
**                CUSTOM   :    N/A 
**                STAGE    : fabncdv1stage.dbo.tpzt_usable_meme_cw_extr
**                                                         
**  
**   PROCEDURES REFERENCED :    N/A  
**                  FACETS :    N/A  
**                  CUSTOM :    N/A  
**  
**   STANDARD LOGGING PROCS:    harcore.dbo.harsp_gen_util_job_hdr_lgr  
**                              harcore.dbo.harsp_gen_util_job_ftr_lgr  
**                              harcore.dbo.harsp_gen_util_step_hdr_lgr  
**                              harcore.dbo.harsp_gen_util_step_ftr_lgr  
**  
** REVISION HISTORY        :  
** VERSION  DATE         DEVELOPER       DESCRIPTION  
** -------  ----------   -------------   -------------------  
** 1.0      07/10/2014   Anusha Vaidyanathan    Initial version
 
****************************************************************/  

AS  
BEGIN 
  
   /****************************************************************  
   **          DECLARE LOCAL VARIABLES                            **  
   ****************************************************************/  
   DECLARE @lnRetCd                INT              -- Proc return code  
   DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field  
   DECLARE @lnCurrentStep          INT              -- Current Step Number  
   DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time  
   DECLARE @lnTotalSteps           INT              -- Total Steps In Proc  
   DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name  
   DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name  
   DECLARE @lvcDBName              VARCHAR(32)      -- DB Name  
   DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version  
   DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name  
   DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time  
   DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step  
   DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time  
   DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
   DECLARE @ldtLastRunDate         DATETIME         -- LastRunDate
                 
   
   /****************************************************************  
   **          INITIALIZE  VARIABLES                              **  
   ****************************************************************/  
    SELECT  @lnRetCd          = 0,  
            @lvcMsg           = NULL,  
            @lnCurrentStep    = 0,  
            @lnTotalSteps     = 2,  
            @ldtStepEndTime   = NULL,  
            @lvcVersionNum    = '1.0'  
     
    SELECT  @lvcServerName          = @@SERVERNAME,  
            @lvcDBName              = DB_NAME(),  
            @lvcUser                = USER_NAME(),  
            @lvcObjectName          = OBJECT_NAME(@@PROCID),  
            @ldtProcessStartTime    = GETDATE() 
              
        
    /****************************************************************  
   **               BEGIN PROCESS                                 **  
   *****************************************************************/  
      
    /**************  PRINT JOB HEADER DATA *************************/  
      
    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr  
        @pchObjectName        = @lvcObjectName,  
        @pdtProcessStartTime  = @ldtProcessStartTime,  
        @pchServerName        = @lvcServerName,  
        @pchDBName            = @lvcDBName,  
        @pchUserName          = @lvcUser,  
        @pchVersionNum        = @lvcVersionNum  
 
    /**************  PRINT STEP 1 HEADER DATA *************************/

         SELECT @lnCurrentStep = @lnCurrentStep + 1,
         @ldtStepStartTime    = GETDATE(),
         @lvcMsg              = @lvcObjectName + ': Truncate Staging table tpzt_usable_meme_cw_extr'

          EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
          @pnStepNumber       = @lnCurrentStep,
          @pdtStepStartTime   = @ldtStepStartTime,
          @pnTotalSteps       = @lnTotalSteps,
          @pchStepMsg         = @lvcMsg  
         
    /********** STEP 1 Truncate staging table tpzt_usable_meme_cw_extr**********/

    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_usable_meme_cw_extr
           
    /************* Error Checking for Truncate Statement*************/          
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  
  
        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Truncate Staging table tpzt_usable_meme_cw_extr FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END
            
    /**************  PRINT STEP 1 FOOTER DATA *************************/

         SELECT @ldtStepEndTime    = GETDATE()
         
         EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
          @pdtStepStartTime       = @ldtStepStartTime,
          @pdtStepEndTime         = @ldtStepEndTime,
          @pdtProcessStartTime    = @ldtProcessStartTime,
          @pnRowCount             = @lnRowsProcessed
         

    /**************  PRINT STEP 2 HEADER DATA *************************/

         SELECT @lnCurrentStep = @lnCurrentStep + 1,
         @ldtStepStartTime    = GETDATE(),
         @lvcMsg              = @lvcObjectName + ': Populating the Staging table tpzt_usable_meme_cw_extr with the previous months record'
         
         EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
          @pnStepNumber       = @lnCurrentStep,
          @pdtStepStartTime   = @ldtStepStartTime,
          @pnTotalSteps       = @lnTotalSteps,
          @pchStepMsg         = @lvcMsg
          
    /************* STEP 2 Populating the Staging table tpzt_usable_meme_extr with the previous days record *************/  
          
       INSERT INTO fabncdv1stage.dbo.tpzt_usable_meme_cw_extr
        (
          New_Group_Number,          
          Old_Member_Number,
          New_Member_Number,
          Social_Security_Number,
          Member_Name               
        )
        SELECT DISTINCT
        New_Group_Number = LEFT(SUBSTRING(LTRIM(RTRIM(grgr.GRGR_ID)),1,8) + SPACE(8),8),                     
        Old_Member_Number = LTRIM(RTRIM(sbsb.SBSB_ID+RIGHT('00'+CONVERT(VARCHAR,meme.MEME_SFX,0),2))),         
        New_Member_Number = LTRIM(RTRIM(sbsb.SBSB_ID+RIGHT('00'+CONVERT(VARCHAR,meme.MEME_SFX,0),2))), 
        Social_Security_Number= RIGHT('000000000'+meme.MEME_SSN,9),
        Member_Name = LEFT(SUBSTRING(LTRIM(RTRIM(meme.MEME_FIRST_NAME)),1,15)+SPACE(15),15)
        
        FROM fabncdv1.dbo.CMC_GRGR_GROUP grgr
        INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme
             ON grgr.GRGR_CK = meme.GRGR_CK
	    INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb
 		    ON  meme.SBSB_CK = sbsb.SBSB_CK
 		
			        
    /********** Error Checking for insert statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Populating data in stage table fabncdv1stage.dbo.tpzt_usable_meme_cw_extr with monthly records FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END
       /**************  PRINT STEP 2 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed  
END         
    
    /**************  PRINT JOB FOOTER DATA ****************************/  
  
   SELECT @ldtProcessEndTime = GETDATE() 
    
   EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr  
     @pchObjectName         = @lvcObjectName,  
     @pdtProcessStartTime   = @ldtProcessStartTime,  
     @pdtProcessEndTime     = @ldtProcessEndTime  
   RETURN  @lnRetCd 
  
GO
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_usable_meme_cw_extr') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.tpzp_usable_meme_cw_extr >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_usable_meme_cw_extr>>>'
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/ 

                             
       
       
   
        
          
        
        
        
     
          
        
        
        
     