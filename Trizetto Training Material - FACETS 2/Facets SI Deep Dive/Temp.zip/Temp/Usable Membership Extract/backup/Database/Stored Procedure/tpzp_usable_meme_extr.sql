/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_usable_meme_extr') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.tpzp_usable_meme_extr
    IF OBJECT_ID('dbo.tpzp_usable_meme_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_usable_meme_extr >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_usable_meme_extr >>>'
END
GO
/****************************************************************  
** END MAINTENANCE WRAPPER.                                    **  
****************************************************************/  
  
CREATE PROCEDURE [dbo].[tpzp_usable_meme_extr]  
  
/****************************************************************  
**   NAME                  :   dbo.tpzp_usable_meme_extr 
**  
**  
**   PVCS LOCATION         :   Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Stored Procedures\Stage
**  
**   FUNCTION              :            : For MONTHLY:
**                           STEP 1: Truncate staging table fabncdv1stage.dbo.tpzt_usable_meme_extr
**                           STEP 2: Populating stage table fabncdv1stage.dbo.tpzt_usable_meme_extr with the monthly record
**                           
**                           
**                              
**  
**   PARAMETERS            :  
**                   INPUT :     
**                  OUTPUT :      
**  
**   RETURN CODES          :   0 on success  
**  
**   TABLES REFERENCED     :  
**                FACETS   : 
**                           fabncdv1.dbo.CMC_CSPI_CS_PLAN
**                           fabncdv1.dbo.CMC_GRGR_GROUP
**                           fabncdv1.dbo.CMC_SBSB_SUBSC   
**                FACETSXC :    N/A  
**                CUSTOM   :    N/A 
**                STAGE    : fabncdv1stage.dbo.tpzp_usable_meme_extr
**                           fabncdv1stage.dbo.tpzt_vend_ext_common_cw
**                                                         
**  
**   PROCEDURES REFERENCED :    N/A  
**                  FACETS :    N/A  
**                  CUSTOM :    N/A  
**  
**   STANDARD LOGGING PROCS:    harcore.dbo.harsp_gen_util_job_hdr_lgr  
**                              harcore.dbo.harsp_gen_util_job_ftr_lgr  
**                              harcore.dbo.harsp_gen_util_step_hdr_lgr  
**                              harcore.dbo.harsp_gen_util_step_ftr_lgr  
**  
** REVISION HISTORY        :  
** VERSION  DATE         DEVELOPER       DESCRIPTION  
** -------  ----------   -------------   -------------------  
** 1.0      06/26/2014   Anusha Vaidyanathan    Initial version
 
****************************************************************/  

AS  
BEGIN 
  
   /****************************************************************  
   **          DECLARE LOCAL VARIABLES                            **  
   ****************************************************************/  
   DECLARE @lnRetCd                INT              -- Proc return code  
   DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field  
   DECLARE @lnCurrentStep          INT              -- Current Step Number  
   DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time  
   DECLARE @lnTotalSteps           INT              -- Total Steps In Proc  
   DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name  
   DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name  
   DECLARE @lvcDBName              VARCHAR(32)      -- DB Name  
   DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version  
   DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name  
   DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time  
   DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step  
   DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time  
   DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
   DECLARE @ldtLastRunDate         DATETIME         -- LastRunDate
                 
   
   /****************************************************************  
   **          INITIALIZE  VARIABLES                              **  
   ****************************************************************/  
    SELECT  @lnRetCd          = 0,  
            @lvcMsg           = NULL,  
            @lnCurrentStep    = 0,  
            @lnTotalSteps     = 2,  
            @ldtStepEndTime   = NULL,  
            @lvcVersionNum    = '1.0'  
     
    SELECT  @lvcServerName          = @@SERVERNAME,  
            @lvcDBName              = DB_NAME(),  
            @lvcUser                = USER_NAME(),  
            @lvcObjectName          = OBJECT_NAME(@@PROCID),  
            @ldtProcessStartTime    = GETDATE() 
              
        
    /****************************************************************  
   **               BEGIN PROCESS                                 **  
   *****************************************************************/  
      
    /**************  PRINT JOB HEADER DATA *************************/  
      
    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr  
        @pchObjectName        = @lvcObjectName,  
        @pdtProcessStartTime  = @ldtProcessStartTime,  
        @pchServerName        = @lvcServerName,  
        @pchDBName            = @lvcDBName,  
        @pchUserName          = @lvcUser,  
        @pchVersionNum        = @lvcVersionNum  
 
    /**************  PRINT STEP 1 HEADER DATA *************************/

         SELECT @lnCurrentStep = @lnCurrentStep + 1,
         @ldtStepStartTime    = GETDATE(),
         @lvcMsg              = @lvcObjectName + ': Truncate Staging table tpzp_usable_meme_extr'

          EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
          @pnStepNumber       = @lnCurrentStep,
          @pdtStepStartTime   = @ldtStepStartTime,
          @pnTotalSteps       = @lnTotalSteps,
          @pchStepMsg         = @lvcMsg  
         
    /********** STEP 1 Truncate staging table tpzt_usable_meme_extr**********/

    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_usable_meme_extr
           
    /************* Error Checking for Truncate Statement*************/          
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  
  
        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Truncate Staging table tpzt_usable_meme_extr_old FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END
            
    /**************  PRINT STEP 1 FOOTER DATA *************************/

         SELECT @ldtStepEndTime    = GETDATE()
         
         EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
          @pdtStepStartTime       = @ldtStepStartTime,
          @pdtStepEndTime         = @ldtStepEndTime,
          @pdtProcessStartTime    = @ldtProcessStartTime,
          @pnRowCount             = @lnRowsProcessed
         

    /**************  PRINT STEP 2 HEADER DATA *************************/

         SELECT @lnCurrentStep = @lnCurrentStep + 1,
         @ldtStepStartTime    = GETDATE(),
         @lvcMsg              = @lvcObjectName + ': Populating the Staging table tpzt_usable_meme_extr with the previous days record'
         
         EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
          @pnStepNumber       = @lnCurrentStep,
          @pdtStepStartTime   = @ldtStepStartTime,
          @pnTotalSteps       = @lnTotalSteps,
          @pchStepMsg         = @lvcMsg
          
    /************* STEP 2 Populating the Staging table tpzt_usable_meme_extr with the previous days record *************/  
          
       INSERT INTO fabncdv1stage.dbo.tpzt_usable_meme_extr
        (
        GRPNUM,
        METIND,
        MEMBNO,
        LSTNAM,
        FSTNAM,
        MIDNAM,
        BTHDAT,
        SEXCOD,
        SSN,
        SALARY,  
        CLSCOD,
        LIFMTHPRM,
        ADDMTHPRM,
        DLIMTHPRM,
        WDBMTHPRM,
        LTDMTHPRM,
        SLIMTHPRM,
        SADMTHPRM,
        --Voluntary Life Rate
        --Voluntary ADD Rate
        --Voluntary STD Rate
        --Voluntary LID Rate
        CARCOD,
        LIFACTVOL,
		LIFRPERUT,
		LIFRATSRC,
		ADDACTVOL,
		ADDRPERUT,
		ADDRATSRC,
		DLIACTVOL,
		DLIRPERUT,
		DLIRATSRC,
		WDBACTVOL,
		WDBRPERUT,
		WDBRATSRC,
		LTDACTVOL,
		LTDRPERUT,
		LTDRATSRC,
		SLIACTVOL,
		SLIRPERUT,
		SLIRATSRC,
		SADACTVOL,
		SADRPERUT,
		SADRATSRC,
		--Benefit Amount for Voluntary Life
        --Benefit Rate Per Unit Voluntary Life 
		--Rate Method for Voluntary Life
		--Benefit Amount for Voluntary ADD
		--Benefit Rate Per Unit Voluntary ADD
		--Rate Method for Voluntary ADD
		--Benefit Amount for Voluntary STD
		--Benefit Rate Per Unit Voluntary STD
		--Rate Method for Voluntary STD
		--Benefit Amount for Voluntary LTD
		--Benefit Rate Per Unit Voluntary LTD
		--Rate Method for Voluntary LTD
		PDTHRU,
		HIRDAT,
		AGE,
		ACCTNO,
		CLSEFFDAT,
		CLSEXPDAT,
		LIFEFFDAT,
		LIFEXPDAT,
		LIFREASCD,
		LIFLSTCHG,
		ADDEFFDAT,
		ADDEXPDAT,
		ADDREASCD,
		ADDLSTCHG,
		DLIEFFDAT,
		DLIEXPDAT,
		DLIREASCD,
		DLILSTCHG,
		WDBEFFDAT,
		WDBEXPDAT,
		WDBREASCD,
		WDBLSTCHG,
		LTDEFFDAT,
		LTDEXPDAT,
		LTDREASCD,
		LTDLSTCHG,
		SLIEFFDAT,
		SLIEXPDAT,
		SLIREASCD,
		SLILSTCHG,
		SADEFFDAT,
		SADEXPDAT,
		SADREASCD,
		SADLSTCHG
		--Voluntary Life Effective Date
		--Voluntary Life Expiration Date
		--Voluntary Life Termination Reason
		--Voluntary Life Last Change Date
		--Voluntary ADD Effective Date
		--Voluntary ADD  Expiration Date
		--Voluntary ADD Termination Reason
		--Voluntary ADD Last Change Date
		--Voluntary STD Effective Date
		--Voluntary STD Expiration Date
		--Voluntary STD Termination Reason
		--Voluntary STD Last Change Date
		--Voluntary LTD Effective Date
		--Voluntary LTD Expiration Date
		--Voluntary LTD Termination Reason
		--Voluntary LTD Last Change Date

        )
        SELECT DISTINCT
            GRPNUM = LEFT(SUBSTRING(LTRIM(RTRIM(grgr.GRGR_ID)),1,8) + SPACE(8),8),                      -- To be verified since power has 6 bytes
        METIND = '2',
        MEMBNO = LEFT(SUBSTRING(LTRIM(RTRIM(sbsb.SBSB_ID)),1,12) + SPACE(12),12), 
        LSTNAM = LEFT(SUBSTRING(LTRIM(RTRIM(comm.MEME_LAST_NAME)),1,15) + SPACE(15),15),
        FSTNAM = LEFT(SUBSTRING(LTRIM(RTRIM(comm.MEME_FIRST_NAME)),1,10) + SPACE(10),10),
        MIDNAM = LEFT(SUBSTRING(LTRIM(RTRIM(comm.MEME_MID_INIT)),1,1) + SPACE(1),1),
        BTHDAT = CONVERT(VARCHAR(7),comm.MEME_BIRTH_DT,112),
        SEXCOD = LEFT(LTRIM(RTRIM(comm.MEME_SEX))+SPACE(1),1),
        SSN    = RIGHT('000000000'+comm.MEME_SSN,9),
        SALARY = CONVERT(VARCHAR(9),sbsa.SBSA_SAL_AMT),
        CLSCOD = CONVERT(VARCHAR(3),cspi.CSCS_ID),
        LIFMTHPRM ='CNX',
        ADDMTHPRM = 'CNX',
        DLIMTHPRM ='CNX',
        WDBMTHPRM ='CNX',
        LTDMTHPRM ='CNX',
        SLIMTHPRM ='CNX',
        SADMTHPRM ='CNX',
        --Voluntary Life Rate
        --Voluntary ADD Rate
        --Voluntary STD Rate
        --Voluntary LID Rate
        CARCOD ='CN',
        LIFACTVOL = LEFT(SUBSTRING(LTRIM(RTRIM(cspi.CSPI_ID)),1,11) + SPACE(11),11),
		LIFRPERUT ='CNX',
		LIFRATSRC ='CN',
		ADDACTVOL ='CNX',
		ADDRPERUT ='CNX',
		ADDRATSRC ='CN',
		DLIACTVOL ='CNX',
		DLIRPERUT ='CNX',
		DLIRATSRC ='CN',
		WDBACTVOL ='CNX',
		WDBRPERUT ='CNX',
		WDBRATSRC ='CN',
		LTDACTVOL ='CNX',
		LTDRPERUT ='CNX',
		LTDRATSRC ='CN',
		SLIACTVOL ='CNX',
		SLIRPERUT ='CNX',
		SLIRATSRC ='CN',
		SADACTVOL ='CNX',
		SADRPERUT ='CNX',
		SADRATSRC ='CN',
		--Benefit Amount for Voluntary Life
        --Benefit Rate Per Unit Voluntary Life 
		--Rate Method for Voluntary Life
		--Benefit Amount for Voluntary ADD
		--Benefit Rate Per Unit Voluntary ADD
		--Rate Method for Voluntary ADD
		--Benefit Amount for Voluntary STD
		--Benefit Rate Per Unit Voluntary STD
		--Rate Method for Voluntary STD
		--Benefit Amount for Voluntary LTD
		--Benefit Rate Per Unit Voluntary LTD
		--Rate Method for Voluntary LTD
		PDTHRU ='CNX',
		HIRDAT   = CONVERT(VARCHAR(7),sbsb.SBSB_HIRE_DT,112), 
		AGE ='CNX',
		ACCTNO = 'CNX',
		CLSEFFDAT ='CNX',
		CLSEXPDAT ='CNX',
		LIFEFFDAT ='CNX',
		LIFEXPDAT='CNX',
		LIFREASCD ='CNX',
		LIFLSTCHG ='CNX',
		ADDEFFDAT ='CNX',
		ADDEXPDAT ='CNX',
		ADDREASCD ='CNX',
		ADDLSTCHG ='CNX',
		DLIEFFDAT ='CNX',
		DLIEXPDAT ='CNX',
		DLIREASCD ='CNX',
		DLILSTCHG ='CNX',
		WDBEFFDAT ='CNX',
		WDBEXPDAT ='CNX',
		WDBREASCD ='CNX',
		WDBLSTCHG ='CNX',
		LTDEFFDAT ='CNX',
		LTDEXPDAT ='CNX',
		LTDREASCD ='CNX',
		LTDLSTCHG ='CNX',
		SLIEFFDAT ='CNX',
		SLIEXPDAT ='CNX',
		SLIREASCD ='CNX',
		SLILSTCHG ='CNX',
		SADEFFDAT ='CNX',
		SADEXPDAT ='CNX',
		SADREASCD ='CNX',
		SADLSTCHG ='CNX'
		--Voluntary Life Effective Date
		--Voluntary Life Expiration Date
		--Voluntary Life Termination Reason
		--Voluntary Life Last Change Date
		--Voluntary ADD Effective Date
		--Voluntary ADD  Expiration Date
		--Voluntary ADD Termination Reason
		--Voluntary ADD Last Change Date
		--Voluntary STD Effective Date
		--Voluntary STD Expiration Date
		--Voluntary STD Termination Reason
		--Voluntary STD Last Change Date
		--Voluntary LTD Effective Date
		--Voluntary LTD Expiration Date
		--Voluntary LTD Termination Reason
		--Voluntary LTD Last Change Date

		FROM    fabncdv1stage.dbo.tpzt_comm_elig_extr comm
		INNER JOIN fabncdv1.dbo.CMC_SBSA_SALARY sbsa
		     ON comm.SBSB_CK = sbsa.SBSB_CK
		     --AND comm.SBSA_EFF_DT = sbsa.SBSA_EFF_DT
		INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr
		    ON  comm.GRGR_CK = grgr.GRGR_CK
	    INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb
 		    ON  comm.SBSB_CK = sbsb.SBSB_CK
 		INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi 
            ON cspi.GRGR_CK = comm.GRGR_CK  
            AND cspi.CSPD_CAT=comm.CSPD_CAT 
            AND cspi.CSPI_ID = comm.CSPI_ID
         
 		    --WHERE cspi.CSPI_TERM_DT >= DATEADD(DD,1,CONVERT (VARCHAR(12),@ldtLastRunDate,110))
 		    --AND cspi.CSPI_TERM_DT  > cspi.CSPI_EFF_DT
			        
    /********** Error Checking for insert statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Populating data in stage table fabncdv1stage.dbo.tpzt_usable_meme_extr with present days record FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END
       /**************  PRINT STEP 2 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed  
END         
    
    /**************  PRINT JOB FOOTER DATA ****************************/  
  
   SELECT @ldtProcessEndTime = GETDATE() 
    
   EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr  
     @pchObjectName         = @lvcObjectName,  
     @pdtProcessStartTime   = @ldtProcessStartTime,  
     @pdtProcessEndTime     = @ldtProcessEndTime  
   RETURN  @lnRetCd 
  
GO
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_usable_meme_extr') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.tpzp_usable_meme_extr >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_usable_meme_extr>>>'
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/ 

                             
       
       
   
        
          
        
        
        
     
          
        
        
        
     