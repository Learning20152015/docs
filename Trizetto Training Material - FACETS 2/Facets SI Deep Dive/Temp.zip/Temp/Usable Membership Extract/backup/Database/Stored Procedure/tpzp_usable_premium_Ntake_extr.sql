/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_usable_premium_Ntake_extr') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.tpzp_usable_premium_Ntake_extr
    IF OBJECT_ID('dbo.tpzp_usable_premium_Ntake_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_usable_premium_Ntake_extr >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_usable_premium_Ntake_extr >>>'
END
GO
/****************************************************************  
** END MAINTENANCE WRAPPER.                                    **  
****************************************************************/  
  
CREATE PROCEDURE [dbo].[tpzp_usable_premium_Ntake_extr]  
  
/****************************************************************  
**   NAME                  :   dbo.tpzp_usable_premium_Ntake_extr 
**  
**  
**   PVCS LOCATION         :   Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Stored Procedures\Stage
**  
**   FUNCTION              :            : For MONTHLY:
**                           STEP 1: Truncate staging table fabncdv1stage.dbo.tpzt_usable_premium_Ntake_extr
**                           STEP 2: Populating stage table fabncdv1stage.dbo.tpzt_usable_premium_Ntake_extr with the monthly record
**                           
**                           
**                           
**                              
**  
**   PARAMETERS            :  
**                   INPUT :     
**                  OUTPUT :      
**  
**   RETURN CODES          :   0 on success  
**  
**   TABLES REFERENCED     :  
**                FACETS   : 
**                           
**                              
**                FACETSXC :    N/A  
**                CUSTOM   :    N/A 
**                STAGE    : fabncdv1stage.dbo.tpzp_usable_premium_Ntake_extr
**                                                        
**  
**   PROCEDURES REFERENCED :    N/A  
**                  FACETS :    N/A  
**                  CUSTOM :    N/A  
**  
**   STANDARD LOGGING PROCS:    harcore.dbo.harsp_gen_util_job_hdr_lgr  
**                              harcore.dbo.harsp_gen_util_job_ftr_lgr  
**                              harcore.dbo.harsp_gen_util_step_hdr_lgr  
**                              harcore.dbo.harsp_gen_util_step_ftr_lgr  
**  
** REVISION HISTORY        :  
** VERSION  DATE         DEVELOPER       DESCRIPTION  
** -------  ----------   -------------   -------------------  
** 1.0      07/03/2014   Anusha Vaidyanathan    Initial version
 
****************************************************************/  

AS  
BEGIN 
  
   /****************************************************************  
   **          DECLARE LOCAL VARIABLES                            **  
   ****************************************************************/  
   DECLARE @lnRetCd                INT              -- Proc return code  
   DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field  
   DECLARE @lnCurrentStep          INT              -- Current Step Number  
   DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time  
   DECLARE @lnTotalSteps           INT              -- Total Steps In Proc  
   DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name  
   DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name  
   DECLARE @lvcDBName              VARCHAR(32)      -- DB Name  
   DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version  
   DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name  
   DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time  
   DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step  
   DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time  
   DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
   DECLARE @ldtLastRunDate         DATETIME         -- LastRunDate
                 
   
   /****************************************************************  
   **          INITIALIZE  VARIABLES                              **  
   ****************************************************************/  
    SELECT  @lnRetCd          = 0,  
            @lvcMsg           = NULL,  
            @lnCurrentStep    = 0,  
            @lnTotalSteps     = 2,  
            @ldtStepEndTime   = NULL,  
            @lvcVersionNum    = '1.0'  
     
    SELECT  @lvcServerName          = @@SERVERNAME,  
            @lvcDBName              = DB_NAME(),  
            @lvcUser                = USER_NAME(),  
            @lvcObjectName          = OBJECT_NAME(@@PROCID),  
            @ldtProcessStartTime    = GETDATE() 
              
        
    /****************************************************************  
   **               BEGIN PROCESS                                 **  
   *****************************************************************/  
      
    /**************  PRINT JOB HEADER DATA *************************/  
      
    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr  
        @pchObjectName        = @lvcObjectName,  
        @pdtProcessStartTime  = @ldtProcessStartTime,  
        @pchServerName        = @lvcServerName,  
        @pchDBName            = @lvcDBName,  
        @pchUserName          = @lvcUser,  
        @pchVersionNum        = @lvcVersionNum  
 
    /**************  PRINT STEP 1 HEADER DATA *************************/

         SELECT @lnCurrentStep = @lnCurrentStep + 1,
         @ldtStepStartTime    = GETDATE(),
         @lvcMsg              = @lvcObjectName + ': Truncate Staging table tpzt_usable_premium_Ntake_extr'

          EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
          @pnStepNumber       = @lnCurrentStep,
          @pdtStepStartTime   = @ldtStepStartTime,
          @pnTotalSteps       = @lnTotalSteps,
          @pchStepMsg         = @lvcMsg  
         
    /********** STEP 1 Truncate staging table tpzt_usable_premium_Ntake_extr**********/

    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_usable_premium_Ntake_extr
           
    /************* Error Checking for Truncate Statement*************/          
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  
  
        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Truncate Staging table tpzt_usable_premium_Ntake_extr FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END
            
    /**************  PRINT STEP 1 FOOTER DATA *************************/

         SELECT @ldtStepEndTime    = GETDATE()
         
         EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
          @pdtStepStartTime       = @ldtStepStartTime,
          @pdtStepEndTime         = @ldtStepEndTime,
          @pdtProcessStartTime    = @ldtProcessStartTime,
          @pnRowCount             = @lnRowsProcessed
         

    /**************  PRINT STEP 2 HEADER DATA *************************/

         SELECT @lnCurrentStep = @lnCurrentStep + 1,
         @ldtStepStartTime    = GETDATE(),
         @lvcMsg              = @lvcObjectName + ': Populating the Staging table tpzt_usable_premium_Ntake_extr with the monthly record'
         
         EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
          @pnStepNumber       = @lnCurrentStep,
          @pdtStepStartTime   = @ldtStepStartTime,
          @pnTotalSteps       = @lnTotalSteps,
          @pchStepMsg         = @lvcMsg
          
    /************* STEP 2 Populating the Staging table tpzt_usable_premium_Ntake_extr with the monthly record *************/  
          
       INSERT INTO fabncdv1stage.dbo.tpzt_usable_premium_Ntake_extr
        (
Grp ,                    
MHSGroupName ,  
LIF,            
add1,           
WDB,            
LTD,            
SLI,            
SAD,           
VGTL2,          
VADD1,          
VSTD1,          
VLTD,           
VADD,           
PREM,           
COMM,          
NET,           
MHS_lif_cnt,    
MHS_add_cnt,    
MHS_dep_cnt,    
MHS_std_cnt,    
MHS_ltd_cnt,    
MHS_sli_cnt,    
MHS_sad_cnt,    
MHS_vgtl2_cnt,  
MHS_vadd2_cnt,  
MHS_vstd2_cnt,  
MHS_vltd_cnt,   
MHS_lif_ben,    
MHS_add_ben,    
MHS_dep_ben,    
MHS_std_ben,    
MHS_ltd_ben,    
MHS_sli_ben,    
MHS_sad_ben,   
MHS_vgtl_ben,   
MHS_vadd_ben,   
MHS_vstd_ben,   
MHS_vltd_ben,   
MHS_lif_rate,   
MHS_add_rate,   
MHS_dep_rate,   
MHS_std_rate,   
MHS_ltd_rate,  
MHS_sli_rate,   
MHS_sad_rate,   
MHS_vgtl_rate,  
MHS_vltd_rate1, 
MHS_vstd_rate,  
MHS_vltd_rate,  
MHS_lif_type,   
MHS_add_type,   
MHS_dep_type,   
MHS_std_type,   
MHS_ltd_type,   
MHS_sli_type,   
MHS_sad_type,   
MHS_vgtl_type,  
MHS_vstd_type,  
MHS_vltd_type,  
MHS_vadd_type,  
EffectiveDate  
)
        SELECT DISTINCT
Grp                      = LEFT(SUBSTRING(LTRIM(RTRIM(grgr.GRGR_ID)),1,8) + SPACE(8),8),                    
MHSGroupName             = LEFT(SUBSTRING(LTRIM(RTRIM(grgr.GRGR_NAME)),1,120) + SPACE(120),120),  
LIF                      ='CNX',            
add1                     ='CNX',           
WDB                      ='CNX',             
LTD						 ='CNX',													            
SLI						 ='CNX',								            
SAD						 ='CNX',						           
VGTL2				     ='CNX',     
VADD1					 ='CNX',		          
VSTD1                    ='CNX',     
VLTD                     ='CNX',
VADD                     ='CNX',
PREM                     ='CNX',
COMM                     ='CNX',
NET                      ='CNX',
MHS_lif_cnt              ='CNX',
MHS_add_cnt              ='CNX',
MHS_dep_cnt              ='CNX',
MHS_std_cnt              ='CNX',
MHS_ltd_cnt              ='CNX',
MHS_sli_cnt              ='CNX',
MHS_sad_cnt              ='CNX',
MHS_vgtl2_cnt            ='CNX',
MHS_vadd2_cnt            ='CNX',
MHS_vstd2_cnt            ='CNX',
MHS_vltd_cnt             ='CNX',
MHS_lif_ben              ='CNX',
MHS_add_ben              ='CNX',
MHS_dep_ben              ='CNX',
MHS_std_ben              ='CNX',
MHS_ltd_ben              ='CNX',
MHS_sli_ben              ='CNX',
MHS_sad_ben              ='CNX',
MHS_vgtl_ben             ='CNX',
MHS_vadd_ben             ='CNX',
MHS_vstd_ben             ='CNX',
MHS_vltd_ben             ='CNX',
MHS_lif_rate             ='CNX',
MHS_add_rate             ='CNX',
MHS_dep_rate             ='CNX',
MHS_std_rate             ='CNX',
MHS_ltd_rate             ='CNX',
MHS_sli_rate             ='CNX',
MHS_sad_rate             ='CNX',
MHS_vgtl_rate            ='CNX',
MHS_vltd_rate1           ='CNX',
MHS_vstd_rate            ='CNX',
MHS_vltd_rate            ='CNX',
MHS_lif_type             ='CNX',
MHS_add_type             ='CNX',
MHS_dep_type             ='CNX',
MHS_std_type             ='CNX',
MHS_ltd_typ              ='CNX',
MHS_sli_type             ='CNX',
MHS_sad_type             ='CNX',
MHS_vgtl_type            ='CNX',
MHS_vstd_type            ='CNX',
MHS_vltd_type            ='CNX',
MHS_vadd_type            ='CNX',
EffectiveDate            ='CNX'

from fabncdv1.dbo.CMC_GRGR_GROUP grgr

          
			        
    /********** Error Checking for insert statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Populating data in stage table fabncdv1stage.dbo.tpzt_usable_premium_Ntake_extr with monthly records FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END
       /**************  PRINT STEP 2 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed  
END         
    
    /**************  PRINT JOB FOOTER DATA ****************************/  
  
   SELECT @ldtProcessEndTime = GETDATE() 
    
   EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr  
     @pchObjectName         = @lvcObjectName,  
     @pdtProcessStartTime   = @ldtProcessStartTime,  
     @pdtProcessEndTime     = @ldtProcessEndTime  
   RETURN  @lnRetCd 
  
GO
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_usable_premium_Ntake_extr') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.tpzp_usable_premium_Ntake_extr >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_usable_premium_Ntake_extr>>'
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/ 

                             
       
       
   
        
          
        
        
        
     
          
        
        
        
     