/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_premium_Ntake_extr') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_premium_Ntake_extr
  IF OBJECT_ID('dbo.tpzt_usable_premium_Ntake_extr') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_premium_Ntake_extr >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_premium_Ntake_extr >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
/****************************************************************
**   NAME                  : dbo.tpzt_usable_premium_Ntake_extr 
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the records related to Usable Premium Ntake
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0       07/03/2014   Anusha Vaidyanathan     Intial Version
****************************************************************/
CREATE TABLE dbo.tpzt_usable_premium_Ntake_extr
(
Grp                     VARCHAR(8)          NULL,
MHSGroupName            VARCHAR(120)        NULL,
LIF                     VARCHAR(10)         NULL,
add1                    VARCHAR(10)         NULL,
WDB                     VARCHAR(10)         NULL,
LTD                     VARCHAR(10)         NULL,
SLI                     VARCHAR(10)         NULL,
SAD                     VARCHAR(10)         NULL,
VGTL2                   VARCHAR(10)         NULL,
VADD1                   VARCHAR(10)         NULL,
VSTD1                   VARCHAR(10)         NULL,
VLTD                    VARCHAR(10)         NULL,
VADD                    VARCHAR(10)         NULL,
PREM                    VARCHAR(12)         NULL,
COMM                    VARCHAR(10)         NULL,
NET                     VARCHAR(12)         NULL,
MHS_lif_cnt             VARCHAR(6)          NULL,
MHS_add_cnt             VARCHAR(6)          NULL,
MHS_dep_cnt             VARCHAR(6)          NULL,
MHS_std_cnt             VARCHAR(6)          NULL,
MHS_ltd_cnt             VARCHAR(6)          NULL,
MHS_sli_cnt             VARCHAR(6)          NULL,
MHS_sad_cnt             VARCHAR(6)          NULL,
MHS_vgtl2_cnt           VARCHAR(6)          NULL,
MHS_vadd2_cnt           VARCHAR(6)          NULL,
MHS_vstd2_cnt           VARCHAR(6)          NULL,
MHS_vltd_cnt            VARCHAR(6)          NULL,
MHS_lif_ben             VARCHAR(11)         NULL,
MHS_add_ben             VARCHAR(11)         NULL,
MHS_dep_ben             VARCHAR(11)         NULL,
MHS_std_ben             VARCHAR(11)         NULL,
MHS_ltd_ben             VARCHAR(11)         NULL,
MHS_sli_ben             VARCHAR(11)         NULL,
MHS_sad_ben             VARCHAR(11)         NULL,
MHS_vgtl_ben            VARCHAR(11)         NULL,
MHS_vadd_ben            VARCHAR(11)         NULL,
MHS_vstd_ben            VARCHAR(11)         NULL,
MHS_vltd_ben            VARCHAR(11)         NULL,
MHS_lif_rate            VARCHAR(5)          NULL,
MHS_add_rate            VARCHAR(5)          NULL,
MHS_dep_rate            VARCHAR(5)          NULL,
MHS_std_rate            VARCHAR(5)          NULL,
MHS_ltd_rate            VARCHAR(5)          NULL,
MHS_sli_rate            VARCHAR(5)          NULL,
MHS_sad_rate            VARCHAR(5)          NULL,
MHS_vgtl_rate           VARCHAR(5)          NULL,
MHS_vltd_rate1          VARCHAR(5)          NULL,
MHS_vstd_rate           VARCHAR(5)          NULL,
MHS_vltd_rate           VARCHAR(5)          NULL,
MHS_lif_type            VARCHAR(30)         NULL,
MHS_add_type            VARCHAR(30)         NULL,
MHS_dep_type            VARCHAR(30)         NULL,
MHS_std_type            VARCHAR(30)         NULL,
MHS_ltd_type            VARCHAR(30)         NULL,
MHS_sli_type            VARCHAR(30)         NULL,
MHS_sad_type            VARCHAR(30)         NULL,
MHS_vgtl_type           VARCHAR(30)         NULL,
MHS_vstd_type           VARCHAR(30)         NULL,
MHS_vltd_type           VARCHAR(30)         NULL,
MHS_vadd_type           VARCHAR(30)         NULL,
EffectiveDate           VARCHAR(8)          NULL,
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_premium_Ntake_extr ') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_premium_Ntake_extr >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_premium_Ntake_extr >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
