
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('[dbo].[tpzt_GIS_Monthly_Premium_extr]') IS NOT NULL
BEGIN
    DROP TABLE [dbo].[tpzt_GIS_Monthly_Premium_extr]
    IF OBJECT_ID('[dbo].[tpzt_GIS_Monthly_Premium_extr]') IS NOT NULL
        PRINT '<<< FAILED DROPPING TABLE [dbo].[tpzt_GIS_Monthly_Premium_extr] >>>'
    ELSE
        PRINT '<<< DROPPED TABLE [dbo].[tpzt_GIS_Monthly_Premium_extr] >>>'
END
Go
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/
/****************************************************************
**   NAME                  : dbo.tpzt_GIS_Monthly_Premium_extr 
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : 
**
** REVISION HISTORY        :
**
** VERSION  DATE          DEVELOPER         DESCRIPTION
** -------- ----------  -------------       --------------
**   1.0    07/16/2014  Anusha Vaidyanathan       Intial Version
***************************************************************/

CREATE TABLE [dbo].[tpzt_GIS_Monthly_Premium_extr]
(
    Group_Number	                    VARCHAR(8)					NULL,
	Anniversary_Date                    VARCHAR(4)					NULL,
	Account_Number                      VARCHAR(10)			        NULL,
    Bill_From_Date                      VARCHAR(8)					NULL,
	Bill_Thru_Date                      VARCHAR(8)					NULL,
	Remarks                             VARCHAR(100)                NULL
    
) 
GO
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
GO
IF OBJECT_ID('[dbo].[tpzt_GIS_Monthly_Premium_extr]') IS NOT NULL
    PRINT '<<< CREATED TABLE [dbo].[tpzt_GIS_Monthly_Premium_extr] >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE [dbo].[tpzt_GIS_Monthly_Premium_extr] >>>'
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/


 

