
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('[dbo].[tpzt_usable_grp_cw_extr]') IS NOT NULL
BEGIN
    DROP TABLE [dbo].[tpzt_usable_grp_cw_extr]
    IF OBJECT_ID('[dbo].[tpzt_usable_grp_cw_extr]') IS NOT NULL
        PRINT '<<< FAILED DROPPING TABLE [dbo].[tpzt_usable_grp_cw_extr] >>>'
    ELSE
        PRINT '<<< DROPPED TABLE [dbo].[tpzt_usable_grp_cw_extr] >>>'
END
Go
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/
/****************************************************************
**   NAME                  : dbo.tpzt_usable_grp_cw_extr 
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : 
**
** REVISION HISTORY        :
**
** VERSION  DATE          DEVELOPER         DESCRIPTION
** -------- ----------  -------------       --------------
**   1.0    07/10/2014  Anusha Vaidyanathan       Intial Version
***************************************************************/

CREATE TABLE [dbo].[tpzt_usable_grp_cw_extr]
(
    [Old_Group_Number]          VARCHAR(8),
    [New_Group_Number]          VARCHAR(8),
    [New_Group_Name]            VARCHAR(50)
    
) 
GO
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
GO
IF OBJECT_ID('[dbo].[tpzt_usable_grp_cw_extr]') IS NOT NULL
    PRINT '<<< CREATED TABLE [dbo].[tpzt_usable_grp_cw_extr] >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE [dbo].[tpzt_usable_grp_cw_extr] >>>'
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/



