/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_meme_extr') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_meme_extr 
  IF OBJECT_ID('dbo.tpzt_usable_meme_extr') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_meme_extr >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_meme_extr >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
/****************************************************************
**   NAME                  : dbo.tpzt_usable_meme_extr
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the records related to Usable Weekly Member Extract 
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0       06/26/2014   Anusha Vaidyanathan     Intial Version
****************************************************************/
CREATE TABLE dbo.tpzt_usable_meme_extr 
(   
        GRPNUM          VARCHAR(8)				    NULL,
        METIND          VARCHAR(1)					NULL,
        MEMBNO          VARCHAR(12)					NULL,
        LSTNAM          VARCHAR(15)					NULL,
        FSTNAM          VARCHAR(10)					NULL,
        MIDNAM          VARCHAR(1)					NULL,
        BTHDAT          VARCHAR(7)					NULL,
        SEXCOD          VARCHAR(1)					NULL,
        SSN             VARCHAR(10)					NULL,
        SALARY          VARCHAR(9)					NULL,
        CLSCOD          VARCHAR(3)					NULL,
        LIFMTHPRM       VARCHAR(5)					NULL,
        ADDMTHPRM       VARCHAR(5)					NULL,
        DLIMTHPRM       VARCHAR(5)					NULL,
        WDBMTHPRM       VARCHAR(5)					NULL,
        LTDMTHPRM       VARCHAR(5)					NULL,
        SLIMTHPRM       VARCHAR(5)					NULL,
        SADMTHPRM       VARCHAR(5)					NULL,
       --Voluntary Life Rate                        (col name not available )
       --Voluntary ADD Rate                         (col name not available ) 
       --Voluntary STD Rate                         (col name not available )
       --Voluntary LID Rate                         (col name not available )
        CARCOD          VARCHAR(2)					NULL,
        LIFACTVOL       VARCHAR(11)					NULL,
		LIFRPERUT       VARCHAR(5)					NULL,
		LIFRATSRC       VARCHAR(2)					NULL,
		ADDACTVOL       VARCHAR(11)					NULL,
		ADDRPERUT       VARCHAR(5)					NULL,
		ADDRATSRC       VARCHAR(2)					NULL,
		DLIACTVOL       VARCHAR(11)					NULL,
		DLIRPERUT       VARCHAR(5)					NULL,
		DLIRATSRC       VARCHAR(2)					NULL,
		WDBACTVOL       VARCHAR(11)					NULL,
		WDBRPERUT       VARCHAR(5)					NULL,
		WDBRATSRC       VARCHAR(2)					NULL,
		LTDACTVOL       VARCHAR(11)					NULL,
		LTDRPERUT       VARCHAR(5)					NULL,
		LTDRATSRC       VARCHAR(2)					NULL,
		SLIACTVOL       VARCHAR(11)					NULL,
		SLIRPERUT       VARCHAR(5)					NULL,
		SLIRATSRC       VARCHAR(2)					NULL,
		SADACTVOL       VARCHAR(11)					NULL,
		SADRPERUT       VARCHAR(5)					NULL,
		SADRATSRC       VARCHAR(2)					NULL,
		--Benefit Amount for Voluntary Life        (col name not available )
		--Benefit Rate Per Unit Voluntary Life     (col name not available )
		--Rate Method for Voluntary Life           (col name not available )
		--Benefit Amount for Voluntary ADD         (col name not available )
		--Benefit Rate Per Unit Voluntary ADD      (col name not available )
		--Rate Method for Voluntary ADD            (col name not available )
		--Benefit Amount for Voluntary STD         (col name not available )
		--Benefit Rate Per Unit Voluntary STD      (col name not available )
		--Rate Method for Voluntary STD            (col name not available )
		--Benefit Amount for Voluntary LTD         (col name not available )
		--Benefit Rate Per Unit Voluntary LTD      (col name not available )
		--Rate Method for Voluntary LTD            (col name not available )
		PDTHRU          VARCHAR(7)					NULL,
		HIRDAT          VARCHAR(7)					NULL,
		AGE             VARCHAR(3)					NULL,
		ACCTNO          VARCHAR(10)					NULL,
		CLSEFFDAT       VARCHAR(7)					NULL,
		CLSEXPDAT       VARCHAR(7)					NULL,
		LIFEFFDAT       VARCHAR(7)					NULL,
		LIFEXPDAT       VARCHAR(7)					NULL,
		LIFREASCD       VARCHAR(4)					NULL,
		LIFLSTCHG       VARCHAR(7)					NULL,
		ADDEFFDAT       VARCHAR(7)					NULL,
		ADDEXPDAT       VARCHAR(7)					NULL,
		ADDREASCD       VARCHAR(4)					NULL,
		ADDLSTCHG       VARCHAR(7)					NULL,
		DLIEFFDAT       VARCHAR(7)					NULL,
		DLIEXPDAT       VARCHAR(7)					NULL,
		DLIREASCD       VARCHAR(4)					NULL,
		DLILSTCHG       VARCHAR(7)					NULL,
		WDBEFFDAT       VARCHAR(7)					NULL,
		WDBEXPDAT       VARCHAR(7)					NULL,
		WDBREASCD       VARCHAR(4)					NULL,
		WDBLSTCHG       VARCHAR(7)					NULL,
		LTDEFFDAT       VARCHAR(7)					NULL,
		LTDEXPDAT       VARCHAR(7)					NULL,
		LTDREASCD       VARCHAR(4)					NULL,
		LTDLSTCHG       VARCHAR(7)					NULL,
		SLIEFFDAT       VARCHAR(7)					NULL,
		SLIEXPDAT       VARCHAR(7)					NULL,
		SLIREASCD       VARCHAR(4)					NULL,
		SLILSTCHG       VARCHAR(7)					NULL,
		SADEFFDAT       VARCHAR(7)					NULL,
		SADEXPDAT       VARCHAR(7)					NULL,
		SADREASCD       VARCHAR(4)					NULL,
		SADLSTCHG       VARCHAR(7)					NULL,
		--Voluntary Life Effective Date             (col name not available )
		--Voluntary Life Expiration Date            (col name not available )
		--Voluntary Life Termination Reason         (col name not available )
		--Voluntary Life Last Change Date           (col name not available )
		--Voluntary ADD Effective Date              (col name not available )
		--Voluntary ADD  Expiration Date            (col name not available )
		--Voluntary ADD Termination Reason          (col name not available )
		--Voluntary ADD Last Change Date            (col name not available )
		--Voluntary STD Effective Date              (col name not available )
		--Voluntary STD Expiration Date             (col name not available )
		--Voluntary STD Termination Reason          (col name not available )
		--Voluntary STD Last Change Date            (col name not available )
		--Voluntary LTD Effective Date              (col name not available )
		--Voluntary LTD Expiration Date             (col name not available )
		--Voluntary LTD Termination Reason          (col name not available )
		--Voluntary LTD Last Change Date            (col name not available )

		
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_meme_extr') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_meme_extr >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_meme_extr >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

 


