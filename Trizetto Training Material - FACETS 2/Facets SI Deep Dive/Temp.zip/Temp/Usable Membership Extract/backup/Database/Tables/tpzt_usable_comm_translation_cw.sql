
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('[dbo].[tpzt_usable_meme_translation_cw]') IS NOT NULL
BEGIN
    DROP TABLE [dbo].[tpzt_usable_meme_translation_cw]
    IF OBJECT_ID('[dbo].[tpzt_usable_meme_translation_cw]') IS NOT NULL
        PRINT '<<< FAILED DROPPING TABLE [dbo].[tpzt_usable_meme_translation_cw] >>>'
    ELSE
        PRINT '<<< DROPPED TABLE [dbo].[tpzt_usable_meme_translation_cw] >>>'
END
Go
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/
/****************************************************************
**   NAME                  : dbo.tpzt_usable_meme_translation_cw
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used as translation table to translate the Facets Plan ID to the Eyemed Product ID and Benefit Level
**
** REVISION HISTORY        :
**
** VERSION  DATE          DEVELOPER         DESCRIPTION
** -------- ----------  -------------       --------------
**   1.0    07/09/2014  Anusha Vaidyanathan       Intial Version
***************************************************************/

CREATE TABLE [dbo].[tpzt_usable_meme_translation_cw]
(
    [Market_Segment_Size]                    VARCHAR(50),
    [Total_Commission_Withholdings]          DECIMAL(5,2),
    [Begin_Date]                             DATETIME
    
) 
GO
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
GO
IF OBJECT_ID('[dbo].[tpzt_usable_meme_translation_cw]') IS NOT NULL
    PRINT '<<< CREATED TABLE [dbo].[tpzt_usable_meme_translation_cw] >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE [dbo].[tpzt_usable_meme_translation_cw] >>>'
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/


