/****************************************************************
**   NAME                  : tpzt_Usable_comm_script
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the translation table data
**
**   REVISION HISTORY      :
**
**   VERSION   DATE         DEVELOPER        DESCRIPTION
**   -------   ----------   -------------    ------------------
**   1.0       07/07/2014   Anusha Vaidyanathan    Initial Version
****************************************************************/
   /***********   Truncate staging table tpzt_usable_comm_translation_cw   ***********/

    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_usable_comm_translation_cw
    GO
    
    /*********************   End of TRUNCATE statement   **********************/

    /*******  Inserting data into  staging table tpzt_usable_meme_translation_cw  ******/

INSERT INTO fabncdv1stage.dbo.tpzt_usable_comm_translation_cw ([Market_Segment_Size],[Total_Commission_Withholdings],[Begin_Date]) VALUES('1-50','20',getdate()) 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_comm_translation_cw ([Market_Segment_Size],[Total_Commission_Withholdings],[Begin_Date]) VALUES('51-99','18',getdate()) 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_comm_translation_cw ([Market_Segment_Size],[Total_Commission_Withholdings],[Begin_Date]) VALUES('100-249','15',getdate()) 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_comm_translation_cw ([Market_Segment_Size],[Total_Commission_Withholdings],[Begin_Date]) VALUES('250-999','10',getdate()) 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_comm_translation_cw ([Market_Segment_Size],[Total_Commission_Withholdings],[Begin_Date]) VALUES('1000+','6',getdate()) 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_comm_translation_cw ([Market_Segment_Size],[Total_Commission_Withholdings],[Begin_Date]) VALUES('Voluntary Life','20',getdate()) 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_comm_translation_cw ([Market_Segment_Size],[Total_Commission_Withholdings],[Begin_Date]) VALUES('Voluntary ADD','20',getdate()) 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_comm_translation_cw ([Market_Segment_Size],[Total_Commission_Withholdings],[Begin_Date]) VALUES('Voluntary STD','20',getdate()) 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_comm_translation_cw ([Market_Segment_Size],[Total_Commission_Withholdings],[Begin_Date]) VALUES('Voluntary LTD','20',getdate()) 
GO

