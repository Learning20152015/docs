/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_meme_crosswalk_extr') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_meme_crosswalk_extr
  IF OBJECT_ID('dbo.tpzt_usable_meme_crosswalk_extr') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_meme_crosswalk_extr >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_meme_crosswalk_extr >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_meme_crosswalk_extr
/****************************************************************
**   NAME                  : dbo.tpzt_usable_meme_crosswalk_extr
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the crosswalk records related to USAble Weekly Membership Extract.
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0      09/10/2014   Ghazala Ameen       Intial Version
****************************************************************/
(   
    OLD_GROUP_NUMBER       VARCHAR(8)     NULL,
    NEW_GROUP_NUMBER       VARCHAR(8)     NULL,
    NEW_GROUP_NAME         VARCHAR(30)    NULL,
    OLD_MEMBER_NUMBER      VARCHAR(12)    NULL,
    NEW_MEMBER_NUMBER      VARCHAR(12)    NULL,
    SSN                    VARCHAR(9)     NULL,
    MEMBER_NAME            VARCHAR(21)    NULL
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_meme_crosswalk_extr') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_meme_crosswalk_extr >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_meme_crosswalk_extr >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
