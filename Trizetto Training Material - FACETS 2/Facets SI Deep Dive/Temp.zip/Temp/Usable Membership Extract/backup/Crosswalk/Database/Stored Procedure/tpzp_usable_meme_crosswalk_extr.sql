/***************************************************************
  BEGIN MAINTENANCE WRAPPER.
***************************************************************/

IF OBJECT_ID('dbo.tpzp_usable_meme_crosswalk_extr') IS NOT NULL
BEGIN
  DROP PROCEDURE dbo.tpzp_usable_meme_crosswalk_extr

  IF OBJECT_ID('dbo.tpzp_usable_meme_crosswalk_extr') IS NOT NULL
    PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_usable_meme_crosswalk_extr >>>'
  ELSE
    PRINT '<<< DROPPED PROCEDURE dbo.tpzp_usable_meme_crosswalk_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
***************************************************************/

CREATE PROCEDURE [dbo].[tpzp_usable_meme_crosswalk_extr]

/****************************************************************
**   NAME                  : dbo.tpzp_usable_meme_crosswalk_extr
**
**
**   PVCS LOCATION         : 
**
**   FUNCTION              : STEP 1 Truncating stage table fabncdv1stage.dbo.tpzt_usable_meme_crosswalk_extr
**                           STEP 2 Inserting updated records in stage table fabncdv1stage.dbo.tpzt_usable_meme_crosswalk_extr
**
**   PARAMETERS            :
**                   INPUT :
**                  OUTPUT :
**
**   RETURN CODES          : 0 on success
**
**   TABLES REFERENCED     :
**                FACETS   : fabncdv1.dbo.
**                           fabncdv1.dbo.
**                           fabncdv1.dbo.
**                           fabncdv1.dbo.
**
**                FACETSXC : N/A
**                CUSTOM   : N/A
**                STAGE    : N/A
**
**   PROCEDURES REFERENCED :
**                  FACETS :
**                  CUSTOM :
**   STANDARD LOGGING PROCS:
**                           harcore.dbo.harsp_gen_util_job_hdr_lgr
**                           harcore.dbo.harsp_gen_util_job_ftr_lgr
**                           harcore.dbo.harsp_gen_util_step_hdr_lgr
**                           harcore.dbo.harsp_gen_util_step_ftr_lgr
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0      09/10/2014   Ghazala Ameen       Initial Version
****************************************************************/
AS

BEGIN

/****************************************************************
**          DECLARE LOCAL VARIABLES                            **
****************************************************************/

    DECLARE @lnRetCd                INT              -- Proc return code
    DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time
    DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
    DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time
    DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time
    DECLARE @lnCurrentStep          INT              -- Current Step Number
    DECLARE @lnTotalSteps           INT              -- Total Steps In Proc
    DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field
    DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name
    DECLARE @lvcDBName              VARCHAR(32)      -- DB Name
    DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version
    DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name
    DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name
    DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step
    DECLARE @ldtLastRunDt           DATETIME         -- Last run date
    DECLARE @ldtCurrentDate         DATETIME         -- Current date

/****************************************************************
**          INITIALIZE  VARIABLES                              **
****************************************************************/

    SELECT @lnRetCd        = 0,
      @lvcMsg              = NULL,
      @lnCurrentStep       = 0,  
      @lnTotalSteps        = 2,
      @ldtStepEndTime      = NULL,
      @lvcVersionNum       = '1.0'

    SELECT @lvcServerName  = @@SERVERNAME,
      @lvcDBName           = DB_NAME(),
      @lvcUser             = USER_NAME(),
      @lvcObjectName       = OBJECT_NAME(@@PROCID),
      @ldtProcessStartTime = GETDATE(),
      @ldtCurrentDate      = CONVERT(VARCHAR(10),GETDATE(),101)

/****************************************************************
**               BEGIN PROCESS                                 **
*****************************************************************/

/**************  PRINT JOB HEADER DATA *************************/

    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr
      @pchObjectName        = @lvcObjectName,
      @pdtProcessStartTime  = @ldtProcessStartTime,
      @pchServerName        = @lvcServerName,
      @pchDBName            = @lvcDBName,
      @pchUserName          = @lvcUser,
      @pchVersionNum        = @lvcVersionNum


/**************  PRINT STEP 1 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Truncating stage table fabncdv1stage.dbo.tpzt_usable_meme_crosswalk_extr'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 1 Truncating stage table fabncdv1stage.dbo.tpzt_usable_meme_crosswalk_extr **********/

   TRUNCATE TABLE fabncdv1stage.dbo.tpzt_usable_meme_crosswalk_extr
               
/********** Error Checking for truncate statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Truncating stage table fabncdv1stage.dbo.tpzt_usable_meme_crosswalk_extr FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 1 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed
      
/**************  PRINT STEP 2 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Inserting updated records in stage table fabncdv1stage.dbo.tpzt_usable_meme_crosswalk_extr'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 2 Inserting updated records in stage table fabncdv1stage.dbo.tpzt_usable_meme_crosswalk_extr **********/

    INSERT INTO fabncdv1stage.dbo.tpzt_usable_meme_crosswalk_extr 
      (
        OLD_GROUP_NUMBER,
        NEW_GROUP_NUMBER,
        NEW_GROUP_NAME,
        OLD_MEMBER_NUMBER,
        NEW_MEMBER_NUMBER,
        SSN,
        MEMBER_NAME
      )
    SELECT DISTINCT
        OLD_GROUP_NUMBER   = LEFT(SUBSTRING(ISNULL(LTRIM(RTRIM(atuf.ATUF_TEXT1)),''),1,8) + SPACE(8),8),
        NEW_GROUP_NUMBER   = LEFT(SUBSTRING(ISNULL(LTRIM(RTRIM(grgr.GRGR_ID)),''),1,8) + SPACE(8),8),
        NEW_GROUP_NAME     = LEFT(SUBSTRING(ISNULL(LTRIM(RTRIM(grgr.GRGR_NAME)),''),1,30) + SPACE(30),30),
        OLD_MEMBER_NUMBER  = LEFT(SUBSTRING(ISNULL(LTRIM(RTRIM(atuf.ATUF_TEXT2)),''),1,12) + SPACE(12),12),
        NEW_MEMBER_NUMBER  = LEFT(ISNULL(LTRIM(RTRIM(sbsb.SBSB_ID)),'') + SPACE(12),12),
        SSN                = LEFT(ISNULL(LTRIM(RTRIM(meme.MEME_SSN)),'') + SPACE(9),9),
        MEMBER_NAME        = LEFT(SUBSTRING(ISNULL(LTRIM(RTRIM(meme.MEME_FIRST_NAME)),''),1,10) + ' ' +
                                SUBSTRING(ISNULL(LTRIM(RTRIM(meme.MEME_MID_INIT)),''),1,1) + ' ' +
                                SUBSTRING(ISNULL(LTRIM(RTRIM(meme.MEME_LAST_NAME)),''),1,10) + SPACE(21),21)
    FROM 
        fabncdv1.dbo.CMC_GRGR_GROUP grgr
        INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
        INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe ON mepe.MEME_CK = meme.MEME_CK
		INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi ON cspi.CSPI_ID = mepe.CSPI_ID
        INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb ON meme.SBSB_CK = sbsb.SBSB_CK
        LEFT JOIN fabncdv1.dbo.CER_ATXR_ATTACH_U atxr ON atxr.ATXR_SOURCE_ID = meme.ATXR_SOURCE_ID
        LEFT JOIN fabncdv1.dbo.CER_ATUF_USERFLD_D atuf ON atuf.ATSY_ID = atxr.ATSY_ID
    WHERE 
		cspi.CSPD_CAT IN ('X','Y','L','A','S','T','Z','B','E','K','J')
        (CONVERT(VARCHAR(8),GETDATE(),112) BETWEEN CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) AND CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112)
         OR CONVERT(VARCHAR(8),mepe.MEPE_EFF_DT,112) >= CONVERT(VARCHAR(8),GETDATE(),112)
         OR CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112) > DATEADD(MONTH,-12,CONVERT(VARCHAR(8),GETDATE(),112)))

/********** Error Checking for insert statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Inserting updated records in stage table fabncdv1stage.dbo.tpzt_usable_meme_crosswalk_extr FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 2 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed

/**************  PRINT JOB FOOTER DATA ****************************/

    SELECT @ldtProcessEndTime = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr
      @pchObjectName          = @lvcObjectName,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pdtProcessEndTime      = @ldtProcessEndTime
    RETURN  @lnRetCd
END
GO
/****************************************************************
 BEGIN MAINTENANCE WRAPPER:
*****************************************************************/
IF OBJECT_ID('dbo.tpzp_usable_meme_crosswalk_extr') IS NOT NULL
  PRINT '<<< CREATED PROCEDURE dbo.tpzp_usable_meme_crosswalk_extr >>>'
       
ELSE
  PRINT '<<<ERROR CREATING PROCEDURE dbo.tpzp_usable_meme_crosswalk_extr >>>'
GO

/****************************************************************
 END MAINTENANCE WRAPPER:
*****************************************************************/