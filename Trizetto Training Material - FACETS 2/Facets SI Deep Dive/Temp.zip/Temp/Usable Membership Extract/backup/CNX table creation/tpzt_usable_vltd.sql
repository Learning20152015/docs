/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_vltd') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_vltd
  IF OBJECT_ID('dbo.tpzt_usable_vltd') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_vltd >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_vltd >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_vltd
/****************************************************************
**   NAME                  : dbo.tpzt_usable_vltd
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : Voluntary Long Term Disability (VLTD)
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0       07/31/2014   Shekhar Kadam      Intial Version
****************************************************************/
(   
	GRGR_ID								varchar(8) null,
	GRGR_ID_OLD							varchar(8) null,
	CSCS_ID								varchar(4) null,
	CSCS_ID_OLD							varchar(4) null,
	CSPI_ID								varchar(8) null,
	ELIMINATION_PERIOD					int null,
	BENEFIT_TYPE						varchar(10) null,
	BENEFIT_PERCENTAGE					int null,
	MAXIMUM_AMOUNT						money null,
	OCCUPATION_MONTHLY_PERIOD			int null,
	EARNINGS_TEST						varchar(10) null,
	SALARY_INCLUDES						varchar(20) null,
	SS_INTEGRATION						varchar(10) null,
	BENEFIT_CALCULATION					varchar(10) null,
	MAX_BENEFIT_PERIOD					varchar(10) null,
	DISABILITY_DEFINITION				varchar(50) null,
	MINIMUM_BENEFIT						varchar(10) null,
	EXISTING_CONDITION_EXCLUSION		varchar(10) null,
	SPECIAL_CONDITION_LIMITATION		char(1) null,
	SURVIVOR_BENEFITS					varchar(10) null,
	IS_SEC125_CAFETERIA_PLAN			char(1) null,
	PRIOR_CARRIER						varchar(25) null,		
	TERMINATION_DATE					datetime null
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_vltd') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_vltd >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_vltd >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
