/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_ltd') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_ltd
  IF OBJECT_ID('dbo.tpzt_usable_ltd') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_ltd >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_ltd >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_ltd
/****************************************************************
**   NAME                  : dbo.tpzt_usable_ltd
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : Long Term Disability (LTD)
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0       07/31/2014   Shekhar Kadam      Intial Version
****************************************************************/
(   
    GRGR_ID						varchar(8) null,
    GRGR_ID_OLD					varchar(8) null,
    CSCS_ID						varchar(4) null,
    CSCS_ID_OLD					varchar(4) null,
    CSPI_ID						varchar(8) null,
	PLAN_TYPE					varchar(20) null,
	EMPLOYER_CONTRIBUTION		int null,
	SALARY_GROSS_UP				char(1) null,
	ELIMINATION_PERIOD			int null,
	OCCUPATION_MONTHLY_PERIOD	varchar(20) null,
	SALARY_INCLUDES				varchar(30) null,
	SS_INTEGRATION				varchar(50) null,
	BENEFIT_CALCULATION			varchar(10) null,
	PERCENTAGE_OF_SALARY		decimal(5,2) null,
	MONTHLY_MAXIMUM				money,
	MAX_BENEFIT_PERIOD			varchar(50)  null,
	DISABILITY_DEF				varchar(50)	 null,
	EARNING_TESTS				varchar(10) null,
	MINIMUM_BENEFIT				varchar(10) null,
	COND_EXCLUSION_EXISTING		varchar(10) null,
	SPECIAL_CONDITION_LIMITATION	char(1) null,
	SURVIVOR_BENEFIT				varchar(10) null,
	TELEPHONIC_EAP				char(1) null,
	FICA						char(1) null,
	PRIOR_CARRIER				varchar(20) null,
	PARTICIPATION_PERCENTAGE	int null        
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_ltd') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_ltd >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_ltd >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
