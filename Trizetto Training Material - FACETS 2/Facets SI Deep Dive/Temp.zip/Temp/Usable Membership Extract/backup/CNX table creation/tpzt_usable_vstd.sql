/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_vstd') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_vstd
  IF OBJECT_ID('dbo.tpzt_usable_vstd') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_vstd >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_vstd >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_vstd
/****************************************************************
**   NAME                  : dbo.tpzt_usable_vstd
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : Voluntary Short Term Disability (VSTD)
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0       07/31/2014   Shekhar Kadam      Intial Version
****************************************************************/
(   
	GRGR_ID							varchar(8) null,
	GRGR_ID_OLD						varchar(8) null,
	CSCS_ID							varchar(4) null,
	CSCS_ID_OLD						varchar(4) null,
	CSPI_ID							varchar(8) null,
	ACCIDENT_SICK_DURATION			varchar(10) null,
	BENEFIT_TYPE					varchar(10) null,
	MAX_AMOUNT						money null,
	BENEFIT_PERCENTAGE				decimal(5,2) null,
	MAX_WEEKLY_BENEFIT				money null,
	IS_SEC125_CAFETERIA_PLAN		char(1),
	PRIOR_CARRIER					varchar(20) null,	
	PARTICIPATION_PERCENTAGE		decimal(5,2) null

)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_vstd') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_vstd >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_vstd >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
