/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_dl') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_dl
  IF OBJECT_ID('dbo.tpzt_usable_dl') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_dl >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_dl >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_dl
/****************************************************************
**   NAME                  : dbo.tpzt_usable_dl
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : Dependent Life (DL)
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0       07/31/2014   Shekhar Kadam      Intial Version
****************************************************************/
(  
	GRGR_ID					varchar(8) null,
	GRGR_ID_OLD				varchar(8) null,
	CSCS_ID					varchar(4) null,
	CSCS_ID_OLD				varchar(4) null,
	CSPI_ID					varchar(8) null, 
	EMPLOYER_CONTRIBUTION	int null,
	COVERAGE_OPTION			varchar(20) null,
	[PLAN]					money null
        
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_dl') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_dl >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_dl >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
