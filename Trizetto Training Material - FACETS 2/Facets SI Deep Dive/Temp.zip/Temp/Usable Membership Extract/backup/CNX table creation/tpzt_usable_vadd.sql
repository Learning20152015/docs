/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_vadd') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_vadd
  IF OBJECT_ID('dbo.tpzt_usable_vadd') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_vadd >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_vadd >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_vadd
/****************************************************************
**   NAME                  : dbo.tpzt_usable_vadd
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : Voluntary Accidental Death & Dismemberment (VADD)
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0       07/31/2014   Shekhar Kadam      Intial Version
****************************************************************/
(   
	GRGR_ID						varchar(8) null,
	GRGR_ID_OLD					varchar(8) null,
	CSCS_ID						varchar(4) null,
    CSCS_ID_OLD					varchar(4) null,
	CSPI_ID						varchar(8) null,
	DEP_CHILD_COVERAGE			money null,
	BENEFIT_AMOUNT				decimal(9,2) null,
	TIMES_SALARY				varchar(10) null,
	MAXIMUM_SALARY				money null,
	SPOUSE_AMOUNT				money null,
	COVERAGE_OPTION				varchar(10) null,
	AGE_65						int null,
	AGE_70						int null,
	AGE_75						int null,
	AGE_80						int null
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_vadd') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_vadd >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_vadd >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
