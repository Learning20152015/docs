/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_vl') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_vl
  IF OBJECT_ID('dbo.tpzt_usable_vl') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_vl >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_vl >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_vl
/****************************************************************
**   NAME                  : dbo.tpzt_usable_vl
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : Voluntary Life (VL)
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0       07/31/2014   Shekhar Kadam      Intial Version
****************************************************************/
(   
	GRGR_ID							varchar(8) null,
	GRGR_ID_OLD						varchar(8) null,
	CSCS_ID							varchar(4) null,
	CSCS_ID_OLD						varchar(4) null,
	CSPI_ID							varchar(8) null,
	IS_RATES_SMOKER_DISTINCT		char(1) null,
	GUARANTEED_ISSUE				decimal(9,2) null	,
	AGE_65							int null,
	AGE_70							int null,
	AGE_75							int null,
	AGE_80							int null,
	COVERAGE_OPTION					decimal(5,2) null,
	BENEFIT_AMOUNT					decimal(9,2) null,
	DEPENDANT_CHILD_COVERAGE		varchar(10) null,
	TIMES_SALARY					varchar(10) null,
	MAXIMUM_SALARY					money null,
	SPOUSE_AMOUNT					money null
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_vl') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_vl >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_vl >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
