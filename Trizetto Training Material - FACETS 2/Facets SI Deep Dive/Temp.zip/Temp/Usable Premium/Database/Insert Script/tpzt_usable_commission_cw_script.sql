/****************************************************************
**   NAME                  : tpzt_usable_commission_cw_script
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\SQL\Stage
**
**   FUNCTION              : This table is used to hold the commission percentage detail.
**
**   REVISION HISTORY      :
**
**   VERSION   DATE         DEVELOPER        DESCRIPTION
**   -------   ----------   -------------    ------------------
**   1.0       08/27/2014   Ghazala Ameen    Initial Version
****************************************************************/
   /***********   Truncate staging table tpzt_usable_commission_cw   ***********/

    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_usable_commission_cw
    GO
    
    /*********************   End of TRUNCATE statement   **********************/

    /*******  Inserting data into  staging table tpzt_usable_commission_cw  ******/

INSERT INTO fabncdv1stage.dbo.tpzt_usable_commission_cw (MIN_MARKET_SEGMENT,MAX_MARKET_SEGMENT,BEGIN_DATE,PERCENTAGE,PLAN_DESCRIPTION) VALUES('1','50','01/01/14','0.20','') 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_commission_cw (MIN_MARKET_SEGMENT,MAX_MARKET_SEGMENT,BEGIN_DATE,PERCENTAGE,PLAN_DESCRIPTION) VALUES('51','99','01/01/14','0.18','') 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_commission_cw (MIN_MARKET_SEGMENT,MAX_MARKET_SEGMENT,BEGIN_DATE,PERCENTAGE,PLAN_DESCRIPTION) VALUES('100','249','01/01/14','0.15','') 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_commission_cw (MIN_MARKET_SEGMENT,MAX_MARKET_SEGMENT,BEGIN_DATE,PERCENTAGE,PLAN_DESCRIPTION) VALUES('250','999','01/01/14','0.10','') 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_commission_cw (MIN_MARKET_SEGMENT,MAX_MARKET_SEGMENT,BEGIN_DATE,PERCENTAGE,PLAN_DESCRIPTION) VALUES('1000','','01/01/14','0.6','') 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_commission_cw (MIN_MARKET_SEGMENT,MAX_MARKET_SEGMENT,BEGIN_DATE,PERCENTAGE,PLAN_DESCRIPTION) VALUES('','','01/01/14','0.25','Voluntary Life') 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_commission_cw (MIN_MARKET_SEGMENT,MAX_MARKET_SEGMENT,BEGIN_DATE,PERCENTAGE,PLAN_DESCRIPTION) VALUES('','','01/01/14','0.25','Voluntary ADD') 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_commission_cw (MIN_MARKET_SEGMENT,MAX_MARKET_SEGMENT,BEGIN_DATE,PERCENTAGE,PLAN_DESCRIPTION) VALUES('','','01/01/14','0.25','Voluntary STD') 
GO
INSERT INTO fabncdv1stage.dbo.tpzt_usable_commission_cw (MIN_MARKET_SEGMENT,MAX_MARKET_SEGMENT,BEGIN_DATE,PERCENTAGE,PLAN_DESCRIPTION) VALUES('','','01/01/14','0.25','Voluntary LTD') 
GO