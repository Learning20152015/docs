/***************************************************************
  BEGIN MAINTENANCE WRAPPER.
***************************************************************/

IF OBJECT_ID('dbo.tpzp_usable_premium_ntake_extr') IS NOT NULL
BEGIN
  DROP PROCEDURE dbo.tpzp_usable_premium_ntake_extr

  IF OBJECT_ID('dbo.tpzp_usable_premium_ntake_extr') IS NOT NULL
    PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_usable_premium_ntake_extr >>>'
  ELSE
    PRINT '<<< DROPPED PROCEDURE dbo.tpzp_usable_premium_ntake_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
***************************************************************/

CREATE PROCEDURE [dbo].[tpzp_usable_premium_ntake_extr]

/****************************************************************
**   NAME                  : dbo.tpzp_usable_premium_ntake_extr
**
**
**   PVCS LOCATION         : 
**
**   FUNCTION              : STEP 1 Truncating stage table fabncdv1stage.dbo.tpzt_usable_premium_ntake_extr 
**                           STEP 2 Inserting updated records in stage table fabncdv1stage.dbo.tpzt_usable_premium_ntake_extr
**                           STEP 3 Updating Staging table tpzt_usable_premium_ntake_extr
**                           STEP 4 Updating Staging table tpzt_usable_premium_ntake_extr  for LIF_COUNT column
**                           STEP 5 Updating Staging table tpzt_usable_premium_ntake_extr  for calculating count for various plans
**                           STEP 6 Updating Staging table tpzt_usable_premium_ntake_extr  for calculating count for various voluntary plans
**                           STEP 7 Inserting values in stage table tpzt_usable_premium_ntake_extr for various Benefit Amounts and Benfit Rate per unit life columns
**                           STEP 8 Truncate Staging table tpzt_usable_premium_ntake_error
**                           STEP 9 Insert error records in staging table tpzt_usable_premium_ntake_error
**
**   PARAMETERS            :
**                   INPUT :
**                  OUTPUT :
**
**   RETURN CODES          : 0 on success
**
**   TABLES REFERENCED     :
**                FACETS   : fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi  
**                           fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei
**                           fabncdv1.dbo.CMC_BLBL_BILL_SUMM blbl
**                           fabncdv1.dbo.CDS_INSB_SB_DETAIL
**
**                FACETSXC : N/A
**                CUSTOM   : 
**                STAGE    : fabncdv1stage.dbo.tpzt_comm_elig_extr
**                           fabncdv1stage.dbo.tpzt_usable_vadd
**                           fabncdv1stage.dbo.tpzt_usable_vl
**                           fabncdv1stage.dbo.tpzt_usable_sa
**                           fabncdv1stage.dbo.tpzt_usable_sl
**                           fabncdv1stage.dbo.tpzt_usable_ltd
**                           fabncdv1stage.dbo.tpzt_usable_wdb
**                           fabncdv1stage.dbo.tpzt_usable_dl
**                           fabncdv1stage.dbo.tpzt_usable_gtl_add
**
**   PROCEDURES REFERENCED :
**                  FACETS :
**                  CUSTOM :
**   STANDARD LOGGING PROCS:
**                           harcore.dbo.harsp_gen_util_job_hdr_lgr
**                           harcore.dbo.harsp_gen_util_job_ftr_lgr
**                           harcore.dbo.harsp_gen_util_step_hdr_lgr
**                           harcore.dbo.harsp_gen_util_step_ftr_lgr
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0      08/26/2014   Ghazala Ameen       Initial Version
** 1.1      09/26/2014   Ghazala Ameen       Updated logic for Premium Amount and Commission Column and 
                                             updated for Bill Create date and Bill From date
** 1.2      10/08/2014   Ghazala Ameen       Updated for sign before premium amounts
** 1.3      10/21/2014   Shekhar Kadam       Sorted by Group number.
****************************************************************/
AS

BEGIN

/****************************************************************
**          DECLARE LOCAL VARIABLES                            **
****************************************************************/

    DECLARE @lnRetCd                INT              -- Proc return code
    DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time
    DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
    DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time
    DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time
    DECLARE @lnCurrentStep          INT              -- Current Step Number
    DECLARE @lnTotalSteps           INT              -- Total Steps In Proc
    DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field
    DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name
    DECLARE @lvcDBName              VARCHAR(32)      -- DB Name
    DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version
    DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name
    DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name
    DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step
    DECLARE @ldtLastRunDt           DATETIME         -- Last run date
    DECLARE @ldtCurrentDate         DATETIME         -- Current date
    DECLARE @lvcCommission_li       VARCHAR(15)      -- Commision Percentage for life premium plans
    DECLARE @lvcCommission_add      VARCHAR(15)      -- Commision Percentage for add premium plans
    DECLARE @lvcCommission_dl       VARCHAR(15)      -- Commision Percentage for dependent life premium plans
    DECLARE @lvcCommission_wdb      VARCHAR(15)      -- Commision Percentage for wdb premium plans
    DECLARE @lvcCommission_ltd      VARCHAR(15)      -- Commision Percentage for ltd premium plans
    DECLARE @lvcCommission_sl       VARCHAR(15)      -- Commision Percentage for supplemental life premium plans
    DECLARE @lvcCommission_sa       VARCHAR(15)      -- Commision Percentage for supplemental add premium plans
    DECLARE @lvcCommission_vlisp    VARCHAR(15)      -- Commision Percentage for Voluntary life spouse premium plans
    DECLARE @lvcCommission_vlich    VARCHAR(15)      -- Commision Percentage for Voluntary life child premium plans
    DECLARE @lvcCommission_vaddsp   VARCHAR(15)      -- Commision Percentage for Voluntary add spouse premium plans
    DECLARE @lvcCommission_vaddch   VARCHAR(15)      -- Commision Percentage for Voluntary add child premium plans
    DECLARE @lvcCommission_vl       VARCHAR(15)      -- Commision Percentage for Voluntary Life plan
    DECLARE @lvcCommission_vadd     VARCHAR(15)      -- Commision Percentage for Voluntary ADD plan
    DECLARE @lvcCommission_vstd     VARCHAR(15)      -- Commision Percentage for Voluntary STD plan
    DECLARE @lvcCommission_vltd     VARCHAR(15)      -- Commision Percentage for Voluntary LTD plan
    
    

----------- table variable for stroing premium information ------------------    
    declare  @PremiumNtake_extr TABLE 
		(
			GROUP_NUMBER                   VARCHAR (8) NULL,
			GROUP_NAME                     VARCHAR (120) NULL,
			BLCT_DISP_CD                   VARCHAR (1) NULL,
			LIFE_PREMIUM_AMOUNT            VARCHAR (14) NULL,
			ADD_PREMIUM_AMOUNT             VARCHAR (14) NULL,
			DEP_PREMIUM_AMOUNT             VARCHAR (14) NULL,
			WDB_PREMIUM_AMOUNT             VARCHAR (14) NULL,
			LTD_PREMIUM_AMOUNT             VARCHAR (14) NULL,
			SLI_PREMIUM_AMOUNT             VARCHAR (14) NULL,
			SAD_PREMIUM_AMOUNT             VARCHAR (14) NULL,
			VOLUNTARY_LIF_PREMIUM_AMOUNT   VARCHAR (14) NULL,
			VOLUNTARY_LIFSP_PREMIUM_AMOUNT VARCHAR (14) NULL,
			VOLUNTARY_LIFCH_PREMIUM_AMOUNT VARCHAR (14) NULL,
			VOLUNTARY_ADD_PREMIUM_AMOUNT   VARCHAR (14) NULL,
			VOLUNTARY_ADDSP_PREMIUM_AMOUNT VARCHAR (14) NULL,
			VOLUNTARY_ADDCH_PREMIUM_AMOUNT VARCHAR (14) NULL,
			VOLUNTARY_STD_PREMIUM_AMOUNT   VARCHAR (14) NULL,
			VOLUNTARY_LTD_PREMIUM_AMOUNT   VARCHAR (14) NULL,
			PREMIUM_AMOUNT                 VARCHAR (16) NULL,
			COMMISSION                     VARCHAR (16) NULL,
			NET_AMOUNT                     VARCHAR (16) NULL,
			LIF_COUNT                      VARCHAR (6) NULL,
			ADD_COUNT                      VARCHAR (6) NULL,
			DEP_COUNT                      VARCHAR (6) NULL,
			STD_COUNT                      VARCHAR (6) NULL,
			LTD_COUNT                      VARCHAR (6) NULL,
			SLI_COUNT                      VARCHAR (6) NULL,
			SAD_COUNT                      VARCHAR (6) NULL,
			VOLUNTARY_LIF_COUNT            VARCHAR (6) NULL,
			VOLUNTARY_LIFSP_COUNT          VARCHAR (6) NULL,
			VOLUNTARY_LIFCH_COUNT          VARCHAR (6) NULL,
			VOLUNTARY_ADD_COUNT            VARCHAR (6) NULL,
			VOLUNTARY_ADDSP_COUNT          VARCHAR (6) NULL,
			VOLUNTARY_ADDCH_COUNT          VARCHAR (6) NULL,
			VOLUNTARY_LTD_COUNT            VARCHAR (6) NULL,
			VOLUNTARY_STD_COUNT            VARCHAR (6) NULL,
			BENEFIT_AMOUNT_FOR_LIFE        VARCHAR (16) NULL,
			BENEFIT_AMOUNT_FOR_ADD         VARCHAR (16) NULL,
			BENEFIT_AMOUNT_FOR_DEP         VARCHAR (16) NULL,
			BENEFIT_AMOUNT_FOR_STD         VARCHAR (16) NULL,
			BENEFIT_AMOUNT_FOR_LTD         VARCHAR (16) NULL,
			BENEFIT_AMOUNT_FOR_SLI         VARCHAR (16) NULL,
			BENEFIT_AMOUNT_FOR_SAD         VARCHAR (16) NULL,
			BENEFIT_AMOUNT_FOR_VLIF        VARCHAR (16) NULL,
			BENEFIT_AMOUNT_FOR_VLIFSP      VARCHAR (16) NULL,
			BENEFIT_AMOUNT_FOR_VLIFCH      VARCHAR (16) NULL,
			BENEFIT_AMOUNT_FOR_VADD        VARCHAR (16) NULL,
			BENEFIT_AMOUNT_FOR_VADDSP      VARCHAR (16) NULL,
			BENEFIT_AMOUNT_FOR_VADDCH      VARCHAR (16) NULL,
			BENEFIT_AMOUNT_FOR_VLTD        VARCHAR (16) NULL,
			BENEFIT_AMOUNT_FOR_VSTD        VARCHAR (16) NULL,
			BENEFIT_RATE_PER_UNIT_LIFE     VARCHAR (11) NULL,
			BENEFIT_RATE_PER_UNIT_ADD      VARCHAR (11) NULL,
			BENEFIT_RATE_PER_UNIT_DEP      VARCHAR (11) NULL,
			BENEFIT_RATE_PER_UNIT_STD      VARCHAR (11) NULL,
			BENEFIT_RATE_PER_UNIT_LTD      VARCHAR (11) NULL,
			BENEFIT_RATE_PER_UNIT_SLI      VARCHAR (11) NULL,
			BENEFIT_RATE_PER_UNIT_SAD      VARCHAR (11) NULL,
			BENEFIT_RATE_PER_UNIT_VLIF     VARCHAR (11) NULL,
			BENEFIT_RATE_PER_UNIT_VLIFSP   VARCHAR (11) NULL,
			BENEFIT_RATE_PER_UNIT_VLIFCH   VARCHAR (11) NULL,
			BENEFIT_RATE_PER_UNIT_VADD     VARCHAR (11) NULL,
			BENEFIT_RATE_PER_UNIT_VADDSP   VARCHAR (11) NULL,
			BENEFIT_RATE_PER_UNIT_VADDCH   VARCHAR (11) NULL,
			BENEFIT_RATE_PER_UNIT_VLTD     VARCHAR (11) NULL,
			BENEFIT_RATE_PER_UNIT_VSTD     VARCHAR (11) NULL,
			LIFE_TYPE                      VARCHAR (30) DEFAULT (space((30))) NULL,
			ADD_TYPE                       VARCHAR (30) DEFAULT (space((30))) NULL,
			DEP_TYPE                       VARCHAR (30) DEFAULT (space((30))) NULL,
			STD_TYPE                       VARCHAR (30) DEFAULT (space((30))) NULL,
			LTD_TYPE                       VARCHAR (30) DEFAULT (space((30))) NULL,
			SLI_TYPE                       VARCHAR (30) DEFAULT (space((30))) NULL,
			SAD_TYPE                       VARCHAR (30) DEFAULT (space((30))) NULL,
			VLIF_TYPE                      VARCHAR (30) DEFAULT (space((30))) NULL,
			VLIFSP_TYPE                    VARCHAR (30) DEFAULT (space((30))) NULL,
			VLIFCH_TYPE                    VARCHAR (30) DEFAULT (space((30))) NULL,
			VADD_TYPE                      VARCHAR (30) DEFAULT (space((30))) NULL,
			VADDSP_TYPE                    VARCHAR (30) DEFAULT (space((30))) NULL,
			VADDCH_TYPE                    VARCHAR (30) DEFAULT (space((30))) NULL,
			VLTD_TYPE                      VARCHAR (30) DEFAULT (space((30))) NULL,
			VSTD_TYPE                      VARCHAR (30) DEFAULT (space((30))) NULL,
			BILL_FROM_DATE                 VARCHAR (10) NULL,
			BILL_CREATE_DATE               VARCHAR (10) NULL
	)		
		
		
	
----------- Table variable for storing  product category count other an vol prod ------------------    
    DECLARE @ProdCount TABLE
    (
        GRGR_ID      VARCHAR(8),
        L            VARCHAR(6),
        A            VARCHAR(6),
        E            VARCHAR(6),
        K            VARCHAR(6),
        S            VARCHAR(6),
        T            VARCHAR(6),
        X            VARCHAR(6),
        Y            VARCHAR(6),
        J            VARCHAR(6)
    )
----------- Table variable for storing  vol product category count other an vol prod ------------------     
    DECLARE @VolProdCount TABLE
    (
        GRGR_ID        VARCHAR(8),
        MEME_REL       VARCHAR(1),
        Z              VARCHAR(6),
        B              VARCHAR(6)
    )
	
----------- Table variable for storing  product category premium amount other an vol prod ------------------    
    DECLARE @PremiumAmount TABLE
    (
        GROUP_NUMBER                    VARCHAR(8),
        GROUP_NAME                      VARCHAR(120),
        BLCT_DISP_CD					varchar(1),
        LIFE_PREMIUM_AMOUNT             VARCHAR(14),
        ADD_PREMIUM_AMOUNT              VARCHAR(14),
		DEP_PREMIUM_AMOUNT              VARCHAR(14),
        WDB_PREMIUM_AMOUNT              VARCHAR(14),
        LTD_PREMIUM_AMOUNT              VARCHAR(14),
        SLI_PREMIUM_AMOUNT              VARCHAR(14),
        SAD_PREMIUM_AMOUNT              VARCHAR(14),
        VOLUNTARY_STD_PREMIUM_AMOUNT    VARCHAR(14),
        VOLUNTARY_LTD_PREMIUM_AMOUNT    VARCHAR(14),
        BILL_FROM_DATE					varchar(10),
        BILL_CREATE_DATE				varchar(10)
    )
    
----------- Table variable for storing  product category premium amount other for vol prod ------------------    
    DECLARE @PremiumAmountVolMem TABLE
    (
        GROUP_NUMBER                    VARCHAR(8),
        GROUP_NAME                      VARCHAR(120),
        MEM_REL                         VARCHAR(1),
        BLCT_DISP_CD					varchar(1),
        VOLUNTARY_LIF_PREMIUM_AMOUNT    VARCHAR(14),
        VOLUNTARY_ADD_PREMIUM_AMOUNT    VARCHAR(14),
        BILL_FROM_DATE					varchar(10),
        BILL_CREATE_DATE				varchar(10)
    )
    
----------- Table variable for storing  Premium amount for voluntary products for spouse ------------------    --
	DECLARE @PremiumAmountVolSp TABLE
    (
        GROUP_NUMBER                    VARCHAR(8),
        GROUP_NAME                      VARCHAR(120),
        MEM_REL                         VARCHAR(1),
        BLCT_DISP_CD					varchar(1),
        VOLUNTARY_LIFSP_PREMIUM_AMOUNT  VARCHAR(14),
        VOLUNTARY_ADDSP_PREMIUM_AMOUNT  VARCHAR(14),
        BILL_FROM_DATE					varchar(10),
        BILL_CREATE_DATE				varchar(10)
    )
    
	
----------- Table variable for storing  --Premium amount for voluntary products for children ------------------    -- 
	DECLARE @PremiumAmountVolCh TABLE
    (
        GROUP_NUMBER                    VARCHAR(8),
        GROUP_NAME                      VARCHAR(120),
        MEM_REL                         VARCHAR(1),
        BLCT_DISP_CD					varchar(1),
        VOLUNTARY_LIFCH_PREMIUM_AMOUNT    VARCHAR(14),
        VOLUNTARY_ADDCH_PREMIUM_AMOUNT    VARCHAR(14),
        BILL_FROM_DATE					varchar(10),
        BILL_CREATE_DATE				varchar(10)
    )
    
----------- Table variable for storing commission ---------------------------
    DECLARE @CommissionTable TABLE
    (
		GROUP_NUMBER		VARCHAR(8),
		BLCT_DISP_CD		VARCHAR(1),
		BILL_FROM_DATE		VARCHAR(10),
		BILL_CREATE_DATE	VARCHAR(10),
		PREMIUM_TOTAL		VARCHAR(16),
        Commission			VARCHAR(16),        
        COM_VOL_LIF_PREMIUM_COM VARCHAR(16),        
        COM_VOL_ADD_PREMIUM_COM VARCHAR(16),        
        COM_VOL_STD_PREMIUM_COM VARCHAR(16),        
        COM_VOL_LTD_PREMIUM_COM VARCHAR(16)
    )
	--no of Employees
	DECLARE @NOEMPLOYESS TABLE
	(
		GROUP_NUMBER		VARCHAR(8), 
		GRGR_TOTAL_EMPL		INT,
		PERCENTAGE			DECIMAL(3,2)
	)
	
	DECLARE @IntCommission TABLE
	(	
		GROUP_NUMBER		VARCHAR(8),
		BLCT_DISP_CD		VARCHAR(1),
		BILL_FROM_DATE		VARCHAR(10), 
		BILL_CREATE_DATE	VARCHAR(10),
		PREMIUM_TOTAL		VARCHAR(16)
	)

--------Table variable for vol prod category --------------------	
	DECLARE @VOLPRODCAT TABLE
	(
		GROUP_NUMBER		VARCHAR(8),
		PERCENTAGE			DECIMAL(3,2),
		CSPD_CAT			VARCHAR(1),
		BLCT_DISP_CD		VARCHAR(1),
		BILL_FROM_DATE		VARCHAR(10), 
		BILL_CREATE_DATE	VARCHAR(10),
		PREMIUM_TOTAL		VARCHAR(16)
	)

/****************************************************************
**          INITIALIZE  VARIABLES                              **
****************************************************************/

    SELECT @lnRetCd        = 0, 
      @lvcMsg              = NULL,
      @lnCurrentStep       = 0,  
      @lnTotalSteps        = 9,
      @ldtStepEndTime      = NULL,
      @lvcVersionNum       = '1.1'

    SELECT @lvcServerName  = @@SERVERNAME,
      @lvcDBName           = DB_NAME(),
      @lvcUser             = USER_NAME(),
      @lvcObjectName       = OBJECT_NAME(@@PROCID),
      @ldtProcessStartTime = GETDATE(),
      @ldtCurrentDate      = CONVERT(VARCHAR (10), GETDATE(), 101)

/****************************************************************
**               BEGIN PROCESS                                 **
*****************************************************************/

/**************  PRINT JOB HEADER DATA *************************/

    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr
      @pchObjectName        = @lvcObjectName,
      @pdtProcessStartTime  = @ldtProcessStartTime,
      @pchServerName        = @lvcServerName,
      @pchDBName            = @lvcDBName,
      @pchUserName          = @lvcUser,
      @pchVersionNum        = @lvcVersionNum


/**************  PRINT STEP 1 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Truncating stage table fabncdv1stage.dbo.tpzt_usable_premium_ntake_extr'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 1 Truncating stage table fabncdv1stage.dbo.tpzt_usable_premium_ntake_extr **********/

   TRUNCATE TABLE fabncdv1stage.dbo.tpzt_usable_premium_ntake_extr
               
/********** Error Checking for truncate statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Truncating stage table fabncdv1stage.dbo.tpzt_usable_premium_ntake_extr FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 1 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed
      
/**************  PRINT STEP 2 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Inserting updated records in stage table fabncdv1stage.dbo.tpzt_usable_premium_ntake_extr'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 2 Inserting updated records in stage table @PremiumNtake_extr **********/

/***** Inserting for Premium Amounts in table variable other than vol product******/

	 ;WITH CTE_COMM ( CSPDCAT,BLCT_DISP_CD,GROUP_NUMBER,GROUP_NAME,PREMIUM_AMOUNT,BILL_FROM_DATE,BILL_CREATE_DATE)
	 as
	 (
	 SELECT  DISTINCT CSPDCAT =cspi.CSPD_CAT , 
			inct.BLCT_DISP_CD ,
			GROUP_NUMBER                   = LEFT(ISNULL(LTRIM(RTRIM(grgr.GRGR_ID)),'') + SPACE(8),8),
	        
			GROUP_NAME                     = LEFT(ISNULL(SUBSTRING(LTRIM(RTRIM(grgr.GRGR_NAME)),1,120),'') + SPACE(120),120),
			PREMIUM_AMOUNT =  case when cspi.CSPD_CAT IN ('X','Y','L','A','S','E','K','J')
										then inct.BLCT_PREM_SB
									when cspi.CSPD_CAT IN ('T')
										then inct.BLCT_PREM_DEP
								end,
	        
			BILL_FROM_DATE				= CONVERT(VARCHAR(10), bliv.BLBL_DUE_DT,101),
			BILL_CREATE_DATE			= CONVERT(VARCHAR(8),bliv.BLIV_CREATE_DTM, 112)
	        
			FROM  fabncdv1.dbo.CMC_GRGR_GROUP grgr 
					INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
					INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
					INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
			        												
					LEFT JOIN fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
	        														
        			LEFT JOIN fabncdv1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blei.BLEI_CK
					INNER JOIN fabncdv1.dbo.CDS_INCT_COMPONENT inct ON inct.BLIV_ID = bliv.BLIV_ID
												AND inct.CSPI_ID = cspi.CSPI_ID
			WHERE cspi.CSPD_CAT IN ('X','Y','L','A','S','T','E','K','J')
										
			AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101') 
										AND DATEADD(s,-0,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,-1)))
										
			AND  inct.BLCT_DISP_CD IN ('M', 'R')   
			)	
			
		
		INSERT INTO @PremiumAmount 
		(
			GROUP_NUMBER,
			GROUP_NAME,
			BLCT_DISP_CD,
			LIFE_PREMIUM_AMOUNT,
			ADD_PREMIUM_AMOUNT,
			DEP_PREMIUM_AMOUNT,
			WDB_PREMIUM_AMOUNT,
			LTD_PREMIUM_AMOUNT,
			SLI_PREMIUM_AMOUNT,
			SAD_PREMIUM_AMOUNT,
			VOLUNTARY_STD_PREMIUM_AMOUNT,
			VOLUNTARY_LTD_PREMIUM_AMOUNT,
			BILL_FROM_DATE,
			BILL_CREATE_DATE
		)
		SELECT 
		   GROUP_NUMBER,
		   GROUP_NAME,
		   BLCT_DISP_CD,
		   isnull(L,'+0000000000.00') AS LIFE_PREMIUM_AMOUNT,
		   isnull(A,'+0000000000.00') AS ADD_PREMIUM_AMOUNT,
		   isnull(T,'+0000000000.00') AS DEP_PREMIUM_AMOUNT,
		   isnull(X,'+0000000000.00') AS WDB_PREMIUM_AMOUNT,
		   isnull(Y,'+0000000000.00') AS LTD_PREMIUM_AMOUNT,
		   isnull(S,'+0000000000.00') AS SLI_PREMIUM_AMOUNT,
		   isnull(E,'+0000000000.00') AS SAD_PREMIUM_AMOUNT,
		   isnull(K,'+0000000000.00') AS VOLUNTARY_STD_PREMIUM_AMOUNT,
		   isnull(J,'+0000000000.00') AS VOLUNTARY_LTD_PREMIUM_AMOUNT,
		   BILL_FROM_DATE,
		   BILL_CREATE_DATE
	       
		FROM
		(
			SELECT CSPDCAT,BLCT_DISP_CD,GROUP_NUMBER,GROUP_NAME,
					PREMIUM_AMOUNT =  CASE WHEN CONVERT(DECIMAL(10,2),sum(PREMIUM_AMOUNT)) >0000000000.00
												THEN '+' + RIGHT(REPLICATE('0',13) + CAST(CAST(ISNULL(sum(PREMIUM_AMOUNT),'0000000000.00')AS NUMERIC(10,2))AS VARCHAR),13)
												WHEN  CONVERT(DECIMAL(10,2),sum(PREMIUM_AMOUNT)) < 0000000000.00
												THEN '-' + RIGHT(REPLICATE('0',13) + CAST(CAST(ISNULL(REPLACE(sum(PREMIUM_AMOUNT),'-',''),'0000000000.00')AS NUMERIC(10,2))AS VARCHAR),13)
												END,
					BILL_FROM_DATE,BILL_CREATE_DATE 
			FROM CTE_COMM
				GROUP BY CSPDCAT,BLCT_DISP_CD,GROUP_NUMBER,GROUP_NAME,BILL_FROM_DATE,BILL_CREATE_DATE
	 					
		)d
		pivot
		(
	       
		  MIN(PREMIUM_AMOUNT)
		  for CSPDCAT in (X,Y,L,A,S,T,E,K,J)
		) piv;

/****** Inserting for Voluntary Premium Amount for Subscriber in table variables ******/
;WITH CTE_COMMVS ( CSPDCAT,BLCT_DISP_CD,
					GROUP_NUMBER,	GROUP_NAME,	MEM_REL,
					PREMIUM_AMOUNT,	BILL_FROM_DATE,	BILL_CREATE_DATE)
 as
 (
	SELECT  DISTINCT CSPDCAT =cspi.CSPD_CAT ,inct.BLCT_DISP_CD ,
		
        GROUP_NUMBER                = LEFT(ISNULL(LTRIM(RTRIM(grgr.GRGR_ID)),'') + SPACE(8),8),
        GROUP_NAME                  = LEFT(ISNULL(SUBSTRING(LTRIM(RTRIM(grgr.GRGR_NAME)),1,120),'') + SPACE(120),120),
        MEM_REL                     = meme.MEME_REL,    
        PREMIUM_AMOUNT				= inct.BLCT_PREM_SB ,
        
		BILL_FROM_DATE				= CONVERT(VARCHAR(10), bliv.BLBL_DUE_DT,101),
        BILL_CREATE_DATE			= CONVERT(VARCHAR(8),bliv.BLIV_CREATE_DTM, 112)
        
        FROM  fabncdv1.dbo.CMC_GRGR_GROUP grgr 
        INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
        INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme 	ON meme.GRGR_CK = grgr.GRGR_CK
        INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
        LEFT JOIN fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei  ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
		LEFT JOIN fabncdv1.dbo.CMC_BLIV_INVOICE bliv 	ON bliv.BLEI_CK = blei.BLEI_CK
		INNER JOIN fabncdv1.dbo.CDS_INCT_COMPONENT inct ON inct.BLIV_ID = bliv.BLIV_ID
												AND inct.CSPI_ID = cspi.CSPI_ID
    WHERE cspi.CSPD_CAT IN ('Z','B')
        AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101')
							AND DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,0))) 
	AND meme.MEME_REL = 'M'
	AND 	inct.BLCT_DISP_CD IN ('M', 'R')
 )
   
   
   INSERT INTO @PremiumAmountVolMem 
    (
        GROUP_NUMBER,
        GROUP_NAME,
        MEM_REL,
    	BLCT_DISP_CD,
        VOLUNTARY_LIF_PREMIUM_AMOUNT,
        VOLUNTARY_ADD_PREMIUM_AMOUNT,
    	BILL_FROM_DATE,
        BILL_CREATE_DATE
    )
    SELECT 
        GROUP_NUMBER,
        GROUP_NAME,
        MEM_REL,
        BLCT_DISP_CD,
        isnull(Z,'+0000000000.00') AS VOLUNTARY_LIF_PREMIUM_AMOUNT,
        isnull(B,'+0000000000.00') AS VOLUNTARY_ADD_PREMIUM_AMOUNT,
        BILL_FROM_DATE,
        BILL_CREATE_DATE
    FROM
    (
    	SELECT  CSPDCAT,
    			GROUP_NUMBER,
    			GROUP_NAME, MEM_REL,
    			BLCT_DISP_CD,
				PREMIUM_AMOUNT = CASE WHEN CONVERT(DECIMAL(10,2),sum(PREMIUM_AMOUNT)) >0000000000.00
											THEN '+' + RIGHT(REPLICATE('0',13) + CAST(CAST(ISNULL(sum(PREMIUM_AMOUNT),'0000000000.00')AS NUMERIC(10,2))AS VARCHAR),13)
											WHEN  CONVERT(DECIMAL(10,2),sum(PREMIUM_AMOUNT)) < 0000000000.00
											THEN '-' + RIGHT(REPLICATE('0',13) + CAST(CAST(ISNULL(REPLACE(sum(PREMIUM_AMOUNT),'-',''),'0000000000.00')AS NUMERIC(10,2))AS VARCHAR),13)
											END,
				BILL_FROM_DATE,
				BILL_CREATE_DATE
		FROM CTE_COMMVS
			GROUP BY CSPDCAT,GROUP_NUMBER,GROUP_NAME,MEM_REL,BLCT_DISP_CD,BILL_FROM_DATE,BILL_CREATE_DATE
	
    )d
    pivot
    (
      MIN(PREMIUM_AMOUNT)
      for CSPDCAT in (Z,B)
	)piv;
    
/******* Inserting Premium Amount Values in extr table from table variables *******/
    INSERT INTO @PremiumNtake_extr 
   (
        GROUP_NUMBER,
        GROUP_NAME,
        BLCT_DISP_CD,
        LIFE_PREMIUM_AMOUNT,
        ADD_PREMIUM_AMOUNT,
		DEP_PREMIUM_AMOUNT,
        WDB_PREMIUM_AMOUNT,
        LTD_PREMIUM_AMOUNT,
        SLI_PREMIUM_AMOUNT,
        SAD_PREMIUM_AMOUNT,
        VOLUNTARY_STD_PREMIUM_AMOUNT,
        VOLUNTARY_LTD_PREMIUM_AMOUNT,
        BILL_FROM_DATE,
        BILL_CREATE_DATE   
    )
    SELECT  
        GROUP_NUMBER,
        GROUP_NAME,
        BLCT_DISP_CD,
        LIFE_PREMIUM_AMOUNT,
        ADD_PREMIUM_AMOUNT,
		DEP_PREMIUM_AMOUNT,
        WDB_PREMIUM_AMOUNT,
        LTD_PREMIUM_AMOUNT,
        SLI_PREMIUM_AMOUNT,
        SAD_PREMIUM_AMOUNT,
        VOLUNTARY_STD_PREMIUM_AMOUNT,
        VOLUNTARY_LTD_PREMIUM_AMOUNT,
        BILL_FROM_DATE,
        BILL_CREATE_DATE
    FROM @PremiumAmount

/**** Inserting Voluntary Premium Amount from table variable for Subscribers *****/
    ;with CTEM as
    (
        SELECT preAmt.GROUP_NUMBER AS GROUP_NUMBER,
               preAmt.VOLUNTARY_LIF_PREMIUM_AMOUNT AS LIFP,
               preAmt.VOLUNTARY_ADD_PREMIUM_AMOUNT AS VOLADD
        FROM @PremiumAmountVolMem preAmt
        WHERE preAmt.MEM_REL = 'M'
    )
    UPDATE extr
    SET extr.VOLUNTARY_LIF_PREMIUM_AMOUNT    = cte.LIFP,
        extr.VOLUNTARY_ADD_PREMIUM_AMOUNT = cte.VOLADD
    FROM @PremiumNtake_extr extr
    INNER JOIN CTEM cte ON cte.GROUP_NUMBER = extr.GROUP_NUMBER

/****** Inserting for Voluntary Premium Amount for Spouse in table variables ******/
   
   ;WITH CTE_COMMVSP ( CSPDCAT,BLCT_DISP_CD,GROUP_NUMBER,GROUP_NAME,MEM_REL,PREMIUM_AMOUNT,BILL_FROM_DATE,BILL_CREATE_DATE)
	 as
	 (
		SELECT  DISTINCT CSPDCAT =cspi.CSPD_CAT , inct.BLCT_DISP_CD ,
				GROUP_NUMBER                = LEFT(ISNULL(LTRIM(RTRIM(grgr.GRGR_ID)),'') + SPACE(8),8),
				GROUP_NAME                  = LEFT(ISNULL(SUBSTRING(LTRIM(RTRIM(grgr.GRGR_NAME)),1,120),'') + SPACE(120),120),
				MEM_REL                     = meme.MEME_REL,
		        PREMIUM_AMOUNT				= inct.BLCT_PREM_DEP ,
				
		        BILL_FROM_DATE				= CONVERT(VARCHAR(10), bliv.BLBL_DUE_DT,101),
				BILL_CREATE_DATE			= CONVERT(VARCHAR(8),bliv.BLIV_CREATE_DTM, 112)
        
				FROM  fabncdv1.dbo.CMC_GRGR_GROUP grgr 
				INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
				INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
				INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
				LEFT JOIN fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
				LEFT JOIN fabncdv1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blei.BLEI_CK
				INNER JOIN fabncdv1.dbo.CDS_INCT_COMPONENT inct ON inct.BLIV_ID = bliv.BLIV_ID
												AND inct.CSPI_ID = cspi.CSPI_ID
			WHERE cspi.CSPD_CAT IN ('Z','B')
			    AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101')
							AND DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,0))) 
			AND meme.MEME_REL IN('H','W')
			AND 	inct.BLCT_DISP_CD IN ('M', 'R')
	 )
   
   
   
    INSERT INTO @PremiumAmountVolSp 
    (
        GROUP_NUMBER,
        GROUP_NAME,
        MEM_REL,
        BLCT_DISP_CD,
        VOLUNTARY_LIFSP_PREMIUM_AMOUNT,
        VOLUNTARY_ADDSP_PREMIUM_AMOUNT,
        BILL_FROM_DATE,
        BILL_CREATE_DATE
    )
    SELECT 
        GROUP_NUMBER,
        GROUP_NAME,
        MEM_REL,
        BLCT_DISP_CD,
        isnull(Z,'+0000000000.00') AS VOLUNTARY_LIFSP_PREMIUM_AMOUNT,
        isnull(B,'+0000000000.00') AS VOLUNTARY_ADDSP_PREMIUM_AMOUNT,
        BILL_FROM_DATE,
        BILL_CREATE_DATE
    FROM
    (
			SELECT  CSPDCAT,
    			GROUP_NUMBER,
    			GROUP_NAME, MEM_REL,
    			BLCT_DISP_CD,
				PREMIUM_AMOUNT = CASE WHEN CONVERT(DECIMAL(10,2),sum(PREMIUM_AMOUNT)) >0000000000.00
											THEN '+' + RIGHT(REPLICATE('0',13) + CAST(CAST(ISNULL(sum(PREMIUM_AMOUNT),'0000000000.00')AS NUMERIC(10,2))AS VARCHAR),13)
											WHEN  CONVERT(DECIMAL(10,2),sum(PREMIUM_AMOUNT)) < 0000000000.00
											THEN '-' + RIGHT(REPLICATE('0',13) + CAST(CAST(ISNULL(REPLACE(sum(PREMIUM_AMOUNT),'-',''),'0000000000.00')AS NUMERIC(10,2))AS VARCHAR),13)
											END,
				BILL_FROM_DATE,
				BILL_CREATE_DATE
		FROM CTE_COMMVSP
			GROUP BY CSPDCAT,BLCT_DISP_CD,GROUP_NUMBER,GROUP_NAME,MEM_REL,BILL_FROM_DATE,BILL_CREATE_DATE
	
	
    )d
    pivot
    (
      MIN(PREMIUM_AMOUNT)
      for CSPDCAT in (Z,B)
    ) piv;
    
	
/**** Inserting Voluntary Premium Amount from table variable for Dependents *****/
    ;with CTEM as
    (
        SELECT preAmt.GROUP_NUMBER AS GROUP_NUMBER,
               preAmt.VOLUNTARY_LIFSP_PREMIUM_AMOUNT AS LIFP,
               preAmt.VOLUNTARY_ADDSP_PREMIUM_AMOUNT AS VOLADD
        FROM @PremiumAmountVolSp preAmt
    )
    UPDATE extr
    SET extr.VOLUNTARY_LIFSP_PREMIUM_AMOUNT = isnull(cte.LIFP,'+0000000000.00'),
		extr.VOLUNTARY_ADDSP_PREMIUM_AMOUNT = isnull(cte.VOLADD,'+0000000000.00')
    FROM @PremiumNtake_extr extr
    INNER JOIN CTEM cte ON cte.GROUP_NUMBER = extr.GROUP_NUMBER

/****** Inserting for Voluntary Premium Amount for Spouse in table variables ******/
   

   ;WITH CTE_COMMVCH ( CSPDCAT,BLCT_DISP_CD,GROUP_NUMBER,GROUP_NAME,MEM_REL,
					PREMIUM_AMOUNT,BILL_FROM_DATE,BILL_CREATE_DATE)
	 as
	 (
				SELECT  DISTINCT CSPDCAT =cspi.CSPD_CAT , inct.BLCT_DISP_CD,
				GROUP_NUMBER                = LEFT(ISNULL(LTRIM(RTRIM(grgr.GRGR_ID)),'') + SPACE(8),8),
				GROUP_NAME                  = LEFT(ISNULL(SUBSTRING(LTRIM(RTRIM(grgr.GRGR_NAME)),1,120),'') + SPACE(120),120),
				MEM_REL                     = meme.MEME_REL,
		        PREMIUM_AMOUNT				= inct.BLCT_PREM_DEP ,
				
				BILL_FROM_DATE				= CONVERT(VARCHAR(10), bliv.BLBL_DUE_DT,101),
				BILL_CREATE_DATE			= CONVERT(VARCHAR(8),bliv.BLIV_CREATE_DTM, 112)
		        
				FROM  fabncdv1.dbo.CMC_GRGR_GROUP grgr 
				INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
				INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
				INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
				LEFT JOIN fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
        			LEFT JOIN fabncdv1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blei.BLEI_CK
				INNER JOIN fabncdv1.dbo.CDS_INCT_COMPONENT inct ON inct.BLIV_ID = bliv.BLIV_ID
												AND inct.CSPI_ID = cspi.CSPI_ID
			WHERE cspi.CSPD_CAT IN ('Z','B')
			AND inct.CSPI_ID = cspi.CSPI_ID
			    AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101')
							AND DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,0)))  
			AND meme.MEME_REL IN('S','D')
				AND 	inct.BLCT_DISP_CD IN ('M', 'R')
	 )   
	 


	
INSERT INTO @PremiumAmountVolCh 
    (
        GROUP_NUMBER,
        GROUP_NAME,
        MEM_REL,
        BLCT_DISP_CD,
        VOLUNTARY_LIFCH_PREMIUM_AMOUNT,
        VOLUNTARY_ADDCH_PREMIUM_AMOUNT,
        BILL_FROM_DATE,
        BILL_CREATE_DATE
    )
 SELECT 
        GROUP_NUMBER,
        GROUP_NAME,
        MEM_REL,
        BLCT_DISP_CD,
        isnull(Z,'+0000000000.00') AS VOLUNTARY_LIFCH_PREMIUM_AMOUNT,
        isnull(B,'+0000000000.00') AS VOLUNTARY_ADDCH_PREMIUM_AMOUNT,
        BILL_FROM_DATE,
        BILL_CREATE_DATE
    FROM
    (
			SELECT  CSPDCAT,
    			GROUP_NUMBER,
    			GROUP_NAME, MEM_REL,
    			BLCT_DISP_CD,
				PREMIUM_AMOUNT = CASE WHEN CONVERT(DECIMAL(10,2),sum(PREMIUM_AMOUNT)) >0000000000.00
											THEN '+' + RIGHT(REPLICATE('0',13) + CAST(CAST(ISNULL(sum(PREMIUM_AMOUNT),'0000000000.00')AS NUMERIC(10,2))AS VARCHAR),13)
											WHEN  CONVERT(DECIMAL(10,2),sum(PREMIUM_AMOUNT)) < 0000000000.00
											THEN '-' + RIGHT(REPLICATE('0',13) + CAST(CAST(ISNULL(REPLACE(sum(PREMIUM_AMOUNT),'-',''),'0000000000.00')AS NUMERIC(10,2))AS VARCHAR),13)
											END,
				BILL_FROM_DATE,
				BILL_CREATE_DATE
		FROM CTE_COMMVCH
			GROUP BY CSPDCAT,BLCT_DISP_CD,GROUP_NUMBER,GROUP_NAME,MEM_REL,BILL_FROM_DATE,BILL_CREATE_DATE
	
	
    )d
    pivot
    (
      MIN(PREMIUM_AMOUNT)
      for CSPDCAT in (Z,B)
    ) piv;
   
   
   
	
/**** Inserting Voluntary Premium Amount from table variable for Dependents *****/
    ;with CTEM as
    (
        SELECT preAmt.GROUP_NUMBER AS GROUP_NUMBER,
               preAmt.VOLUNTARY_LIFCH_PREMIUM_AMOUNT AS LIFP,
               preAmt.VOLUNTARY_ADDCH_PREMIUM_AMOUNT AS VOLADD
        FROM @PremiumAmountVolCh preAmt
    )
    UPDATE extr
    SET extr.VOLUNTARY_LIFCH_PREMIUM_AMOUNT = isnull(cte.LIFP,'+0000000000.00'),
		extr.VOLUNTARY_ADDCH_PREMIUM_AMOUNT = isnull(cte.VOLADD,'+0000000000.00')
    FROM @PremiumNtake_extr extr
    INNER JOIN CTEM cte ON cte.GROUP_NUMBER = extr.GROUP_NUMBER	

/********** Error Checking for insert statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Inserting updated records in stage table @PremiumNtake_extr FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 2 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed

/**************  PRINT STEP 3  HEADER DATA *************************/  
  
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
            @ldtStepStartTime = GETDATE(),  
            @lvcMsg = @lvcObjectName + ': Updating staging table tpzt_usable_premium_ntake_extr '  

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
        @pnStepNumber     = @lnCurrentStep,  
        @pdtStepStartTime = @ldtStepStartTime,  
        @pnTotalSteps     = @lnTotalSteps,  
        @pchStepMsg       = @lvcMsg 
                 
/************* STEP 3 Updating Staging table tpzt_usable_premium_ntake_extr *************/

	;with CTE_PREMTABLE
	(	
		GROUP_NUMBER,
		BLCT_DISP_CD,
		BILL_FROM_DATE, 
		BILL_CREATE_DATE,
		PREMIUM_TOTAL
	)
	AS
	(
		SELECT GROUP_NUMBER,
				BLCT_DISP_CD,
				BILL_FROM_DATE, 
				BILL_CREATE_DATE,
				SUM(
					CONVERT(DECIMAL(10,2), ISNULL(LIFE_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(ADD_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(DEP_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(WDB_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(LTD_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(SLI_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(SAD_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_LIF_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_LIFSP_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_LIFCH_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_ADD_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_ADDSP_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_ADDCH_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_STD_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_LTD_PREMIUM_AMOUNT,0))
				)
		FROM @PremiumNtake_extr 
		GROUP BY  GROUP_NUMBER,BLCT_DISP_CD,BILL_FROM_DATE, BILL_CREATE_DATE
	)

	UPDATE extr
	SET extr.PREMIUM_AMOUNT =  CASE WHEN CONVERT(DECIMAL(12,2),cte.PREMIUM_TOTAL) >000000000000.00
											THEN '+' + RIGHT(REPLICATE('0',15) + CAST(CAST(ISNULL(cte.PREMIUM_TOTAL,'000000000000.00')AS NUMERIC(12,2))AS VARCHAR),15)
											WHEN  CONVERT(DECIMAL(12,2),cte.PREMIUM_TOTAL) < 000000000000.00
											THEN '-' + RIGHT(REPLICATE('0',15) + CAST(CAST(ISNULL(REPLACE(cte.PREMIUM_TOTAL,'-',''),'000000000000.00')AS NUMERIC(12,2))AS VARCHAR),15)
											END
	FROM @PremiumNtake_extr extr 
	INNER JOIN CTE_PREMTABLE cte ON cte.GROUP_NUMBER = extr.GROUP_NUMBER
								AND cte. BLCT_DISP_CD = extr.BLCT_DISP_CD
								AND cte.BILL_FROM_DATE = extr.BILL_FROM_DATE
								AND cte.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
								
/*********** Update for commission column ********/

	INSERT INTO @NOEMPLOYESS (GROUP_NUMBER,GRGR_TOTAL_EMPL,PERCENTAGE)
	SELECT DISTINCT GROUP_NUMBER, grgr.GRGR_TOTAL_EMPL,CAST(xwalk.PERCENTAGE AS NUMERIC(3,2))
	FROM  @PremiumNtake_extr ntake
	INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr ON grgr.GRGR_ID = ntake.GROUP_NUMBER
	INNER JOIN fabncdv1stage.dbo.tpzt_usable_commission_cw xwalk 
			ON grgr.GRGR_TOTAL_EMPL BETWEEN CAST(xwalk.MIN_MARKET_SEGMENT AS INT) AND CAST(xwalk.MAX_MARKET_SEGMENT AS INT)
			
	INSERT INTO @IntCommission(GROUP_NUMBER,BLCT_DISP_CD,BILL_FROM_DATE,BILL_CREATE_DATE,PREMIUM_TOTAL)
	(
		SELECT  GROUP_NUMBER,
				BLCT_DISP_CD,
				BILL_FROM_DATE, 
				BILL_CREATE_DATE,
				SUM(
					CONVERT(DECIMAL(10,2), ISNULL(LIFE_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(ADD_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(DEP_PREMIUM_AMOUNT,0))	+ 
					CONVERT(DECIMAL(10,2), ISNULL(WDB_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(LTD_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(SLI_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(SAD_PREMIUM_AMOUNT,0))					
				)PREMIUM_AMOUNT

		FROM @PremiumNtake_extr 
		GROUP BY  GROUP_NUMBER,BLCT_DISP_CD,BILL_FROM_DATE, BILL_CREATE_DATE
	)

	INSERT INTO @CommissionTable
	(
		GROUP_NUMBER	,
		BLCT_DISP_CD	,
		BILL_FROM_DATE	,
		BILL_CREATE_DATE,
		PREMIUM_TOTAL	,
		Commission		
	)
	SELECT 
		cte.GROUP_NUMBER	,
		cte.BLCT_DISP_CD	,
		cte.BILL_FROM_DATE	,
		cte.BILL_CREATE_DATE,
		cte.PREMIUM_TOTAL,
		COMMISSION1 = CONVERT(DECIMAL(12,2),cte.PREMIUM_TOTAL) * CONVERT(DECIMAL(3,2),PERCENTAGE)
	FROM @PremiumNtake_extr ntake
	INNER JOIN 	@IntCommission cte ON   cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= ntake.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = ntake.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = ntake.BILL_CREATE_DATE
	INNER JOIN @NOEMPLOYESS emp ON cte.GROUP_NUMBER = emp.GROUP_NUMBER
	
------------------------------------------------------------------------------------------------------------------------  

	INSERT INTO @VOLPRODCAT (GROUP_NUMBER,PERCENTAGE,CSPD_CAT) 
	SELECT DISTINCT ntake.GROUP_NUMBER,  
				CAST(xwalk.PERCENTAGE AS NUMERIC(3,2)),cspi.CSPD_CAT
				
	FROM  @PremiumNtake_extr ntake
		INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr ON grgr.GRGR_ID = ntake.GROUP_NUMBER
		inNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
		INNER JOIN fabncdv1stage.dbo.tpzt_usable_commission_cw xwalk 
				ON UPPER(xwalk.PLAN_DESCRIPTION) in (UPPER('Voluntary LTD'),UPPER('Voluntary STD'),UPPER('Voluntary ADD'),UPPER('Voluntary Life'))   
	WHERE  cspi.CSPD_CAT IN ('Z','B','J','K')

	DECLARE @VolCommission TABLE
	(	
		GROUP_NUMBER		            VARCHAR(8),
		BLCT_DISP_CD		            VARCHAR(1),
		BILL_FROM_DATE		            VARCHAR(10), 
		BILL_CREATE_DATE	            VARCHAR(10),
		VOLUNTARY_LIF_PREMIUM_AMOUNT	VARCHAR(15),
		VOLUNTARY_ADD_PREMIUM_AMOUNT	VARCHAR(15),
		VOLUNTARY_STD_PREMIUM_AMOUNT	VARCHAR(15),
		VOLUNTARY_LTD_PREMIUM_AMOUNT	VARCHAR(15)
	)

	INSERT INTO @VolCommission
	(
		GROUP_NUMBER,
		BLCT_DISP_CD,
		BILL_FROM_DATE,
		BILL_CREATE_DATE,
		VOLUNTARY_LIF_PREMIUM_AMOUNT,
		VOLUNTARY_ADD_PREMIUM_AMOUNT,
		VOLUNTARY_STD_PREMIUM_AMOUNT,
		VOLUNTARY_LTD_PREMIUM_AMOUNT
	)
	(
		SELECT  ntake.GROUP_NUMBER,
				ntake.BLCT_DISP_CD,
				ntake.BILL_FROM_DATE, 
				ntake.BILL_CREATE_DATE,
				SUM(CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_LIF_PREMIUM_AMOUNT,0)) +
					CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_LIFSP_PREMIUM_AMOUNT,0)) +
					CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_LIFCH_PREMIUM_AMOUNT,0))
					),
				SUM(CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_ADD_PREMIUM_AMOUNT,0)) +
					CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_ADDSP_PREMIUM_AMOUNT,0)) +
					CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_ADDCH_PREMIUM_AMOUNT,0))
					),
				SUM(CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_STD_PREMIUM_AMOUNT,0)))		,
				SUM(CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_LTD_PREMIUM_AMOUNT,0)))
		FROM @PremiumNtake_extr ntake
		GROUP BY  ntake.GROUP_NUMBER,ntake.BLCT_DISP_CD,ntake.BILL_FROM_DATE, ntake.BILL_CREATE_DATE
	)

	UPDATE comt
	SET comt.COM_VOL_LIF_PREMIUM_COM = CONVERT(DECIMAL(10,2),cte.VOLUNTARY_LIF_PREMIUM_AMOUNT) * CONVERT(DECIMAL(3,2),PERCENTAGE)
	FROM @PremiumNtake_extr ntake
									
	INNER JOIN 	@VolCommission cte ON   cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= ntake.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = ntake.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = ntake.BILL_CREATE_DATE
	INNER JOIN @CommissionTable comt ON cte.GROUP_NUMBER	= comt.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= comt.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = comt.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = comt.BILL_CREATE_DATE
									
	INNER JOIN @VOLPRODCAT procat ON cte.GROUP_NUMBER = procat.GROUP_NUMBER
	WHERE procat.CSPD_CAT ='Z'
	
	UPDATE comt
	SET comt.COM_VOL_ADD_PREMIUM_COM = CONVERT(DECIMAL(10,2),cte.VOLUNTARY_ADD_PREMIUM_AMOUNT) * CONVERT(DECIMAL(3,2),PERCENTAGE)
	FROM @PremiumNtake_extr ntake

	INNER JOIN 	@VolCommission cte ON   cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= ntake.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = ntake.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = ntake.BILL_CREATE_DATE
	INNER JOIN @CommissionTable comt ON cte.GROUP_NUMBER	= comt.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= comt.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = comt.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = comt.BILL_CREATE_DATE
	
	INNER JOIN @VOLPRODCAT procat ON cte.GROUP_NUMBER = procat.GROUP_NUMBER
	WHERE procat.CSPD_CAT ='B'

	UPDATE comt
	SET comt.COM_VOL_STD_PREMIUM_COM = CONVERT(DECIMAL(10,2),cte.VOLUNTARY_STD_PREMIUM_AMOUNT) * CONVERT(DECIMAL(3,2),PERCENTAGE)
	FROM @PremiumNtake_extr ntake	

	INNER JOIN 	@VolCommission cte ON   cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= ntake.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = ntake.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = ntake.BILL_CREATE_DATE
	
	INNER JOIN @CommissionTable comt ON cte.GROUP_NUMBER	= comt.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= comt.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = comt.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = comt.BILL_CREATE_DATE
									
	INNER JOIN @VOLPRODCAT procat on cte.GROUP_NUMBER = procat.GROUP_NUMBER
	WHERE procat.CSPD_CAT ='K'

	UPDATE comt
	SET comt.COM_VOL_LTD_PREMIUM_COM = CONVERT(DECIMAL(10,2),cte.VOLUNTARY_LTD_PREMIUM_AMOUNT) * CONVERT(DECIMAL(3,2),PERCENTAGE)
	FROM @PremiumNtake_extr ntake	

	INNER JOIN 	@VolCommission cte ON   cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= ntake.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = ntake.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = ntake.BILL_CREATE_DATE
	INNER JOIN @CommissionTable comt ON cte.GROUP_NUMBER	= comt.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= comt.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = comt.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = comt.BILL_CREATE_DATE
	INNER JOIN @VOLPRODCAT procat ON cte.GROUP_NUMBER = procat.GROUP_NUMBER
	WHERE procat.CSPD_CAT ='J'

	
	;with CTE_Commission
	(
		GROUP_NUMBER	,	
		BLCT_DISP_CD	,	
		BILL_FROM_DATE	,	
		BILL_CREATE_DATE,	
		Commission			
	)
	AS
	(
	SELECT ntake.GROUP_NUMBER,
		ntake.BLCT_DISP_CD,
		ntake.BILL_FROM_DATE,
		ntake.BILL_CREATE_DATE,
		COMMISSION1 = sum ( CONVERT(DECIMAL(10,2),ISNULL(comt.Commission,0)) +
							CONVERT(DECIMAL(10,2),ISNULL(comt.COM_VOL_LIF_PREMIUM_COM,0)) +
							CONVERT(DECIMAL(10,2),ISNULL(comt.COM_VOL_ADD_PREMIUM_COM,0)) +
							CONVERT(DECIMAL(10,2),ISNULL(comt.COM_VOL_STD_PREMIUM_COM,0)) +
							CONVERT(DECIMAL(10,2),ISNULL(comt.COM_VOL_LTD_PREMIUM_COM,0))
							)
						
	FROM @PremiumNtake_extr ntake
	INNER JOIN @CommissionTable comt ON  ntake.GROUP_NUMBER	= comt.GROUP_NUMBER
									AND	ntake.BLCT_DISP_CD	= comt.BLCT_DISP_CD
									AND	ntake.BILL_FROM_DATE	 = comt.BILL_FROM_DATE
									AND	ntake.BILL_CREATE_DATE = comt.BILL_CREATE_DATE
	GROUP BY ntake.GROUP_NUMBER,
			ntake.BLCT_DISP_CD,
			ntake.BILL_FROM_DATE,
			ntake.BILL_CREATE_DATE
	)

	UPDATE ntake
	SET ntake.COMMISSION = CASE WHEN CONVERT(DECIMAL(12,2),comt.Commission) >000000000000.00
											THEN '+' + RIGHT(REPLICATE('0',15) + CAST(CAST(ISNULL(comt.Commission,'000000000000.00')AS NUMERIC(12,2))AS VARCHAR),15)
											WHEN  CONVERT(DECIMAL(12,2),comt.Commission) < 000000000000.00
											THEN '-' + RIGHT(REPLICATE('0',15) + CAST(CAST(ISNULL(REPLACE(comt.Commission,'-',''),'000000000000.00')AS NUMERIC(12,2))AS VARCHAR),15)
											END
	FROM @PremiumNtake_extr ntake
	INNER JOIN CTE_Commission comt ON  ntake.GROUP_NUMBER	= comt.GROUP_NUMBER
									AND	ntake.BLCT_DISP_CD	= comt.BLCT_DISP_CD
									AND	ntake.BILL_FROM_DATE	 = comt.BILL_FROM_DATE
									AND	ntake.BILL_CREATE_DATE = comt.BILL_CREATE_DATE

/********* Update for Net_AMOUNT column **********/
    
    UPDATE extr
    SET extr.NET_AMOUNT = CASE WHEN CONVERT(DECIMAL(12,2),(CAST(extr.PREMIUM_AMOUNT AS NUMERIC(12,2)) - CAST(extr.COMMISSION AS NUMERIC(12,2)))) >000000000000.00
											THEN '+' + RIGHT(REPLICATE('0',15) + CAST(CAST(ISNULL((CAST(extr.PREMIUM_AMOUNT AS NUMERIC(12,2)) - CAST(extr.COMMISSION AS NUMERIC(12,2))),'000000000000.00')AS NUMERIC(12,2))AS VARCHAR),15)
											WHEN  CONVERT(DECIMAL(12,2),(CAST(extr.PREMIUM_AMOUNT AS NUMERIC(12,2)) - CAST(extr.COMMISSION AS NUMERIC(12,2)))) < 000000000000.00
											THEN '-' + RIGHT(REPLICATE('0',15) + CAST(CAST(ISNULL(REPLACE((CAST(extr.PREMIUM_AMOUNT AS NUMERIC(12,2)) - CAST(extr.COMMISSION AS NUMERIC(12,2))),'-',''),'000000000000.00')AS NUMERIC(12,2))AS VARCHAR),15)
											END
											
    FROM @PremiumNtake_extr extr
    
/************* Error Checking for Updating Staging table tpzt_usable_premium_ntake_extr *************/  
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  

        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Updating Staging table tpzt_usable_premium_ntake_extr FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END       
          
/**************  PRINT STEP 3 FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed   

 

/**************  PRINT STEP 5  HEADER DATA *************************/  
  
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
            @ldtStepStartTime = GETDATE(),  
            @lvcMsg = @lvcObjectName + ': Updating staging table tpzt_usable_premium_ntake_extr for calculating count for various plans '  

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
        @pnStepNumber     = @lnCurrentStep,  
        @pdtStepStartTime = @ldtStepStartTime,  
        @pnTotalSteps     = @lnTotalSteps,  
        @pchStepMsg       = @lvcMsg 
                 
/************* STEP 5 Updating Staging table tpzt_usable_premium_ntake_extr  for calculating count for various plans *************/  
 
 --------------------Number of lives for Modal ----------------------------         
    INSERT INTO @ProdCount 
        SELECT GRGR_ID,
				--BLCT_DISP_CD,
				L = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(L AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
				A = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(A AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                E = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(E AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                K = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(K AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                S = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(S AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                T = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(T AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                X = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(X AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                Y = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(Y AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                J = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(J AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6)
        
        FROM
                (
                SELECT DISTINCT
                GRGR_ID = grgr.GRGR_ID, inct.BLCT_DISP_CD, 
                CSPDCAT =cspi.CSPD_CAT,
                PRDT_COUNT =  case when cspi.CSPD_CAT IN ('L','A','E','K','S','X','Y','J')
										then inct.BLCT_LVS_SB
									when cspi.CSPD_CAT IN ('T')
										then inct.BLCT_LVS_DEP
							end
										
                
         FROM  fabncdv1.dbo.CMC_GRGR_GROUP grgr 
                    INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
                    INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
                    LEFT JOIN fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
        		LEFT JOIN fabncdv1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blei.BLEI_CK
				INNER JOIN fabncdv1.dbo.CDS_INCT_COMPONENT inct ON inct.BLIV_ID = bliv.BLIV_ID
												AND inct.CSPI_ID = cspi.CSPI_ID
		WHERE cspi.CSPD_CAT IN ('L','A','E','K','S','T','X','Y','J')
		    AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101')
							AND DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,0))) 
		AND  inct.BLCT_DISP_CD ='M'
		 )d
            pivot
            (
                max(PRDT_COUNT)
                for CSPDCAT in (L,A,E,K,S,T,X,Y,J)
            ) AS piv
          GROUP BY GRGR_ID

 ---updating the count field for modal entry -------------- 
    UPDATE extr
    SET LIF_COUNT = L,ADD_COUNT = A, DEP_COUNT = T, STD_COUNT = X, LTD_COUNT = Y , SLI_COUNT = S, SAD_COUNT = E,
         VOLUNTARY_STD_COUNT = K, VOLUNTARY_LTD_COUNT = J
    FROM @PremiumNtake_extr extr
    INNER JOIN @ProdCount pdtcount  ON pdtcount.GRGR_ID = extr.GROUP_NUMBER
	where extr.BLCT_DISP_CD = 'M'
	
	
	
	--------------------Number of lives for retroactive ----------------------------
	
	delete from  @ProdCount
	
	INSERT INTO @ProdCount 
        SELECT GRGR_ID,
				--BLCT_DISP_CD,
				L = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(L AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
				A = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(A AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                E = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(E AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                K = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(K AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                S = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(S AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                T = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(T AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                X = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(X AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                Y = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(Y AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                J = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(J AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6)
        
        FROM
                (
                SELECT DISTINCT
                GRGR_ID = grgr.GRGR_ID, inct.BLCT_DISP_CD, 
                CSPDCAT =cspi.CSPD_CAT,
                PRDT_COUNT =  case when cspi.CSPD_CAT IN ('L','A','E','K','S','X','Y','J')
										then inct.BLCT_LVS_SB
									when cspi.CSPD_CAT IN ('T')
										then inct.BLCT_LVS_DEP
							end
										
                
         FROM  fabncdv1.dbo.CMC_GRGR_GROUP grgr 
                    INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
                    INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
                    LEFT JOIN fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
        		LEFT JOIN fabncdv1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blei.BLEI_CK
				INNER JOIN fabncdv1.dbo.CDS_INCT_COMPONENT inct ON inct.BLIV_ID = bliv.BLIV_ID
												AND inct.CSPI_ID = cspi.CSPI_ID
		WHERE cspi.CSPD_CAT IN ('L','A','E','K','S','T','X','Y','J')
		    AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101')
							AND DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,0))) 
		AND  inct.BLCT_DISP_CD ='R'
		 )d
            pivot
            (
                max(PRDT_COUNT)
                for CSPDCAT in (L,A,E,K,S,T,X,Y,J)
            ) AS piv
          GROUP BY GRGR_ID
 
 ---updating the count field for retroactive entry --------------
        
    UPDATE extr
    SET LIF_COUNT = L,ADD_COUNT = A, DEP_COUNT = T, STD_COUNT = X, LTD_COUNT = Y , SLI_COUNT = S, SAD_COUNT = E,
         VOLUNTARY_STD_COUNT = K, VOLUNTARY_LTD_COUNT = J
    FROM @PremiumNtake_extr extr
    INNER JOIN @ProdCount pdtcount  ON pdtcount.GRGR_ID = extr.GROUP_NUMBER
	where extr.BLCT_DISP_CD = 'R'
	
	
	
	
    
/************* Error Checking for Updating Staging table tpzt_usable_premium_ntake_extr for calculating count for various plans *************/  
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  

        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Updating Staging table tpzt_usable_premium_ntake_extr for calculating count for various plans FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END       
          
/**************  PRINT STEP 5 FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed   

/**************  PRINT STEP 6  HEADER DATA *************************/  
  
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
            @ldtStepStartTime = GETDATE(),  
            @lvcMsg = @lvcObjectName + ': Updating staging table tpzt_usable_premium_ntake_extr for calculating count for various voluntary plans '  

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
        @pnStepNumber     = @lnCurrentStep,  
        @pdtStepStartTime = @ldtStepStartTime,  
        @pnTotalSteps     = @lnTotalSteps,  
        @pchStepMsg       = @lvcMsg 
                 
/************* STEP 6 Updating Staging table tpzt_usable_premium_ntake_extr  for calculating count for various voluntary plans *************/  
 
 
 
 -----------------Number of lives for Modal Vol Prod Life for Subscriber ---------------------------
          
    INSERT INTO @VolProdCount 
        SELECT GRGR_ID,MEME_REL, Z = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(Z,'000000')AS NUMERIC(6,0))AS VARCHAR),6)
                ,B = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(B,'000000')AS NUMERIC(6,0))AS VARCHAR),6)
        FROM
                (
							SELECT DISTINCT
							GRGR_ID = grgr.GRGR_ID,  
							CSPDCAT =cspi.CSPD_CAT,
							MEME_REL = meme.MEME_REL,
							VOL_PRDT_COUNT = inct.BLCT_LVS_SB
			                
					  FROM  fabncdv1.dbo.CMC_GRGR_GROUP grgr 
									INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
									INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
									INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
									LEFT JOIN fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
        						LEFT JOIN fabncdv1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blei.BLEI_CK
								INNER JOIN fabncdv1.dbo.CDS_INCT_COMPONENT inct ON inct.BLIV_ID = bliv.BLIV_ID
												AND inct.CSPI_ID = cspi.CSPI_ID
												--AND inct.BLCT_DISP_CD = blct.BLCT_DISP_CD
						 WHERE cspi.CSPD_CAT IN ('Z','B') 
						    AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101')
																AND DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,0))) 
										
							AND  inct.BLCT_DISP_CD = 'M'
							AND   meme.MEME_REL = 'M'
		
            )d
            pivot
            (
				max(VOL_PRDT_COUNT)
				for CSPDCAT in (Z,B)
            ) AS piv
              
    UPDATE extr
    SET VOLUNTARY_LIF_COUNT = Z,VOLUNTARY_ADD_COUNT = B
    FROM @PremiumNtake_extr extr
			INNER JOIN @VolProdCount volpdtcount  ON volpdtcount.GRGR_ID = extr.GROUP_NUMBER
										 AND volpdtcount.MEME_REL = 'M'
	WHERE  extr.BLCT_DISP_CD ='M'
    
    
-----------------Number of lives for Modal  Vol Prod Life for spouse and child ---------------------------    
    delete from @VolProdCount
    
    INSERT INTO @VolProdCount 
        SELECT GRGR_ID,MEME_REL, Z = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(Z,'000000')AS NUMERIC(6,0))AS VARCHAR),6)
                ,B = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(B,'000000')AS NUMERIC(6,0))AS VARCHAR),6)
        FROM
                (
                SELECT DISTINCT
                GRGR_ID = grgr.GRGR_ID,  
                CSPDCAT =cspi.CSPD_CAT,
                MEME_REL = meme.MEME_REL,
                VOL_PRDT_COUNT = inct.BLCT_LVS_DEP
      FROM  fabncdv1.dbo.CMC_GRGR_GROUP grgr 
                    INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
                    INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
                    INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
                    LEFT JOIN fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
        		LEFT JOIN fabncdv1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blei.BLEI_CK
				INNER JOIN fabncdv1.dbo.CDS_INCT_COMPONENT inct ON inct.BLIV_ID = bliv.BLIV_ID
												AND inct.CSPI_ID = cspi.CSPI_ID
		 WHERE cspi.CSPD_CAT IN ('Z','B') 
		    AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101')
											AND DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,0))) 
		AND  inct.BLCT_DISP_CD = 'M'
		AND meme.MEME_REL in ('H','W','S','D')
		
            )d
            pivot
            (
				max(VOL_PRDT_COUNT)
				for CSPDCAT in (Z,B)
            ) AS piv

    UPDATE extr
    SET VOLUNTARY_LIFSP_COUNT = Z,VOLUNTARY_ADDSP_COUNT = B
    FROM @PremiumNtake_extr extr
    INNER JOIN @VolProdCount volpdtcount ON volpdtcount.GRGR_ID = extr.GROUP_NUMBER
											AND volpdtcount.MEME_REL IN ('H','W')
    where extr.BLCT_DISP_CD ='M'

    UPDATE extr
    SET VOLUNTARY_LIFCH_COUNT = Z,VOLUNTARY_ADDCH_COUNT = B
    FROM @PremiumNtake_extr extr
    INNER JOIN @VolProdCount volpdtcount ON volpdtcount.GRGR_ID = extr.GROUP_NUMBER
											AND volpdtcount.MEME_REL IN ('S','D')
    where extr.BLCT_DISP_CD ='M'
    
    
    
    
    -----------------Number of lives for Retroactive  for Subscriber------------------------------------------------
    delete from @VolProdCount
    
     INSERT INTO @VolProdCount 
        SELECT GRGR_ID,MEME_REL, Z = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(Z,'000000')AS NUMERIC(6,0))AS VARCHAR),6)
                ,B = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(B,'000000')AS NUMERIC(6,0))AS VARCHAR),6)
        FROM
                (
							SELECT DISTINCT
							GRGR_ID = grgr.GRGR_ID,  
							CSPDCAT =cspi.CSPD_CAT,
							MEME_REL = meme.MEME_REL,
							VOL_PRDT_COUNT = inct.BLCT_LVS_SB
			                
					  FROM  fabncdv1.dbo.CMC_GRGR_GROUP grgr 
									INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
									INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
									INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
									LEFT JOIN fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
								LEFT JOIN fabncdv1.dbo.CMC_BLCT_COMP_TOTL blct ON blct.BLEI_CK = blei.BLEI_CK		 
        																		AND blct.CSPI_ID = cspi.CSPI_ID
        						LEFT JOIN fabncdv1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blct.BLEI_CK
								INNER JOIN fabncdv1.dbo.CDS_INCT_COMPONENT inct ON inct.BLIV_ID = bliv.BLIV_ID
												AND inct.CSPI_ID = cspi.CSPI_ID
												--AND inct.BLCT_DISP_CD = blct.BLCT_DISP_CD
						 WHERE cspi.CSPD_CAT IN ('Z','B') 
						    AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101')
															AND DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,0))) 
						AND  inct.BLCT_DISP_CD = 'R'
						AND meme.MEME_REL = 'M'
		
            )d
            pivot
            (
            max(VOL_PRDT_COUNT)
            for CSPDCAT in (Z,B)
            ) AS piv
              
    UPDATE extr
    SET VOLUNTARY_LIF_COUNT = Z,VOLUNTARY_ADD_COUNT = B
    FROM @PremiumNtake_extr extr
		 INNER JOIN @VolProdCount volpdtcount  ON volpdtcount.GRGR_ID = extr.GROUP_NUMBER
										 AND volpdtcount.MEME_REL = 'M'
	WHERE extr.BLCT_DISP_CD ='R'
    
    
  -----------------Number of lives for Retroactive  for Spouse and Child ------------------------------------------------   
    delete from @VolProdCount
    
    INSERT INTO @VolProdCount 
        SELECT GRGR_ID,MEME_REL, Z = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(Z,'000000')AS NUMERIC(6,0))AS VARCHAR),6)
                ,B = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(B,'000000')AS NUMERIC(6,0))AS VARCHAR),6)
        FROM
                (
                SELECT DISTINCT
                GRGR_ID = grgr.GRGR_ID,  
                CSPDCAT =cspi.CSPD_CAT,
                MEME_REL = meme.MEME_REL,
                VOL_PRDT_COUNT = inct.BLCT_LVS_DEP
      FROM  fabncdv1.dbo.CMC_GRGR_GROUP grgr 
                    INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
                    INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
                    INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
                    LEFT JOIN fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
        		LEFT JOIN fabncdv1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blei.BLEI_CK
				INNER JOIN fabncdv1.dbo.CDS_INCT_COMPONENT inct ON inct.BLIV_ID = bliv.BLIV_ID
												AND inct.CSPI_ID = cspi.CSPI_ID
		 WHERE cspi.CSPD_CAT IN ('Z','B') 
		    AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101')
											AND DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,0))) 
		
		AND  inct.BLCT_DISP_CD = 'R'
		AND meme.MEME_REL in ('H','W','S','D')
		
            )d
            pivot
            (
            max(VOL_PRDT_COUNT)
            for CSPDCAT in (Z,B)
            ) AS piv

    UPDATE extr
    SET VOLUNTARY_LIFSP_COUNT = Z,VOLUNTARY_ADDSP_COUNT = B
    FROM @PremiumNtake_extr extr
    INNER JOIN @VolProdCount volpdtcount ON volpdtcount.GRGR_ID = extr.GROUP_NUMBER
					AND volpdtcount.MEME_REL IN ('H','W')
	WHERE extr.BLCT_DISP_CD = 'R'

    UPDATE extr
    SET VOLUNTARY_LIFCH_COUNT = Z,VOLUNTARY_ADDCH_COUNT = B
    FROM @PremiumNtake_extr extr
    INNER JOIN @VolProdCount volpdtcount ON volpdtcount.GRGR_ID = extr.GROUP_NUMBER
							AND volpdtcount.MEME_REL IN ('S','D')
   	WHERE extr.BLCT_DISP_CD = 'R' 
    
/************* Error Checking for Updating Staging table tpzt_usable_premium_ntake_extr  for calculating count for various voluntary plans *************/  
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  

        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Updating Staging table tpzt_usable_premium_ntake_extr for calculating count for various voluntary plans FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
		END       
          
/**************  PRINT STEP 6 FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed   

/**************  PRINT STEP 7 HEADER DATA *************************/  
  
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
            @ldtStepStartTime = GETDATE(),  
            @lvcMsg = @lvcObjectName + ': Inserting values in stage table tpzt_usable_premium_ntake_extr for various Benefit Amounts and Benfit Rate per unit life columns '  

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
        @pnStepNumber     = @lnCurrentStep,  
        @pdtStepStartTime = @ldtStepStartTime,  
        @pnTotalSteps     = @lnTotalSteps,  
        @pchStepMsg       = @lvcMsg 
                 
/************* STEP 7 Inserting values in stage table tpzt_usable_premium_ntake_extr for various Benefit Amounts and Benfit Rate per unit life columns *************/  
          
    DECLARE @BenefitData TABLE(
        GRGR_ID                        VARCHAR(8),
        CSPI_ID						   varchar(8),
		CSPD_CAT					  varchar(1),
        BILL_CREATE_DATE			  varchar(8),
        BILL_FROM_DATE				  varchar(10),
        BLCT_DISP_CD				   varchar(1),
        MEME_REL					   varchar(1),
        BENEFIT_AMOUNT_FOR_LIFE        VARCHAR(16),
        BENEFIT_AMOUNT_FOR_ADD         VARCHAR(16),
        BENEFIT_AMOUNT_FOR_DEP         VARCHAR(16),
        BENEFIT_AMOUNT_FOR_STD         VARCHAR(16),
        BENEFIT_AMOUNT_FOR_LTD         VARCHAR(16),
        BENEFIT_AMOUNT_FOR_SLI         VARCHAR(16),
        BENEFIT_AMOUNT_FOR_SAD         VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VLIF        VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VLIFSP      VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VLIFCH      VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VADD        VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VADDSP      VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VADDCH      VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VLTD        VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VSTD        VARCHAR(16),
        BENEFIT_RATE_PER_UNIT_LIFE     VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_ADD      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_DEP      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_STD      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_LTD      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_SLI      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_SAD      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VLIF     VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VLIFSP   VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VLIFCH   VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VADD     VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VADDSP   VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VADDCH   VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VLTD     VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VSTD     VARCHAR(11))
                
    INSERT INTO @BenefitData
    SELECT DISTINCT
        GRGR_ID = grgr.GRGR_ID,
        CSPI_ID = cspi.CSPI_ID,
        CSPD_CAT = cspi.CSPD_CAT,
        BILL_CREATE_DATE = CONVERT(VARCHAR(8), bliv.BLIV_CREATE_DTM,112),
        BILL_FROM_DATE				= CONVERT(VARCHAR(10), blct.BLBL_DUE_DT,101),
        
        BLCT_DISP_CD = blct.BLCT_DISP_CD,
        MEME_REL =	meme.MEME_REL,
        BENEFIT_AMOUNT_FOR_LIFE        = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT distinct isnull(gtl.BENEFIT_AMOUNT,0) 
                                          FROM fabncdv1custom.dbo.tpzt_usable_gtl_add gtl
                                          WHERE gtl.GRGR_ID = grgr.GRGR_ID
                                          AND gtl.CSCS_ID = cspi.CSCS_ID
                                          AND gtl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'L'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                          
        BENEFIT_AMOUNT_FOR_ADD         = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT distinct isnull(gtl.BENEFIT_AMOUNT,0) 
                                            FROM fabncdv1custom.dbo.tpzt_usable_gtl_add gtl
                                            WHERE gtl.GRGR_ID = grgr.GRGR_ID
                                            AND gtl.CSCS_ID = cspi.CSCS_ID
                                             AND gtl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'A'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_DEP         = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT distinct isnull(usabledl.[PLAN],0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_dl usabledl
                                            WHERE usabledl.GRGR_ID = grgr.GRGR_ID 
                                            AND usabledl.CSCS_ID = cspi.CSCS_ID
                                             AND usabledl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'T'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_STD         = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT distinct isnull(usablewdb.BENEFIT_AMOUNT,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_wdb usablewdb
                                              WHERE usablewdb.GRGR_ID = grgr.GRGR_ID 
                                            AND usablewdb.CSCS_ID = cspi.CSCS_ID
                                             AND usablewdb.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'X'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_LTD         = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT distinct isnull(usableltd.MONTHLY_MAXIMUM,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_ltd usableltd
                                            WHERE usableltd.GRGR_ID = grgr.GRGR_ID 
                                            AND usableltd.CSCS_ID = cspi.CSCS_ID
                                             AND usableltd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'Y'),'0000000.0000')AS NUMERIC(16,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_SLI         = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT distinct isnull(usablesl.BENEFIT_AMOUNT,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_sli usablesl
                                            WHERE usablesl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablesl.CSCS_ID = cspi.CSCS_ID
                                             AND usablesl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'S'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_SAD         = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT distinct isnull(usablesa.BENEFIT_AMOUNT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_sad usablesa
                                            WHERE usablesa.GRGR_ID = grgr.GRGR_ID 
                                            AND usablesa.CSCS_ID = cspi.CSCS_ID
                                             AND usablesa.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'E'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_VLIF        = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevl.BENEFIT_AMOUNT,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_vl usablevl
                                              WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'Z'
                                            AND meme.MEME_REL = 'M'
                                            ),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_VLIFSP      = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevl.SPOUSE_AMOUNT,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_vl usablevl
                                            WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'Z'
                                            AND meme.MEME_REL IN('H','W')
                                            ),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_VLIFCH      = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevl.DEPENDANT_CHILD_COVERAGE,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_vl usablevl
                                            WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'Z'
                                            AND meme.MEME_REL IN('S','D')
                                            ),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_VADD        = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevadd.BENEFIT_AMOUNT,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'B'
                                            AND meme.MEME_REL = 'M'
                                            ),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_VADDSP      = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevadd.SPOUSE_AMOUNT,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'B'
                                            AND meme.MEME_REL IN('H','W')
                                            ),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_VADDCH      = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevadd.DEP_CHILD_COVERAGE,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'B'
                                            AND meme.MEME_REL IN('S','D')
                                            ),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
        
        BENEFIT_AMOUNT_FOR_VLTD        = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevltd.MAXIMUM_AMOUNT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vltd usablevltd
                                            WHERE usablevltd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevltd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevltd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'J'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),

        BENEFIT_AMOUNT_FOR_VSTD        = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevstd.MAX_WEEKLY_BENEFIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vstd usablevstd
                                            WHERE usablevstd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevstd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevstd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'K'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
											
        BENEFIT_RATE_PER_UNIT_LIFE =   RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablegtl.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_gtl_add usablegtl
                                            WHERE usablegtl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablegtl.CSCS_ID = cspi.CSCS_ID
                                             AND usablegtl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'L'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_ADD      =  RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablegtl.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_gtl_add usablegtl
                                            WHERE usablegtl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablegtl.CSCS_ID = cspi.CSCS_ID
                                             AND usablegtl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'A'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_DEP      =  RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usabledl.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_dl usabledl
                                            WHERE usabledl.GRGR_ID = grgr.GRGR_ID 
                                            AND usabledl.CSCS_ID = cspi.CSCS_ID
                                             AND usabledl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'T'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
											
        
        BENEFIT_RATE_PER_UNIT_STD      = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablewdb.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_wdb usablewdb
                                            WHERE usablewdb.GRGR_ID = grgr.GRGR_ID 
                                            AND usablewdb.CSCS_ID = cspi.CSCS_ID
                                             AND usablewdb.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'X'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
		
        BENEFIT_RATE_PER_UNIT_LTD      = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usableltd.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_ltd usableltd
                                            WHERE usableltd.GRGR_ID = grgr.GRGR_ID 
                                            AND usableltd.CSCS_ID = cspi.CSCS_ID
                                             AND usableltd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'Y'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_SLI      = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablesli.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_sli usablesli
                                            WHERE usablesli.GRGR_ID = grgr.GRGR_ID 
                                            AND usablesli.CSCS_ID = cspi.CSCS_ID
                                             AND usablesli.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'S'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_SAD      = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablesad.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_sad usablesad
                                            WHERE usablesad.GRGR_ID = grgr.GRGR_ID 
                                            AND usablesad.CSCS_ID = cspi.CSCS_ID
                                             AND usablesad.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'E'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_VLIF     = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevl.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vl usablevl
                                            WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'Z'
											AND meme.MEME_REL = 'M'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_VLIFSP   = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevl.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vl usablevl
                                            WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'Z'
											AND meme.MEME_REL IN('H','W')),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_VLIFCH   = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevl.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vl usablevl
                                            WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'Z'
											AND meme.MEME_REL IN('D','S')),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_VADD     = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevadd.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'B'
											AND meme.MEME_REL = 'M'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_VADDSP   = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevadd.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'B'
											AND meme.MEME_REL IN('H','W')),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
		
											
        BENEFIT_RATE_PER_UNIT_VADDCH   = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevadd.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'B'
											AND meme.MEME_REL IN('D','S')),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_VLTD     = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevltd.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vltd usablevltd
                                            WHERE usablevltd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevltd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevltd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'J'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
		
        BENEFIT_RATE_PER_UNIT_VSTD     = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevstd.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vstd usablevstd
                                            WHERE usablevstd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevstd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevstd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'K'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11)
											
    FROM 
        fabncdv1.dbo.CMC_GRGR_GROUP grgr 
            INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
            INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
            INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
            LEFT JOIN fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
				LEFT JOIN fabncdv1.dbo.CMC_BLCT_COMP_TOTL blct ON blct.BLEI_CK = blei.BLEI_CK		 
        														AND blct.CSPI_ID = cspi.CSPI_ID
        		LEFT JOIN fabncdv1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blct.BLEI_CK
																AND bliv.BLBL_DUE_DT = blct.BLBL_DUE_DT
		WHERE cspi.CSPD_CAT IN ('X','Y','L','A','S','T','E','K','J','Z','B')
		    AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101')
											AND DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,0))) 
		AND  blct.BLCT_DISP_CD IN ('M', 'R')


---------------updated the extr table	Benefit Amounts and Benfit Rate per unit life columns
	
UPDATE extr
		SET extr.BENEFIT_AMOUNT_FOR_LIFE = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_LIFE,0)
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'L'
																and bnft.MEME_REL = 'M'
											),
			extr.BENEFIT_AMOUNT_FOR_ADD = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_ADD,0)
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'A'
																and bnft.MEME_REL = 'M'
											),	
			extr.BENEFIT_AMOUNT_FOR_DEP = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_DEP,0)
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'T'
																and bnft.MEME_REL <> 'M'
											),	
		  extr.BENEFIT_AMOUNT_FOR_STD = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_STD,0)
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'X'
																and bnft.MEME_REL = 'M'
											),	
		 extr.BENEFIT_AMOUNT_FOR_LTD = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_LTD,0)
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'Y'
																and bnft.MEME_REL = 'M'
											),	
											
		 extr.BENEFIT_AMOUNT_FOR_SLI = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_SLI,0)
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'S'
																and bnft.MEME_REL = 'M'
											),										
											
		  extr.BENEFIT_AMOUNT_FOR_SAD = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_SAD,0)
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'E'
																and bnft.MEME_REL = 'M'
											),	
		 extr.BENEFIT_AMOUNT_FOR_VLIF = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VLIF,0)
										   FROM 	@BenefitData bnft  
										   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
															and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
															and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
															and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
															AND bnft.CSPD_CAT = 'Z'
															and bnft.MEME_REL = 'M'
										),	
		 extr.BENEFIT_AMOUNT_FOR_VLIFSP = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VLIFSP,0)
										   FROM 	@BenefitData bnft  
										   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
															and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
															and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
															and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
															AND bnft.CSPD_CAT = 'Z'
															and bnft.MEME_REL in ('H','W')
										),	
																				
		 extr.BENEFIT_AMOUNT_FOR_VLIFCH = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VLIFCH,0)
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'Z'
																and bnft.MEME_REL in ('S','D')
											),	
		 extr.BENEFIT_AMOUNT_FOR_VADD = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VADD,0)
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'B'
																and bnft.MEME_REL = 'M'
											),	
											
		 extr.BENEFIT_AMOUNT_FOR_VADDSP = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VADDSP,0)
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'B'
																and bnft.MEME_REL in ('H','W')
											),	
											
		 extr.BENEFIT_AMOUNT_FOR_VADDCH = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VADDCH,0)
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'B'
																and bnft.MEME_REL in ('S','D')
											),	
		
		extr.BENEFIT_AMOUNT_FOR_VLTD = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VLTD,0)
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'K'
																and bnft.MEME_REL = 'M'
											),	
											
		extr.BENEFIT_AMOUNT_FOR_VSTD = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VSTD,0)
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'J'
																and bnft.MEME_REL = 'M'
											),
											
-------------------------BENEFIT_RATE_PER_UNIT -------------------------	

			extr.BENEFIT_RATE_PER_UNIT_LIFE = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_LIFE IS NOT NULL
																		 THEN RIGHT(REPLICATE('0',10) + CONVERT(VARCHAR,CONVERT(DECIMAL(12,5), BENEFIT_RATE_PER_UNIT_LIFE)),11)
																		 ELSE '00000.00000'
																  END
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'L'
																and bnft.MEME_REL = 'M'
											),	
			extr.BENEFIT_RATE_PER_UNIT_ADD = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_ADD IS NOT NULL
																		 THEN RIGHT(REPLICATE('0',10) + CONVERT(VARCHAR,CONVERT(DECIMAL(12,5), BENEFIT_RATE_PER_UNIT_ADD)),11)
																		 ELSE '00000.00000'
																  END
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'A'
																and bnft.MEME_REL = 'M'
											),	
			extr.BENEFIT_RATE_PER_UNIT_DEP = (SELECT distinct  CASE WHEN BENEFIT_RATE_PER_UNIT_DEP IS NOT NULL
																		 THEN RIGHT(REPLICATE('0',10) + CONVERT(VARCHAR,CONVERT(DECIMAL(12,5), BENEFIT_RATE_PER_UNIT_DEP)),11)
																		 ELSE '00000.00000'
																  END
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'T'
																and bnft.MEME_REL = 'M'
											),	
			extr.BENEFIT_RATE_PER_UNIT_STD = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_STD IS NOT NULL
																		 THEN RIGHT(REPLICATE('0',10) + CONVERT(VARCHAR,CONVERT(DECIMAL(12,5), BENEFIT_RATE_PER_UNIT_STD)),11)
																		 ELSE '00000.00000'
																  END 
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'X'
																and bnft.MEME_REL = 'M'
											),	
		extr.BENEFIT_RATE_PER_UNIT_LTD = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_LTD IS NOT NULL
																		 THEN RIGHT(REPLICATE('0',10) + CONVERT(VARCHAR,CONVERT(DECIMAL(12,5), BENEFIT_RATE_PER_UNIT_LTD)),11)
																		 ELSE '00000.00000'
																  END 
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'Y'
																and bnft.MEME_REL = 'M'
											),	
		extr.BENEFIT_RATE_PER_UNIT_SLI = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_SLI IS NOT NULL
																		 THEN RIGHT(REPLICATE('0',10) + CONVERT(VARCHAR,CONVERT(DECIMAL(12,5), BENEFIT_RATE_PER_UNIT_SLI)),11)
																		 ELSE '00000.00000'
																  END
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'S'
																and bnft.MEME_REL = 'M'
											),	
		extr.BENEFIT_RATE_PER_UNIT_SAD = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_SAD IS NOT NULL
																		 THEN RIGHT(REPLICATE('0',10) + CONVERT(VARCHAR,CONVERT(DECIMAL(12,5), BENEFIT_RATE_PER_UNIT_SAD)),11)
																		 ELSE '00000.00000'
																  END 
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'E'
																and bnft.MEME_REL = 'M'
											),
		extr.BENEFIT_RATE_PER_UNIT_VLIF = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_VLIF IS NOT NULL
																		 THEN RIGHT(REPLICATE('0',10) + CONVERT(VARCHAR,CONVERT(DECIMAL(12,5), BENEFIT_RATE_PER_UNIT_VLIF)),11)
																		 ELSE '00000.00000'
																  END
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'Z'
																and bnft.MEME_REL = 'M'
											),
		extr.BENEFIT_RATE_PER_UNIT_VLIFSP = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_VLIFSP IS NOT NULL
																		 THEN RIGHT(REPLICATE('0',10) + CONVERT(VARCHAR,CONVERT(DECIMAL(12,5), BENEFIT_RATE_PER_UNIT_VLIFSP)),11)
																		 ELSE '00000.00000'
																  END
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'Z'
																and bnft.MEME_REL in ('H','W')
											),	
		extr.BENEFIT_RATE_PER_UNIT_VLIFCH = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_VLIFCH IS NOT NULL
																		 THEN RIGHT(REPLICATE('0',10) + CONVERT(VARCHAR,CONVERT(DECIMAL(12,5), BENEFIT_RATE_PER_UNIT_VLIFCH)),11)
																		 ELSE '00000.00000'
																  END
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'Z'
																and bnft.MEME_REL in ('S','D')
											),	
		extr.BENEFIT_RATE_PER_UNIT_VADD = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_VADD IS NOT NULL
																		 THEN RIGHT(REPLICATE('0',10) + CONVERT(VARCHAR,CONVERT(DECIMAL(12,5), BENEFIT_RATE_PER_UNIT_VADD)),11)
																		 ELSE '00000.00000'
																  END
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'B'
																and bnft.MEME_REL = 'M'
											),	
		extr.BENEFIT_RATE_PER_UNIT_VADDSP = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_VADDSP IS NOT NULL
																		 THEN RIGHT(REPLICATE('0',10) + CONVERT(VARCHAR,CONVERT(DECIMAL(12,5), BENEFIT_RATE_PER_UNIT_VADDSP)),11)
																		 ELSE '00000.00000'
																  END
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'B'
																and bnft.MEME_REL in ('H','W')
											),	
		extr.BENEFIT_RATE_PER_UNIT_VADDCH = (SELECT distinct  CASE WHEN BENEFIT_RATE_PER_UNIT_VADDCH IS NOT NULL
																		 THEN RIGHT(REPLICATE('0',10) + CONVERT(VARCHAR,CONVERT(DECIMAL(12,5), BENEFIT_RATE_PER_UNIT_VADDCH)),11)
																		 ELSE '00000.00000'
																  END
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'B'
																and bnft.MEME_REL in ('S','D')
											),
		extr.BENEFIT_RATE_PER_UNIT_VLTD = (SELECT distinct  CASE WHEN BENEFIT_RATE_PER_UNIT_VLTD IS NOT NULL
																		 THEN RIGHT(REPLICATE('0',10) + CONVERT(VARCHAR,CONVERT(DECIMAL(12,5), BENEFIT_RATE_PER_UNIT_VLTD)),11)
																		 ELSE '00000.00000'
																  END
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'K'
																and bnft.MEME_REL = 'M'
											),
		extr.BENEFIT_RATE_PER_UNIT_VSTD = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_VSTD IS NOT NULL
																		 THEN RIGHT(REPLICATE('0',10) + CONVERT(VARCHAR,CONVERT(DECIMAL(12,5), BENEFIT_RATE_PER_UNIT_VSTD)),11)
																		 ELSE '00000.00000'
																  END
											   FROM 	@BenefitData bnft  
											   WHERE  bnft.GRGR_ID = extr.GROUP_NUMBER
																and bnft.BLCT_DISP_CD = extr.BLCT_DISP_CD
																and bnft.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
																and bnft.BILL_FROM_DATE = extr.BILL_FROM_DATE
																AND bnft.CSPD_CAT = 'J'
																and bnft.MEME_REL = 'M'
											)	
		
											
FROM @PremiumNtake_extr extr	
	
	
    
/************* Error Checking for Inserting values in stage table tpzt_usable_premium_ntake_extr for various Benefit Amounts and Benfit Rate per unit life columns *************/  
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  

        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Inserting values in stage table tpzt_usable_premium_ntake_extr for various Benefit Amounts and Benfit Rate per unit life columns FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END       
          
/**************  PRINT STEP 7 FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed 

/**************  PRINT STEP 7A HEADER DATA *************************/  
  
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
            @ldtStepStartTime = GETDATE(),  
            @lvcMsg = @lvcObjectName + ': inserting data into fabncdv1stage.dbo.tpzt_usable_premium_ntake '  

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
        @pnStepNumber     = @lnCurrentStep,  
        @pdtStepStartTime = @ldtStepStartTime,  
        @pnTotalSteps     = @lnTotalSteps,  
        @pchStepMsg       = @lvcMsg 
        
/************* STEP 7A inserting data into  fabncdv1stage.dbo.tpzt_usable_premium_ntake *************/  
          
          insert into fabncdv1stage.dbo.tpzt_usable_premium_ntake_extr 
				select  GROUP_NUMBER                   ,
						GROUP_NAME                     ,
						BLCT_DISP_CD                   ,
						LIFE_PREMIUM_AMOUNT            ,
						ADD_PREMIUM_AMOUNT             ,
						DEP_PREMIUM_AMOUNT             ,
						WDB_PREMIUM_AMOUNT             ,
						LTD_PREMIUM_AMOUNT             ,
						SLI_PREMIUM_AMOUNT             ,
						SAD_PREMIUM_AMOUNT             ,
						VOLUNTARY_LIF_PREMIUM_AMOUNT   ,
						VOLUNTARY_LIFSP_PREMIUM_AMOUNT ,
						VOLUNTARY_LIFCH_PREMIUM_AMOUNT ,
						VOLUNTARY_ADD_PREMIUM_AMOUNT   ,
						VOLUNTARY_ADDSP_PREMIUM_AMOUNT ,
						VOLUNTARY_ADDCH_PREMIUM_AMOUNT ,
						VOLUNTARY_STD_PREMIUM_AMOUNT   ,
						VOLUNTARY_LTD_PREMIUM_AMOUNT   ,
						PREMIUM_AMOUNT                 ,
						COMMISSION                     ,
						NET_AMOUNT                     ,
						LIF_COUNT                      ,
						ADD_COUNT                      ,
						DEP_COUNT                      ,
						STD_COUNT                      ,
						LTD_COUNT                      ,
						SLI_COUNT                      ,
						SAD_COUNT                      ,
						VOLUNTARY_LIF_COUNT            ,
						VOLUNTARY_LIFSP_COUNT          ,
						VOLUNTARY_LIFCH_COUNT          ,
						VOLUNTARY_ADD_COUNT            ,
						VOLUNTARY_ADDSP_COUNT          ,
						VOLUNTARY_ADDCH_COUNT          ,
						VOLUNTARY_LTD_COUNT            ,
						VOLUNTARY_STD_COUNT            ,
						BENEFIT_AMOUNT_FOR_LIFE        ,
						BENEFIT_AMOUNT_FOR_ADD         ,
						BENEFIT_AMOUNT_FOR_DEP         ,
						BENEFIT_AMOUNT_FOR_STD         ,
						BENEFIT_AMOUNT_FOR_LTD         ,
						BENEFIT_AMOUNT_FOR_SLI         ,
						BENEFIT_AMOUNT_FOR_SAD         ,
						BENEFIT_AMOUNT_FOR_VLIF        ,
						BENEFIT_AMOUNT_FOR_VLIFSP      ,
						BENEFIT_AMOUNT_FOR_VLIFCH      ,
						BENEFIT_AMOUNT_FOR_VADD        ,
						BENEFIT_AMOUNT_FOR_VADDSP      ,
						BENEFIT_AMOUNT_FOR_VADDCH      ,
						BENEFIT_AMOUNT_FOR_VLTD        ,
						BENEFIT_AMOUNT_FOR_VSTD        ,
						BENEFIT_RATE_PER_UNIT_LIFE     ,
						BENEFIT_RATE_PER_UNIT_ADD      ,
						BENEFIT_RATE_PER_UNIT_DEP      ,
						BENEFIT_RATE_PER_UNIT_STD      ,
						BENEFIT_RATE_PER_UNIT_LTD      ,
						BENEFIT_RATE_PER_UNIT_SLI      ,
						BENEFIT_RATE_PER_UNIT_SAD      ,
						BENEFIT_RATE_PER_UNIT_VLIF     ,
						BENEFIT_RATE_PER_UNIT_VLIFSP   ,
						BENEFIT_RATE_PER_UNIT_VLIFCH   ,
						BENEFIT_RATE_PER_UNIT_VADD     ,
						BENEFIT_RATE_PER_UNIT_VADDSP   ,
						BENEFIT_RATE_PER_UNIT_VADDCH   ,
						BENEFIT_RATE_PER_UNIT_VLTD     ,
						BENEFIT_RATE_PER_UNIT_VSTD     ,
						LIFE_TYPE                      ,
						ADD_TYPE                       ,
						DEP_TYPE                       ,
						STD_TYPE                       ,
						LTD_TYPE                       ,
						SLI_TYPE                       ,
						SAD_TYPE                       ,
						VLIF_TYPE                      ,
						VLIFSP_TYPE                    ,
						VLIFCH_TYPE                    ,
						VADD_TYPE                      ,
						VADDSP_TYPE                    ,
						VADDCH_TYPE                    ,
						VLTD_TYPE                      ,
						VSTD_TYPE                      ,
						BILL_FROM_DATE                 ,
				 	BILL_CREATE_DATE               
				from @PremiumNtake_extr
					order by GROUP_NUMBER ASC
          
/************* Error Checking for Truncate Staging table tpzt_usable_premium_ntake_error *************/  
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  

        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : inserting data fabncdv1stage.dbo.tpzt_usable_premium_ntake failed'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END       
          
/**************  PRINT STEP 7A FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed  



            
/**************  PRINT STEP 8 HEADER DATA *************************/  
  
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
            @ldtStepStartTime = GETDATE(),  
            @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_usable_premium_ntake_error '  

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
        @pnStepNumber     = @lnCurrentStep,  
        @pdtStepStartTime = @ldtStepStartTime,  
        @pnTotalSteps     = @lnTotalSteps,  
        @pchStepMsg       = @lvcMsg 
        
/************* STEP 8 Truncate Staging table tpzt_usable_premium_ntake_error *************/  
          
   TRUNCATE TABLE fabncdv1stage.dbo.tpzt_usable_premium_ntake_error  
          
/************* Error Checking for Truncate Staging table tpzt_usable_premium_ntake_error *************/  
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  

        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Truncate Staging table tpzt_usable_premium_ntake_error FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END       
          
/**************  PRINT STEP 8 FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed   

/**************  PRINT STEP 9  HEADER DATA *************************/  
  
        SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Insert error records in staging table tpzt_usable_premium_ntake_error'  

        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg 

                 
/************* STEP 9 Insert error records in staging table tpzt_usable_premium_ntake_error *************/  
          
    DELETE FROM @PremiumNtake_extr
    OUTPUT DELETED.GROUP_NUMBER,
           DELETED.GROUP_NAME,
           DELETED.BILL_FROM_DATE
    INTO fabncdv1stage.dbo.tpzt_usable_premium_ntake_error
    WHERE LTRIM(RTRIM(ISNULL(GROUP_NUMBER,''))) = ''
        OR LTRIM(RTRIM(ISNULL(GROUP_NAME,''))) = ''
        OR LTRIM(RTRIM(ISNULL(BILL_FROM_DATE,''))) = ''

/************* Error Checking for Inserting in Staging table tpzt_usable_premium_ntake_error  *************/  
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  

        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Inserting error records in staging table tpzt_usable_premium_ntake_error FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END       
          
/**************  PRINT STEP 9 FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed   

/**************  PRINT JOB FOOTER DATA ****************************/

    SELECT @ldtProcessEndTime = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr
      @pchObjectName          = @lvcObjectName,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pdtProcessEndTime      = @ldtProcessEndTime
    RETURN  @lnRetCd
END
GO
/****************************************************************
 BEGIN MAINTENANCE WRAPPER:
*****************************************************************/
IF OBJECT_ID('dbo.tpzp_usable_premium_ntake_extr') IS NOT NULL
  PRINT '<<< CREATED PROCEDURE dbo.tpzp_usable_premium_ntake_extr >>>'
       
ELSE
  PRINT '<<<ERROR CREATING PROCEDURE dbo.tpzp_usable_premium_ntake_extr >>>'
GO

/****************************************************************
 END MAINTENANCE WRAPPER:
*****************************************************************/