/***************************************************************
  BEGIN MAINTENANCE WRAPPER.
***************************************************************/

IF OBJECT_ID('dbo.tpzp_usable_premium_ntake_extr') IS NOT NULL
BEGIN
  DROP PROCEDURE dbo.tpzp_usable_premium_ntake_extr

  IF OBJECT_ID('dbo.tpzp_usable_premium_ntake_extr') IS NOT NULL
    PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_usable_premium_ntake_extr >>>'
  ELSE
    PRINT '<<< DROPPED PROCEDURE dbo.tpzp_usable_premium_ntake_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
***************************************************************/

CREATE PROCEDURE [dbo].[tpzp_usable_premium_ntake_extr]

/****************************************************************
**   NAME                  : dbo.tpzp_usable_premium_ntake_extr
**
**
**   PVCS LOCATION         : 
**
**   FUNCTION              : STEP 1 Truncating stage table fabncua1stage.dbo.tpzt_usable_premium_ntake_extr 
**                           STEP 2 Inserting updated records in stage table fabncua1stage.dbo.tpzt_usable_premium_ntake_extr
**                           STEP 3 Updating Staging table tpzt_usable_premium_ntake_extr
**                           STEP 4 Updating Staging table tpzt_usable_premium_ntake_extr  for LIF_COUNT column
**                           STEP 5 Updating Staging table tpzt_usable_premium_ntake_extr  for calculating count for various plans
**                           STEP 6 Updating Staging table tpzt_usable_premium_ntake_extr  for calculating count for various voluntary plans
**                           STEP 7 Inserting values in stage table tpzt_usable_premium_ntake_extr for various Benefit Amounts and Benfit Rate per unit life columns
**                           STEP 8 Truncate Staging table tpzt_usable_premium_ntake_error
**                           STEP 9 Insert error records in staging table tpzt_usable_premium_ntake_error
**
**   PARAMETERS            :
**                   INPUT :
**                  OUTPUT :
**
**   RETURN CODES          : 0 on success
**
**   TABLES REFERENCED     :
**                FACETS   : fabncua1.dbo.CMC_CSPI_CS_PLAN cspi  
**                           fabncua1.dbo.CMC_BLEI_ENTY_INFO blei
**                           fabncua1.dbo.CMC_BLBL_BILL_SUMM blbl
**                           fabncua1.dbo.CDS_INSB_SB_DETAIL
**
**                FACETSXC : N/A
**                CUSTOM   : 
**                STAGE    : fabncua1stage.dbo.tpzt_comm_elig_extr
**                           fabncua1stage.dbo.tpzt_usable_vadd
**                           fabncua1stage.dbo.tpzt_usable_vl
**                           fabncua1stage.dbo.tpzt_usable_sa
**                           fabncua1stage.dbo.tpzt_usable_sl
**                           fabncua1stage.dbo.tpzt_usable_ltd
**                           fabncua1stage.dbo.tpzt_usable_wdb
**                           fabncua1stage.dbo.tpzt_usable_dl
**                           fabncua1stage.dbo.tpzt_usable_gtl_add
**
**   PROCEDURES REFERENCED :
**                  FACETS :
**                  CUSTOM :
**   STANDARD LOGGING PROCS:
**                           harcore.dbo.harsp_gen_util_job_hdr_lgr
**                           harcore.dbo.harsp_gen_util_job_ftr_lgr
**                           harcore.dbo.harsp_gen_util_step_hdr_lgr
**                           harcore.dbo.harsp_gen_util_step_ftr_lgr
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0      08/26/2014   Ghazala Ameen       Initial Version
** 1.1      09/26/2014   Ghazala Ameen       Updated logic for Premium Amount and Commission Column and 
                                             updated for Bill Create date and Bill From date
****************************************************************/
AS

BEGIN

/****************************************************************
**          DECLARE LOCAL VARIABLES                            **
****************************************************************/

    DECLARE @lnRetCd                INT              -- Proc return code
    DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time
    DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
    DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time
    DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time
    DECLARE @lnCurrentStep          INT              -- Current Step Number
    DECLARE @lnTotalSteps           INT              -- Total Steps In Proc
    DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field
    DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name
    DECLARE @lvcDBName              VARCHAR(32)      -- DB Name
    DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version
    DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name
    DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name
    DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step
    DECLARE @ldtLastRunDt           DATETIME         -- Last run date
    DECLARE @ldtCurrentDate         DATETIME         -- Current date
    DECLARE @lvcCommission_li       VARCHAR(15)      -- Commision Percentage for life premium plans
    DECLARE @lvcCommission_add      VARCHAR(15)      -- Commision Percentage for add premium plans
    DECLARE @lvcCommission_dl       VARCHAR(15)      -- Commision Percentage for dependent life premium plans
    DECLARE @lvcCommission_wdb      VARCHAR(15)      -- Commision Percentage for wdb premium plans
    DECLARE @lvcCommission_ltd      VARCHAR(15)      -- Commision Percentage for ltd premium plans
    DECLARE @lvcCommission_sl       VARCHAR(15)      -- Commision Percentage for supplemental life premium plans
    DECLARE @lvcCommission_sa       VARCHAR(15)      -- Commision Percentage for supplemental add premium plans
    DECLARE @lvcCommission_vlisp    VARCHAR(15)      -- Commision Percentage for Voluntary life spouse premium plans
    DECLARE @lvcCommission_vlich    VARCHAR(15)      -- Commision Percentage for Voluntary life child premium plans
    DECLARE @lvcCommission_vaddsp   VARCHAR(15)      -- Commision Percentage for Voluntary add spouse premium plans
    DECLARE @lvcCommission_vaddch   VARCHAR(15)      -- Commision Percentage for Voluntary add child premium plans
    DECLARE @lvcCommission_vl       VARCHAR(15)      -- Commision Percentage for Voluntary Life plan
    DECLARE @lvcCommission_vadd     VARCHAR(15)      -- Commision Percentage for Voluntary ADD plan
    DECLARE @lvcCommission_vstd     VARCHAR(15)      -- Commision Percentage for Voluntary STD plan
    DECLARE @lvcCommission_vltd     VARCHAR(15)      -- Commision Percentage for Voluntary LTD plan
    
	--count of various products
    DECLARE @ProdCount TABLE
    (
        GRGR_ID      VARCHAR(8),
        L            VARCHAR(6),
        A            VARCHAR(6),
        E            VARCHAR(6),
        K            VARCHAR(6),
        S            VARCHAR(6),
        T            VARCHAR(6),
        X            VARCHAR(6),
        Y            VARCHAR(6),
        J            VARCHAR(6)
    )
    --count of Voluntary products
    DECLARE @VolProdCount TABLE
    (
        GRGR_ID        VARCHAR(8),
        MEME_REL       VARCHAR(1),
        Z              VARCHAR(6),
        B              VARCHAR(6)
    )
	--Premium Amount
    DECLARE @PremiumAmount TABLE
    (
        GROUP_NUMBER                    VARCHAR(8),
        GROUP_NAME                      VARCHAR(120),
        BLCT_DISP_CD					varchar(1),
        LIFE_PREMIUM_AMOUNT             MONEY,
        ADD_PREMIUM_AMOUNT              MONEY,
		DEP_PREMIUM_AMOUNT               MONEY,
        WDB_PREMIUM_AMOUNT              MONEY,
        LTD_PREMIUM_AMOUNT              MONEY,
        SLI_PREMIUM_AMOUNT              MONEY,
        SAD_PREMIUM_AMOUNT              MONEY,
        VOLUNTARY_STD_PREMIUM_AMOUNT    MONEY,
        VOLUNTARY_LTD_PREMIUM_AMOUNT    MONEY,
        BILL_FROM_DATE					varchar(10),
        BILL_CREATE_DATE				varchar(10)
    )
	--Premium amount for voluntary products for members
    DECLARE @PremiumAmountVolMem TABLE
    (
        GROUP_NUMBER                    VARCHAR(8),
        GROUP_NAME                      VARCHAR(120),
        MEM_REL                         VARCHAR(1),
        VOLUNTARY_LIF_PREMIUM_AMOUNT    MONEY,
        VOLUNTARY_ADD_PREMIUM_AMOUNT    MONEY
    )
	--Premium amount for voluntary products for spouse
	DECLARE @PremiumAmountVolSp TABLE
    (
        GROUP_NUMBER                    VARCHAR(8),
        GROUP_NAME                      VARCHAR(120),
        MEM_REL                         VARCHAR(1),
        VOLUNTARY_LIFSP_PREMIUM_AMOUNT    MONEY,
        VOLUNTARY_ADDSP_PREMIUM_AMOUNT    MONEY
    )
	--Premium amount for voluntary products for children
	DECLARE @PremiumAmountVolCh TABLE
    (
        GROUP_NUMBER                    VARCHAR(8),
        GROUP_NAME                      VARCHAR(120),
        MEM_REL                         VARCHAR(1),
        VOLUNTARY_LIFCH_PREMIUM_AMOUNT    MONEY,
        VOLUNTARY_ADDCH_PREMIUM_AMOUNT    MONEY
    )
    ---commission variable declaration
    DECLARE @CommissionTable TABLE
    (
		GROUP_NUMBER		VARCHAR(8),
		BLCT_DISP_CD		VARCHAR(1),
		BILL_FROM_DATE		VARCHAR(10),
		BILL_CREATE_DATE	VARCHAR(10),
		PREMIUM_TOTAL		VARCHAR(15),
        Commission			VARCHAR(15),        
        --COM_VOL_LIF_PREMIUM_AMT VARCHAR(20),
        COM_VOL_LIF_PREMIUM_COM VARCHAR(15),        
        --COM_VOL_ADD_PREMIUM_AMT VARCHAR(20),
        COM_VOL_ADD_PREMIUM_COM VARCHAR(15),        
        --COM_VOL_STD_PREMIUM_AMT VARCHAR(20),
        COM_VOL_STD_PREMIUM_COM VARCHAR(15),        
        --COM_VOL_LTD_PREMIUM_AMT VARCHAR(20),
        COM_VOL_LTD_PREMIUM_COM VARCHAR(15)
    )
	--no of Employees
	DECLARE @NOEMPLOYESS TABLE
	(
		GROUP_NUMBER		VARCHAR(8), 
		GRGR_TOTAL_EMPL		INT,
		PERCENTAGE			DECIMAL(3,2)
	)
	
	DECLARE @IntCommission TABLE
	(	
		GROUP_NUMBER		VARCHAR(8),
		BLCT_DISP_CD		VARCHAR(1),
		BILL_FROM_DATE		VARCHAR(10), 
		BILL_CREATE_DATE	VARCHAR(10),
		PREMIUM_TOTAL		VARCHAR(15)
	)
	DECLARE @VOLPRODCAT TABLE
	(
		GROUP_NUMBER		VARCHAR(8),
		PERCENTAGE			DECIMAL(3,2),
		CSPD_CAT			VARCHAR(1),
		BLCT_DISP_CD		VARCHAR(1),
		BILL_FROM_DATE		VARCHAR(10), 
		BILL_CREATE_DATE	VARCHAR(10),
		PREMIUM_TOTAL		VARCHAR(15)
	)

/****************************************************************
**          INITIALIZE  VARIABLES                              **
****************************************************************/

    SELECT @lnRetCd        = 0, 
      @lvcMsg              = NULL,
      @lnCurrentStep       = 0,  
      @lnTotalSteps        = 9,
      @ldtStepEndTime      = NULL,
      @lvcVersionNum       = '1.1'

    SELECT @lvcServerName  = @@SERVERNAME,
      @lvcDBName           = DB_NAME(),
      @lvcUser             = USER_NAME(),
      @lvcObjectName       = OBJECT_NAME(@@PROCID),
      @ldtProcessStartTime = GETDATE(),
      @ldtCurrentDate      = CONVERT(VARCHAR (10), GETDATE(), 101)

/****************************************************************
**               BEGIN PROCESS                                 **
*****************************************************************/

/**************  PRINT JOB HEADER DATA *************************/

    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr
      @pchObjectName        = @lvcObjectName,
      @pdtProcessStartTime  = @ldtProcessStartTime,
      @pchServerName        = @lvcServerName,
      @pchDBName            = @lvcDBName,
      @pchUserName          = @lvcUser,
      @pchVersionNum        = @lvcVersionNum


/**************  PRINT STEP 1 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Truncating stage table fabncua1stage.dbo.tpzt_usable_premium_ntake_extr'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 1 Truncating stage table fabncua1stage.dbo.tpzt_usable_premium_ntake_extr **********/

   TRUNCATE TABLE fabncua1stage.dbo.tpzt_usable_premium_ntake_extr
               
/********** Error Checking for truncate statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Truncating stage table fabncua1stage.dbo.tpzt_usable_premium_ntake_extr FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 1 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed
      
/**************  PRINT STEP 2 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Inserting updated records in stage table fabncua1stage.dbo.tpzt_usable_premium_ntake_extr'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 2 Inserting updated records in stage table fabncua1stage.dbo.tpzt_usable_premium_ntake_extr **********/

/***** Inserting for Premium Amounts in table variable ******/
    INSERT INTO @PremiumAmount 
    (
        GROUP_NUMBER,
        GROUP_NAME,
        BLCT_DISP_CD,
        LIFE_PREMIUM_AMOUNT,
        ADD_PREMIUM_AMOUNT,
		DEP_PREMIUM_AMOUNT,
        WDB_PREMIUM_AMOUNT,
        LTD_PREMIUM_AMOUNT,
        SLI_PREMIUM_AMOUNT,
        SAD_PREMIUM_AMOUNT,
        VOLUNTARY_STD_PREMIUM_AMOUNT,
        VOLUNTARY_LTD_PREMIUM_AMOUNT,
        BILL_FROM_DATE,
        BILL_CREATE_DATE
    )
    SELECT 
       GROUP_NUMBER,
       GROUP_NAME,
       BLCT_DISP_CD,
       L AS LIFE_PREMIUM_AMOUNT,
       A AS ADD_PREMIUM_AMOUNT,
	   T AS DEP_PREMIUM_AMOUNT,
       X AS WDB_PREMIUM_AMOUNT,
       Y AS LTD_PREMIUM_AMOUNT,
       S AS SLI_PREMIUM_AMOUNT,
       E AS SAD_PREMIUM_AMOUNT,
       K AS VOLUNTARY_STD_PREMIUM_AMOUNT,
       J AS VOLUNTARY_LTD_PREMIUM_AMOUNT,
       BILL_FROM_DATE,
       BILL_CREATE_DATE
       
    FROM
    (
        SELECT  DISTINCT CSPDCAT =cspi.CSPD_CAT , 
        blct.BLCT_DISP_CD ,
        GROUP_NUMBER                   = LEFT(ISNULL(LTRIM(RTRIM(grgr.GRGR_ID)),'') + SPACE(8),8),
        
        GROUP_NAME                     = LEFT(ISNULL(SUBSTRING(LTRIM(RTRIM(grgr.GRGR_NAME)),1,120),'') + SPACE(120),120),
        
        PREMIUM_AMOUNT 				 = blct.BLCT_PREM_SB,
        BILL_FROM_DATE				= CONVERT(VARCHAR(10), blct.BLBL_DUE_DT,101),
        BILL_CREATE_DATE			= CONVERT(VARCHAR(8),bliv.BLIV_CREATE_DTM, 112)
        
		FROM  fabncua1.dbo.CMC_GRGR_GROUP grgr 
				INNER JOIN fabncua1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
				INNER JOIN fabncua1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
				INNER JOIN fabncua1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
		        												
				LEFT JOIN fabncua1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
				LEFT JOIN fabncua1.dbo.CMC_BLCT_COMP_TOTL blct ON blct.BLEI_CK = blei.BLEI_CK		 
        														AND blct.CSPI_ID = cspi.CSPI_ID
        		LEFT JOIN fabncua1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blct.BLEI_CK
																AND bliv.BLBL_DUE_DT = blct.BLBL_DUE_DT
		WHERE cspi.CSPD_CAT IN ('X','Y','L','A','S','T','E','K','J')
		AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101') 
									AND DATEADD(s,-0,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,-1)))
		AND  blct.BLCT_DISP_CD IN ('M', 'R')					
    )d
    pivot
    (
       
      MIN(PREMIUM_AMOUNT)
      for CSPDCAT in (X,Y,L,A,S,T,E,K,J)
    ) piv;

/****** Inserting for Voluntary Premium Amount for Subscriber in table variables ******/
    INSERT INTO @PremiumAmountVolMem 
    (
        GROUP_NUMBER,
        GROUP_NAME,
        MEM_REL,
        VOLUNTARY_LIF_PREMIUM_AMOUNT,
        VOLUNTARY_ADD_PREMIUM_AMOUNT
    )
    SELECT 
        GROUP_NUMBER,
        GROUP_NAME,
        MEM_REL,
        Z AS VOLUNTARY_LIF_PREMIUM_AMOUNT,
        B AS VOLUNTARY_ADD_PREMIUM_AMOUNT
    FROM
    (
        SELECT  DISTINCT CSPDCAT =cspi.CSPD_CAT ,blct.BLCT_DISP_CD ,bliv.BLIV_CREATE_DTM,
        GROUP_NUMBER                = LEFT(ISNULL(LTRIM(RTRIM(grgr.GRGR_ID)),'') + SPACE(8),8),
        GROUP_NAME                  = LEFT(ISNULL(SUBSTRING(LTRIM(RTRIM(grgr.GRGR_NAME)),1,120),'') + SPACE(120),120),
        MEM_REL                     = meme.MEME_REL,        
        PREMIUM_AMOUNT				= blct.BLCT_PREM_SB
        
        FROM  fabncua1.dbo.CMC_GRGR_GROUP grgr 
        INNER JOIN fabncua1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
        INNER JOIN fabncua1.dbo.CMC_MEME_MEMBER meme 	ON meme.GRGR_CK = grgr.GRGR_CK
        INNER JOIN fabncua1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
        LEFT JOIN fabncua1.dbo.CMC_BLEI_ENTY_INFO blei  ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
        LEFT JOIN fabncua1.dbo.CMC_BLCT_COMP_TOTL blct  ON blct.BLEI_CK = blei.BLEI_CK
														AND blct.CSPI_ID = cspi.CSPI_ID
		LEFT JOIN fabncua1.dbo.CMC_BLIV_INVOICE bliv 	ON bliv.BLEI_CK = blct.BLEI_CK
														AND bliv.BLBL_DUE_DT = blct.BLBL_DUE_DT
    WHERE cspi.CSPD_CAT IN ('Z','B')
    AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) +0, '19000101') 
							AND DATEADD(s,-0,DATEADD(mm, DATEDIFF(m,0,GETDATE())+1,0))) 
	AND meme.MEME_REL = 'M'
	AND 	blct.BLCT_DISP_CD IN ('M', 'R')
	
    )d
    pivot
    (
      MIN(PREMIUM_AMOUNT)
      for CSPDCAT in (Z,B)
    ) piv;
    
/******* Inserting Premium Amount Values in extr table from table variables *******/
    INSERT INTO fabncua1stage.dbo.tpzt_usable_premium_ntake_extr 
   (
        GROUP_NUMBER,
        GROUP_NAME,
        BLCT_DISP_CD,
        LIFE_PREMIUM_AMOUNT,
        ADD_PREMIUM_AMOUNT,
		DEP_PREMIUM_AMOUNT,
        WDB_PREMIUM_AMOUNT,
        LTD_PREMIUM_AMOUNT,
        SLI_PREMIUM_AMOUNT,
        SAD_PREMIUM_AMOUNT,
        VOLUNTARY_STD_PREMIUM_AMOUNT,
        VOLUNTARY_LTD_PREMIUM_AMOUNT,
        BILL_FROM_DATE,
        BILL_CREATE_DATE   
    )
    SELECT  
        GROUP_NUMBER,
        GROUP_NAME,
        BLCT_DISP_CD,
        LIFE_PREMIUM_AMOUNT,
        ADD_PREMIUM_AMOUNT,
		DEP_PREMIUM_AMOUNT,
        WDB_PREMIUM_AMOUNT,
        LTD_PREMIUM_AMOUNT,
        SLI_PREMIUM_AMOUNT,
        SAD_PREMIUM_AMOUNT,
        VOLUNTARY_STD_PREMIUM_AMOUNT,
        VOLUNTARY_LTD_PREMIUM_AMOUNT,
        BILL_FROM_DATE,
        BILL_CREATE_DATE
    FROM @PremiumAmount

/**** Inserting Voluntary Premium Amount from table variable for Subscribers *****/
    ;with CTEM as
    (
        SELECT preAmt.GROUP_NUMBER AS GROUP_NUMBER,
               preAmt.VOLUNTARY_LIF_PREMIUM_AMOUNT AS LIFP,
               preAmt.VOLUNTARY_ADD_PREMIUM_AMOUNT AS VOLADD
        FROM @PremiumAmountVolMem preAmt
        WHERE preAmt.MEM_REL = 'M'
    )
    UPDATE extr
    SET extr.VOLUNTARY_LIF_PREMIUM_AMOUNT    = cte.LIFP,
        extr.VOLUNTARY_ADD_PREMIUM_AMOUNT = cte.VOLADD
    FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr extr
    INNER JOIN CTEM cte ON cte.GROUP_NUMBER = extr.GROUP_NUMBER

/****** Inserting for Voluntary Premium Amount for Spouse in table variables ******/
    INSERT INTO @PremiumAmountVolSp 
    (
        GROUP_NUMBER,
        GROUP_NAME,
        MEM_REL,
        VOLUNTARY_LIFSP_PREMIUM_AMOUNT,
        VOLUNTARY_ADDSP_PREMIUM_AMOUNT
    )
    SELECT 
        GROUP_NUMBER,
        GROUP_NAME,
        MEM_REL,
        Z AS VOLUNTARY_LIFSP_PREMIUM_AMOUNT,
        B AS VOLUNTARY_ADDSP_PREMIUM_AMOUNT
    FROM
    (
        SELECT  DISTINCT CSPDCAT =cspi.CSPD_CAT , blct.BLCT_DISP_CD ,bliv.BLIV_CREATE_DTM,
        GROUP_NUMBER                = LEFT(ISNULL(LTRIM(RTRIM(grgr.GRGR_ID)),'') + SPACE(8),8),
        GROUP_NAME                  = LEFT(ISNULL(SUBSTRING(LTRIM(RTRIM(grgr.GRGR_NAME)),1,120),'') + SPACE(120),120),
        MEM_REL                        = meme.MEME_REL,
        
        PREMIUM_AMOUNT				= blct.BLCT_PREM_DEP
        
        FROM  fabncua1.dbo.CMC_GRGR_GROUP grgr 
        INNER JOIN fabncua1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
        INNER JOIN fabncua1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
        INNER JOIN fabncua1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
        LEFT JOIN fabncua1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
        LEFT JOIN fabncua1.dbo.CMC_BLCT_COMP_TOTL blct ON blct.BLEI_CK = blei.BLEI_CK
														AND blct.CSPI_ID = cspi.CSPI_ID
			LEFT JOIN fabncua1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blct.BLEI_CK
																AND bliv.BLBL_DUE_DT = blct.BLBL_DUE_DT
    WHERE cspi.CSPD_CAT IN ('Z','B')
    AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) +0, '19000101') 
							AND DATEADD(s,-0,DATEADD(mm, DATEDIFF(m,0,GETDATE())+1,0))) 
	AND meme.MEME_REL IN('H','W')
	AND 	blct.BLCT_DISP_CD IN ('M', 'R')
	AND blct.BLCT_DISP_CD = 'M'
    )d
    pivot
    (
      MIN(PREMIUM_AMOUNT)
      for CSPDCAT in (Z,B)
    ) piv;
	
/**** Inserting Voluntary Premium Amount from table variable for Dependents *****/
    ;with CTEM as
    (
        SELECT preAmt.GROUP_NUMBER AS GROUP_NUMBER,
               preAmt.VOLUNTARY_LIFSP_PREMIUM_AMOUNT AS LIFP,
               preAmt.VOLUNTARY_ADDSP_PREMIUM_AMOUNT AS VOLADD
        FROM @PremiumAmountVolSp preAmt
    )
    UPDATE extr
    SET extr.VOLUNTARY_LIFSP_PREMIUM_AMOUNT = cte.LIFP,
		extr.VOLUNTARY_ADDSP_PREMIUM_AMOUNT = cte.VOLADD
    FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr extr
    INNER JOIN CTEM cte ON cte.GROUP_NUMBER = extr.GROUP_NUMBER

/****** Inserting for Voluntary Premium Amount for Spouse in table variables ******/
    INSERT INTO @PremiumAmountVolCh 
    (
        GROUP_NUMBER,
        GROUP_NAME,
        MEM_REL,
        VOLUNTARY_LIFCH_PREMIUM_AMOUNT,
        VOLUNTARY_ADDCH_PREMIUM_AMOUNT
    )
    SELECT 
        GROUP_NUMBER,
        GROUP_NAME,
        MEM_REL,
        Z AS VOLUNTARY_LIFCH_PREMIUM_AMOUNT,
        B AS VOLUNTARY_ADDCH_PREMIUM_AMOUNT
    FROM
    (
        SELECT  DISTINCT CSPDCAT =cspi.CSPD_CAT , blct.BLCT_DISP_CD ,bliv.BLIV_CREATE_DTM,
        GROUP_NUMBER                = LEFT(ISNULL(LTRIM(RTRIM(grgr.GRGR_ID)),'') + SPACE(8),8),
        GROUP_NAME                  = LEFT(ISNULL(SUBSTRING(LTRIM(RTRIM(grgr.GRGR_NAME)),1,120),'') + SPACE(120),120),
        MEM_REL                        = meme.MEME_REL,
        
        PREMIUM_AMOUNT				= blct.BLCT_PREM_DEP
        
        FROM  fabncua1.dbo.CMC_GRGR_GROUP grgr 
        INNER JOIN fabncua1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
        INNER JOIN fabncua1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
        INNER JOIN fabncua1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
        LEFT JOIN fabncua1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
        LEFT JOIN fabncua1.dbo.CMC_BLCT_COMP_TOTL blct ON blct.BLEI_CK = blei.BLEI_CK
        	LEFT JOIN fabncua1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blct.BLEI_CK
																AND bliv.BLBL_DUE_DT = blct.BLBL_DUE_DT
    WHERE cspi.CSPD_CAT IN ('Z','B')
    AND blct.CSPI_ID = cspi.CSPI_ID
    AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) +0, '19000101') 
							AND DATEADD(s,-0,DATEADD(mm, DATEDIFF(m,0,GETDATE())+1,0))) 
	AND meme.MEME_REL IN('S','D')
		AND 	blct.BLCT_DISP_CD IN ('M', 'R')
    )d
    pivot
    (
      MIN(PREMIUM_AMOUNT)
      for CSPDCAT in (Z,B)
    ) piv;
	
/**** Inserting Voluntary Premium Amount from table variable for Dependents *****/
    ;with CTEM as
    (
        SELECT preAmt.GROUP_NUMBER AS GROUP_NUMBER,
               preAmt.VOLUNTARY_LIFCH_PREMIUM_AMOUNT AS LIFP,
               preAmt.VOLUNTARY_ADDCH_PREMIUM_AMOUNT AS VOLADD
        FROM @PremiumAmountVolCh preAmt
    )
    UPDATE extr
    SET extr.VOLUNTARY_LIFCH_PREMIUM_AMOUNT = cte.LIFP,
		extr.VOLUNTARY_ADDCH_PREMIUM_AMOUNT = cte.VOLADD
    FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr extr
    INNER JOIN CTEM cte ON cte.GROUP_NUMBER = extr.GROUP_NUMBER	

/********** Error Checking for insert statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Inserting updated records in stage table fabncua1stage.dbo.tpzt_usable_premium_ntake_extr FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 2 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed

/**************  PRINT STEP 3  HEADER DATA *************************/  
  
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
            @ldtStepStartTime = GETDATE(),  
            @lvcMsg = @lvcObjectName + ': Updating staging table tpzt_usable_premium_ntake_extr '  

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
        @pnStepNumber     = @lnCurrentStep,  
        @pdtStepStartTime = @ldtStepStartTime,  
        @pnTotalSteps     = @lnTotalSteps,  
        @pchStepMsg       = @lvcMsg 
                 
/************* STEP 3 Updating Staging table tpzt_usable_premium_ntake_extr *************/

	;with CTE_PREMTABLE
	(	
		GROUP_NUMBER,
		BLCT_DISP_CD,
		BILL_FROM_DATE, 
		BILL_CREATE_DATE,
		PREMIUM_TOTAL
	)
	AS
	(
		SELECT GROUP_NUMBER,
				BLCT_DISP_CD,
				BILL_FROM_DATE, 
				BILL_CREATE_DATE,
				SUM(
					CONVERT(DECIMAL(10,2), ISNULL(LIFE_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(ADD_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(DEP_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(WDB_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(LTD_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(SLI_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(SAD_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_LIF_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_LIFSP_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_LIFCH_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_ADD_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_ADDSP_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_ADDCH_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_STD_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(VOLUNTARY_LTD_PREMIUM_AMOUNT,0))
				)
		FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr 
		GROUP BY  GROUP_NUMBER,BLCT_DISP_CD,BILL_FROM_DATE, BILL_CREATE_DATE
	)

	UPDATE extr
	SET extr.PREMIUM_AMOUNT =  cte.PREMIUM_TOTAL
	FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr extr 
	INNER JOIN CTE_PREMTABLE cte ON cte.GROUP_NUMBER = extr.GROUP_NUMBER
								AND cte. BLCT_DISP_CD = extr.BLCT_DISP_CD
								AND cte.BILL_FROM_DATE = extr.BILL_FROM_DATE
								AND cte.BILL_CREATE_DATE = extr.BILL_CREATE_DATE
								
/*********** Update for commission column ********/

	INSERT INTO @NOEMPLOYESS (GROUP_NUMBER,GRGR_TOTAL_EMPL,PERCENTAGE)
	SELECT DISTINCT GROUP_NUMBER, grgr.GRGR_TOTAL_EMPL,CAST(xwalk.PERCENTAGE AS NUMERIC(3,2))
	FROM  fabncua1stage.dbo.tpzt_usable_premium_ntake_extr ntake
	INNER JOIN fabncua1.dbo.CMC_GRGR_GROUP grgr ON grgr.GRGR_ID = ntake.GROUP_NUMBER
	INNER JOIN fabncua1stage.dbo.tpzt_usable_commission_cw xwalk 
			ON grgr.GRGR_TOTAL_EMPL BETWEEN CAST(xwalk.MIN_MARKET_SEGMENT AS INT) AND CAST(xwalk.MAX_MARKET_SEGMENT AS INT)
			
	INSERT INTO @IntCommission(GROUP_NUMBER,BLCT_DISP_CD,BILL_FROM_DATE,BILL_CREATE_DATE,PREMIUM_TOTAL)
	(
		SELECT  GROUP_NUMBER,
				BLCT_DISP_CD,
				BILL_FROM_DATE, 
				BILL_CREATE_DATE,
				SUM(
					CONVERT(DECIMAL(10,2), ISNULL(LIFE_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(ADD_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(DEP_PREMIUM_AMOUNT,0))	+ 
					CONVERT(DECIMAL(10,2), ISNULL(WDB_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(LTD_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(SLI_PREMIUM_AMOUNT,0)) + 
					CONVERT(DECIMAL(10,2), ISNULL(SAD_PREMIUM_AMOUNT,0))					
				)PREMIUM_AMOUNT

		FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr 
		GROUP BY  GROUP_NUMBER,BLCT_DISP_CD,BILL_FROM_DATE, BILL_CREATE_DATE
	)

	INSERT INTO @CommissionTable
	(
		GROUP_NUMBER	,
		BLCT_DISP_CD	,
		BILL_FROM_DATE	,
		BILL_CREATE_DATE,
		PREMIUM_TOTAL	,
		Commission		
	)
	SELECT 
		cte.GROUP_NUMBER	,
		cte.BLCT_DISP_CD	,
		cte.BILL_FROM_DATE	,
		cte.BILL_CREATE_DATE,
		cte.PREMIUM_TOTAL,
		COMMISSION1 = CONVERT(DECIMAL(12,2),cte.PREMIUM_TOTAL) * CONVERT(DECIMAL(3,2),PERCENTAGE)
	FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr ntake
	INNER JOIN 	@IntCommission cte ON   cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= ntake.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = ntake.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = ntake.BILL_CREATE_DATE
	INNER JOIN @NOEMPLOYESS emp ON cte.GROUP_NUMBER = emp.GROUP_NUMBER
	
------------------------------------------------------------------------------------------------------------------------  

	INSERT INTO @VOLPRODCAT (GROUP_NUMBER,PERCENTAGE,CSPD_CAT) 
	SELECT DISTINCT ntake.GROUP_NUMBER,  
				CAST(xwalk.PERCENTAGE AS NUMERIC(3,2)),cspi.CSPD_CAT
				
	FROM  fabncua1stage.dbo.tpzt_usable_premium_ntake_extr ntake
		INNER JOIN fabncua1.dbo.CMC_GRGR_GROUP grgr ON grgr.GRGR_ID = ntake.GROUP_NUMBER
		inNER JOIN fabncua1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
		INNER JOIN fabncua1stage.dbo.tpzt_usable_commission_cw xwalk 
				ON UPPER(xwalk.PLAN_DESCRIPTION) in (UPPER('Voluntary LTD'),UPPER('Voluntary STD'),UPPER('Voluntary ADD'),UPPER('Voluntary Life'))   
	WHERE  cspi.CSPD_CAT IN ('Z','B','J','K')

	DECLARE @VolCommission TABLE
	(	
		GROUP_NUMBER		            VARCHAR(8),
		BLCT_DISP_CD		            VARCHAR(1),
		BILL_FROM_DATE		            VARCHAR(10), 
		BILL_CREATE_DATE	            VARCHAR(10),
		VOLUNTARY_LIF_PREMIUM_AMOUNT	VARCHAR(15),
		VOLUNTARY_ADD_PREMIUM_AMOUNT	VARCHAR(15),
		VOLUNTARY_STD_PREMIUM_AMOUNT	VARCHAR(15),
		VOLUNTARY_LTD_PREMIUM_AMOUNT	VARCHAR(15)
	)

	INSERT INTO @VolCommission
	(
		GROUP_NUMBER,
		BLCT_DISP_CD,
		BILL_FROM_DATE,
		BILL_CREATE_DATE,
		VOLUNTARY_LIF_PREMIUM_AMOUNT,
		VOLUNTARY_ADD_PREMIUM_AMOUNT,
		VOLUNTARY_STD_PREMIUM_AMOUNT,
		VOLUNTARY_LTD_PREMIUM_AMOUNT
	)
	(
		SELECT  ntake.GROUP_NUMBER,
				ntake.BLCT_DISP_CD,
				ntake.BILL_FROM_DATE, 
				ntake.BILL_CREATE_DATE,
				SUM(CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_LIF_PREMIUM_AMOUNT,0)) +
					CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_LIFSP_PREMIUM_AMOUNT,0)) +
					CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_LIFCH_PREMIUM_AMOUNT,0))
					),
				SUM(CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_ADD_PREMIUM_AMOUNT,0)) +
					CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_ADDSP_PREMIUM_AMOUNT,0)) +
					CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_ADDCH_PREMIUM_AMOUNT,0))
					),
				SUM(CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_STD_PREMIUM_AMOUNT,0)))		,
				SUM(CONVERT(DECIMAL(10,2), ISNULL(ntake.VOLUNTARY_LTD_PREMIUM_AMOUNT,0)))
		FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr ntake
		GROUP BY  ntake.GROUP_NUMBER,ntake.BLCT_DISP_CD,ntake.BILL_FROM_DATE, ntake.BILL_CREATE_DATE
	)

	UPDATE comt
	SET comt.COM_VOL_LIF_PREMIUM_COM = CONVERT(DECIMAL(10,2),cte.VOLUNTARY_LIF_PREMIUM_AMOUNT) * CONVERT(DECIMAL(3,2),PERCENTAGE)
	     --comt.COM_VOL_LIF_PREMIUM_AMT = CONVERT(DECIMAL(10,2),cte.VOLUNTARY_LIF_PREMIUM_AMOUNT)
	FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr ntake
									
	INNER JOIN 	@VolCommission cte ON   cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= ntake.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = ntake.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = ntake.BILL_CREATE_DATE
	INNER JOIN @CommissionTable comt ON cte.GROUP_NUMBER	= comt.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= comt.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = comt.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = comt.BILL_CREATE_DATE
									
	INNER JOIN @VOLPRODCAT procat ON cte.GROUP_NUMBER = procat.GROUP_NUMBER
	WHERE procat.CSPD_CAT ='Z'
	
	UPDATE comt
	SET comt.COM_VOL_ADD_PREMIUM_COM = CONVERT(DECIMAL(10,2),cte.VOLUNTARY_ADD_PREMIUM_AMOUNT) * CONVERT(DECIMAL(3,2),PERCENTAGE)
		--comt.COM_VOL_ADD_PREMIUM_AMT = CONVERT(DECIMAL(10,2),cte.VOLUNTARY_ADD_PREMIUM_AMOUNT)
	FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr ntake

	INNER JOIN 	@VolCommission cte ON   cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= ntake.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = ntake.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = ntake.BILL_CREATE_DATE
	INNER JOIN @CommissionTable comt ON cte.GROUP_NUMBER	= comt.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= comt.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = comt.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = comt.BILL_CREATE_DATE
	
	INNER JOIN @VOLPRODCAT procat ON cte.GROUP_NUMBER = procat.GROUP_NUMBER
	WHERE procat.CSPD_CAT ='B'

	UPDATE comt
	SET comt.COM_VOL_STD_PREMIUM_COM = CONVERT(DECIMAL(10,2),cte.VOLUNTARY_STD_PREMIUM_AMOUNT) * CONVERT(DECIMAL(3,2),PERCENTAGE)
	--comt.COM_VOL_STD_PREMIUM_AMT = convert(decimal(10,2),cte.VOLUNTARY_STD_PREMIUM_AMOUNT)
	FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr ntake	

	INNER JOIN 	@VolCommission cte ON   cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= ntake.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = ntake.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = ntake.BILL_CREATE_DATE
	
	INNER JOIN @CommissionTable comt ON cte.GROUP_NUMBER	= comt.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= comt.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = comt.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = comt.BILL_CREATE_DATE
									
	INNER JOIN @VOLPRODCAT procat on cte.GROUP_NUMBER = procat.GROUP_NUMBER
	WHERE procat.CSPD_CAT ='K'

	UPDATE comt
	SET comt.COM_VOL_LTD_PREMIUM_COM = CONVERT(DECIMAL(10,2),cte.VOLUNTARY_LTD_PREMIUM_AMOUNT) * CONVERT(DECIMAL(3,2),PERCENTAGE)
		--comt.COM_VOL_LTD_PREMIUM_AMT = convert(decimal(10,2),cte.VOLUNTARY_LTD_PREMIUM_AMOUNT)
	FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr ntake	

	INNER JOIN 	@VolCommission cte ON   cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.GROUP_NUMBER	= ntake.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= ntake.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = ntake.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = ntake.BILL_CREATE_DATE
	INNER JOIN @CommissionTable comt ON cte.GROUP_NUMBER	= comt.GROUP_NUMBER
									AND	cte.BLCT_DISP_CD	= comt.BLCT_DISP_CD
									AND	cte.BILL_FROM_DATE	 = comt.BILL_FROM_DATE
									AND	cte.BILL_CREATE_DATE = comt.BILL_CREATE_DATE
	INNER JOIN @VOLPRODCAT procat ON cte.GROUP_NUMBER = procat.GROUP_NUMBER
	WHERE procat.CSPD_CAT ='J'

	
	;with CTE_Commission
	(
		GROUP_NUMBER	,	
		BLCT_DISP_CD	,	
		BILL_FROM_DATE	,	
		BILL_CREATE_DATE,	
		Commission			
	)
	AS
	(
	SELECT ntake.GROUP_NUMBER,
		ntake.BLCT_DISP_CD,
		ntake.BILL_FROM_DATE,
		ntake.BILL_CREATE_DATE,
		COMMISSION1 = sum ( CONVERT(DECIMAL(10,2),ISNULL(comt.Commission,0)) +
							CONVERT(DECIMAL(10,2),ISNULL(comt.COM_VOL_LIF_PREMIUM_COM,0)) +
							CONVERT(DECIMAL(10,2),ISNULL(comt.COM_VOL_ADD_PREMIUM_COM,0)) +
							CONVERT(DECIMAL(10,2),ISNULL(comt.COM_VOL_STD_PREMIUM_COM,0)) +
							CONVERT(DECIMAL(10,2),ISNULL(comt.COM_VOL_LTD_PREMIUM_COM,0))
							)
						
	FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr ntake
	INNER JOIN @CommissionTable comt ON  ntake.GROUP_NUMBER	= comt.GROUP_NUMBER
									AND	ntake.BLCT_DISP_CD	= comt.BLCT_DISP_CD
									AND	ntake.BILL_FROM_DATE	 = comt.BILL_FROM_DATE
									AND	ntake.BILL_CREATE_DATE = comt.BILL_CREATE_DATE
	GROUP BY ntake.GROUP_NUMBER,
			ntake.BLCT_DISP_CD,
			ntake.BILL_FROM_DATE,
			ntake.BILL_CREATE_DATE
	)

	UPDATE ntake
	SET ntake.COMMISSION = comt.Commission
	FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr ntake
	INNER JOIN CTE_Commission comt ON  ntake.GROUP_NUMBER	= comt.GROUP_NUMBER
									AND	ntake.BLCT_DISP_CD	= comt.BLCT_DISP_CD
									AND	ntake.BILL_FROM_DATE	 = comt.BILL_FROM_DATE
									AND	ntake.BILL_CREATE_DATE = comt.BILL_CREATE_DATE

/********* Update for Net_AMOUNT column **********/
    
    UPDATE extr
    SET extr.NET_AMOUNT = RIGHT(REPLICATE('0',15) + CAST(CAST(ISNULL((CAST(extr.PREMIUM_AMOUNT AS NUMERIC(12,2)) - CAST(extr.COMMISSION AS NUMERIC(12,2))),'000000000000.00')AS NUMERIC(12,2)) AS VARCHAR),15)
    FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr extr
    
/************* Error Checking for Updating Staging table tpzt_usable_premium_ntake_extr *************/  
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  

        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Updating Staging table tpzt_usable_premium_ntake_extr FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END       
          
/**************  PRINT STEP 3 FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed   

/**************  PRINT STEP 4  HEADER DATA *************************/  
  
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
            @ldtStepStartTime = GETDATE(),  
            @lvcMsg = @lvcObjectName + ': Updating staging table tpzt_usable_premium_ntake_extr for LIF_COUNT column'  

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
        @pnStepNumber     = @lnCurrentStep,  
        @pdtStepStartTime = @ldtStepStartTime,  
        @pnTotalSteps     = @lnTotalSteps,  
        @pchStepMsg       = @lvcMsg 
   
/************* STEP 4 Updating Staging table tpzt_usable_premium_ntake_extr  for LIF_COUNT column*************/  
          
  --  ;with CTE
  --      AS
  --      (
  --          SELECT GRGR_ID, L = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(L AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6)
  --          FROM
  --              (
  --              SELECT DISTINCT
  --              GRGR_ID = grgr.GRGR_ID,
  --              CSPDCAT =cspi.CSPD_CAT,
  --              LIF_COUNT              = RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT COUNT(DISTINCT (insb.BLSB_LVS_SB))
  --                                        FROM fabncua1.dbo.CDS_INSB_SB_DETAIL insb
  --                                        WHERE  insb.GRGR_CK = grgr.GRGR_CK AND
  --                                         insb.GRGR_ID = grgr.GRGR_ID
  --                                        AND cspi.CSPD_CAT ='L'
  --                                        AND (CONVERT(VARCHAR(8),cspi.CSPI_TERM_DT,112) = '99999999'
  --                                             OR CONVERT(VARCHAR(8),cspi.CSPI_TERM_DT,112) > CONVERT(VARCHAR(8),GETDATE(),112))
  --                                             ),'0')AS NUMERIC(6,0)) AS VARCHAR),6)
               
  --             FROM  fabncua1.dbo.CMC_GRGR_GROUP grgr 
  --                  INNER JOIN fabncua1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
  --                  INNER JOIN fabncua1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
  --                  INNER JOIN fabncua1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
  --                  LEFT JOIN fabncua1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
		--		LEFT JOIN fabncua1.dbo.CMC_BLCT_COMP_TOTL blct ON blct.BLEI_CK = blei.BLEI_CK		 
  --      														AND blct.CSPI_ID = cspi.CSPI_ID
  --      		LEFT JOIN fabncua1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blct.BLEI_CK
		--														AND bliv.BLBL_DUE_DT = blct.BLBL_DUE_DT
		--WHERE cspi.CSPD_CAT ='L'
		--AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) +0, '19000101') 
		--							AND DATEADD(s,-0,DATEADD(mm, DATEDIFF(m,0,GETDATE())+1,0)))
		--AND  blct.BLCT_DISP_CD IN ('M', 'R')
		
  --              )d
  --          pivot
  --          (
  --          max(LIF_COUNT)
  --          for CSPDCAT in (L)
  --          ) AS piv
  --      GROUP BY GRGR_ID
  --      )
        
  --  UPDATE extr
  --  SET LIF_COUNT = L
  --  FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr extr
  --  INNER JOIN CTE 
  --  ON CTE.GRGR_ID = extr.GROUP_NUMBER

/************* Error Checking for Updating Staging table tpzt_usable_premium_ntake_extr  for LIF_COUNT column*************/  

        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Updating Staging table tpzt_usable_premium_ntake_extr for LIF_COUNT column FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END       
          
/**************  PRINT STEP 4 FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed   

/**************  PRINT STEP 5  HEADER DATA *************************/  
  
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
            @ldtStepStartTime = GETDATE(),  
            @lvcMsg = @lvcObjectName + ': Updating staging table tpzt_usable_premium_ntake_extr for calculating count for various plans '  

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
        @pnStepNumber     = @lnCurrentStep,  
        @pdtStepStartTime = @ldtStepStartTime,  
        @pnTotalSteps     = @lnTotalSteps,  
        @pchStepMsg       = @lvcMsg 
                 
/************* STEP 5 Updating Staging table tpzt_usable_premium_ntake_extr  for calculating count for various plans *************/  
          
    INSERT INTO @ProdCount 
        SELECT GRGR_ID,
				L = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(L AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
				A = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(A AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                E = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(E AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                K = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(K AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                S = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(S AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                T = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(T AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                X = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(X AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                Y = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(Y AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6),
                J = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(SUM(CAST(J AS NUMERIC(6,0))),'000000')AS NUMERIC(6,0))AS VARCHAR),6)
        
        FROM
                (
                SELECT DISTINCT
                GRGR_ID = grgr.GRGR_ID,  
                CSPDCAT =cspi.CSPD_CAT,
                PRDT_COUNT = blct.BLCT_LVS_SB
                --PRDT_COUNT     =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT COUNT(DISTINCT (insb.BLSB_LVS_SB))
                --                          FROM fabncua1.dbo.CDS_INSB_SB_DETAIL insb
                --                          WHERE  insb.GRGR_CK = grgr.GRGR_CK
                --                          AND insb.GRGR_ID = grgr.GRGR_ID
                --                          AND  cspi.CSPD_CAT IN ('A','E','K','S','T','X','Y','J')
                --                          AND (CONVERT(VARCHAR(8),cspi.CSPI_TERM_DT,112) = '99999999'
                --                               OR CONVERT(VARCHAR(8),cspi.CSPI_TERM_DT,112) > CONVERT(VARCHAR(8),GETDATE(),112))
                --                               ),'0')AS NUMERIC(6,0)) AS VARCHAR),6)
         FROM  fabncua1.dbo.CMC_GRGR_GROUP grgr 
                    INNER JOIN fabncua1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
                    INNER JOIN fabncua1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
                    LEFT JOIN fabncua1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
				LEFT JOIN fabncua1.dbo.CMC_BLCT_COMP_TOTL blct ON blct.BLEI_CK = blei.BLEI_CK		 
        														AND blct.CSPI_ID = cspi.CSPI_ID
        		LEFT JOIN fabncua1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blct.BLEI_CK
																AND bliv.BLBL_DUE_DT = blct.BLBL_DUE_DT
		WHERE cspi.CSPD_CAT IN ('L','A','E','K','S','T','X','Y','J')
		AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101') 
									AND DATEADD(s,-0,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,-1)))
		AND  blct.BLCT_DISP_CD IN ('M', 'R')
		 )d
            pivot
            (
                max(PRDT_COUNT)
                for CSPDCAT in (L,A,E,K,S,T,X,Y,J)
            ) AS piv
          GROUP BY GRGR_ID
        
    UPDATE extr
    SET LIF_COUNT = L,ADD_COUNT = A, DEP_COUNT = T, STD_COUNT = X, LTD_COUNT = Y , SLI_COUNT = S, SAD_COUNT = E,
         VOLUNTARY_STD_COUNT = K, VOLUNTARY_LTD_COUNT = J
    FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr extr
    INNER JOIN @ProdCount pdtcount 
    ON pdtcount.GRGR_ID = extr.GROUP_NUMBER
    
/************* Error Checking for Updating Staging table tpzt_usable_premium_ntake_extr for calculating count for various plans *************/  
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  

        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Updating Staging table tpzt_usable_premium_ntake_extr for calculating count for various plans FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END       
          
/**************  PRINT STEP 5 FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed   

/**************  PRINT STEP 6  HEADER DATA *************************/  
  
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
            @ldtStepStartTime = GETDATE(),  
            @lvcMsg = @lvcObjectName + ': Updating staging table tpzt_usable_premium_ntake_extr for calculating count for various voluntary plans '  

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
        @pnStepNumber     = @lnCurrentStep,  
        @pdtStepStartTime = @ldtStepStartTime,  
        @pnTotalSteps     = @lnTotalSteps,  
        @pchStepMsg       = @lvcMsg 
                 
/************* STEP 6 Updating Staging table tpzt_usable_premium_ntake_extr  for calculating count for various voluntary plans *************/  
          
    INSERT INTO @VolProdCount 
        SELECT GRGR_ID,MEME_REL, Z = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(Z,'000000')AS NUMERIC(6,0))AS VARCHAR),6)
                ,B = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(B,'000000')AS NUMERIC(6,0))AS VARCHAR),6)
        FROM
                (
							SELECT DISTINCT
							GRGR_ID = grgr.GRGR_ID,  
							CSPDCAT =cspi.CSPD_CAT,
							MEME_REL = meme.MEME_REL,
							VOL_PRDT_COUNT = blct.BLCT_LVS_SB
			                
							--VOL_PRDT_COUNT     =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT COUNT(DISTINCT (blct.BLCT_LVS_SB))
							--                          FROM fabncua1.dbo.CDS_INSB_SB_DETAIL insb
							--                          WHERE  insb.GRGR_CK = grgr.GRGR_CK
							--                          AND insb.GRGR_ID = grgr.GRGR_ID
							--                          AND cspi.CSPD_CAT IN('Z','B')
							--                          AND (CONVERT(VARCHAR(8),cspi.CSPI_TERM_DT,112) = '99999999'
							--                               OR CONVERT(VARCHAR(8),cspi.CSPI_TERM_DT,112) > CONVERT(VARCHAR(8),GETDATE(),112))
							--                               ),'0')AS NUMERIC(6,0)) AS VARCHAR),6)
					  FROM  fabncua1.dbo.CMC_GRGR_GROUP grgr 
									INNER JOIN fabncua1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
									INNER JOIN fabncua1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
									INNER JOIN fabncua1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
									LEFT JOIN fabncua1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
								LEFT JOIN fabncua1.dbo.CMC_BLCT_COMP_TOTL blct ON blct.BLEI_CK = blei.BLEI_CK		 
        																		AND blct.CSPI_ID = cspi.CSPI_ID
        						LEFT JOIN fabncua1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blct.BLEI_CK
																				AND bliv.BLBL_DUE_DT = blct.BLBL_DUE_DT
						 WHERE cspi.CSPD_CAT IN ('Z','B') 
						AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101') 
									AND DATEADD(s,-0,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,-1)))
						AND  blct.BLCT_DISP_CD IN ('M', 'R')
						AND meme.MEME_REL = 'M'
		
            )d
            pivot
            (
            max(VOL_PRDT_COUNT)
            for CSPDCAT in (Z,B)
            ) AS piv
              
    UPDATE extr
    SET VOLUNTARY_LIF_COUNT = Z,VOLUNTARY_ADD_COUNT = B
    FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr extr
    INNER JOIN @VolProdCount volpdtcount  ON volpdtcount.GRGR_ID = extr.GROUP_NUMBER
    AND volpdtcount.MEME_REL = 'M'
    
    
    
    delete from @VolProdCount
    
    INSERT INTO @VolProdCount 
        SELECT GRGR_ID,MEME_REL, Z = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(Z,'000000')AS NUMERIC(6,0))AS VARCHAR),6)
                ,B = RIGHT(REPLICATE('0',6) + CAST(CAST(ISNULL(B,'000000')AS NUMERIC(6,0))AS VARCHAR),6)
        FROM
                (
                SELECT DISTINCT
                GRGR_ID = grgr.GRGR_ID,  
                CSPDCAT =cspi.CSPD_CAT,
                MEME_REL = meme.MEME_REL,
                VOL_PRDT_COUNT = blct.BLCT_LVS_DEP
                --VOL_PRDT_COUNT     =  RIGHT(REPLICATE('0', 6) + CAST(CAST(ISNULL((SELECT COUNT(DISTINCT (blct.BLCT_LVS_DEP))
                --                          FROM fabncua1.dbo.CDS_INSB_SB_DETAIL insb
                --                          WHERE  insb.GRGR_CK = grgr.GRGR_CK
                --                          AND insb.GRGR_ID = grgr.GRGR_ID
                --                          AND cspi.CSPD_CAT IN('Z','B')
                --                          AND (CONVERT(VARCHAR(8),cspi.CSPI_TERM_DT,112) = '99999999'
                --                               OR CONVERT(VARCHAR(8),cspi.CSPI_TERM_DT,112) > CONVERT(VARCHAR(8),GETDATE(),112))
                --                               ),'0')AS NUMERIC(6,0)) AS VARCHAR),6)
      FROM  fabncua1.dbo.CMC_GRGR_GROUP grgr 
                    INNER JOIN fabncua1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
                    INNER JOIN fabncua1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
                    INNER JOIN fabncua1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
                    LEFT JOIN fabncua1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
				LEFT JOIN fabncua1.dbo.CMC_BLCT_COMP_TOTL blct ON blct.BLEI_CK = blei.BLEI_CK		 
        														AND blct.CSPI_ID = cspi.CSPI_ID
        		LEFT JOIN fabncua1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blct.BLEI_CK
																AND bliv.BLBL_DUE_DT = blct.BLBL_DUE_DT
		 WHERE cspi.CSPD_CAT IN ('Z','B') 
		AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101') 
									AND DATEADD(s,-0,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,-1)))
		AND  blct.BLCT_DISP_CD IN ('M', 'R')
		AND meme.MEME_REL in ('H','W','S','D')
		
            )d
            pivot
            (
            max(VOL_PRDT_COUNT)
            for CSPDCAT in (Z,B)
            ) AS piv

    UPDATE extr
    SET VOLUNTARY_LIFSP_COUNT = Z,VOLUNTARY_ADDSP_COUNT = B
    FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr extr
    INNER JOIN @VolProdCount volpdtcount ON volpdtcount.GRGR_ID = extr.GROUP_NUMBER
    AND volpdtcount.MEME_REL IN ('H','W')

    UPDATE extr
    SET VOLUNTARY_LIFCH_COUNT = Z,VOLUNTARY_ADDCH_COUNT = B
    FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr extr
    INNER JOIN @VolProdCount volpdtcount ON volpdtcount.GRGR_ID = extr.GROUP_NUMBER
    AND volpdtcount.MEME_REL IN ('S','D')
    
/************* Error Checking for Updating Staging table tpzt_usable_premium_ntake_extr  for calculating count for various voluntary plans *************/  
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  

        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Updating Staging table tpzt_usable_premium_ntake_extr for calculating count for various voluntary plans FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
		END       
          
/**************  PRINT STEP 6 FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed   

/**************  PRINT STEP 7 HEADER DATA *************************/  
  
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
            @ldtStepStartTime = GETDATE(),  
            @lvcMsg = @lvcObjectName + ': Inserting values in stage table tpzt_usable_premium_ntake_extr for various Benefit Amounts and Benfit Rate per unit life columns '  

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
        @pnStepNumber     = @lnCurrentStep,  
        @pdtStepStartTime = @ldtStepStartTime,  
        @pnTotalSteps     = @lnTotalSteps,  
        @pchStepMsg       = @lvcMsg 
                 
/************* STEP 7 Inserting values in stage table tpzt_usable_premium_ntake_extr for various Benefit Amounts and Benfit Rate per unit life columns *************/  
          
    DECLARE @BenefitData TABLE(
        GRGR_ID                        VARCHAR(8),
        BENEFIT_AMOUNT_FOR_LIFE        VARCHAR(16),
        BENEFIT_AMOUNT_FOR_ADD         VARCHAR(16),
        BENEFIT_AMOUNT_FOR_DEP         VARCHAR(16),
        BENEFIT_AMOUNT_FOR_STD         VARCHAR(16),
        BENEFIT_AMOUNT_FOR_LTD         VARCHAR(16),
        BENEFIT_AMOUNT_FOR_SLI         VARCHAR(16),
        BENEFIT_AMOUNT_FOR_SAD         VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VLIF        VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VLIFSP      VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VLIFCH      VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VADD        VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VADDSP      VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VADDCH      VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VLTD        VARCHAR(16),
        BENEFIT_AMOUNT_FOR_VSTD        VARCHAR(16),
        BENEFIT_RATE_PER_UNIT_LIFE     VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_ADD      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_DEP      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_STD      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_LTD      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_SLI      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_SAD      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VLIF     VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VLIFSP   VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VLIFCH   VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VADD     VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VADDSP   VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VADDCH   VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VLTD     VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VSTD     VARCHAR(11))
                
    INSERT INTO @BenefitData
    SELECT DISTINCT
        GRGR_ID = grgr.GRGR_ID,
        BENEFIT_AMOUNT_FOR_LIFE        = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT gtl.BENEFIT_AMOUNT 
                                          FROM fabncua1custom.dbo.tpzt_usable_gtl_add gtl
                                          WHERE gtl.GRGR_ID = grgr.GRGR_ID
                                          AND gtl.CSCS_ID = cspi.CSCS_ID
                                          AND gtl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'L'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                          
        BENEFIT_AMOUNT_FOR_ADD         = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT gtl.BENEFIT_AMOUNT 
                                            FROM fabncua1custom.dbo.tpzt_usable_gtl_add gtl
                                            WHERE gtl.GRGR_ID = grgr.GRGR_ID
                                            AND gtl.CSCS_ID = cspi.CSCS_ID
                                             AND gtl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'A'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_DEP         = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT usabledl.[PLAN]
                                            FROM fabncua1custom.dbo.tpzt_usable_dl usabledl
                                            WHERE usabledl.GRGR_ID = grgr.GRGR_ID 
                                            AND usabledl.CSCS_ID = cspi.CSCS_ID
                                             AND usabledl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'T'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_STD         = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT usablewdb.BENEFIT_AMOUNT
                                            FROM fabncua1custom.dbo.tpzt_usable_wdb usablewdb
                                              WHERE usablewdb.GRGR_ID = grgr.GRGR_ID 
                                            AND usablewdb.CSCS_ID = cspi.CSCS_ID
                                             AND usablewdb.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'X'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_LTD         = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT usableltd.MONTHLY_MAXIMUM
                                            FROM fabncua1custom.dbo.tpzt_usable_ltd usableltd
                                            WHERE usableltd.GRGR_ID = grgr.GRGR_ID 
                                            AND usableltd.CSCS_ID = cspi.CSCS_ID
                                             AND usableltd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'Y'),'0000000.0000')AS NUMERIC(16,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_SLI         = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT usablesl.BENEFIT_AMOUNT
                                            FROM fabncua1custom.dbo.tpzt_usable_sli usablesl
                                            WHERE usablesl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablesl.CSCS_ID = cspi.CSCS_ID
                                             AND usablesl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'S'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_SAD         = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT usablesa.BENEFIT_AMOUNT
                                              FROM fabncua1custom.dbo.tpzt_usable_sad usablesa
                                            WHERE usablesa.GRGR_ID = grgr.GRGR_ID 
                                            AND usablesa.CSCS_ID = cspi.CSCS_ID
                                             AND usablesa.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'E'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_VLIF        = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT usablevl.BENEFIT_AMOUNT
                                            FROM fabncua1custom.dbo.tpzt_usable_vl usablevl
                                              WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'Z'
                                            AND meme.MEME_REL = 'M'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_VLIFSP      = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT usablevl.SPOUSE_AMOUNT
                                            FROM fabncua1custom.dbo.tpzt_usable_vl usablevl
                                            WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'Z'
                                            AND meme.MEME_REL IN('H','W')),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_VLIFCH      = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT usablevl.DEPENDANT_CHILD_COVERAGE
                                            FROM fabncua1custom.dbo.tpzt_usable_vl usablevl
                                            WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'Z'
                                            AND meme.MEME_REL IN('S','D')),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_VADD        = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT usablevadd.BENEFIT_AMOUNT
                                            FROM fabncua1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'B'
                                            AND meme.MEME_REL = 'M'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_VADDSP      = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT usablevadd.SPOUSE_AMOUNT
                                            FROM fabncua1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'B'
                                            AND meme.MEME_REL IN('H','W')),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
                                            
        BENEFIT_AMOUNT_FOR_VADDCH      = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT usablevadd.DEP_CHILD_COVERAGE
                                            FROM fabncua1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'B'
                                            AND meme.MEME_REL IN('S','D')),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
        
        BENEFIT_AMOUNT_FOR_VLTD        = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT usablevltd.MAXIMUM_AMOUNT
                                              FROM fabncua1custom.dbo.tpzt_usable_vltd usablevltd
                                            WHERE usablevltd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevltd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevltd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'J'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),

        BENEFIT_AMOUNT_FOR_VSTD        = RIGHT(REPLICATE('0',16) + CAST(CAST(ISNULL((SELECT usablevstd.MAX_WEEKLY_BENEFIT
                                              FROM fabncua1custom.dbo.tpzt_usable_vstd usablevstd
                                            WHERE usablevstd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevstd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevstd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'K'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),16),
											
        BENEFIT_RATE_PER_UNIT_LIFE     = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT usablegtl.BENEFIT_RATE_PER_UNIT
                                              FROM fabncua1custom.dbo.tpzt_usable_gtl_add usablegtl
                                            WHERE usablegtl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablegtl.CSCS_ID = cspi.CSCS_ID
                                             AND usablegtl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'L'),'00000.00000')AS NUMERIC(5,5)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_ADD      = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT usablegtl.BENEFIT_RATE_PER_UNIT
                                              FROM fabncua1custom.dbo.tpzt_usable_gtl_add usablegtl
                                            WHERE usablegtl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablegtl.CSCS_ID = cspi.CSCS_ID
                                             AND usablegtl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'A'),'00000.00000')AS NUMERIC(5,5)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_DEP      = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT usabledl.BENEFIT_RATE_PER_UNIT
                                              FROM fabncua1custom.dbo.tpzt_usable_dl usabledl
                                            WHERE usabledl.GRGR_ID = grgr.GRGR_ID 
                                            AND usabledl.CSCS_ID = cspi.CSCS_ID
                                             AND usabledl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'T'),'00000.00000')AS NUMERIC(5,5)) AS VARCHAR),11),
											
        
        BENEFIT_RATE_PER_UNIT_STD      = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT usablewdb.BENEFIT_RATE_PER_UNIT
                                              FROM fabncua1custom.dbo.tpzt_usable_wdb usablewdb
                                            WHERE usablewdb.GRGR_ID = grgr.GRGR_ID 
                                            AND usablewdb.CSCS_ID = cspi.CSCS_ID
                                             AND usablewdb.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'X'),'00000.00000')AS NUMERIC(5,5)) AS VARCHAR),11),
		
        BENEFIT_RATE_PER_UNIT_LTD      = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT usableltd.BENEFIT_RATE_PER_UNIT
                                              FROM fabncua1custom.dbo.tpzt_usable_ltd usableltd
                                            WHERE usableltd.GRGR_ID = grgr.GRGR_ID 
                                            AND usableltd.CSCS_ID = cspi.CSCS_ID
                                             AND usableltd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'Y'),'00000.00000')AS NUMERIC(5,5)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_SLI      = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT usablesli.BENEFIT_RATE_PER_UNIT
                                              FROM fabncua1custom.dbo.tpzt_usable_sli usablesli
                                            WHERE usablesli.GRGR_ID = grgr.GRGR_ID 
                                            AND usablesli.CSCS_ID = cspi.CSCS_ID
                                             AND usablesli.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'S'),'00000.00000')AS NUMERIC(5,5)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_SAD      = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT usablesad.BENEFIT_RATE_PER_UNIT
                                              FROM fabncua1custom.dbo.tpzt_usable_sad usablesad
                                            WHERE usablesad.GRGR_ID = grgr.GRGR_ID 
                                            AND usablesad.CSCS_ID = cspi.CSCS_ID
                                             AND usablesad.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'E'),'00000.00000')AS NUMERIC(5,5)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_VLIF     = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT usablevl.BENEFIT_RATE_PER_UNIT
                                              FROM fabncua1custom.dbo.tpzt_usable_vl usablevl
                                            WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'Z'
											AND meme.MEME_REL = 'M'),'00000.00000')AS NUMERIC(5,5)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_VLIFSP   = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT usablevl.BENEFIT_RATE_PER_UNIT
                                              FROM fabncua1custom.dbo.tpzt_usable_vl usablevl
                                            WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'Z'
											AND meme.MEME_REL IN('H','W')),'00000.00000')AS NUMERIC(5,5)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_VLIFCH   = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT usablevl.BENEFIT_RATE_PER_UNIT
                                              FROM fabncua1custom.dbo.tpzt_usable_vl usablevl
                                            WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'Z'
											AND meme.MEME_REL IN('D','S')),'00000.00000')AS NUMERIC(5,5)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_VADD     = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT usablevadd.BENEFIT_RATE_PER_UNIT
                                              FROM fabncua1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'B'
											AND meme.MEME_REL = 'M'),'00000.00000')AS NUMERIC(5,5)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_VADDSP   = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT usablevadd.BENEFIT_RATE_PER_UNIT
                                              FROM fabncua1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'B'
											AND meme.MEME_REL IN('H','W')),'00000.00000')AS NUMERIC(5,5)) AS VARCHAR),11),
		
											
        BENEFIT_RATE_PER_UNIT_VADDCH   = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT usablevadd.BENEFIT_RATE_PER_UNIT
                                              FROM fabncua1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'B'
											AND meme.MEME_REL IN('D','S')),'00000.00000')AS NUMERIC(5,5)) AS VARCHAR),11),
											
        BENEFIT_RATE_PER_UNIT_VLTD     = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT usablevltd.BENEFIT_RATE_PER_UNIT
                                              FROM fabncua1custom.dbo.tpzt_usable_vltd usablevltd
                                            WHERE usablevltd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevltd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevltd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'J'),'00000.00000')AS NUMERIC(5,5)) AS VARCHAR),11),
		
        BENEFIT_RATE_PER_UNIT_VSTD     = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT usablevstd.BENEFIT_RATE_PER_UNIT
                                              FROM fabncua1custom.dbo.tpzt_usable_vstd usablevstd
                                            WHERE usablevstd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevstd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevstd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'K'),'00000.00000')AS NUMERIC(5,5)) AS VARCHAR),11)
											
    FROM 
        fabncua1.dbo.CMC_GRGR_GROUP grgr 
            INNER JOIN fabncua1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK 
            INNER JOIN fabncua1.dbo.CMC_MEME_MEMBER meme ON meme.GRGR_CK = grgr.GRGR_CK
            INNER JOIN fabncua1.dbo.CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
            LEFT JOIN fabncua1.dbo.CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = sgsg.SGSG_CK
				LEFT JOIN fabncua1.dbo.CMC_BLCT_COMP_TOTL blct ON blct.BLEI_CK = blei.BLEI_CK		 
        														AND blct.CSPI_ID = cspi.CSPI_ID
        		LEFT JOIN fabncua1.dbo.CMC_BLIV_INVOICE bliv ON bliv.BLEI_CK = blct.BLEI_CK
																AND bliv.BLBL_DUE_DT = blct.BLBL_DUE_DT
		WHERE cspi.CSPD_CAT IN ('X','Y','L','A','S','T','E','K','J')
		AND (bliv.BLIV_CREATE_DTM BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, '19000101', GETDATE()) -1, '19000101') 
									AND DATEADD(s,-0,DATEADD(mm, DATEDIFF(m,0,GETDATE())+0,-1)))
		AND  blct.BLCT_DISP_CD IN ('M', 'R')
		
	UPDATE extr
	SET extr.BENEFIT_AMOUNT_FOR_LIFE       = bnft.BENEFIT_AMOUNT_FOR_LIFE      ,
		extr.BENEFIT_AMOUNT_FOR_ADD        = bnft.BENEFIT_AMOUNT_FOR_ADD       ,
		extr.BENEFIT_AMOUNT_FOR_DEP        = bnft.BENEFIT_AMOUNT_FOR_DEP       ,
		extr.BENEFIT_AMOUNT_FOR_STD        = bnft.BENEFIT_AMOUNT_FOR_STD       ,
		extr.BENEFIT_AMOUNT_FOR_LTD        = bnft.BENEFIT_AMOUNT_FOR_LTD       ,
		extr.BENEFIT_AMOUNT_FOR_SLI        = bnft.BENEFIT_AMOUNT_FOR_SLI       ,
		extr.BENEFIT_AMOUNT_FOR_SAD        = bnft.BENEFIT_AMOUNT_FOR_SAD       ,
		extr.BENEFIT_AMOUNT_FOR_VLIF       = bnft.BENEFIT_AMOUNT_FOR_VLIF      ,
		extr.BENEFIT_AMOUNT_FOR_VLIFSP     = bnft.BENEFIT_AMOUNT_FOR_VLIFSP    ,
		extr.BENEFIT_AMOUNT_FOR_VLIFCH     = bnft.BENEFIT_AMOUNT_FOR_VLIFCH    ,
		extr.BENEFIT_AMOUNT_FOR_VADD       = bnft.BENEFIT_AMOUNT_FOR_VADD      ,
		extr.BENEFIT_AMOUNT_FOR_VADDSP     = bnft.BENEFIT_AMOUNT_FOR_VADDSP    ,
		extr.BENEFIT_AMOUNT_FOR_VADDCH     = bnft.BENEFIT_AMOUNT_FOR_VADDCH    ,
		extr.BENEFIT_AMOUNT_FOR_VLTD       = bnft.BENEFIT_AMOUNT_FOR_VLTD      ,
		extr.BENEFIT_AMOUNT_FOR_VSTD       = bnft.BENEFIT_AMOUNT_FOR_VSTD      ,
		extr.BENEFIT_RATE_PER_UNIT_LIFE    = bnft.BENEFIT_RATE_PER_UNIT_LIFE   ,
		extr.BENEFIT_RATE_PER_UNIT_ADD     = bnft.BENEFIT_RATE_PER_UNIT_ADD    ,
		extr.BENEFIT_RATE_PER_UNIT_DEP     = bnft.BENEFIT_RATE_PER_UNIT_DEP    ,
		extr.BENEFIT_RATE_PER_UNIT_STD     = bnft.BENEFIT_RATE_PER_UNIT_STD    ,
		extr.BENEFIT_RATE_PER_UNIT_LTD     = bnft.BENEFIT_RATE_PER_UNIT_LTD    ,
		extr.BENEFIT_RATE_PER_UNIT_SLI     = bnft.BENEFIT_RATE_PER_UNIT_SLI    ,
		extr.BENEFIT_RATE_PER_UNIT_SAD     = bnft.BENEFIT_RATE_PER_UNIT_SAD    ,
		extr.BENEFIT_RATE_PER_UNIT_VLIF    = bnft.BENEFIT_RATE_PER_UNIT_VLIF   ,
		extr.BENEFIT_RATE_PER_UNIT_VLIFSP  = bnft.BENEFIT_RATE_PER_UNIT_VLIFSP ,
		extr.BENEFIT_RATE_PER_UNIT_VLIFCH  = bnft.BENEFIT_RATE_PER_UNIT_VLIFCH ,
		extr.BENEFIT_RATE_PER_UNIT_VADD    = bnft.BENEFIT_RATE_PER_UNIT_VADD   ,
		extr.BENEFIT_RATE_PER_UNIT_VADDSP  = bnft.BENEFIT_RATE_PER_UNIT_VADDSP ,
		extr.BENEFIT_RATE_PER_UNIT_VADDCH  = bnft.BENEFIT_RATE_PER_UNIT_VADDCH ,
		extr.BENEFIT_RATE_PER_UNIT_VLTD    = bnft.BENEFIT_RATE_PER_UNIT_VLTD   ,
		extr.BENEFIT_RATE_PER_UNIT_VSTD    = bnft.BENEFIT_RATE_PER_UNIT_VSTD   
		
	FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr extr
	INNER JOIN @BenefitData bnft 
    ON bnft.GRGR_ID = extr.GROUP_NUMBER
    
/************* Error Checking for Inserting values in stage table tpzt_usable_premium_ntake_extr for various Benefit Amounts and Benfit Rate per unit life columns *************/  
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  

        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Inserting values in stage table tpzt_usable_premium_ntake_extr for various Benefit Amounts and Benfit Rate per unit life columns FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END       
          
/**************  PRINT STEP 7 FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed 
            
/**************  PRINT STEP 8 HEADER DATA *************************/  
  
    SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
            @ldtStepStartTime = GETDATE(),  
            @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_usable_premium_ntake_error '  

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
        @pnStepNumber     = @lnCurrentStep,  
        @pdtStepStartTime = @ldtStepStartTime,  
        @pnTotalSteps     = @lnTotalSteps,  
        @pchStepMsg       = @lvcMsg 
        
/************* STEP 8 Truncate Staging table tpzt_usable_premium_ntake_error *************/  
          
   TRUNCATE TABLE fabncua1stage.dbo.tpzt_usable_premium_ntake_error  
          
/************* Error Checking for Truncate Staging table tpzt_usable_premium_ntake_error *************/  
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  

        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Truncate Staging table tpzt_usable_premium_ntake_error FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END       
          
/**************  PRINT STEP 8 FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed   

/**************  PRINT STEP 9  HEADER DATA *************************/  
  
        SELECT  @lnCurrentStep    = @lnCurrentStep + 1,  
                @ldtStepStartTime = GETDATE(),  
                @lvcMsg = @lvcObjectName + ': Insert error records in staging table tpzt_usable_premium_ntake_error'  

        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
                @pnStepNumber     = @lnCurrentStep,  
                @pdtStepStartTime = @ldtStepStartTime,  
                @pnTotalSteps     = @lnTotalSteps,  
                @pchStepMsg       = @lvcMsg 

                 
/************* STEP 9 Insert error records in staging table tpzt_usable_premium_ntake_error *************/  
          
    DELETE FROM fabncua1stage.dbo.tpzt_usable_premium_ntake_extr
    OUTPUT DELETED.GROUP_NUMBER,
           DELETED.GROUP_NAME,
           DELETED.BILL_FROM_DATE
    INTO fabncua1stage.dbo.tpzt_usable_premium_ntake_error
    WHERE LTRIM(RTRIM(ISNULL(GROUP_NUMBER,''))) = ''
        OR LTRIM(RTRIM(ISNULL(GROUP_NAME,''))) = ''
        OR LTRIM(RTRIM(ISNULL(BILL_FROM_DATE,''))) = ''

/************* Error Checking for Inserting in Staging table tpzt_usable_premium_ntake_error  *************/  
          
        SELECT @lnRetCd    = @@ERROR,  
        @lnRowsProcessed = @@ROWCOUNT  

        IF @lnRetCd <> 0  
            BEGIN  
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
                + ' : Inserting error records in staging table tpzt_usable_premium_ntake_error FAILED'  
                + ' RETURNCODE: '  
                + CONVERT(CHAR(6),@lnRetCd)  
                PRINT  @lvcMsg  
                RETURN @lnRetCd  
            END       
          
/**************  PRINT STEP 9 FOOTER DATA *************************/

        SELECT @ldtStepEndTime      = GETDATE()
        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime       = @ldtStepStartTime,
            @pdtStepEndTime         = @ldtStepEndTime,
            @pdtProcessStartTime    = @ldtProcessStartTime,
            @pnRowCount             = @lnRowsProcessed   

/**************  PRINT JOB FOOTER DATA ****************************/

    SELECT @ldtProcessEndTime = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr
      @pchObjectName          = @lvcObjectName,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pdtProcessEndTime      = @ldtProcessEndTime
    RETURN  @lnRetCd
END
GO
/****************************************************************
 BEGIN MAINTENANCE WRAPPER:
*****************************************************************/
IF OBJECT_ID('dbo.tpzp_usable_premium_ntake_extr') IS NOT NULL
  PRINT '<<< CREATED PROCEDURE dbo.tpzp_usable_premium_ntake_extr >>>'
       
ELSE
  PRINT '<<<ERROR CREATING PROCEDURE dbo.tpzp_usable_premium_ntake_extr >>>'
GO

/****************************************************************
 END MAINTENANCE WRAPPER:
*****************************************************************/