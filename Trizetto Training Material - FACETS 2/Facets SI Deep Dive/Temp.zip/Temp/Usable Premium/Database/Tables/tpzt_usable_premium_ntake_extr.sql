/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_premium_ntake_extr') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_premium_ntake_extr
  IF OBJECT_ID('dbo.tpzt_usable_premium_ntake_extr') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_premium_ntake_extr >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_premium_ntake_extr >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_premium_ntake_extr
/****************************************************************
**   NAME                  : dbo.tpzt_usable_premium_ntake_extr
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : 
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0      08/25/2014   Shekhar Kadam       Intial Version
** 1.1      09/29/2014   Ghazala Ameen       Updated for length of columns and added DEP_PREMIUM_AMOUNT column
** 1.2      10/09/2014   Ghazala Ameen       Updated the length to add '+' for Premium amount
** 1.3      10/09/2014   Ghazala Ameen       Updated the length to add '+' for Premium amount
** 1.4      10/21/2014   Ghazala Ameen       Added missing field DEP_PREMIUM_AMOUNT
****************************************************************/
(   
    GROUP_NUMBER                         VARCHAR(8)        NULL,
    GROUP_NAME                           VARCHAR(120)      NULL,
	BLCT_DISP_CD					     VARCHAR(1)        NULL,
    LIFE_PREMIUM_AMOUNT                  VARCHAR(14)       NULL,
    ADD_PREMIUM_AMOUNT                   VARCHAR(14)       NULL,
	DEP_PREMIUM_AMOUNT                   VARCHAR(14)       NULL,
    WDB_PREMIUM_AMOUNT                   VARCHAR(14)       NULL,
    LTD_PREMIUM_AMOUNT                   VARCHAR(14)       NULL,
    SLI_PREMIUM_AMOUNT                   VARCHAR(14)       NULL,
    SAD_PREMIUM_AMOUNT                   VARCHAR(14)       NULL,
    VOLUNTARY_LIF_PREMIUM_AMOUNT         VARCHAR(14)       NULL,
    VOLUNTARY_LIFSP_PREMIUM_AMOUNT       VARCHAR(14)       NULL,
    VOLUNTARY_LIFCH_PREMIUM_AMOUNT       VARCHAR(14)       NULL,
    VOLUNTARY_ADD_PREMIUM_AMOUNT         VARCHAR(14)       NULL,
    VOLUNTARY_ADDSP_PREMIUM_AMOUNT       VARCHAR(14)       NULL,
    VOLUNTARY_ADDCH_PREMIUM_AMOUNT       VARCHAR(14)       NULL,
    VOLUNTARY_STD_PREMIUM_AMOUNT         VARCHAR(14)       NULL,
    VOLUNTARY_LTD_PREMIUM_AMOUNT         VARCHAR(14)       NULL,
    PREMIUM_AMOUNT                       VARCHAR(16)       NULL,
    COMMISSION                           VARCHAR(16)       NULL,
    NET_AMOUNT                           VARCHAR(16)       NULL,
    LIF_COUNT                            VARCHAR(6)        NULL,
    ADD_COUNT                            VARCHAR(6)        NULL,
    DEP_COUNT                            VARCHAR(6)        NULL,
    STD_COUNT                            VARCHAR(6)        NULL,
    LTD_COUNT                            VARCHAR(6)        NULL,
    SLI_COUNT                            VARCHAR(6)        NULL,
    SAD_COUNT                            VARCHAR(6)        NULL,
    VOLUNTARY_LIF_COUNT                  VARCHAR(6)        NULL,
    VOLUNTARY_LIFSP_COUNT                VARCHAR(6)        NULL,
    VOLUNTARY_LIFCH_COUNT                VARCHAR(6)        NULL,
    VOLUNTARY_ADD_COUNT                  VARCHAR(6)        NULL,
    VOLUNTARY_ADDSP_COUNT                VARCHAR(6)        NULL,
    VOLUNTARY_ADDCH_COUNT                VARCHAR(6)        NULL,
    VOLUNTARY_LTD_COUNT                  VARCHAR(6)        NULL,
    VOLUNTARY_STD_COUNT                  VARCHAR(6)        NULL,
    BENEFIT_AMOUNT_FOR_LIFE              VARCHAR(16)       NULL,
    BENEFIT_AMOUNT_FOR_ADD               VARCHAR(16)       NULL,
    BENEFIT_AMOUNT_FOR_DEP               VARCHAR(16)       NULL,
    BENEFIT_AMOUNT_FOR_STD               VARCHAR(16)       NULL,
    BENEFIT_AMOUNT_FOR_LTD               VARCHAR(16)       NULL,
    BENEFIT_AMOUNT_FOR_SLI               VARCHAR(16)       NULL,
    BENEFIT_AMOUNT_FOR_SAD               VARCHAR(16)       NULL,
    BENEFIT_AMOUNT_FOR_VLIF              VARCHAR(16)       NULL,
    BENEFIT_AMOUNT_FOR_VLIFSP            VARCHAR(16)       NULL,
    BENEFIT_AMOUNT_FOR_VLIFCH            VARCHAR(16)       NULL,
    BENEFIT_AMOUNT_FOR_VADD              VARCHAR(16)       NULL,
    BENEFIT_AMOUNT_FOR_VADDSP            VARCHAR(16)       NULL,
    BENEFIT_AMOUNT_FOR_VADDCH            VARCHAR(16)       NULL,
    BENEFIT_AMOUNT_FOR_VLTD              VARCHAR(16)       NULL,
    BENEFIT_AMOUNT_FOR_VSTD              VARCHAR(16)       NULL,
    BENEFIT_RATE_PER_UNIT_LIFE           VARCHAR(11)       NULL,
    BENEFIT_RATE_PER_UNIT_ADD            VARCHAR(11)       NULL,
    BENEFIT_RATE_PER_UNIT_DEP            VARCHAR(11)       NULL,
    BENEFIT_RATE_PER_UNIT_STD            VARCHAR(11)       NULL,
    BENEFIT_RATE_PER_UNIT_LTD            VARCHAR(11)       NULL,
    BENEFIT_RATE_PER_UNIT_SLI            VARCHAR(11)       NULL,
    BENEFIT_RATE_PER_UNIT_SAD            VARCHAR(11)       NULL,
    BENEFIT_RATE_PER_UNIT_VLIF           VARCHAR(11)       NULL,
    BENEFIT_RATE_PER_UNIT_VLIFSP         VARCHAR(11)       NULL,
    BENEFIT_RATE_PER_UNIT_VLIFCH         VARCHAR(11)       NULL,
    BENEFIT_RATE_PER_UNIT_VADD           VARCHAR(11)       NULL,
    BENEFIT_RATE_PER_UNIT_VADDSP         VARCHAR(11)       NULL,
    BENEFIT_RATE_PER_UNIT_VADDCH         VARCHAR(11)       NULL,
    BENEFIT_RATE_PER_UNIT_VLTD           VARCHAR(11)       NULL,
    BENEFIT_RATE_PER_UNIT_VSTD           VARCHAR(11)       NULL,
    LIFE_TYPE                            VARCHAR(30)       DEFAULT SPACE(30),
    ADD_TYPE                             VARCHAR(30)       DEFAULT SPACE(30),
    DEP_TYPE                             VARCHAR(30)       DEFAULT SPACE(30),
    STD_TYPE                             VARCHAR(30)       DEFAULT SPACE(30),
    LTD_TYPE                             VARCHAR(30)       DEFAULT SPACE(30),
    SLI_TYPE                             VARCHAR(30)       DEFAULT SPACE(30),
    SAD_TYPE                             VARCHAR(30)       DEFAULT SPACE(30),
    VLIF_TYPE                            VARCHAR(30)       DEFAULT SPACE(30),
    VLIFSP_TYPE                          VARCHAR(30)       DEFAULT SPACE(30),
    VLIFCH_TYPE                          VARCHAR(30)       DEFAULT SPACE(30),
    VADD_TYPE                            VARCHAR(30)       DEFAULT SPACE(30),
    VADDSP_TYPE                          VARCHAR(30)       DEFAULT SPACE(30),
    VADDCH_TYPE                          VARCHAR(30)       DEFAULT SPACE(30),
    VLTD_TYPE                            VARCHAR(30)       DEFAULT SPACE(30),
    VSTD_TYPE                            VARCHAR(30)       DEFAULT SPACE(30),
    BILL_FROM_DATE                       VARCHAR(10)       NULL,
	BILL_CREATE_DATE					 VARCHAR(10)       NULL
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_premium_ntake_extr') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_premium_ntake_extr >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_premium_ntake_extr >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
