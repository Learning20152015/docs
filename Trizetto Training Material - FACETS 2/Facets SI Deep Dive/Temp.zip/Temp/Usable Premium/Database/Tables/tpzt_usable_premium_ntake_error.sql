/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_premium_ntake_error') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_premium_ntake_error
  IF OBJECT_ID('dbo.tpzt_usable_premium_ntake_error') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_premium_ntake_error >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_premium_ntake_error >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_premium_ntake_error
/****************************************************************
**   NAME                  : dbo.tpzt_usable_premium_ntake_error
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table holds the records with invalid or missing data.
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0      08/25/2014   Ghazala Ameen       Intial Version
****************************************************************/
(   
    GROUP_NUMBER                         VARCHAR(8)        NULL,
    GROUP_NAME                           VARCHAR(120)      NULL,
    BILL_FROM_DATE                       VARCHAR(10)       NULL
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_premium_ntake_error') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_premium_ntake_error >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_premium_ntake_error >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
