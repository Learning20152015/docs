/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzt_usable_commission_cw') IS NOT NULL
BEGIN
  DROP TABLE dbo.tpzt_usable_commission_cw
  IF OBJECT_ID('dbo.tpzt_usable_commission_cw') IS NOT NULL
    PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_usable_commission_cw >>>'
  ELSE
    PRINT '<<< DROPPED TABLE dbo.tpzt_usable_commission_cw >>>'
END
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE TABLE dbo.tpzt_usable_commission_cw
/****************************************************************
**   NAME                  : dbo.tpzt_usable_commission_cw
**
**   DATABASE LOCATION     : Stage
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : 
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0      08/27/2014   Ghazala Ameen       Intial Version
****************************************************************/
(   
    MIN_MARKET_SEGMENT        VARCHAR(20)     NULL,
    MAX_MARKET_SEGMENT        VARCHAR(20)     NULL,
    BEGIN_DATE                VARCHAR(8)      NOT NULL,
    PERCENTAGE                VARCHAR(5)      NOT NULL,
    PLAN_DESCRIPTION          VARCHAR(20)     NULL
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_usable_commission_cw') IS NOT NULL
  PRINT '<<< CREATED TABLE dbo.tpzt_usable_commission_cw >>>'
ELSE
  PRINT '<<< FAILED CREATING TABLE dbo.tpzt_usable_commission_cw >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/
