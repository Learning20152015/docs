
			
DECLARE @firstday DATETIME
DECLARE @lastday DATETIME
DECLARE @currendate DATETIME

SELECT @currendate = getdate();

SELECT @firstday =  CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(@currendate)-1),getdate()),101)
SELECT @lastday = CONVERT(VARCHAR(25),DATEADD(dd,-(DAY(DATEADD(mm,1,@currendate))),DATEADD(mm,1,@currendate)),101) 




SELECT distinct
	--cspi.CSPD_CAT , blei.BLEI_CK,
	GROUP_NUMBER				= grgr.GRGR_ID,
	GROUP_NAME  				= grgr.GRGR_NAME ,
	LIFE_PREMIUM_AMOUNT			= (SELECT DISTINCT BLBL_BILLED_AMT
										FROM CMC_BLBL_BILL_SUMM blbl
									WHERE blbl.BLEI_CK = blei.BLEI_CK
										AND cspi.CSPD_CAT ='M'
										AND convert(VARCHAR(8),blbl.BLBL_DUE_DT,112) BETWEEN convert(VARCHAR(8),'20140201',112) AND convert(VARCHAR(8),'20140301',112)),
	
	
	ADD_PREMIUM_AMOUNT			= (SELECT DISTINCT BLBL_BILLED_AMT
										FROM CMC_BLBL_BILL_SUMM blbl
									WHERE blbl.BLEI_CK = blei.BLEI_CK
										AND cspi.CSPD_CAT ='M'
									 AND convert(VARCHAR(8),blbl.BLBL_DUE_DT,112) BETWEEN convert(VARCHAR(8),'20140201',112) AND convert(VARCHAR(8),'20140301',112)),
										
	
	WDB_PREMIUM_AMOUNT			= (SELECT DISTINCT BLBL_BILLED_AMT
										FROM CMC_BLBL_BILL_SUMM blbl
									WHERE blbl.BLEI_CK = blei.BLEI_CK
										AND cspi.CSPD_CAT ='M'
									  AND convert(VARCHAR(8),blbl.BLBL_DUE_DT,112) BETWEEN convert(VARCHAR(8),'20140201',112) AND convert(VARCHAR(8),'20140301',112)),
										
	
	LTD_PREMIUM_AMOUNT			= (SELECT DISTINCT BLBL_BILLED_AMT
										FROM CMC_BLBL_BILL_SUMM blbl
									WHERE blbl.BLEI_CK = blei.BLEI_CK
										AND cspi.CSPD_CAT ='M'
									 AND convert(VARCHAR(8),blbl.BLBL_DUE_DT,112) BETWEEN convert(VARCHAR(8),'20140201',112) AND convert(VARCHAR(8),'20140301',112)),
										
	
	SLI_PREMIUM_AMOUNT			= (SELECT DISTINCT BLBL_BILLED_AMT
										FROM CMC_BLBL_BILL_SUMM blbl
									WHERE blbl.BLEI_CK = blei.BLEI_CK
										AND cspi.CSPD_CAT ='M'
									  AND convert(VARCHAR(8),blbl.BLBL_DUE_DT,112) BETWEEN convert(VARCHAR(8),'20140201',112) AND convert(VARCHAR(8),'20140301',112)),
	
	
	SAD_PREMIUM_AMOUNT			= (SELECT DISTINCT BLBL_BILLED_AMT
										FROM CMC_BLBL_BILL_SUMM blbl
									WHERE blbl.BLEI_CK = blei.BLEI_CK
										AND cspi.CSPD_CAT ='M'
										AND convert(VARCHAR(8),blbl.BLBL_DUE_DT,112) BETWEEN convert(VARCHAR(8),'20140201',112) AND convert(VARCHAR(8),'20140301',112)),
	
	VOLUNTARY_LIF_PREMIUM_AMOUNT			= (SELECT DISTINCT BLBL_BILLED_AMT
										FROM CMC_BLBL_BILL_SUMM blbl
									WHERE blbl.BLEI_CK = blei.BLEI_CK
										AND cspi.CSPD_CAT ='M'
										AND convert(VARCHAR(8),blbl.BLBL_DUE_DT,112) BETWEEN convert(VARCHAR(8),'20140201',112) AND convert(VARCHAR(8),'20140301',112)),
										
	VOLUNTARY_LIFSP_PREMIUM_AMOUNT			= (SELECT DISTINCT BLBL_BILLED_AMT
										FROM CMC_BLBL_BILL_SUMM blbl
									WHERE blbl.BLEI_CK = blei.BLEI_CK
										AND cspi.CSPD_CAT ='M'
										AND convert(VARCHAR(8),blbl.BLBL_DUE_DT,112) BETWEEN convert(VARCHAR(8),'20140201',112) AND convert(VARCHAR(8),'20140301',112)),
										
	VOLUNTARY_LIFCH_PREMIUM_AMOUNT			= (SELECT DISTINCT BLBL_BILLED_AMT
										FROM CMC_BLBL_BILL_SUMM blbl
									WHERE blbl.BLEI_CK = blei.BLEI_CK
										AND cspi.CSPD_CAT ='M'
									   AND convert(VARCHAR(8),blbl.BLBL_DUE_DT,112) BETWEEN convert(VARCHAR(8),'20140201',112) AND convert(VARCHAR(8),'20140301',112)),
										
	VOLUNTARY_ADD_PREMIUM_AMOUNT			= (SELECT DISTINCT BLBL_BILLED_AMT
										FROM CMC_BLBL_BILL_SUMM blbl
									WHERE blbl.BLEI_CK = blei.BLEI_CK
										AND cspi.CSPD_CAT ='M'
										AND convert(VARCHAR(8),blbl.BLBL_DUE_DT,112) BETWEEN convert(VARCHAR(8),'20140201',112) AND convert(VARCHAR(8),'20140301',112)),
										
	VOLUNTARY_ADDSP_PREMIUM_AMOUNT			= (SELECT DISTINCT BLBL_BILLED_AMT
										FROM CMC_BLBL_BILL_SUMM blbl
									WHERE blbl.BLEI_CK = blei.BLEI_CK
										AND cspi.CSPD_CAT ='M'
									   AND convert(VARCHAR(8),blbl.BLBL_DUE_DT,112) BETWEEN convert(VARCHAR(8),'20140201',112) AND convert(VARCHAR(8),'20140301',112)),
										
	VOLUNTARY_ADDCH_PREMIUM_AMOUNT	= (SELECT DISTINCT BLBL_BILLED_AMT
										FROM CMC_BLBL_BILL_SUMM blbl
									WHERE blbl.BLEI_CK = blei.BLEI_CK
										AND cspi.CSPD_CAT ='M'
									   AND convert(VARCHAR(8),blbl.BLBL_DUE_DT,112) BETWEEN convert(VARCHAR(8),'20140201',112) AND convert(VARCHAR(8),'20140301',112)),
										
	VOLUNTARY_STD_PREMIUM_AMOUNT			= (SELECT DISTINCT BLBL_BILLED_AMT
										FROM CMC_BLBL_BILL_SUMM blbl
									WHERE blbl.BLEI_CK = blei.BLEI_CK
										AND cspi.CSPD_CAT ='M'
										AND convert(VARCHAR(8),blbl.BLBL_DUE_DT,112) BETWEEN convert(VARCHAR(8),'20140201',112) AND convert(VARCHAR(8),'20140301',112)),
										
	VOLUNTARY_LTD_PREMIUM_AMOUNT			= (SELECT DISTINCT BLBL_BILLED_AMT
										FROM CMC_BLBL_BILL_SUMM blbl
									WHERE blbl.BLEI_CK = blei.BLEI_CK
										AND cspi.CSPD_CAT ='M'
										AND convert(VARCHAR(8),blbl.BLBL_DUE_DT,112) BETWEEN convert(VARCHAR(8),'20140201',112) AND convert(VARCHAR(8),'20140301',112)),
	
	PREMIUM_AMOUNT			=	'',		
	grgrISSION				= '',
	NET_AMOUNT				= '',
	
--   	LIF_COUNT				= (SELECT insb.BLSB_LVS_DEP + insb.BLSB_LVS_SB
--   									FROM CDS_INSB_SB_DETAIL insb 
--   									WHERE  insb.GRGR_CK = grgr.GRGR_CK
--																 AND insb.GRGR_ID = grgr.GRGR_ID
--								),

	LIF_COUNT				='',
	ADD_COUNT				='',
	DEP_COUNT				='',
	STD_COUNT				='',	
	LTD_COUNT				='',
	SLI_COUNT				='',
	SAD_COUNT				='',
	VOLUNTARY_LIF_COUNT		='',
	VOLUNTARY_LIFSP_COUNT	='',
	VOLUNTARY_LIFCH_COUNT	='',
	VOLUNTARY_ADD_COUNT		='',
	VOLUNTARY_ADDSP_COUNT	='',
	VOLUNTARY_ADDCH_COUNT	='',
	VOLUNTARY_LTD_COUNT		='',
	VOLUNTARY_STD_COUNT		='',
	
	
	BENEFIT_AMOUNT_FOR_LIFE	= ISNULL((SELECT gtl.BENEFIT_AMOUNT 
				                          FROM fabncdv1stage.dbo.tpzt_usable_gtl_add gtl
				                          WHERE gtl.GRGR_ID = grgr.GRGR_ID
				                          AND gtl.CSCS_ID = cspi.CSCS_ID
				                          AND gtl.CSPI_ID = 'L'),'000.00'),
	BENEFIT_AMOUNT_FOR_ADD	=ISNULL((SELECT gtl.BENEFIT_AMOUNT 
			                          FROM fabncdv1stage.dbo.tpzt_usable_gtl_add gtl
			                          WHERE gtl.GRGR_ID = grgr.GRGR_ID
			                          AND gtl.CSCS_ID = cspi.CSCS_ID
			                          AND gtl.CSPI_ID = 'A'),'000.00'),
	BENEFIT_AMOUNT_FOR_DEP	= ISNULL((SELECT usabledl.[PLAN]
			                          FROM fabncdv1stage.dbo.tpzt_usable_dl usabledl
			                          WHERE usabledl.GRGR_ID = grgr.GRGR_ID 
			                          AND usabledl.CSCS_ID = cspi.CSCS_ID
			                          AND usabledl.CSPI_ID = 'T'),'000.00'),
	BENEFIT_AMOUNT_FOR_STD	= ISNULL((SELECT usablewdb.BENEFIT_AMOUNT
                          				FROM fabncdv1stage.dbo.tpzt_usable_wdb usablewdb
                          					WHERE usablewdb.GRGR_ID = grgr.GRGR_ID 
                          						AND usablewdb.CSCS_ID = cspi.CSCS_ID
                          						AND usablewdb.CSPI_ID = 'X'),'000.00'),
	BENEFIT_AMOUNT_FOR_LTD	= ISNULL((SELECT usableltd.MONTHLY_MAXIMUM
                          				FROM fabncdv1stage.dbo.tpzt_usable_ltd usableltd
				                          WHERE usableltd.GRGR_ID = grgr.GRGR_ID 
				                          AND usableltd.CSCS_ID = cspi.CSCS_ID
				                          AND usableltd.CSPI_ID = 'Y'),'000.00'),
	BENEFIT_AMOUNT_FOR_SLI	=ISNULL((SELECT usablesl.BENEFIT_AMOUNT
                          				FROM fabncdv1stage.dbo.tpzt_usable_sl usablesl
				                          WHERE usablesl.GRGR_ID = grgr.GRGR_ID 
				                          AND usablesl.CSCS_ID = cspi.CSCS_ID
				                          AND usablesl.CSPI_ID = 'S'),'000.00'),
	BENEFIT_AMOUNT_FOR_SAD	= ISNULL((SELECT usablesa.BENEFIT_AMOUNT
                          					FROM fabncdv1stage.dbo.tpzt_usable_sa usablesa
                          						WHERE usablesa.GRGR_ID = grgr.GRGR_ID 
                          						AND usablesa.CSCS_ID = cspi.CSCS_ID
                          						AND usablesa.CSPI_ID = 'E'),'000.00'),
	BENEFIT_AMOUNT_FOR_VLIF	= ISNULL((SELECT usablevl.BENEFIT_AMOUNT
                          				FROM fabncdv1stage.dbo.tpzt_usable_vl usablevl
			                          		WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
			                          AND usablevl.CSCS_ID = cspi.CSCS_ID
			                          AND usablevl.CSPI_ID = 'Z'
			                          AND comm.MEME_REL = 'M'),'0000000.0000'),
	BENEFIT_AMOUNT_FOR_VLIFSP	=ISNULL((SELECT usablevl.SPOUSE_AMOUNT
				                          FROM fabncdv1stage.dbo.tpzt_usable_vl usablevl
				                          WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
				                          AND usablevl.CSCS_ID = cspi.CSCS_ID
				                          AND usablevl.CSPI_ID = 'Z'
				                          AND comm.MEME_REL IN('H','W')),'0000000.0000'),
	BENEFIT_AMOUNT_FOR_VLIFCH	=ISNULL((SELECT usablevl.DEPENDANT_CHILD_COVERAGE
				                          FROM fabncdv1stage.dbo.tpzt_usable_vl usablevl
				                          WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
				                          AND usablevl.CSCS_ID = cspi.CSCS_ID
				                          AND usablevl.CSPI_ID = 'Z'
				                          AND comm.MEME_REL IN('S','D')),'0000000.0000'),
	BENEFIT_AMOUNT_FOR_VADD	=ISNULL((SELECT usablevadd.BENEFIT_AMOUNT
				                          FROM fabncdv1stage.dbo.tpzt_usable_vadd usablevadd
				                          WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
				                          AND usablevadd.CSCS_ID = cspi.CSCS_ID
				                          AND usablevadd.CSPI_ID = 'B'
				                          AND comm.MEME_REL = 'M'),'0000000.0000'),
	BENEFIT_AMOUNT_FOR_VADDSP	=ISNULL((SELECT usablevadd.SPOUSE_AMOUNT
				                          FROM fabncdv1stage.dbo.tpzt_usable_vadd usablevadd
				                          WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
				                          AND usablevadd.CSCS_ID = cspi.CSCS_ID
				                          AND usablevadd.CSPI_ID = 'B'
				                          AND comm.MEME_REL IN('H','W')),'0000000.0000'),
	BENEFIT_AMOUNT_FOR_VADDCH	=ISNULL((SELECT usablevadd.DEP_CHILD_COVERAGE
					                          FROM fabncdv1stage.dbo.tpzt_usable_vadd usablevadd
					                          WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
					                          AND usablevadd.CSCS_ID = cspi.CSCS_ID
					                          AND usablevadd.CSPI_ID = 'B'
					                          AND comm.MEME_REL IN('S','D')),'0000000.0000'),
	BENEFIT_AMOUNT_FOR_VLTD		=ISNULL((SELECT usablevltd.BENEFIT_TYPE
				                          FROM fabncdv1stage.dbo.tpzt_usable_vltd usablevltd
				                          WHERE usablevltd.GRGR_ID = grgr.GRGR_ID 
				                          AND usablevltd.CSCS_ID = cspi.CSCS_ID
				                          AND usablevltd.CSPI_ID = 'J'),'  '),
	BENEFIT_AMOUNT_FOR_VSTD	=ISNULL((SELECT usablevstd.BENEFIT_TYPE
				                          FROM fabncdv1stage.dbo.tpzt_usable_vstd usablevstd
				                          WHERE usablevstd.GRGR_ID = grgr.GRGR_ID 
				                          AND usablevstd.CSCS_ID = cspi.CSCS_ID
				                          AND usablevstd.CSPI_ID = 'K'),'  '),
	
	BENEFIT_RATE_PER_UNIT_LIFE 		='000.06',
	BENEFIT_RATE_PER_UNIT_ADD		='000.06',
	BENEFIT_RATE_PER_UNIT_DEP		='000.06',
	BENEFIT_RATE_PER_UNIT_STD		='000.06',
	BENEFIT_RATE_PER_UNIT_LTD		='000.06',
	BENEFIT_RATE_PER_UNIT_SLI		='000.06',
	BENEFIT_RATE_PER_UNIT_SAD		='000.06',
	BENEFIT_RATE_PER_UNIT_VLIF		='000.06',
	BENEFIT_RATE_PER_UNIT_VLIFSP	='000.06',
	BENEFIT_RATE_PER_UNIT_VLIFCH	='000.06',
	BENEFIT_RATE_PER_UNIT_VADD		='000.06',
	BENEFIT_RATE_PER_UNIT_VADDSP	='000.06' ,	
	BENEFIT_RATE_PER_UNIT_VADDCH	='000.06',
	BENEFIT_RATE_PER_UNIT_VLTD		='000.06',
	BENEFIT_RATE_PER_UNIT_VSTD		='000.06' ,
	
	LIFE_TYPE		='',
	ADD_TYPE		='',
	DEP_TYPE		='',
	STD_TYPE		='',
	LTD_TYPE		='',
	SLI_TYPE		='',
	SAD_TYPE		='',
	VLIF_TYPE		='',
	VLIFSP_TYPE		='',
	VLIFCH_TYPE		='',
	VADD_TYPE		='',
	VADDSP_TYPE		='',
	VADDCH_TYPE		='',
	VLTD_TYPE		='',
	VSTD_TYPE		='',
	BILL_FROM_DATE	=''

			
FROM CMC_GRGR_GROUP grgr
	INNER JOIN fabncdv1stage.dbo.tpzt_comm_elig_extr comm ON comm.GRGR_CK = grgr.GRGR_CK
	INNER JOIN CMC_CSPI_CS_PLAN cspi   ON cspi.GRGR_CK = grgr.GRGR_CK
	INNER JOIN CMC_BLEI_ENTY_INFO blei ON blei.BLEI_BILL_LEVEL_CK = grgr.GRGR_CK
	INNER JOIN CMC_BLBL_BILL_SUMM blbl ON blbl.BLEI_CK = blei.BLEI_CK
WHERE convert(VARCHAR(8),blbl.BLBL_DUE_DT,112) BETWEEN convert(VARCHAR(8),'20140201',112) AND convert(VARCHAR(8),'20140301',112)
	
--AND cspi.CSPD_CAT IN ('X','Y','L','A','S','T','Z','B','E','K')
 

