/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzv_prime_claims_facil_extr') IS NOT NULL
BEGIN
    DROP VIEW dbo.tpzv_prime_claims_facil_extr
    IF OBJECT_ID('dbo.tpzv_prime_claims_facil_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.tpzv_prime_claims_facil_extr >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.tpzv_prime_claims_facil_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/

CREATE VIEW dbo.tpzv_prime_claims_facil_extr

/****************************************************************
**   NAME                  : tpzv_prime_claims_facil_extr
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Views\Stage
**
**   FUNCTION              : This view is used to fetch the details of Facility Claims for Prime
**
**   TABLES REFERENCED     :
**                FACETS   :
**                FACETSXC : N/A
**                CUSTOM   :
**                STAGE    : fabncdv1stage.dbo.tpzt_prime_claims_extr
**
**   REVISION HISTORY      :
**
**   VERSION   DATE         DEVELOPER            DESCRIPTION
**   -------   ----------   -------------        ------------------
**   1.0       03/25/2014   Irfan Mohammed       Initial Version
**   1.1       05/15/2014   Irfan Mohammed       Included column ITS_FLAG
**   1.2       05/30/2014   Divya Anne           Added Header Records
*********************************************************************/

AS

  SELECT

        'prm_mbr_id'                                                                        +'|'+
        'clnt_mbr_id'                                                                       +'|'+
        'crdhld_id'                                                                         +'|'+
        'prsn_cde'                                                                          +'|'+
        'reln_cde'                                                                          +'|'+
        'pat_frst_nme'                                                                      +'|'+
        'pat_mid_nme'                                                                       +'|'+
        'pat_last_nme'                                                                      +'|'+
        'pat_gndr'                                                                          +'|'+
        'pat_addr1'                                                                         +'|'+
        'pat_addr2'                                                                         +'|'+
        'pat_dob'                                                                           +'|'+
        'pat_city'                                                                          +'|'+
        'pat_state'                                                                         +'|'+
        'pat_zip'                                                                           +'|'+
        'clm_id'                                                                            +'|'+
        'clm_ln'                                                                            +'|'+
        'clm_pymt_id'                                                                       +'|'+
        'emgcy_room_cde'                                                                    +'|'+
        'svc_from_dte'                                                                      +'|'+
        'svc_to_dte'                                                                        +'|'+
        'paid_dte'                                                                          +'|'+
        'clnt_crr_id'                                                                       +'|'+
        'clnt_grp_main'                                                                     +'|'+
        'clnt_grp_sub'                                                                      +'|'+
        'dnl_rem_cde'                                                                       +'|'+
        'typ_of_bill_cde'                                                                   +'|'+
        'bill_form_typ'                                                                     +'|'+
        'fed_tax_id'                                                                        +'|'+
        'bill_prvdr_npi_cde1'                                                               +'|'+
        'bill_prvdr_npi_cde2'                                                               +'|'+
        'bill_prvdr_taxonomy'                                                               +'|'+
        'svc_prvdr_npi_cde'                                                                 +'|'+
        'svc_prvdr_npi_cde2'                                                                +'|'+
        'svc_prvdr_taxonomy'                                                                +'|'+
        'bill_prvdr_spec_cde'                                                               +'|'+
        'svc_prvdr_spec_cde'                                                                +'|'+
        'diag_rel_grp_cde'                                                                  +'|'+
        'drg_grouper_cde'                                                                   +'|'+
        'admit_diag_cde'                                                                    +'|'+
        'in_ntwk_indctr'                                                                    +'|'+
        'icd9_proc_cde1'                                                                    +'|'+
        'icd9_proc_cde2'                                                                    +'|'+
        'icd9_proc_cde3'                                                                    +'|'+
        'icd10_proc_cde1'                                                                   +'|'+
        'icd10_proc_cde2'                                                                   +'|'+
        'icd10_proc_cde3'                                                                   +'|'+
        'proc_cde'                                                                          +'|'+
        'proc_mod_cde1'                                                                     +'|'+
        'proc_mod_cde2'                                                                     +'|'+
        'icd9_ln_diag_cde'                                                                  +'|'+
        'icd9_diag_cde1'                                                                    +'|'+
        'icd9_diag_cde2'                                                                    +'|'+
        'icd9_diag_cde3'                                                                    +'|'+
        'icd9_diag_cde4'                                                                    +'|'+
        'icd9_diag_cde5'                                                                    +'|'+
        'icd10_ln_diag_cde'                                                                 +'|'+
        'icd10_diag_cde1'                                                                   +'|'+
        'icd10_diag_cde2'                                                                   +'|'+
        'icd10_diag_cde3'                                                                   +'|'+
        'icd10_diag_cde4'                                                                   +'|'+
        'icd10_diag_cde5'                                                                   +'|'+
        'nbr_units'                                                                         +'|'+
        'ndc'                                                                               +'|'+
        '340b_ind'                                                                          +'|'+
        'revn_cde'                                                                          +'|'+
        'typ_svc_cde'                                                                       +'|'+
        'plc_svc_cde'                                                                       +'|'+
        'admit_dte'                                                                         +'|'+
        'dschg_dte'                                                                         +'|'+
        'inpat_svc_day_nbr'                                                                 +'|'+
        'dschg_stat_cde'                                                                    +'|'+
        'charge_amt'                                                                        +'|'+
        'coins_amt'                                                                         +'|'+
        'copay_amt'                                                                         +'|'+
        'deduct_amt'                                                                        +'|'+
        'non_covrd_amt'                                                                     +'|'+
        'covrd_pymt_amt'                                                                    +'|'+
        'cob_pymt_amt'                                                                      +'|'+
        'plan_paid_amt'                                                                     +'|'+
        'ntwk_dcnt_amt'                                                                     +'|'+
        'othr_adj_amt'                                                                      +'|'+
        'othr_ins_cde'                                                                      +'|'+
        'mdcr_pymt_amt'                                                                     +'|'+
        'src_typ_cde'                                                                       +'|'+
        'prod_typ_cde'                                                                      +'|'+
        'clm_stat_cde'                                                                      +'|'+
        'orig_clm_id'                                                                       +'|'+
        'prnt_clm_id'                                                                       +'|'+
        'revrs_clm_id'                                                                      +'|'+
        'nc_clm_stat_cde'                                                                   +'|'+
        'its_flag'                                                                          +'|'+
        'bcbsnc_srvc_cde'                                                                   +'|'+
        'bcbsnc_srvc_cd_typ'                                                                +'|'+
        'icd_type_cde'                                                                      AS HEADER

        UNION ALL

  SELECT

        ISNULL(LTRIM(RTRIM(extr.PRM_MBR_ID)),'')                                            +'|'+
        ISNULL(LTRIM(RTRIM(extr.CLNT_MBR_ID)),'')                                           +'|'+
        ISNULL(LTRIM(RTRIM(extr.CRDHLD_ID)),'')                                             +'|'+
        ISNULL(LTRIM(RTRIM(extr.PRSN_CDE)),'')                                              +'|'+
        ISNULL(LTRIM(RTRIM(extr.RELN_CDE)) ,'')                                             +'|'+
        ISNULL(LTRIM(RTRIM(extr.PAT_FRST_NME)),'')                                          +'|'+
        ISNULL(LTRIM(RTRIM(extr.PAT_MID_NME)),'')                                           +'|'+
        ISNULL(LTRIM(RTRIM(extr.PAT_LAST_NME)),'')                                          +'|'+
        ISNULL(LTRIM(RTRIM(extr.PAT_GNDR)),'')                                              +'|'+
        ISNULL(LTRIM(RTRIM(extr.PAT_ADDR1)),'')                                             +'|'+
        ISNULL(LTRIM(RTRIM(extr.PAT_ADDR2)),'')                                             +'|'+
        ISNULL(LTRIM(RTRIM(extr.PAT_DOB)),'')                                               +'|'+
        ISNULL(LTRIM(RTRIM(extr.PAT_CITY)),'')                                              +'|'+
        ISNULL(LTRIM(RTRIM(extr.PAT_STATE)),'')                                             +'|'+
        ISNULL(LTRIM(RTRIM(extr.PAT_ZIP)),'')                                               +'|'+
        ISNULL(LTRIM(RTRIM(extr.CLM_ID)),'')                                                +'|'+
        ISNULL(LTRIM(RTRIM(CONVERT(VARCHAR, extr.CLM_LN))),'')                              +'|'+
        ISNULL(LTRIM(RTRIM(extr.CLM_PYMT_ID)),'')                                           +'|'+
        ISNULL(LTRIM(RTRIM(extr.EMGCY_ROOM_CDE)),'')                                        +'|'+
        ISNULL(LTRIM(RTRIM(extr.SVC_FROM_DTE)),'')                                          +'|'+
        ISNULL(LTRIM(RTRIM(extr.SVC_TO_DTE)),'')                                            +'|'+
        ISNULL(LTRIM(RTRIM(extr.PAID_DTE)),'')                                              +'|'+
        'NC1000'                                                                            +'|'+
        ISNULL(LTRIM(RTRIM(extr.CLNT_GRP_MAIN)),'')                                         +'|'+
        ISNULL(LTRIM(RTRIM(extr.CLNT_GRP_SUB)),'')                                          +'|'+
        ISNULL(LTRIM(RTRIM(extr.DNL_REM_CDE)),'')                                           +'|'+
        ISNULL(extr.TYP_OF_BILL_CDE,'')                                                     +'|'+
        ISNULL(LTRIM(RTRIM(extr.BILL_FORM_TYP)),'')                                         +'|'+
        ISNULL(LTRIM(RTRIM(extr.FED_TAX_ID)),'')                                            +'|'+
        ISNULL(LTRIM(RTRIM(extr.BILL_PRVDR_NPI_CDE1)),'')                                   +'|'+
        ISNULL(LTRIM(RTRIM(extr.BILL_PRVDR_NPI_CDE2)),'')                                   +'|'+
        ISNULL(LTRIM(RTRIM(extr.BILL_PRVDR_TAXONOMY)),'')                                   +'|'+
        ISNULL(LTRIM(RTRIM(extr.SVC_PRVDR_NPI_CDE)),'')                                     +'|'+
        ISNULL(LTRIM(RTRIM(extr.RNDR_PRVDR_NPI_CDE2)),'')                                   +'|'+
        ISNULL(LTRIM(RTRIM(extr.RNDR_PRVDR_TAXONOMY)),'')                                   +'|'+
        ISNULL(LTRIM(RTRIM(extr.BILL_PRVDR_SPEC_CDE)),'')                                   +'|'+
        ISNULL(LTRIM(RTRIM(extr.SVC_PRVDR_SPEC_CDE)),'')                                    +'|'+
        ISNULL(LTRIM(RTRIM(extr.DIAG_REL_GRP_CDE)),'')                                      +'|'+
        ISNULL(LTRIM(RTRIM(extr.DRG_GROUPER_CDE)),'')                                       +'|'+
        ISNULL(LTRIM(RTRIM(extr.ADMIT_DIAG_CDE)),'')                                        +'|'+
        ISNULL(LTRIM(RTRIM(extr.IN_NTWK_INDCTR)),'')                                        +'|'+
        ISNULL(LTRIM(RTRIM(extr.ICD9_PROC_CDE1)),'')                                        +'|'+
        CASE WHEN (extr.ICD9_PROC_CDE1 <> '' AND extr.ICD9_PROC_CDE1 IS NOT NULL)
             THEN '00000000000'  + '|'
             ELSE ''             + '|'
        END +
        CASE WHEN (extr.ICD9_PROC_CDE1 <> '' AND extr.ICD9_PROC_CDE1 IS NOT NULL)
             THEN '00000000000'  + '|'
             ELSE ''             + '|'
        END +
        LTRIM(RTRIM(extr.ICD10_PROC_CDE1))                                                  +'|'+
        CASE WHEN (extr.ICD10_PROC_CDE1 <> '' AND extr.ICD10_PROC_CDE1 IS NOT NULL)
             THEN '00000000000'  + '|'
             ELSE ''             + '|'
        END +
        CASE WHEN (extr.ICD10_PROC_CDE1 <> '' AND extr.ICD10_PROC_CDE1 IS NOT NULL)
             THEN '00000000000'  + '|'
             ELSE ''             + '|'
        END +
        ISNULL(LTRIM(RTRIM(extr.PROC_CDE)),'')                                              +'|'+
        ISNULL(LTRIM(RTRIM(extr.PROC_MOD_CDE1)),'')                                         +'|'+
        ISNULL(LTRIM(RTRIM(extr.PROC_MOD_CDE2)),'')                                         +'|'+
        ISNULL(LTRIM(RTRIM(extr.ICD9_LN_DIAG_CDE)),'')                                      +'|'+
        ISNULL(LTRIM(RTRIM(extr.ICD9_DIAG_CDE1)),'')                                        +'|'+
        ISNULL(LTRIM(RTRIM(extr.ICD9_DIAG_CDE2)),'')                                        +'|'+
        ISNULL(LTRIM(RTRIM(extr.ICD9_DIAG_CDE3)),'')                                        +'|'+
        ISNULL(LTRIM(RTRIM(extr.ICD9_DIAG_CDE4)),'')                                        +'|'+
        ''                                                                                  +'|'+
        ISNULL(LTRIM(RTRIM(extr.ICD10_LN_DIAG_CDE)),'')                                     +'|'+
        ISNULL(LTRIM(RTRIM(extr.ICD10_DIAG_CDE1)),'')                                       +'|'+
        ISNULL(LTRIM(RTRIM(extr.ICD10_DIAG_CDE2)),'')                                       +'|'+
        ISNULL(LTRIM(RTRIM(extr.ICD10_DIAG_CDE3)),'')                                       +'|'+
        ISNULL(LTRIM(RTRIM(extr.ICD10_DIAG_CDE4)),'')                                       +'|'+
        ''                                                                                  +'|'+
        ISNULL(LTRIM(RTRIM(extr.NBR_UNITS)),'')                                             +'|'+
        ISNULL(LTRIM(RTRIM(extr.NDC)),'')                                                   +'|'+
        'U'                                                                                 +'|'+
        ISNULL(LTRIM(RTRIM(extr.REVN_CDE)),'')                                              +'|'+
        '0'                                                                                 +'|'+
        ISNULL(LTRIM(RTRIM(extr.PLC_SVC_CDE)),'')                                           +'|'+
        ISNULL(LTRIM(RTRIM(extr.ADMIT_DTE)),'')                                             +'|'+
        ISNULL(LTRIM(RTRIM(extr.DSCHG_DTE)),'')                                             +'|'+
        ISNULL(LTRIM(RTRIM(extr.INPAT_SVC_DAY_NBR)),'')                                     +'|'+
        ISNULL(LTRIM(RTRIM(extr.DSCHG_STAT_CDE)),'')                                        +'|'+
        ISNULL(LTRIM(RTRIM(extr.CHARGE_AMT)),'')                                            +'|'+
        ISNULL(LTRIM(RTRIM(extr.COINS_AMT)),'')                                             +'|'+
        ISNULL(LTRIM(RTRIM(extr.COPAY_AMT)),'')                                             +'|'+
        ISNULL(LTRIM(RTRIM(extr.DEDUCT_AMT)),'')                                            +'|'+
        ISNULL(LTRIM(RTRIM(extr.NON_COVRD_AMT)),'')                                         +'|'+
        ISNULL(LTRIM(RTRIM(extr.COVRD_PYMT_AMT)),'')                                        +'|'+
        ISNULL(LTRIM(RTRIM(extr.COB_PYMT_AMT)),'')                                          +'|'+
        ISNULL(LTRIM(RTRIM(extr.PLAN_PAID_AMT)),'')                                         +'|'+
        ISNULL(LTRIM(RTRIM(extr.NTWK_DCNT_AMT)),'')                                         +'|'+
        '0.00'                                                                              +'|'+
        ISNULL(LTRIM(RTRIM(extr.OTHR_INS_CDE)),'')                                          +'|'+
        '0.00'                                                                              +'|'+
        '2'                                                                                 +'|'+
        ISNULL(LTRIM(RTRIM(extr.PROD_TYP_CDE)),'')                                          +'|'+
        ISNULL(LTRIM(RTRIM(extr.CLM_STAT_CDE)),'')                                          +'|'+
        ISNULL(LTRIM(RTRIM(extr.ORIG_CLM_ID)),'')                                           +'|'+
        '0'                                                                                 +'|'+
        ISNULL(LTRIM(RTRIM(extr.REVRS_CLM_ID)),'')                                          +'|'+
        ISNULL(LTRIM(RTRIM(extr.NC_CLM_STAT_CDE)),'')                                       +'|'+
        ISNULL(LTRIM(RTRIM(extr.ITS_FLAG)),'')                                              +'|'+
        ''                                                                                  +'|'+
        ''                                                                                  +'|'+
        ISNULL(LTRIM(RTRIM(extr.ICD_TYPE_CDE)),'')                                          AS FACILITY_DETAILS

    FROM  fabncdv1stage.dbo.tpzt_prime_claims_extr extr
    WHERE extr.BILL_FORM_TYP = 'F'

GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzv_prime_claims_facil_extr') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.tpzv_prime_claims_facil_extr >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.tpzv_prime_claims_facil_extr >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/