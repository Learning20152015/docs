/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzt_prime_claims_extr') IS NOT NULL
BEGIN
    DROP TABLE dbo.tpzt_prime_claims_extr
    IF OBJECT_ID('dbo.tpzt_prime_claims_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_prime_claims_extr >>>'
    ELSE
        PRINT '<<< DROPPED TABLE dbo.tpzt_prime_claims_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/
/****************************************************************
**   NAME                  : tpzt_prime_claims_extr
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the details of Medical Claims for Prime
**
**   REVISION HISTORY      :
**
**   VERSION   DATE         DEVELOPER           DESCRIPTION
**   -------   ----------   -------------       ------------------
**   1.0       03/25/2014   Irfan Mohammed      Initial Version
**   1.1       05/15/2014   Irfan Mohammed      Included column ITS_FLAG
****************************************************************/
CREATE TABLE dbo.tpzt_prime_claims_extr
(
    MEME_CK                         VARCHAR(9)          NULL,
    SBSB_CK                         VARCHAR(9)          NULL,
    SBSB_ID                         VARCHAR(9)          NULL,
    MEME_SFX                        INT                 NULL,
    MEME_REL                        CHAR(1)             NULL,
    PRM_MBR_ID                      VARCHAR(11)         NULL,
    CLNT_MBR_ID                     VARCHAR(11)         NULL,
    CRDHLD_ID                       VARCHAR(11)         NULL,
    PRSN_CDE                        VARCHAR(2)          NULL,
    RELN_CDE                        VARCHAR(3)          NULL,
    PAT_FRST_NME                    VARCHAR(50)         NULL,
    PAT_MID_NME                     VARCHAR(25)         NULL,
    PAT_LAST_NME                    VARCHAR(50)         NULL,
    PAT_GNDR                        VARCHAR(1)          NULL,
    PAT_ADDR1                       VARCHAR(55)         NULL,
    PAT_ADDR2                       VARCHAR(55)         NULL,
    PAT_DOB                         VARCHAR(8)          NULL,
    PAT_CITY                        VARCHAR(30)         NULL,
    PAT_STATE                       VARCHAR(8)          NULL,
    PAT_ZIP                         VARCHAR(10)         NULL,
    CLM_ID                          VARCHAR(12)         NULL,
    CLM_LN                          SMALLINT            NULL,
    CLM_PYMT_ID                     VARCHAR(12)         NULL,
    EMGCY_ROOM_CDE                  VARCHAR(1)          NULL,
    SVC_FROM_DTE                    VARCHAR(8)          NULL,
    SVC_TO_DTE                      VARCHAR(8)          NULL,
    PAID_DTE                        VARCHAR(8)          NULL,
    CLNT_GRP_MAIN                   VARCHAR(10)         NULL,
    CLNT_GRP_SUB                    VARCHAR(15)         NULL,
    DNL_REM_CDE                     VARCHAR(17)         NULL,
    TYP_OF_BILL_CDE                 VARCHAR(8)          NULL,
    BILL_FORM_TYP                   VARCHAR(1)          NULL,
    FED_TAX_ID                      VARCHAR(17)         NULL,
    BILL_PRVDR_NPI_CDE1             VARCHAR(17)         NULL,
    BILL_PRVDR_NPI_CDE2             VARCHAR(17)         NULL,
    BILL_PRVDR_TAXONOMY             VARCHAR(17)         NULL,
    SVC_PRVDR_NPI_CDE               VARCHAR(17)         NULL,
    RNDR_PRVDR_NPI_CDE2             VARCHAR(17)         NULL,
    RNDR_PRVDR_TAXONOMY             VARCHAR(17)         NULL,
    BILL_PRVDR_SPEC_CDE             VARCHAR(11)         NULL,
    SVC_PRVDR_SPEC_CDE              VARCHAR(11)         NULL,
    DIAG_REL_GRP_CDE                VARCHAR(11)         NULL,
    DRG_GROUPER_CDE                 VARCHAR(4)          NULL,
    ADMIT_DIAG_CDE                  VARCHAR(8)          NULL,
    IN_NTWK_INDCTR                  VARCHAR(1)          NULL,
    ICD9_PROC_CDE1                  VARCHAR(11)         NULL,
    ICD10_PROC_CDE1                 VARCHAR(11)         NULL,
    PROC_CDE                        VARCHAR(11)         NULL,
    PROC_MOD_CDE1                   VARCHAR(8)          NULL,
    PROC_MOD_CDE2                   VARCHAR(8)          NULL,
    ICD9_LN_DIAG_CDE                VARCHAR(8)          NULL,
    ICD9_DIAG_CDE1                  VARCHAR(8)          NULL,
    ICD9_DIAG_CDE2                  VARCHAR(8)          NULL,
    ICD9_DIAG_CDE3                  VARCHAR(8)          NULL,
    ICD9_DIAG_CDE4                  VARCHAR(8)          NULL,
    ICD10_LN_DIAG_CDE               VARCHAR(8)          NULL,
    ICD10_DIAG_CDE1                 VARCHAR(8)          NULL,
    ICD10_DIAG_CDE2                 VARCHAR(8)          NULL,
    ICD10_DIAG_CDE3                 VARCHAR(8)          NULL,
    ICD10_DIAG_CDE4                 VARCHAR(8)          NULL,
    NBR_UNITS                       VARCHAR(12)         NULL,
    NDC                             VARCHAR(11)         NULL,
    REVN_CDE                        VARCHAR(11)         NULL,
    PLC_SVC_CDE                     VARCHAR(8)          NULL,
    ADMIT_DTE                       VARCHAR(8)          NULL,
    DSCHG_DTE                       VARCHAR(8)          NULL,
    INPAT_SVC_DAY_NBR               INT                 NULL,
    DSCHG_STAT_CDE                  VARCHAR(8)          NULL,
    CHARGE_AMT                      VARCHAR(14)         NULL,
    COINS_AMT                       VARCHAR(14)         NULL,
    COPAY_AMT                       VARCHAR(14)         NULL,
    DEDUCT_AMT                      VARCHAR(14)         NULL,
    NON_COVRD_AMT                   VARCHAR(14)         NULL,
    COVRD_PYMT_AMT                  VARCHAR(14)         NULL,
    COB_PYMT_AMT                    VARCHAR(14)         NULL,
    PLAN_PAID_AMT                   VARCHAR(14)         NULL,
    NTWK_DCNT_AMT                   VARCHAR(14)         NULL,
    OTHR_INS_CDE                    VARCHAR(1)          NULL,
    PROD_TYP_CDE                    VARCHAR(8)          NULL,
    CLM_STAT_CDE                    VARCHAR(1)          NULL,
    ORIG_CLM_ID                     VARCHAR(12)         NULL,
    REVRS_CLM_ID                    VARCHAR(12)         NULL,
    NC_CLM_STAT_CDE                 VARCHAR(8)          NULL,
    ITS_FLAG                        VARCHAR(1)          NULL,
    ICD_TYPE_CDE                    VARCHAR(6)          NULL,
    LOW_SVC_DT                      DATETIME            NULL,
    HIGH_SVC_DT                     DATETIME            NULL,
    CLCL_PAYEE_PR_ID                VARCHAR(12)         NULL,               
    CLCL_CL_SUB_TYPE                VARCHAR(1)          NULL,
    PRPR_ID                         VARCHAR(12)         NULL,
    GRGR_CK                         INT                 NULL,
    PDPD_ID                         VARCHAR(8)          NULL,
    IDCD_ID                         VARCHAR(10)         NULL,
    NWPR_PFX                        VARCHAR(4)          NULL,
    NWNW_ID                         VARCHAR(12)         NULL,
    TOT_CHG                         VARCHAR(30)         NULL,
    TOT_PAYABLE                     VARCHAR(30)         NULL
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_prime_claims_extr') IS NOT NULL
    PRINT '<<< CREATED TABLE dbo.tpzt_prime_claims_extr >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE dbo.tpzt_prime_claims_extr >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/