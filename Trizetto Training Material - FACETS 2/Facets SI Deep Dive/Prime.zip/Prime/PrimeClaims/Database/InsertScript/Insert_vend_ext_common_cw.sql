/****************************************************************
**   NAME                  : dbo.tpzt_vend_ext_common_cw
**
**   DATABASE LOCATION     : Stage
**
**   A011                  : 
**
**   PVCS LOCATION         : 
**
**   FUNCTION              : This Cross-Walk table will be used to map 
**                             Facets codes to Topaz codes for different entity
**                                
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0      02/05/2014   Yogesh Sabne         Intial Version
** 1.1      02/25/2014   Yogesh Sabne         New records added as per ALERE Requirement.     
** 1.2      02/27/2014   Pradeep Natarajan    Updated Alere Relationship changes as per review comment
** 1.3      03/04/2014   Divya Anne           Updated Care Radius Relationship and Marital Status
** 1.4      03/19/2014   Divya Anne           Replaced 'R' with 'U' for the Marital Crosswalk for Care Radius Member Extract
** 1.5      03/25/2014   Irfan Mohammed       Updated Prime Claims Relationship details
** 1.6      05/15/2014   Divya Anne           Removed Crosswalk values related to 'PRIMECLAIMS'
****************************************************************/

    /********** STEP 1 Truncate staging table tpzt_vend_ext_common_cw**********/

    TRUNCATE TABLE [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw]

    /********** End of TRUNCATE statement   ******************************/

    /********** STEP 2 Insert into  staging table tpzt_vend_ext_common_cw ****/
    
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','E','Employee/Subscriber','M','AIM')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','S','Spouse','H','AIM')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','S','Spouse','W','AIM')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','C','Child','D','AIM')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','C','Child','O','AIM')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','C','Child','S','AIM')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('LANGUAGE','E','English','ENGL','COMMON')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('LANGUAGE','C','Cantonese Chinese','CHIC','COMMON')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('LANGUAGE','C','Manderin Chinese','CHIM','COMMON')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('LANGUAGE','C','Shanghai Chinese','CHIS','COMMON')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','1','Self','M','PRIME')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','2','Spouse','H','PRIME')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','2','Spouse','W','PRIME')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','3','Child','S','PRIME')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','3','Child','D','PRIME')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','4','Other','O','PRIME')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','5','User-defined','NA','PRIME')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','1','Employee/Subscriber','M','ALERE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','2','Spouse','H','ALERE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','2','Spouse','W','ALERE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','3','Child','D','ALERE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','3','Child','S','ALERE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','4','Other','O','ALERE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] values('INSURANCE','Commercial','Commercial Insurance Type','COMM','ALERE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','18','Self','M','CARE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','01','Spouse','H','CARE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','01','Spouse','W','CARE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','19','Child','D','CARE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','19','Child','S','CARE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('RELATIONSHIP','G8','Other','O','CARE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('MARITAL','D','Divorced','D','CARE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('MARITAL','M','Married','M','CARE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('MARITAL','B','Registered Domestic Partner','P','CARE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('MARITAL','I','Single','S','CARE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('MARITAL','R','Unreported','U','CARE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('MARITAL','W','Widowed','W','CARE')
    GO
    INSERT INTO [fabncdv1stage].[dbo].[tpzt_vend_ext_common_cw] VALUES('MARITAL','X','Legally Separated','X','CARE')
    GO
    
    /**********  End of INSERT STATEMENTS  *****************************/
    
    

