/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_prime_claims_extr') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.tpzp_prime_claims_extr
    IF OBJECT_ID('dbo.tpzp_prime_claims_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_prime_claims_extr >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_prime_claims_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/

CREATE PROCEDURE [dbo].[tpzp_prime_claims_extr]

/****************************************************************
**   NAME                  :    tpzp_prime_claims_extr
**
**   PVCS LOCATION         :
**
**   FUNCTION              :    Step 1: Truncate Staging table tpzt_prime_claims_extr
**                              Step 2: Populating the temp table #tpzt_prime_claims_extr_temp with required records
**                              Step 3: Populating the Staging table tpzt_prime_claims_extr with details of monthly Medical Claims
**                              Step 4: Updating the Staging table tpzt_prime_claims_extr for the fields PAT_ADDR1, PAT_ADDR2, PAT_CITY, PAT_STATE, PAT_ZIP
**                              Step 5: Updating the Staging table tpzt_prime_claims_extr for the fields CLNT_GRP_SUB
**                              Step 6: Updating the Staging table tpzt_prime_claims_extr for the fields DNL_REM_CDE
**                              Step 7: Updating the Staging table tpzt_prime_claims_extr for the fields BILL_PRVDR_NPI_CDE1,BILL_PRVDR_NPI_CDE2,BILL_PRVDR_TAXONOMY,BILL_PRVDR_SPEC_CDE
**                              Step 8: Updating the Staging table tpzt_prime_claims_extr for the fields SVC_PRVDR_NPI_CDE, RNDR_PRVDR_NPI_CDE2, RNDR_PRVDR_TAXONOMY, NDC
**                              Step 9: Updating the Staging table tpzt_prime_claims_extr for the fields DRG_GROUPER_CDE, TYP_OF_BILL_CDE, ADMIT_DTE, DSCHG_DTE, INPAT_SVC_DAY_NBR, DSCHG_STAT_CDE
**                              Step 10: Updating the Staging table tpzt_prime_claims_extr for the fields ICD9_PROC_CDE1, ICD10_PROC_CDE1
**                              Step 11: Updating the Staging table tpzt_prime_claims_extr for the fields ADMIT_DIAG_CDE, ICD9_LN_DIAG_CDE, ICD9_DIAG_CDE1, ICD9_DIAG_CDE2, ICD9_DIAG_CDE3, ICD9_DIAG_CDE4, ICD10_LN_DIAG_CDE, ICD10_DIAG_CDE1, ICD10_DIAG_CDE2, ICD10_DIAG_CDE3, ICD10_DIAG_CDE4
**                              Step 12: Updating the Staging table tpzt_prime_claims_extr for the fields COB_PYMT_AMT
**                              Step 13: Updating the Staging table tpzt_prime_claims_extr for the fields OTHR_INS_CDE
**                              Step 14: Updating the Staging table tpzt_prime_claims_extr for the fields PROD_TYP_CDE
**                              Step 15: Updating the Staging table tpzt_prime_claims_extr for the fields ICD_TYPE_CDE
**                              Step 16: Updating the Staging table tpzt_prime_claims_extr for the fields REVRS_CLM_ID
**
**   PARAMETERS            :
**                  INPUT  :
**                  OUTPUT :
**
**   RETURN CODES          :    0 on success
**
**   TABLES REFERENCED     :
**                FACETS   :    CMC_CLCL_CLAIM
**                              CMC_GRGR_GROUP
**                              CMC_GRRE_RELATION
**                              CMC_MCRE_RELAT_ENT
**                              CMC_MEME_MEMBER
**                              CMC_SBSB_SUBSC
**                              CMC_CDML_CL_LINE
**                              FHP_PMED_MEMBER_D
**                              FHD_ENEN_ENTITY_D
**                              FHD_ENAD_ADDRESS_D
**                              FHP_PMCC_COMM_X
**                              CMC_SBAD_ADDR
**                              CMC_SBSG_RELATION
**                              CMC_SGSG_SUB_GROUP
**                              CMC_CDMD_LI_DISALL
**                              CMC_PRPR_PROV
**                              CMC_CDSD_SUPP_DATA
**                              CMC_CLHP_HOSP
**                              CMC_NWPR_RELATION
**                              CMC_IPCD_PROC_CD
**                              CMC_IDCD_DIAG_CD
**                              CMC_CLMD_DIAG
**                              CMC_CDCB_LI_COB
**                              CMC_MECB_COB
**                              CMC_PDDS_PROD_DESC
**                              CMC_CLMF_MULT_FUNC
**                FACETSXC :    N/A
**                CUSTOM   :
**                STAGE    :    tpzt_prime_claims_extr
**
**   PROCEDURES REFERENCED :    N/A
**                  FACETS :    N/A
**                  CUSTOM :    N/A
**
**   STANDARD LOGGING PROCS:    harcore.dbo.harsp_gen_util_job_hdr_lgr
**                              harcore.dbo.harsp_gen_util_job_ftr_lgr
**                              harcore.dbo.harsp_gen_util_step_hdr_lgr
**                              harcore.dbo.harsp_gen_util_step_ftr_lgr
**
**   REVISION HISTORY      :
**
**   VERSION   DATE         DEVELOPER       DESCRIPTION
**   -------   ----------   -------------   -------------------
**   1.0       03/15/2014   Irfan Mohammed  Initial version
**   1.1       05/15/2014   Irfan Mohammed  Updated the mapping for the feilds RELN_CDE,DNL_REM_CDE,TYP_OF_BILL_CDE,IN_NTWK_INDCTR,OTHR_INS_CDE,SRC_TYP_CDE,ITS_FLAG
****************************************************************/

AS

BEGIN

   /****************************************************************
   **          DECLARE LOCAL VARIABLES                            **
   ****************************************************************/
   DECLARE @lnRetCd                INT              -- Proc return code
   DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field
   DECLARE @lnCurrentStep          INT              -- Current Step Number
   DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time
   DECLARE @lnTotalSteps           INT              -- Total Steps In Proc
   DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name
   DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name
   DECLARE @lvcDBName              VARCHAR(32)      -- DB Name
   DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version
   DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name
   DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time
   DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step
   DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time
   DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time

   /****************************************************************
   **          INITIALIZE  VARIABLES                              **
   ****************************************************************/
    SELECT  @lnRetCd          = 0,
            @lvcMsg           = NULL,
            @lnCurrentStep    = 0,
            @lnTotalSteps     = 16,
            @ldtStepEndTime   = NULL,
            @lvcVersionNum    = '1.1'

    SELECT  @lvcServerName          = @@SERVERNAME,
            @lvcDBName              = DB_NAME(),
            @lvcUser                = USER_NAME(),
            @lvcObjectName          = OBJECT_NAME(@@PROCID),
            @ldtProcessStartTime    = GETDATE()

   /****************************************************************
   **               BEGIN PROCESS                                 **
   *****************************************************************/

    /**************  PRINT JOB HEADER DATA *************************/

    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr
        @pchObjectName        = @lvcObjectName,
        @pdtProcessStartTime  = @ldtProcessStartTime,
        @pchServerName        = @lvcServerName,
        @pchDBName            = @lvcDBName,
        @pchUserName          = @lvcUser,
        @pchVersionNum        = @lvcVersionNum

    /**************  PRINT STEP 1  HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_prime_claims_extr'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 1 Truncate Staging table tpzt_prime_claims_extr *************/

    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_prime_claims_extr

    /************* Error Checking for Truncating Staging table tpzt_prime_claims_extr *************/

    SELECT @lnRetCd    = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Truncating Staging table tpzt_prime_claims_extr FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 1 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed
 /**************  PRINT STEP 2 HEADER DATA *************************/  
  
    SELECT @lnCurrentStep    = @lnCurrentStep + 1,  
           @ldtStepStartTime = GETDATE(),  
           @lvcMsg           = @lvcObjectName + ': Populating the temp table #tpzt_prime_claims_extr_temp with required records'  
  
    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr  
        @pnStepNumber     = @lnCurrentStep,  
        @pdtStepStartTime = @ldtStepStartTime,  
        @pnTotalSteps     = @lnTotalSteps,  
        @pchStepMsg       = @lvcMsg  
  
    /************* STEP 2 Populating the temp table #tpzt_prime_claims_extr_temp with required records *************/  
   SELECT DISTINCT
        MEME_CK             = meme.MEME_CK,
        SBSB_CK             = sbsb.SBSB_CK,
        SBSB_ID             = sbsb.SBSB_ID,
        MEME_SFX            = meme.MEME_SFX,
        MEME_REL            = meme.MEME_REL,
        PRM_MBR_ID          = RIGHT('000000000' + CONVERT(VARCHAR, LTRIM(RTRIM(sbsb.SBSB_ID))), 9) + RIGHT('00' + CONVERT(VARCHAR, meme.MEME_SFX), 2),
        CLNT_MBR_ID         = RIGHT('000000000' + CONVERT(VARCHAR, LTRIM(RTRIM(sbsb.SBSB_ID))), 9) + RIGHT('00' + CONVERT(VARCHAR, meme.MEME_SFX), 2),
        CRDHLD_ID           = RIGHT('000000000' + CONVERT(VARCHAR, LTRIM(RTRIM(sbsb.SBSB_ID))), 9) + '00',
        PRSN_CDE            = RIGHT('00' + CONVERT(VARCHAR, meme.MEME_SFX), 2),
        RELN_CDE            = (select cw.TOPAZ_VALUE FROM fabncdv1stage.dbo.tpzt_vend_ext_common_cw cw where cw.VENDOR = 'PRIME' AND  cw.FACETS_VALUE = meme.MEME_REL),
        PAT_FRST_NME        = meme.MEME_FIRST_NAME,
        PAT_MID_NME         = meme.MEME_MID_INIT,
        PAT_LAST_NME        = meme.MEME_LAST_NAME,
        PAT_GNDR            = meme.MEME_SEX,
        PAT_ADDR1           = '',
        PAT_ADDR2           = '',
        PAT_DOB             = CONVERT(VARCHAR, meme.MEME_BIRTH_DT, 112),
        PAT_CITY            = '',
        PAT_STATE           = '',
        PAT_ZIP             = '',
        CLM_ID              = RIGHT('000000000000' + LTRIM(RTRIM(cdml.CLCL_ID)), 12),
        CLM_LN              = cdml.CDML_SEQ_NO,
        CLM_PYMT_ID         = CASE WHEN (clcl.CLCL_ID_ADJ_FROM <> ''  AND CLCL_ID_ADJ_TO='')
                                   THEN CAST(SUBSTRING(clcl.CLCL_ID,LEN(clcl.CLCL_ID)-1,2)AS SMALLINT)
                                   WHEN (clcl.CLCL_ID_ADJ_FROM = ''  AND CLCL_ID_ADJ_TO='')
                                   THEN '0'
                              END,
        EMGCY_ROOM_CDE      = CASE WHEN cdml.PSCD_ID = '23'
                                   THEN 'Y'
                                   ELSE 'N'
                              END,
        SVC_FROM_DTE        = CONVERT(VARCHAR, cdml.CDML_FROM_DT, 112),
        SVC_TO_DTE          = CONVERT(VARCHAR, cdml.CDML_TO_DT, 112),
        PAID_DTE            = CONVERT(VARCHAR, clcl.CLCL_PAID_DT, 112),
        CLNT_GRP_MAIN       = grgr.GRGR_ID,
        CLNT_GRP_SUB        = '',
        DNL_REM_CDE         = '',
        TYP_OF_BILL_CDE     = '',
        BILL_FORM_TYP       = CASE WHEN clcl.CLCL_CL_SUB_TYPE = 'H'
                                   THEN 'F'
                                   WHEN clcl.CLCL_CL_SUB_TYPE = 'M'
                                   THEN 'P'
                              END,
        FED_TAX_ID          = clcl.CLCL_PAYEE_PR_ID,
        BILL_PRVDR_NPI_CDE1 = '',
        BILL_PRVDR_NPI_CDE2 = '',
        BILL_PRVDR_TAXONOMY = '',
        SVC_PRVDR_NPI_CDE   = '',
        RNDR_PRVDR_NPI_CDE2 = '',
        RNDR_PRVDR_TAXONOMY = '',
        BILL_PRVDR_SPEC_CDE = '',
        SVC_PRVDR_SPEC_CDE  = cdml.PRCF_MCTR_SPEC,
        DIAG_REL_GRP_CDE    = cdml.IDCD_ID_REL,
        DRG_GROUPER_CDE     = '',
        ADMIT_DIAG_CDE      = '',
        IN_NTWK_INDCTR      = CASE WHEN clcl.CLCL_NTWK_IND = 'I'
                                   THEN 'I'
                                   WHEN clcl.CLCL_NTWK_IND = 'O'
                                   THEN 'O'
                                   ELSE 'U'
                              END,
        ICD9_PROC_CDE1      = '',
        ICD10_PROC_CDE1     = '',
        PROC_CDE            = cdml.IPCD_ID,
        PROC_MOD_CDE1       = SUBSTRING(cdml.IPCD_ID, LEN(cdml.IPCD_ID) - 1, 2),
        PROC_MOD_CDE2       = cdml.CDML_IPCD_MOD2,
        ICD9_LN_DIAG_CDE    = '',
        ICD9_DIAG_CDE1      = '',
        ICD9_DIAG_CDE2      = '',
        ICD9_DIAG_CDE3      = '',
        ICD9_DIAG_CDE4      = '',
        ICD10_LN_DIAG_CDE   = '',
        ICD10_DIAG_CDE1     = '',
        ICD10_DIAG_CDE2     = '',
        ICD10_DIAG_CDE3     = '',
        ICD10_DIAG_CDE4     = '',
        NBR_UNITS           = CAST(cdml.CDML_UNITS AS DECIMAL(9,2)),
        NDC                 = '',
        REVN_CDE            = cdml.RCRC_ID,
        PLC_SVC_CDE         = cdml.PSCD_ID,
        ADMIT_DTE           = '',
        DSCHG_DTE           = '',
        INPAT_SVC_DAY_NBR   = '',
        DSCHG_STAT_CDE      = '',
        CHARGE_AMT          = CAST(cdml.CDML_CHG_AMT AS DECIMAL(11,2)),
        COINS_AMT           = CAST(cdml.CDML_COINS_AMT AS DECIMAL(11,2)),
        COPAY_AMT           = CAST(cdml.CDML_COPAY_AMT AS DECIMAL(11,2)),
        DEDUCT_AMT          = CAST(cdml.CDML_DED_AMT AS DECIMAL(11,2)),
        NON_COVRD_AMT       = CAST(cdml.CDML_DISALL_AMT AS DECIMAL(11,2)),
        COVRD_PYMT_AMT      = CAST(cdml.CDML_ALLOW AS DECIMAL(11,2)),
        COB_PYMT_AMT        = '',
        PLAN_PAID_AMT       = CAST(cdml.CDML_PAID_AMT AS DECIMAL(11,2)),
        NTWK_DCNT_AMT       = CAST(cdml.CDML_DISC_AMT AS DECIMAL(11,2)),
        OTHR_INS_CDE        = '',
        PROD_TYP_CDE        = '',
        CLM_STAT_CDE        = CASE WHEN clcl.CLCL_CUR_STS='02'
                                    THEN 'P'
                                    ELSE 'D'
                                END,
        ORIG_CLM_ID         = clcl.CLCL_ID_ADJ_FROM,
        REVRS_CLM_ID        = '',
        NC_CLM_STAT_CDE     = clcl.CLCL_CUR_STS,
        ITS_FLAG            = CASE WHEN clcl.CLCL_PRE_PRICE_IND = 'H'
                                   THEN 'Y'
                                   ELSE 'N'
                              END,
        ICD_TYPE_CDE        = '',
        LOW_SVC_DT          = clcl.CLCL_LOW_SVC_DT,
        HIGH_SVC_DT         = clcl.CLCL_HIGH_SVC_DT,
        CLCL_PAYEE_PR_ID    = clcl.CLCL_PAYEE_PR_ID,
        CLCL_CL_SUB_TYPE    = clcl.CLCL_CL_SUB_TYPE,
        PRPR_ID             = clcl.PRPR_ID,
        GRGR_CK             = clcl.GRGR_CK,
        PDPD_ID             = clcl.PDPD_ID,
        IDCD_ID             = cdml.IDCD_ID,
        NWPR_PFX            = clcl.NWPR_PFX,    
        NWNW_ID             = clcl.NWNW_ID,
        TOT_CHG             = clcl.CLCL_TOT_CHG,
        TOT_PAYABLE         = clcl.CLCL_TOT_PAYABLE
        
        INTO #tpzt_prime_claims_extr_temp   
      
        FROM 
                   fabncdv1.dbo.CMC_CLCL_CLAIM clcl  
        INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr
                ON grgr.GRGR_CK = clcl.GRGR_CK
        INNER JOIN fabncdv1.dbo.CMC_GRRE_RELATION grre
                ON grgr.GRGR_CK = grre.GRGR_CK
               AND grre.GRRE_CATEGORY  = 'OT'
               AND grre.GRRE_MCTR_TYPE = 'SIZE'
        INNER JOIN fabncdv1.dbo.CMC_MCRE_RELAT_ENT mcre
                ON mcre.MCRE_ID = grre.MCRE_GRRE_ID
               AND mcre.MCRE_NAME IN ('SMALL GROUP')
        INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme
                ON clcl.MEME_CK = meme.MEME_CK
        INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb
                ON clcl.SBSB_CK = sbsb.SBSB_CK
        INNER JOIN fabncdv1.dbo.CMC_CDML_CL_LINE cdml
                ON clcl.CLCL_ID = cdml.CLCL_ID
               
        WHERE clcl.CLCL_CL_TYPE='M' 
          AND clcl.CLCL_CL_SUB_TYPE IN ('M','H') 
          AND clcl.CLCL_PAID_DT > DATEADD(MONTH,-1,GETDATE()) 
          AND clcl.CLCL_PAY_PR_IND = 'P'
  
    /************* Error Checking for Populating the temp table #tpzt_prime_claims_extr_temp with required records *************/  
  
    SELECT @lnRetCd         = @@ERROR,  
           @lnRowsProcessed = @@ROWCOUNT  
  
    IF  @lnRetCd <> 0  
        BEGIN  
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)  
            + ' : Populating the temp table #tpzt_prime_claims_extr_temp with required records FAILED'  
            + ' RETURNCODE: '  
            + CONVERT(CHAR(6),@lnRetCd)  
            PRINT  @lvcMsg  
            RETURN @lnRetCd  
        END  
  
    /**************  PRINT STEP 2 FOOTER DATA *************************/  
  
    SELECT @ldtStepEndTime = GETDATE()  
  
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr  
        @pdtStepStartTime    = @ldtStepStartTime,  
        @pdtStepEndTime      = @ldtStepEndTime,  
        @pdtProcessStartTime = @ldtProcessStartTime,  
        @pnRowCount          = @lnRowsProcessed  
        
        
  /**************  PRINT STEP 3 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg = @lvcObjectName + ': Populating the Staging table tpzt_prime_claims_extr with details of monthly Medical Claims'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 3 Populating the Staging table tpzt_prime_claims_extr with details of monthly Medical Claims *************/

    INSERT INTO fabncdv1stage.dbo.tpzt_prime_claims_extr
    (
        MEME_CK,
        SBSB_CK,
        SBSB_ID,
        MEME_SFX,
        MEME_REL,
        PRM_MBR_ID,
        CLNT_MBR_ID,
        CRDHLD_ID,
        PRSN_CDE,
        RELN_CDE,
        PAT_FRST_NME,
        PAT_MID_NME,
        PAT_LAST_NME,
        PAT_GNDR,
        PAT_ADDR1,
        PAT_ADDR2,
        PAT_DOB,
        PAT_CITY,
        PAT_STATE,
        PAT_ZIP,
        CLM_ID,
        CLM_LN,
        CLM_PYMT_ID,
        EMGCY_ROOM_CDE,
        SVC_FROM_DTE,
        SVC_TO_DTE,
        PAID_DTE,
        CLNT_GRP_MAIN,
        CLNT_GRP_SUB,
        DNL_REM_CDE,
        TYP_OF_BILL_CDE,
        BILL_FORM_TYP,
        FED_TAX_ID,
        BILL_PRVDR_NPI_CDE1,
        BILL_PRVDR_NPI_CDE2,
        BILL_PRVDR_TAXONOMY,
        SVC_PRVDR_NPI_CDE,
        RNDR_PRVDR_NPI_CDE2,
        RNDR_PRVDR_TAXONOMY,
        BILL_PRVDR_SPEC_CDE,
        SVC_PRVDR_SPEC_CDE,
        DIAG_REL_GRP_CDE,
        DRG_GROUPER_CDE,
        ADMIT_DIAG_CDE,
        IN_NTWK_INDCTR,
        ICD9_PROC_CDE1,
        ICD10_PROC_CDE1,
        PROC_CDE,
        PROC_MOD_CDE1,
        PROC_MOD_CDE2,
        ICD9_LN_DIAG_CDE,
        ICD9_DIAG_CDE1,
        ICD9_DIAG_CDE2,
        ICD9_DIAG_CDE3,
        ICD9_DIAG_CDE4,
        ICD10_LN_DIAG_CDE,
        ICD10_DIAG_CDE1,
        ICD10_DIAG_CDE2,
        ICD10_DIAG_CDE3,
        ICD10_DIAG_CDE4,
        NBR_UNITS,
        NDC,
        REVN_CDE,
        PLC_SVC_CDE,
        ADMIT_DTE,
        DSCHG_DTE,
        INPAT_SVC_DAY_NBR,
        DSCHG_STAT_CDE,
        CHARGE_AMT,
        COINS_AMT,
        COPAY_AMT,
        DEDUCT_AMT,
        NON_COVRD_AMT,
        COVRD_PYMT_AMT,
        COB_PYMT_AMT,
        PLAN_PAID_AMT,
        NTWK_DCNT_AMT,
        OTHR_INS_CDE,
        PROD_TYP_CDE,
        CLM_STAT_CDE,
        ORIG_CLM_ID,
        REVRS_CLM_ID,
        NC_CLM_STAT_CDE,
        ITS_FLAG,
        ICD_TYPE_CDE,
        LOW_SVC_DT,
        HIGH_SVC_DT,
        CLCL_PAYEE_PR_ID,
        CLCL_CL_SUB_TYPE,
        PRPR_ID,         
        GRGR_CK,         
        PDPD_ID,         
        IDCD_ID,
        NWPR_PFX,
        NWNW_ID,
        TOT_CHG,
        TOT_PAYABLE       
    )
   
    SELECT 
        MEME_CK,
        SBSB_CK,
        SBSB_ID,
        MEME_SFX,
        MEME_REL,
        PRM_MBR_ID,
        CLNT_MBR_ID,
        CRDHLD_ID,
        PRSN_CDE,
        RELN_CDE,
        PAT_FRST_NME,
        PAT_MID_NME,
        PAT_LAST_NME,
        PAT_GNDR,
        PAT_ADDR1,
        PAT_ADDR2,
        PAT_DOB,
        PAT_CITY,
        PAT_STATE,
        PAT_ZIP,
        CLM_ID,
        CLM_LN,
        CLM_PYMT_ID,
        EMGCY_ROOM_CDE,
        SVC_FROM_DTE,
        SVC_TO_DTE,
        PAID_DTE,
        CLNT_GRP_MAIN,
        CLNT_GRP_SUB,
        DNL_REM_CDE,
        TYP_OF_BILL_CDE,
        BILL_FORM_TYP,
        FED_TAX_ID,
        BILL_PRVDR_NPI_CDE1,
        BILL_PRVDR_NPI_CDE2,
        BILL_PRVDR_TAXONOMY,
        SVC_PRVDR_NPI_CDE,
        RNDR_PRVDR_NPI_CDE2,
        RNDR_PRVDR_TAXONOMY,
        BILL_PRVDR_SPEC_CDE,
        SVC_PRVDR_SPEC_CDE,
        DIAG_REL_GRP_CDE,
        DRG_GROUPER_CDE,
        ADMIT_DIAG_CDE,
        IN_NTWK_INDCTR,
        ICD9_PROC_CDE1,
        ICD10_PROC_CDE1,
        PROC_CDE,
        PROC_MOD_CDE1,
        PROC_MOD_CDE2,
        ICD9_LN_DIAG_CDE,
        ICD9_DIAG_CDE1,
        ICD9_DIAG_CDE2,
        ICD9_DIAG_CDE3,
        ICD9_DIAG_CDE4,
        ICD10_LN_DIAG_CDE,
        ICD10_DIAG_CDE1,
        ICD10_DIAG_CDE2,
        ICD10_DIAG_CDE3,
        ICD10_DIAG_CDE4,
        NBR_UNITS,
        NDC,
        REVN_CDE,
        PLC_SVC_CDE,
        ADMIT_DTE,
        DSCHG_DTE,
        INPAT_SVC_DAY_NBR,
        DSCHG_STAT_CDE,
        CHARGE_AMT,
        COINS_AMT,
        COPAY_AMT,
        DEDUCT_AMT,
        NON_COVRD_AMT,
        COVRD_PYMT_AMT,
        COB_PYMT_AMT,
        PLAN_PAID_AMT,
        NTWK_DCNT_AMT,
        OTHR_INS_CDE,
        PROD_TYP_CDE,
        CLM_STAT_CDE,
        ORIG_CLM_ID,
        REVRS_CLM_ID,
        NC_CLM_STAT_CDE,
        ITS_FLAG,
        ICD_TYPE_CDE,
        LOW_SVC_DT,
        HIGH_SVC_DT,
        CLCL_PAYEE_PR_ID,
        CLCL_CL_SUB_TYPE,
        PRPR_ID,         
        GRGR_CK,         
        PDPD_ID,         
        IDCD_ID,
        NWPR_PFX,
        NWNW_ID ,
        TOT_CHG,
        TOT_PAYABLE
        
        FROM #tpzt_prime_claims_extr_temp temp
        WHERE  temp.NC_CLM_STAT_CDE = '02'               
                   
    
    UNION 
    
    SELECT 
        MEME_CK,
        SBSB_CK,
        SBSB_ID,
        MEME_SFX,
        MEME_REL,
        PRM_MBR_ID,
        CLNT_MBR_ID,
        CRDHLD_ID,
        PRSN_CDE,
        RELN_CDE,
        PAT_FRST_NME,
        PAT_MID_NME,
        PAT_LAST_NME,
        PAT_GNDR,
        PAT_ADDR1,
        PAT_ADDR2,
        PAT_DOB,
        PAT_CITY,
        PAT_STATE,
        PAT_ZIP,
        CLM_ID,
        CLM_LN,
        CLM_PYMT_ID,
        EMGCY_ROOM_CDE,
        SVC_FROM_DTE,
        SVC_TO_DTE,
        PAID_DTE,
        CLNT_GRP_MAIN,
        CLNT_GRP_SUB,
        DNL_REM_CDE,
        TYP_OF_BILL_CDE,
        BILL_FORM_TYP,
        FED_TAX_ID,
        BILL_PRVDR_NPI_CDE1,
        BILL_PRVDR_NPI_CDE2,
        BILL_PRVDR_TAXONOMY,
        SVC_PRVDR_NPI_CDE,
        RNDR_PRVDR_NPI_CDE2,
        RNDR_PRVDR_TAXONOMY,
        BILL_PRVDR_SPEC_CDE,
        SVC_PRVDR_SPEC_CDE,
        DIAG_REL_GRP_CDE,
        DRG_GROUPER_CDE,
        ADMIT_DIAG_CDE,
        IN_NTWK_INDCTR,
        ICD9_PROC_CDE1,
        ICD10_PROC_CDE1,
        PROC_CDE,
        PROC_MOD_CDE1,
        PROC_MOD_CDE2,
        ICD9_LN_DIAG_CDE,
        ICD9_DIAG_CDE1,
        ICD9_DIAG_CDE2,
        ICD9_DIAG_CDE3,
        ICD9_DIAG_CDE4,
        ICD10_LN_DIAG_CDE,
        ICD10_DIAG_CDE1,
        ICD10_DIAG_CDE2,
        ICD10_DIAG_CDE3,
        ICD10_DIAG_CDE4,
        NBR_UNITS,
        NDC,
        REVN_CDE,
        PLC_SVC_CDE,
        ADMIT_DTE,
        DSCHG_DTE,
        INPAT_SVC_DAY_NBR,
        DSCHG_STAT_CDE,
        CHARGE_AMT,
        COINS_AMT,
        COPAY_AMT,
        DEDUCT_AMT,
        NON_COVRD_AMT,
        COVRD_PYMT_AMT,
        COB_PYMT_AMT,
        PLAN_PAID_AMT,
        NTWK_DCNT_AMT,
        OTHR_INS_CDE,
        PROD_TYP_CDE,
        CLM_STAT_CDE,
        ORIG_CLM_ID,
        REVRS_CLM_ID,
        NC_CLM_STAT_CDE,
        ITS_FLAG,
        ICD_TYPE_CDE,
        LOW_SVC_DT,
        HIGH_SVC_DT,
        CLCL_PAYEE_PR_ID,
        CLCL_CL_SUB_TYPE,
        PRPR_ID,         
        GRGR_CK,         
        PDPD_ID,         
        IDCD_ID,
        NWPR_PFX,
        NWNW_ID ,
        TOT_CHG,
        TOT_PAYABLE
        
        FROM #tpzt_prime_claims_extr_temp temp
          WHERE (temp.NC_CLM_STAT_CDE = '91' AND temp.COVRD_PYMT_AMT='0')
          
     UNION 
    
    SELECT 
           temp.MEME_CK,
        temp.SBSB_CK,
        temp.SBSB_ID,
        temp.MEME_SFX,
        temp.MEME_REL,
        temp.PRM_MBR_ID,
        temp.CLNT_MBR_ID,
        temp.CRDHLD_ID,
        temp.PRSN_CDE,
        temp.RELN_CDE,
        temp.PAT_FRST_NME,
        temp.PAT_MID_NME,
        temp.PAT_LAST_NME,
        temp.PAT_GNDR,
        temp.PAT_ADDR1,
        temp.PAT_ADDR2,
        temp.PAT_DOB,
        temp.PAT_CITY,
        temp.PAT_STATE,
        temp.PAT_ZIP,
        temp.CLM_ID,
        temp.CLM_LN,
        temp.CLM_PYMT_ID,
        temp.EMGCY_ROOM_CDE,
        temp.SVC_FROM_DTE,
        temp.SVC_TO_DTE,
        temp.PAID_DTE,
        temp.CLNT_GRP_MAIN,
        temp.CLNT_GRP_SUB,
        temp.DNL_REM_CDE,
        temp.TYP_OF_BILL_CDE,
        temp.BILL_FORM_TYP,
        temp.FED_TAX_ID,
        temp.BILL_PRVDR_NPI_CDE1,
        temp.BILL_PRVDR_NPI_CDE2,
        temp.BILL_PRVDR_TAXONOMY,
        temp.SVC_PRVDR_NPI_CDE,
        temp.RNDR_PRVDR_NPI_CDE2,
        temp.RNDR_PRVDR_TAXONOMY,
        temp.BILL_PRVDR_SPEC_CDE,
        temp.SVC_PRVDR_SPEC_CDE,
        temp.DIAG_REL_GRP_CDE,
        temp.DRG_GROUPER_CDE,
        temp.ADMIT_DIAG_CDE,
        temp.IN_NTWK_INDCTR,
        temp.ICD9_PROC_CDE1,
        temp.ICD10_PROC_CDE1,
        temp.PROC_CDE,
        temp.PROC_MOD_CDE1,
        temp.PROC_MOD_CDE2,
        temp.ICD9_LN_DIAG_CDE,
        temp.ICD9_DIAG_CDE1,
        temp.ICD9_DIAG_CDE2,
        temp.ICD9_DIAG_CDE3,
        temp.ICD9_DIAG_CDE4,
        temp.ICD10_LN_DIAG_CDE,
        temp.ICD10_DIAG_CDE1,
        temp.ICD10_DIAG_CDE2,
        temp.ICD10_DIAG_CDE3,
        temp.ICD10_DIAG_CDE4,
        temp.NBR_UNITS,
        temp.NDC,
        temp.REVN_CDE,
        temp.PLC_SVC_CDE,
        temp.ADMIT_DTE,
        temp.DSCHG_DTE,
        temp.INPAT_SVC_DAY_NBR,
        temp.DSCHG_STAT_CDE,
        temp.CHARGE_AMT,
        temp.COINS_AMT,
        temp.COPAY_AMT,
        temp.DEDUCT_AMT,
        temp.NON_COVRD_AMT,
        temp.COVRD_PYMT_AMT,
        temp.COB_PYMT_AMT,
        temp.PLAN_PAID_AMT,
        temp.NTWK_DCNT_AMT,
        temp.OTHR_INS_CDE,
        temp.PROD_TYP_CDE,
        temp.CLM_STAT_CDE,
        temp.ORIG_CLM_ID,
        temp.REVRS_CLM_ID,
        temp.NC_CLM_STAT_CDE,
        temp.ITS_FLAG,
        temp.ICD_TYPE_CDE,
        temp.LOW_SVC_DT,
        temp.HIGH_SVC_DT,
        temp.CLCL_PAYEE_PR_ID,
        temp.CLCL_CL_SUB_TYPE,
        temp.PRPR_ID,         
        temp.GRGR_CK,         
        temp.PDPD_ID,         
        temp.IDCD_ID,
        temp.NWPR_PFX,
        temp.NWNW_ID,
        temp.TOT_CHG,
        temp.TOT_PAYABLE
        
        FROM #tpzt_prime_claims_extr_temp temp
       INNER JOIN fabncdv1.dbo.CMC_CLCL_CLAIM clcl 
       ON temp.ORIG_CLM_ID = clcl.CLCL_ID
       AND clcl.CLCL_CUR_STS = '91' 
       WHERE temp.NC_CLM_STAT_CDE = '01'
       AND temp.ORIG_CLM_ID <> '' 
       AND temp.TOT_CHG = 0 
       AND temp.TOT_PAYABLE = 0  
             

    /************* Error Checking for Populating the Staging table tpzt_prime_claims_extr with details of monthly Medical Claims *************/

    SELECT @lnRetCd    = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Populating the Staging table tpzt_prime_claims_extr with details of monthly Medical Claims FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 3 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed



     /**************  PRINT STEP 4 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg = @lvcObjectName + ': Updating the Staging table tpzt_prime_claims_extr for the fields PAT_ADDR1, PAT_ADDR2, PAT_CITY, PAT_STATE, PAT_ZIP'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 4 Updating the Staging table tpzt_prime_claims_extr for the fields PAT_ADDR1, PAT_ADDR2, PAT_CITY, PAT_STATE, PAT_ZIP *************/

    ;WITH cte
    AS
    (
        SELECT extr.SBSB_CK, extr.MEME_CK, ENAD_ADDR1, ENAD_ADDR2, ENAD_CITY, ENAD_STATE, ENAD_ZIP
        FROM
                   fabncdv1stage.dbo.tpzt_prime_claims_extr extr
        INNER JOIN fabncdv1.dbo.FHP_PMED_MEMBER_D PMED
                ON PMED.PMED_ID = (extr.CLNT_GRP_MAIN + extr.SBSB_ID + CAST(extr.MEME_SFX AS VARCHAR(24)) + extr.MEME_REL)
        INNER JOIN fabncdv1.dbo.FHD_ENEN_ENTITY_D ENEN
                ON ENEN.ENEN_CKE = PMED.PMED_CKE
        INNER JOIN fabncdv1.dbo.FHD_ENAD_ADDRESS_D ENAD
                ON ENAD.ENEN_CKE = ENEN.ENEN_CKE
        INNER JOIN fabncdv1.dbo.FHP_PMCC_COMM_X PMCC
                ON PMCC.PMED_CKE = PMED.PMED_CKE

        WHERE GETDATE() BETWEEN PMCC.PMCC_EFF_DT AND PMCC.PMCC_TERM_DTM
    )

    UPDATE extr
    SET extr.PAT_ADDR1 = CASE WHEN cte.ENAD_ADDR1 IS NOT NULL AND LTRIM(RTRIM(cte.ENAD_ADDR1)) <> ''
                              THEN cte.ENAD_ADDR1
                              ELSE sbad.SBAD_ADDR1
                         END,
        extr.PAT_ADDR2 = CASE WHEN cte.ENAD_ADDR1 IS NOT NULL AND LTRIM(RTRIM(cte.ENAD_ADDR1)) <> ''
                              THEN cte.ENAD_ADDR2
                              ELSE sbad.SBAD_ADDR2
                         END,
        extr.PAT_CITY  = CASE WHEN cte.ENAD_ADDR1 IS NOT NULL AND LTRIM(RTRIM(cte.ENAD_ADDR1)) <> ''
                              THEN cte.ENAD_CITY
                              ELSE sbad.SBAD_CITY
                         END,
        extr.PAT_STATE = CASE WHEN cte.ENAD_ADDR1 IS NOT NULL AND LTRIM(RTRIM(cte.ENAD_ADDR1)) <> ''
                              THEN cte.ENAD_STATE
                              ELSE sbad.SBAD_STATE
                         END,
        extr.PAT_ZIP   = CASE WHEN cte.ENAD_ADDR1 IS NOT NULL AND LTRIM(RTRIM(cte.ENAD_ADDR1)) <> ''
                              THEN SUBSTRING(cte.ENAD_ZIP,1,5) + '-0000'
                              WHEN(sbad.SBAD_ZIP IS NOT NULL AND sbad.SBAD_ZIP <>'' )
                              THEN SUBSTRING(sbad.SBAD_ZIP,1,5) + '-0000'
                              ELSE ''
                         END
    FROM
              fabncdv1stage.dbo.tpzt_prime_claims_extr extr
    LEFT JOIN cte
           ON cte.SBSB_CK = extr.SBSB_CK
          AND cte.MEME_CK = extr.MEME_CK
    LEFT JOIN fabncdv1.dbo.CMC_SBAD_ADDR sbad
           ON extr.SBSB_CK = sbad.SBSB_CK
    LEFT JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme
           ON sbad.SBSB_CK = meme.SBSB_CK
          AND sbad.GRGR_CK = meme.GRGR_CK
          AND extr.MEME_CK = meme.MEME_CK
    WHERE sbad.SBAD_TYPE = meme.SBAD_TYPE_MAIL

    /***** Error Checking for Updating the Staging table tpzt_prime_claims_extr for the fields PAT_ADDR1, PAT_ADDR2, PAT_CITY, PAT_STATE, PAT_ZIP *****/

    SELECT @lnRetCd    = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Updating the Staging table tpzt_prime_claims_extr for the fields PAT_ADDR1, PAT_ADDR2, PAT_CITY, PAT_STATE, PAT_ZIP FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 4 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed
        
     /**************  PRINT STEP 5 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg = @lvcObjectName + ': Updating the Staging table tpzt_prime_claims_extr for the fields CLNT_GRP_SUB'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 5 Updating the Staging table tpzt_prime_claims_extr for the fields CLNT_GRP_SUB *************/

    UPDATE extr
    SET    CLNT_GRP_SUB = ISNULL(sgsg.SGSG_ID,'')
    FROM   fabncdv1stage.dbo.tpzt_prime_claims_extr extr
       INNER JOIN fabncdv1.dbo.CMC_SBSG_RELATION sbsg
       ON            sbsg.SBSB_CK = extr.SBSB_CK
       INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg
       ON         extr.SBSB_CK = sbsg.SBSB_CK 
       AND        sbsg.SGSG_CK = sgsg.SGSG_CK

    /***** Error Checking for Updating the Staging table tpzt_prime_claims_extr for the fields CLNT_GRP_SUB *****/

    SELECT @lnRetCd    = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Updating the Staging table tpzt_prime_claims_extr for the fields CLNT_GRP_SUB FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 5 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed
        
 /**************  PRINT STEP 6 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg = @lvcObjectName + ': Updating the Staging table tpzt_prime_claims_extr for the fields DNL_REM_CDE'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 6 Updating the Staging table tpzt_prime_claims_extr for the fields DNL_REM_CDE *************/

    UPDATE extr
    SET     DNL_REM_CDE =  CASE WHEN (cdmd.EXCD_ID IS NOT NULL AND cdmd.EXCD_ID <> '')
                                THEN cdmd.EXCD_ID + '-' + excd.EXCD_TYPE + '-' + 'FAC'
                                ELSE ''
                           END
                                
    FROM     fabncdv1stage.dbo.tpzt_prime_claims_extr extr
             INNER JOIN fabncdv1.dbo.CMC_CDMD_LI_DISALL cdmd
             ON extr.CLM_ID = RIGHT('000000000000' + LTRIM(RTRIM(cdmd.CLCL_ID)), 12)
             AND extr.CLM_LN = cdmd.CDML_SEQ_NO
             INNER JOIN fabncdv1.dbo.CMC_EXCD_EXPL_CD excd
             ON cdmd.EXCD_ID = excd.EXCD_ID
    WHERE   extr.NC_CLM_STAT_CDE = '91' AND cdmd.CDMD_TYPE = 'SE'

    /***** Error Checking for Updating the Staging table tpzt_prime_claims_extr for the fields DNL_REM_CDE *****/

    SELECT @lnRetCd    = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Updating the Staging table tpzt_prime_claims_extr for the fields DNL_REM_CDE FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 6 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed

 /**************  PRINT STEP 7 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg = @lvcObjectName + ': Updating the Staging table tpzt_prime_claims_extr for the fields BILL_PRVDR_NPI_CDE1,BILL_PRVDR_NPI_CDE2,BILL_PRVDR_TAXONOMY,BILL_PRVDR_SPEC_CDE'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 7 Updating the Staging table tpzt_prime_claims_extr for the fields BILL_PRVDR_NPI_CDE1,BILL_PRVDR_NPI_CDE2,BILL_PRVDR_TAXONOMY,BILL_PRVDR_SPEC_CDE *************/

    UPDATE extr
    SET     BILL_PRVDR_NPI_CDE1 = CASE WHEN extr.CLCL_CL_SUB_TYPE = 'M'
                                        THEN CASE WHEN  (prpr.PRPR_ENTITY='P' AND prpr.PRPR_NPI=prcp.PRCP_NPI)
                                                    THEN prpr.PRPR_NPI
                                                    ELSE prcp.PRCP_NPI
                                              END
                                        ELSE ''
                             END,
            BILL_PRVDR_NPI_CDE2 = CASE WHEN extr.CLCL_CL_SUB_TYPE = 'H'
                                            THEN CASE WHEN prpr.PRPR_ENTITY <> 'P' 
                                                           THEN prpr.PRPR_NPI 
                                                           ELSE '' 
                                                 END
                                       ELSE ''
                                   END,
            BILL_PRVDR_TAXONOMY = prpr.PRPR_TAXONOMY_CD,
            BILL_PRVDR_SPEC_CDE = prpr.PRCF_MCTR_SPEC
    FROM    fabncdv1stage.dbo.tpzt_prime_claims_extr extr
            INNER JOIN fabncdv1.dbo.CMC_PRPR_PROV prpr
            ON        prpr.PRPR_ID  =  extr.CLCL_PAYEE_PR_ID
            LEFT JOIN fabncdv1.dbo.CMC_PRCP_COMM_PRAC prcp
            ON        prcp.PRCP_ID=prpr.PRCP_ID

    /***** Error Checking for Updating the Staging table tpzt_prime_claims_extr for the fields BILL_PRVDR_NPI_CDE1,BILL_PRVDR_NPI_CDE2,BILL_PRVDR_TAXONOMY,BILL_PRVDR_SPEC_CDE *****/

    SELECT @lnRetCd    = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Updating the Staging table tpzt_prime_claims_extr for the fields BILL_PRVDR_NPI_CDE1,BILL_PRVDR_NPI_CDE2,BILL_PRVDR_TAXONOMY,BILL_PRVDR_SPEC_CDE FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 7 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed
        
   /**************  PRINT STEP 8 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg = @lvcObjectName + ': Updating the Staging table tpzt_prime_claims_extr for the fields SVC_PRVDR_NPI_CDE, RNDR_PRVDR_NPI_CDE2, RNDR_PRVDR_TAXONOMY, NDC'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 8 Updating the Staging table tpzt_prime_claims_extr for the fields SVC_PRVDR_NPI_CDE, RNDR_PRVDR_NPI_CDE2, RNDR_PRVDR_TAXONOMY, NDC *************/

    UPDATE extr
    SET    SVC_PRVDR_NPI_CDE = CASE WHEN extr.CLCL_CL_SUB_TYPE = 'M'
                                THEN ISNULL(cdsd.CDSD_PRPR_RE_NPI, '')
                                ELSE ''
                           END,
            RNDR_PRVDR_NPI_CDE2 = CASE WHEN extr.CLCL_CL_SUB_TYPE = 'H'
                                  THEN ISNULL(cdsd.CDSD_PRPR_RE_NPI, '')
                                  ELSE ''
                             END,
            RNDR_PRVDR_TAXONOMY = ISNULL(cdsd.CDSD_PRPR_RE_TAX, ''),
            NDC = ISNULL(cdsd.CDSD_NDC_CODE, '')
    FROM   fabncdv1stage.dbo.tpzt_prime_claims_extr extr
            INNER JOIN fabncdv1.dbo.CMC_CDSD_SUPP_DATA cdsd
                    ON extr.CLM_ID = RIGHT('000000000000' + LTRIM(RTRIM(cdsd.CLCL_ID)), 12)
                    AND extr.CLM_LN = cdsd.CDML_SEQ_NO

    /***** Error Checking for Updating the Staging table tpzt_prime_claims_extr for the fields SVC_PRVDR_NPI_CDE, RNDR_PRVDR_NPI_CDE2, RNDR_PRVDR_TAXONOMY, NDC *****/

    SELECT @lnRetCd    = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Updating the Staging table tpzt_prime_claims_extr for the fields SVC_PRVDR_NPI_CDE, RNDR_PRVDR_NPI_CDE2, RNDR_PRVDR_TAXONOMY, NDC FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 8 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed
        
  /**************  PRINT STEP 9 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg = @lvcObjectName + ': Updating the Staging table tpzt_prime_claims_extr for the fields DRG_GROUPER_CDE, TYP_OF_BILL_CDE, ADMIT_DTE, DSCHG_DTE, INPAT_SVC_DAY_NBR, DSCHG_STAT_CDE'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 9 Updating the Staging table tpzt_prime_claims_extr for the fields DRG_GROUPER_CDE, TYP_OF_BILL_CDE, ADMIT_DTE, DSCHG_DTE, INPAT_SVC_DAY_NBR, DSCHG_STAT_CDE *************/

    UPDATE extr
    SET    DRG_GROUPER_CDE = CASE WHEN extr.CLCL_CL_SUB_TYPE = 'H'
                              THEN ISNULL(clhp.AGRG_ID, '')
                              ELSE ''
                             END,
            TYP_OF_BILL_CDE = CASE WHEN extr.CLCL_CL_SUB_TYPE = 'H' AND clhp.CLHP_FAC_TYPE = '' AND clhp.CLHP_BILL_CLASS = '' AND clhp.CLHP_FREQUENCY = ''
                                    THEN ''
                                    WHEN extr.CLCL_CL_SUB_TYPE = 'H'
                                    THEN ISNULL(CAST(RIGHT(clhp.CLHP_FAC_TYPE,1) AS CHAR(01)), ' ') + ISNULL(CAST(clhp.CLHP_BILL_CLASS AS CHAR(01)), ' ') + ISNULL(CAST(clhp.CLHP_FREQUENCY AS CHAR(01)), ' ')
                                    ELSE ''
                                END,
            ADMIT_DTE = ISNULL(CONVERT(VARCHAR, clhp.CLHP_ADM_DT, 112), ''),
            DSCHG_DTE = ISNULL(CONVERT(VARCHAR, clhp.CLHP_DC_DT, 112), ''),
            INPAT_SVC_DAY_NBR = DATEDIFF(DAY, clhp.CLHP_ADM_DT, clhp.CLHP_DC_DT) + 1,
            DSCHG_STAT_CDE = ISNULL(clhp.CLHP_DC_STAT, '')
    FROM   fabncdv1stage.dbo.tpzt_prime_claims_extr extr
            INNER JOIN fabncdv1.dbo.CMC_CLHP_HOSP clhp
                ON extr.CLM_ID = RIGHT('000000000000' + LTRIM(RTRIM(clhp.CLCL_ID)), 12)

    /***** Error Checking for Updating the Staging table tpzt_prime_claims_extr for the fields DRG_GROUPER_CDE, TYP_OF_BILL_CDE, ADMIT_DTE, DSCHG_DTE, INPAT_SVC_DAY_NBR, DSCHG_STAT_CDE *****/

    SELECT @lnRetCd    = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Updating the Staging table tpzt_prime_claims_extr for the fields DRG_GROUPER_CDE, TYP_OF_BILL_CDE, ADMIT_DTE, DSCHG_DTE, INPAT_SVC_DAY_NBR, DSCHG_STAT_CDE FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 9 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed
        
     
   /**************  PRINT STEP 10 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg = @lvcObjectName + ': Updating the Staging table tpzt_prime_claims_extr for the fields ICD9_PROC_CDE1, ICD10_PROC_CDE1'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 10 Updating the Staging table tpzt_prime_claims_extr for the fields ICD9_PROC_CDE1, ICD10_PROC_CDE1 *************/

    UPDATE extr
    SET    ICD9_PROC_CDE1 = CASE WHEN (ipcd.IPCD_TYPE <> 'Y')
                             THEN extr.PROC_CDE
                             ELSE ''
                        END,                        
            ICD10_PROC_CDE1 = CASE WHEN (ipcd.IPCD_TYPE ='Y')
                             THEN extr.PROC_CDE
                             ELSE ''
                         END
    FROM   fabncdv1stage.dbo.tpzt_prime_claims_extr extr
            INNER JOIN fabncdv1.dbo.CMC_IPCD_PROC_CD ipcd
                    ON extr.PROC_CDE = ipcd.IPCD_ID
                

    /***** Error Checking for Updating the Staging table tpzt_prime_claims_extr for the fields ICD9_PROC_CDE1, ICD10_PROC_CDE1 *****/

    SELECT @lnRetCd    = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Updating the Staging table tpzt_prime_claims_extr for the fields ICD9_PROC_CDE1, ICD10_PROC_CDE1 FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 10 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed
        
 /**************  PRINT STEP 11 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg = @lvcObjectName + ': Updating the Staging table tpzt_prime_claims_extr for the fields ADMIT_DIAG_CDE, ICD9_LN_DIAG_CDE, ICD9_DIAG_CDE1, ICD9_DIAG_CDE2, ICD9_DIAG_CDE3, ICD9_DIAG_CDE4, ICD10_LN_DIAG_CDE, ICD10_DIAG_CDE1, ICD10_DIAG_CDE2, ICD10_DIAG_CDE3, ICD10_DIAG_CDE4'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 11 Updating the Staging table tpzt_prime_claims_extr for the fields ADMIT_DIAG_CDE, ICD9_LN_DIAG_CDE, ICD9_DIAG_CDE1, ICD9_DIAG_CDE2, ICD9_DIAG_CDE3, ICD9_DIAG_CDE4, ICD10_LN_DIAG_CDE, ICD10_DIAG_CDE1, ICD10_DIAG_CDE2, ICD10_DIAG_CDE3, ICD10_DIAG_CDE4 *************/

    UPDATE extr
    SET    ADMIT_DIAG_CDE = CASE WHEN clmd.CLMD_TYPE='AD'
                                THEN REPLACE(clmd.IDCD_ID, '.', '')
                                 ELSE ''
                            END,
            ICD9_LN_DIAG_CDE = CASE WHEN(idcd.IDCD_TYPE= 'I' AND (extr.IDCD_ID <> '' OR extr.IDCD_ID IS NOT NULL))
                                    THEN REPLACE(extr.IDCD_ID,'.','')
                                    ELSE ''
                                END,
           ICD9_DIAG_CDE1 = CASE WHEN (clmd.CLMD_TYPE= '01' AND idcd.IDCD_TYPE= 'I')
                                 THEN REPLACE(clmd.IDCD_ID,'.','')
                                 ELSE ''
                            END,                        
           ICD9_DIAG_CDE2 = CASE WHEN (clmd.CLMD_TYPE= '02' AND idcd.IDCD_TYPE= 'I')
                                 THEN REPLACE(clmd.IDCD_ID,'.','')
                                 ELSE ''
                            END,                        
           ICD9_DIAG_CDE3 = CASE WHEN (clmd.CLMD_TYPE= '03' AND idcd.IDCD_TYPE= 'I')
                                 THEN REPLACE(clmd.IDCD_ID,'.','')
                                 ELSE ''
                            END,                        
           ICD9_DIAG_CDE4 = CASE WHEN (clmd.CLMD_TYPE= '04' AND idcd.IDCD_TYPE= 'I')
                                 THEN REPLACE(clmd.IDCD_ID,'.','')
                                 ELSE ''
                            END,
           ICD10_LN_DIAG_CDE = CASE WHEN (idcd.IDCD_TYPE= 'T' AND (extr.IDCD_ID <> '' OR extr.IDCD_ID IS NOT NULL))
                                     THEN REPLACE(extr.IDCD_ID,'.','')
                                    ELSE ''
                               END,
           ICD10_DIAG_CDE1 = CASE WHEN (clmd.CLMD_TYPE= '01' AND idcd.IDCD_TYPE= 'T')
                                  THEN REPLACE(clmd.IDCD_ID,'.','')
                                  ELSE ''
                             END,
           ICD10_DIAG_CDE2 = CASE WHEN (clmd.CLMD_TYPE= '02' AND idcd.IDCD_TYPE= 'T')
                                  THEN REPLACE(clmd.IDCD_ID,'.','')
                                  ELSE ''
                             END,
           ICD10_DIAG_CDE3 = CASE WHEN (clmd.CLMD_TYPE= '03' AND idcd.IDCD_TYPE= 'T')
                                  THEN REPLACE(clmd.IDCD_ID,'.','')
                                  ELSE ''
                             END,                         
           ICD10_DIAG_CDE4 = CASE WHEN (clmd.CLMD_TYPE= '04' AND idcd.IDCD_TYPE= 'T')
                                  THEN REPLACE(clmd.IDCD_ID,'.','')
                                  ELSE ''
                             END
    FROM   fabncdv1stage.dbo.tpzt_prime_claims_extr extr
           INNER JOIN fabncdv1.dbo.CMC_IDCD_DIAG_CD idcd
                   ON extr.IDCD_ID = idcd.IDCD_ID
           INNER JOIN fabncdv1.dbo.CMC_CLMD_DIAG clmd
                   ON RIGHT('000000000000' + LTRIM(RTRIM(clmd.CLCL_ID)), 12) = extr.CLM_ID
       

    /***** Error Checking for Updating the Staging table tpzt_prime_claims_extr for the fields ADMIT_DIAG_CDE, ICD9_LN_DIAG_CDE, ICD9_DIAG_CDE1, ICD9_DIAG_CDE2, ICD9_DIAG_CDE3, ICD9_DIAG_CDE4, ICD10_LN_DIAG_CDE, ICD10_DIAG_CDE1, ICD10_DIAG_CDE2, ICD10_DIAG_CDE3, ICD10_DIAG_CDE4 *****/

    SELECT @lnRetCd    = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Updating the Staging table tpzt_prime_claims_extr for the fields ADMIT_DIAG_CDE, ICD9_LN_DIAG_CDE, ICD9_DIAG_CDE1, ICD9_DIAG_CDE2, ICD9_DIAG_CDE3, ICD9_DIAG_CDE4, ICD10_LN_DIAG_CDE, ICD10_DIAG_CDE1, ICD10_DIAG_CDE2, ICD10_DIAG_CDE3, ICD10_DIAG_CDE4 FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 11 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed
        
  /**************  PRINT STEP 12 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg = @lvcObjectName + ': Updating the Staging table tpzt_prime_claims_extr for the fields COB_PYMT_AMT'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 12 Updating the Staging table tpzt_prime_claims_extr for the fields COB_PYMT_AMT *************/
               
    UPDATE extr
    SET    COB_PYMT_AMT = ISNULL(cdcb.CDCB_COB_AMT,'')
    FROM   fabncdv1stage.dbo.tpzt_prime_claims_extr extr       
            INNER JOIN fabncdv1.dbo.CMC_CDCB_LI_COB cdcb
                    ON extr.CLM_ID = RIGHT('000000000000' + LTRIM(RTRIM(cdcb.CLCL_ID)), 12)
                    AND extr.CLM_LN = cdcb.CDML_SEQ_NO

    /***** Error Checking for Updating the Staging table tpzt_prime_claims_extr for the fields COB_PYMT_AMT *****/

    SELECT @lnRetCd    = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Updating the Staging table tpzt_prime_claims_extr for the fields COB_PYMT_AMT FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 12 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed
        
 /**************  PRINT STEP 13 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg = @lvcObjectName + ': Updating the Staging table tpzt_prime_claims_extr for the fields OTHR_INS_CDE'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 13 Updating the Staging table tpzt_prime_claims_extr for the fields OTHR_INS_CDE *************/
               
    UPDATE extr
    SET OTHR_INS_CDE = mecb.MECB_INSUR_TYPE 
    FROM       fabncdv1stage.dbo.tpzt_prime_claims_extr extr
    INNER JOIN fabncdv1.dbo.CMC_MECB_COB mecb
            ON extr.MEME_CK = mecb.MEME_CK
           AND extr.GRGR_CK = mecb.GRGR_CK
    WHERE mecb.MECB_INSUR_ORDER = 'P'
      AND CONVERT(DATETIME, extr.SVC_FROM_DTE) BETWEEN mecb.MECB_EFF_DT AND mecb.MECB_TERM_DT

    /***** Error Checking for Updating the Staging table tpzt_prime_claims_extr for the fields OTHR_INS_CDE *****/

    SELECT @lnRetCd    = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Updating the Staging table tpzt_prime_claims_extr for the fields OTHR_INS_CDE FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 13 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed
        
/**************  PRINT STEP 14 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg = @lvcObjectName + ': Updating the Staging table tpzt_prime_claims_extr for the fields PROD_TYP_CDE'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 14 Updating the Staging table tpzt_prime_claims_extr for the fields PROD_TYP_CDE *************/

    UPDATE extr
    SET    PROD_TYP_CDE = ISNULL(pdpd.PDDS_MCTR_BCAT, '')
    FROM   fabncdv1stage.dbo.tpzt_prime_claims_extr extr
           INNER JOIN fabncdv1.dbo.CMC_PDDS_PROD_DESC pdpd
                   ON extr.PDPD_ID = pdpd.PDPD_ID

    /***** Error Checking for Updating the Staging table tpzt_prime_claims_extr for the fields PROD_TYP_CDE *****/

    SELECT @lnRetCd    = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Updating the Staging table tpzt_prime_claims_extr for the fields PROD_TYP_CDE FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 14 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed
        
/**************  PRINT STEP 15 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg = @lvcObjectName + ': Updating the Staging table tpzt_prime_claims_extr for the fields ICD_TYPE_CDE'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 15 Updating the Staging table tpzt_prime_claims_extr for the fields ICD_TYPE_CDE *************/

  UPDATE extr
  SET    ICD_TYPE_CDE = CASE WHEN (clmf.CLMF_ICD_IND_PROC = '9')
                             THEN 'ICD-9'
                             ELSE 'ICD-10'
                        END
  FROM   fabncdv1stage.dbo.tpzt_prime_claims_extr extr
         INNER JOIN fabncdv1.dbo.CMC_CLMF_MULT_FUNC clmf
                 ON RIGHT('000000000000' + LTRIM(RTRIM(clmf.CLCL_ID)), 12) = extr.CLM_ID

    /***** Error Checking for Updating the Staging table tpzt_prime_claims_extr for the fields ICD_TYPE_CDE *****/

    SELECT @lnRetCd    = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Updating the Staging table tpzt_prime_claims_extr for the fields ICD_TYPE_CDE FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 15 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed

    END
/**************  PRINT STEP 16 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
           @ldtStepStartTime = GETDATE(),
           @lvcMsg = @lvcObjectName + ': Updating the Staging table tpzt_prime_claims_extr for the fields REVRS_CLM_ID'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
        @pnStepNumber     = @lnCurrentStep,
        @pdtStepStartTime = @ldtStepStartTime,
        @pnTotalSteps     = @lnTotalSteps,
        @pchStepMsg       = @lvcMsg

    /************* STEP 16 Updating the Staging table tpzt_prime_claims_extr for the fields REVRS_CLM_ID *************/

    UPDATE extr
    SET    REVRS_CLM_ID =  clcl.CLCL_ID
                                
    FROM tpzt_prime_claims_extr extr
        INNER JOIN fabncdv1.dbo.CMC_CLCL_CLAIM clcl 
        ON extr.ORIG_CLM_ID = clcl.CLCL_ID
       AND clcl.CLCL_CUR_STS = '91' 
       WHERE extr.NC_CLM_STAT_CDE = '01'
       AND extr.ORIG_CLM_ID <> '' 
       AND extr.TOT_CHG = '0.00' 
       AND extr.TOT_PAYABLE = '0.00'  

    /***** Error Checking for Updating the Staging table tpzt_prime_claims_extr for the fields REVRS_CLM_ID *****/

    SELECT @lnRetCd    = @@ERROR,
           @lnRowsProcessed = @@ROWCOUNT

    IF  @lnRetCd <> 0
        BEGIN
            SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
            + ' : Updating the Staging table tpzt_prime_claims_extr for the fields REVRS_CLM_ID FAILED'
            + ' RETURNCODE: '
            + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END

    /**************  PRINT STEP 16 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
        @pdtStepStartTime    = @ldtStepStartTime,
        @pdtStepEndTime      = @ldtStepEndTime,
        @pdtProcessStartTime = @ldtProcessStartTime,
        @pnRowCount          = @lnRowsProcessed
GO

/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_prime_claims_extr') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.tpzp_prime_claims_extr >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_prime_claims_extr >>>'
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/
