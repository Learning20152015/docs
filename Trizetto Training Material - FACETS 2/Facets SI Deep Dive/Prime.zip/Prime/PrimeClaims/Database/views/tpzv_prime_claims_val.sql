/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzv_prime_claims_val') IS NOT NULL
BEGIN
    DROP VIEW dbo.tpzv_prime_claims_val
    IF OBJECT_ID('dbo.tpzv_prime_claims_val') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.tpzv_prime_claims_val >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.tpzv_prime_claims_val >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/

CREATE VIEW dbo.tpzv_prime_claims_val

/****************************************************************
**   NAME                  : tpzv_prime_claims_val
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Views\Stage
**
**   FUNCTION              : This view is used to fetch the details of Facility Claims and Professional Claims for Prime
**
**   TABLES REFERENCED     :
**                FACETS   :
**                FACETSXC : N/A
**                CUSTOM   :
**                STAGE    : fabncdv1stage.dbo.tpzt_prime_claims_extr
**
**   REVISION HISTORY      :
**
**   VERSION   DATE         DEVELOPER            DESCRIPTION
**   -------   ----------   -------------        ------------------
**   1.0       03/25/2014   Irfan Mohammed       Initial Version
*********************************************************************/

AS

    SELECT
        'BCBSNC'                                                                +'|'+
        'nc_fac_dtl_'+LEFT(CONVERT(VARCHAR,GETDATE(),112),6)    +'_incr.txt'    +'|'+
        'nc_prof_dtl_'+LEFT(CONVERT(VARCHAR,GETDATE(),112),6)   +'_incr.txt'    +'|'+
        CONVERT(VARCHAR,GETDATE(),112)                                          +'|'+
        LTRIM(RTRIM(COUNT(*)))                                                  +'|'+
        LTRIM(RTRIM(SUM(CAST(extr.CHARGE_AMT AS NUMERIC(38,2)))))               +'|'+
        LTRIM(RTRIM(SUM(CAST(extr.PLAN_PAID_AMT AS NUMERIC(38,2)))))            +'|'+
        LTRIM(RTRIM(CONVERT(VARCHAR,MIN(extr.LOW_SVC_DT),112)))                 +'|'+
        LTRIM(RTRIM(CONVERT(VARCHAR,MAX(extr.HIGH_SVC_DT),112)))                +'|'+
        LTRIM(RTRIM(MIN(extr.PAID_DTE)))                                        +'|'+
        LTRIM(RTRIM(MAX(extr.PAID_DTE)))                                        AS VAL_DETAILS

    FROM  fabncdv1stage.dbo.tpzt_prime_claims_extr extr
    WHERE extr.BILL_FORM_TYP IN ('P','F')


GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzv_prime_claims_val') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.tpzv_prime_claims_val >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.tpzv_prime_claims_val >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/