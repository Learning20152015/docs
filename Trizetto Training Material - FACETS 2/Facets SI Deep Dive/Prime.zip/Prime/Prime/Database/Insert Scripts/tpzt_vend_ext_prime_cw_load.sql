/****************************************************************
**   NAME                  : tpzt_vend_ext_prime_cw_load
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\SQL\Stage
**
**   FUNCTION              : This Insert script is used to insert data into the crosswalk table
**                           tpzt_vend_ext_prime_cw that relates Facets CSPI_ID with Prime Plan Code
**
**   REVISION HISTORY      :
**
**   VERSION   DATE         DEVELOPER        DESCRIPTION
**   -------   ----------   -------------    ------------------
**   1.0       02/25/2014   Divya Anne       Initial Version
**   1.1       02/26/2014   Amit Payasi      Updated the values
****************************************************************/
    
    /***********   Truncate staging table tpzt_vend_ext_common_cw   ***********/

    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_vend_ext_prime_cw
    GO
    
    /*********************   End of TRUNCATE statement   **********************/

    /*******  Inserting data into  staging table tpzt_vend_ext_prime_cw  ******/
    
    INSERT INTO fabncdv1stage.dbo.tpzt_vend_ext_prime_cw VALUES
                                
        ('B0000069','BR000002','NCU4150BN'),
        ('B0000068','BR000002','NCU4150BN'),
        ('B0000003','BR000001','NCU41500N'),
        ('B0000001','BR000001','NCU41500N'),
        ('B0000002','BR000001','NCU41500N'),
        ('B0000005','BR000003','NCU03500N'),
        ('B0000006','BR000001','NCU43500N'),
        ('B0000004','BR000003','NCU03000N'),
        ('B0000008','BR000001','NCU44500N'),
        ('B0000011','BR000001','NCU44000N'),
        ('B0000010','BR000001','NCU44000N'),
        ('B0000007','BR000001','NCU43000N'),
        ('B0000009','BR000001','NCU43500N'),
        ('B0000078','BR000005','NCU0300BN')
        
    GO
    
    /*********************   End of INSERT statement   **********************/