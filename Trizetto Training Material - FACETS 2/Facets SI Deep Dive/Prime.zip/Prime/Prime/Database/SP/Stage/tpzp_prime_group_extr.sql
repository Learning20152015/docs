/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_prime_group_extr') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.tpzp_prime_group_extr
    IF OBJECT_ID('dbo.tpzp_prime_group_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_prime_group_extr >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_prime_group_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/

CREATE PROCEDURE [dbo].[tpzp_prime_group_extr]

/****************************************************************
**   NAME                  :    tpzp_prime_group_extr
**
**   PVCS LOCATION         :    
**
**   FUNCTION              :    populates the staging table tpzt_prime_grp_extr with the Groups data 
**                              who have active pharmacy eligibility either for daily extract or 
**                              monthly extract depending on the input parameter
**
**   PARAMETERS            :
**                  INPUT  :    @pRunFreq
**                  OUTPUT :    
**
**   RETURN CODES          :    0 on success
**
**   TABLES REFERENCED     :
**                FACETS   :    fabncdv1.dbo.CMC_PAGR_PARENT_GR
**                              fabncdv1.dbo.CMC_GRGR_GROUP
**                              fabncdv1.dbo.CMC_CSPI_CS_PLAN
**                FACETSXC :    N/A
**                CUSTOM   :    
**                STAGE    :    fabncdv1stage.dbo.tpzt_vend_ext_prime_cw
**
**   PROCEDURES REFERENCED :    N/A
**                  FACETS :    N/A
**                  CUSTOM :    N/A
**
**   STANDARD LOGGING PROCS:    harcore.dbo.harsp_gen_util_job_hdr_lgr
**                              harcore.dbo.harsp_gen_util_job_ftr_lgr
**                              harcore.dbo.harsp_gen_util_step_hdr_lgr
**                              harcore.dbo.harsp_gen_util_step_ftr_lgr
**
**   REVISION HISTORY      :
**
**   VERSION   DATE         DEVELOPER       DESCRIPTION
**   -------   ----------   -------------   -------------------
**   1.0       02/11/2014   Divya Anne      Initial version
**   1.1       02/24/2014   Divya Anne      Revised logic for CSPI_TERM_DT
**   1.2       02/25/2014   Divya Anne      Revised logic according to the updated Mapping
**   1.3       02/26/2014   Divya Anne      Revised logic w.r.t crosswalk table
**   1.4       02/26/2014   Divya Anne      Revised logic w.r.t crosswalk table and updated the revision history
**   1.5       04/05/2014   Divya Anne      Updated the selection criteria as per CR
**   1.6       04/16/2014   M Shweta Rao    Updated the selection criteria as per CR
****************************************************************/

(
    @pRunFreq       VARCHAR(10)
)

AS

BEGIN

   /****************************************************************
   **          DECLARE LOCAL VARIABLES                            **
   ****************************************************************/
   DECLARE @lnRetCd                INT              -- Proc return code
   DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field
   DECLARE @lnCurrentStep          INT              -- Current Step Number
   DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time
   DECLARE @lnTotalSteps           INT              -- Total Steps In Proc
   DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name
   DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name
   DECLARE @lvcDBName              VARCHAR(32)      -- DB Name
   DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version
   DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name
   DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time
   DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step
   DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time
   DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
   
   /****************************************************************
   **          INITIALIZE  VARIABLES                              **
   ****************************************************************/
    SELECT  @lnRetCd          = 0,
            @lvcMsg           = NULL,
            @lnCurrentStep    = 0,
            @lnTotalSteps     = CASE WHEN @pRunFreq = 'DAILY'
                                     THEN 6
                                     WHEN @pRunFreq = 'MONTHLY'
                                     THEN 2
                                END,
            @ldtStepEndTime   = NULL,
            @lvcVersionNum    = '1.6'
   
    SELECT  @lvcServerName          = @@SERVERNAME,
            @lvcDBName              = DB_NAME(),
            @lvcUser                = USER_NAME(),
            @lvcObjectName          = OBJECT_NAME(@@PROCID),
            @ldtProcessStartTime    = GETDATE()
      
   /****************************************************************
   **               BEGIN PROCESS                                 **
   *****************************************************************/
    
    /**************  PRINT JOB HEADER DATA *************************/
    
    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr
        @pchObjectName        = @lvcObjectName,
        @pdtProcessStartTime  = @ldtProcessStartTime,
        @pchServerName        = @lvcServerName,
        @pchDBName            = @lvcDBName,
        @pchUserName          = @lvcUser,
        @pchVersionNum        = @lvcVersionNum
      
     
    /********** Populate Staging table tpzt_prime_grp_extr with the records related to the Prime Daily Group Extract **********/
    
    IF UPPER(@pRunFreq) = 'DAILY'
        BEGIN
        
        /**************  PRINT STEP 1  HEADER DATA *************************/

        SELECT @lnCurrentStep    = @lnCurrentStep + 1,
               @ldtStepStartTime = GETDATE(),
               @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_prime_grp_extr_old'

        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
            @pnStepNumber     = @lnCurrentStep,
            @pdtStepStartTime = @ldtStepStartTime,
            @pnTotalSteps     = @lnTotalSteps,
            @pchStepMsg       = @lvcMsg
        
        /************* STEP 1 Truncate Staging table tpzt_prime_grp_extr_old *************/
            
        TRUNCATE TABLE fabncdv1stage.dbo.tpzt_prime_grp_extr_old
            
        /************* Error Checking for Truncating Staging table tpzt_prime_grp_extr_old *************/
        
        SELECT @lnRetCd    = @@ERROR,
               @lnRowsProcessed = @@ROWCOUNT

        IF  @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Truncating Staging table tpzt_prime_grp_extr_old FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END     
            
        /**************  PRINT STEP 1 FOOTER DATA *************************/

        SELECT @ldtStepEndTime = GETDATE()

        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime    = @ldtStepStartTime,
            @pdtStepEndTime      = @ldtStepEndTime,
            @pdtProcessStartTime = @ldtProcessStartTime,
            @pnRowCount          = @lnRowsProcessed
            
        /**************  PRINT STEP 2  HEADER DATA *************************/

        SELECT @lnCurrentStep    = @lnCurrentStep + 1,
               @ldtStepStartTime = GETDATE(),
               @lvcMsg = @lvcObjectName + ': Inserting data into Staging table tpzt_prime_grp_extr_old from Staging table tpzt_prime_grp_extr_new'

        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
            @pnStepNumber     = @lnCurrentStep,
            @pdtStepStartTime = @ldtStepStartTime,
            @pnTotalSteps     = @lnTotalSteps,
            @pchStepMsg       = @lvcMsg
        
        /************* STEP 2 Inserting data into Staging table tpzt_prime_grp_extr_old from Staging table tpzt_prime_grp_extr_new *************/
            
        INSERT INTO fabncdv1stage.dbo.tpzt_prime_grp_extr_old
        (
            GRP_ID,
            GRP_NAME,
            FROM_DT,
            THRU_DT,
            BENEFIT_CODE,
            GRP_CLIENT_DEF_DATA
        )
        SELECT
            GRP_ID,
            GRP_NAME,
            FROM_DT,
            THRU_DT,
            BENEFIT_CODE,
            GRP_CLIENT_DEF_DATA
            
        FROM    fabncdv1stage.dbo.tpzt_prime_grp_extr_new
            
        /************* Error Checking for Inserting data into Staging table tpzt_prime_grp_extr_old from Staging table tpzt_prime_grp_extr_new *************/
        
        SELECT @lnRetCd    = @@ERROR,
               @lnRowsProcessed = @@ROWCOUNT

        IF  @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Inserting data into Staging table tpzt_prime_grp_extr_old from Staging table tpzt_prime_grp_extr_new FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END 

        /**************  PRINT STEP 2 FOOTER DATA *************************/

        SELECT @ldtStepEndTime = GETDATE()

        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime    = @ldtStepStartTime,
            @pdtStepEndTime      = @ldtStepEndTime,
            @pdtProcessStartTime = @ldtProcessStartTime,
            @pnRowCount          = @lnRowsProcessed
            
        /**************  PRINT STEP 3  HEADER DATA *************************/

        SELECT @lnCurrentStep    = @lnCurrentStep + 1,
               @ldtStepStartTime = GETDATE(),
               @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_prime_grp_extr_new'

        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
            @pnStepNumber     = @lnCurrentStep,
            @pdtStepStartTime = @ldtStepStartTime,
            @pnTotalSteps     = @lnTotalSteps,
            @pchStepMsg       = @lvcMsg
        
        /************* STEP 3 Truncate Staging table tpzt_prime_grp_extr_new *************/
            
        TRUNCATE TABLE fabncdv1stage.dbo.tpzt_prime_grp_extr_new
            
        /************* Error Checking for Truncating Staging table tpzt_prime_grp_extr_new *************/
        
        SELECT @lnRetCd    = @@ERROR,
               @lnRowsProcessed = @@ROWCOUNT

        IF  @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Truncating Staging table tpzt_prime_grp_extr_new FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
            
        /**************  PRINT STEP 3 FOOTER DATA *************************/

        SELECT @ldtStepEndTime = GETDATE()

        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime    = @ldtStepStartTime,
            @pdtStepEndTime      = @ldtStepEndTime,
            @pdtProcessStartTime = @ldtProcessStartTime,
            @pnRowCount          = @lnRowsProcessed
        
        /**************  PRINT STEP 4 HEADER DATA *************************/

        SELECT @lnCurrentStep    = @lnCurrentStep + 1,
               @ldtStepStartTime = GETDATE(),
               @lvcMsg = @lvcObjectName + ': Populating the Staging table tpzt_prime_grp_extr_new'

        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
            @pnStepNumber     = @lnCurrentStep,
            @pdtStepStartTime = @ldtStepStartTime,
            @pnTotalSteps     = @lnTotalSteps,
            @pchStepMsg       = @lvcMsg
        
        /************* STEP 4 Populating the Staging table tpzt_prime_grp_extr_new *************/
            
        INSERT INTO fabncdv1stage.dbo.tpzt_prime_grp_extr_new
        (
            GRP_ID,
            GRP_NAME,
            FROM_DT,
            THRU_DT,
            BENEFIT_CODE,
            GRP_CLIENT_DEF_DATA
        )
        SELECT DISTINCT
            LEFT(grgr.GRGR_ID + SPACE(15) , 15),
            LEFT(LTRIM(RTRIM(grgr.GRGR_NAME)),25),
            CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_EFF_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_EFF_DT,112),3,6) AS DECIMAL(7)),
            CASE WHEN cspi.CSPI_EFF_DT = cspi.CSPI_TERM_DT
                 THEN CAST(SUBSTRING(CONVERT(VARCHAR,DATEADD(DD, -1, cspi.CSPI_TERM_DT),112),1,1)+ SUBSTRING(CONVERT(VARCHAR,DATEADD(DD, -1, cspi.CSPI_TERM_DT),112),3,6) AS DECIMAL(7))
                 WHEN CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7)) = 9991231
                 THEN 2391231
                 ELSE CAST(SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) AS DECIMAL(7))
            END,
            LTRIM(RTRIM(CASE WHEN LTRIM(RTRIM(ISNULL(pagr.PAGR_ID,''))) <> ''
                             THEN pagr.PAGR_ID
                             ELSE grgr.GRGR_ID
                        END)),
            LEFT(SPACE(16)+SUBSTRING(LTRIM(RTRIM(grgr.GRGR_ID)),1,8)+SUBSTRING(LTRIM(RTRIM(pagr.PAGR_ID)),1,9)+SPACE(256),256)
            
        FROM 
                   fabncdv1.dbo.CMC_PAGR_PARENT_GR pagr
        INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr
        ON         grgr.PAGR_CK = pagr.PAGR_CK
        INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi
        ON         cspi.GRGR_CK = grgr.GRGR_CK
        INNER JOIN fabncdv1stage.dbo.tpzt_vend_ext_prime_cw cw
        ON         cspi.CSPI_ID = cw.FACETS_MEDICAL
        AND        GETDATE() BETWEEN cw.TRANSLATION_EFFECTIVE_DATE AND cw.TRANSLATION_EXPIRATION_DATE
        WHERE 
            cspi.CSPD_CAT = 'M'
        AND cspi.CSPI_EFF_DT >= DATEADD(MM,-18,GETDATE())
        AND EXISTS
        (
            SELECT 1 FROM 
                       fabncdv1.dbo.CMC_PAGR_PARENT_GR pagr
            INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grp
            ON         grp.PAGR_CK = pagr.PAGR_CK
            INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi
            ON         cspi.GRGR_CK = grp.GRGR_CK
            INNER JOIN fabncdv1stage.dbo.tpzt_vend_ext_prime_cw cw
            ON         cspi.CSPI_ID = cw.FACETS_PHARMACY
            AND        GETDATE() BETWEEN cw.TRANSLATION_EFFECTIVE_DATE AND cw.TRANSLATION_EXPIRATION_DATE
            WHERE 
                cspi.CSPD_CAT = 'R'
            AND grp.GRGR_CK = grgr.GRGR_CK
        )
            
        /************* Error Checking for Populating the Staging table tpzt_prime_grp_extr_new *************/
        
        SELECT @lnRetCd    = @@ERROR,
               @lnRowsProcessed = @@ROWCOUNT

        IF  @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Populating the Staging table tpzt_prime_grp_extr_new FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
       
        /**************  PRINT STEP 4 FOOTER DATA *************************/

        SELECT @ldtStepEndTime = GETDATE()

        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime    = @ldtStepStartTime,
            @pdtStepEndTime      = @ldtStepEndTime,
            @pdtProcessStartTime = @ldtProcessStartTime,
            @pnRowCount          = @lnRowsProcessed
            
        /**************  PRINT STEP 5 HEADER DATA *************************/

        SELECT @lnCurrentStep    = @lnCurrentStep + 1,
               @ldtStepStartTime = GETDATE(),
               @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_prime_grp_extr'

        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
            @pnStepNumber     = @lnCurrentStep,
            @pdtStepStartTime = @ldtStepStartTime,
            @pnTotalSteps     = @lnTotalSteps,
            @pchStepMsg       = @lvcMsg
        
        /************* STEP 5 Truncate Staging table tpzt_prime_grp_extr *************/
            
        TRUNCATE TABLE fabncdv1stage.dbo.tpzt_prime_grp_extr
        
        /************* Error Checking for Truncating Staging table tpzt_prime_grp_extr *************/
            
        SELECT @lnRetCd    = @@ERROR,
               @lnRowsProcessed = @@ROWCOUNT

        IF  @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Truncating Staging table tpzt_prime_grp_extr FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
        
        /**************  PRINT STEP 5 FOOTER DATA *************************/

        SELECT @ldtStepEndTime = GETDATE()

        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime    = @ldtStepStartTime,
            @pdtStepEndTime      = @ldtStepEndTime,
            @pdtProcessStartTime = @ldtProcessStartTime,
            @pnRowCount          = @lnRowsProcessed
        
        /**************  PRINT STEP 6 HEADER DATA *************************/

        SELECT @lnCurrentStep    = @lnCurrentStep + 1,
               @ldtStepStartTime = GETDATE(),
               @lvcMsg = @lvcObjectName + ': Populate the Staging table tpzt_prime_grp_extr with Daily Records'

        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
            @pnStepNumber     = @lnCurrentStep,
            @pdtStepStartTime = @ldtStepStartTime,
            @pnTotalSteps     = @lnTotalSteps,
            @pchStepMsg       = @lvcMsg
                
        /************* STEP 6 Populate the Staging table tpzt_prime_grp_extr with Daily Records *************/
        
        INSERT INTO fabncdv1stage.dbo.tpzt_prime_grp_extr
        (
            GRP_ID,
            GRP_NAME,
            FROM_DT,
            THRU_DT,
            BENEFIT_CODE,
            GRP_CLIENT_DEF_DATA            
        )
        SELECT
            LEFT(curr.GRP_ID + SPACE(15), 15),
            LEFT(curr.GRP_NAME + SPACE(25),25),
            CAST(curr.FROM_DT AS VARCHAR),
            CAST(curr.THRU_DT AS VARCHAR),
            LEFT(curr.BENEFIT_CODE + SPACE(10), 10),
            LEFT(curr.GRP_CLIENT_DEF_DATA + SPACE(256), 256)
            
        FROM fabncdv1stage.dbo.tpzt_prime_grp_extr_new curr
        
        EXCEPT
        
        SELECT
            prev.GRP_ID,
            prev.GRP_NAME,
            prev.FROM_DT,
            prev.THRU_DT,
            prev.BENEFIT_CODE,
            prev.GRP_CLIENT_DEF_DATA  
        
        FROM fabncdv1stage.dbo.tpzt_prime_grp_extr_old prev
            
        /************* Error Checking for Populating the Staging table tpzt_prime_grp_extr with Daily Records *************/
        
        SELECT @lnRetCd    = @@ERROR,
               @lnRowsProcessed = @@ROWCOUNT

        IF  @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Populate the Staging table tpzt_prime_grp_extr with Daily Records FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
        
        /**************  PRINT STEP 6 FOOTER DATA *************************/

        SELECT @ldtStepEndTime = GETDATE()

        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime    = @ldtStepStartTime,
            @pdtStepEndTime      = @ldtStepEndTime,
            @pdtProcessStartTime = @ldtProcessStartTime,
            @pnRowCount          = @lnRowsProcessed
        
        END
   
    /********** Populate Staging table tpzt_prime_grp_extr with the records related to the Prime Monthly Group Extract **********/
    
    IF UPPER(@pRunFreq) = 'MONTHLY'
        BEGIN
        
        /**************  PRINT STEP 1 HEADER DATA *************************/

        SELECT @lnCurrentStep    = @lnCurrentStep + 1,
               @ldtStepStartTime = GETDATE(),
               @lvcMsg = @lvcObjectName + ': Truncate Staging table tpzt_prime_grp_extr'

        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
            @pnStepNumber     = @lnCurrentStep,
            @pdtStepStartTime = @ldtStepStartTime,
            @pnTotalSteps     = @lnTotalSteps,
            @pchStepMsg       = @lvcMsg
            
        /************* STEP 1 Truncate Staging table tpzt_prime_grp_extr *************/
        
        TRUNCATE TABLE fabncdv1stage.dbo.tpzt_prime_grp_extr
        
        /************* Error Checking for Truncating Staging table tpzt_prime_grp_extr *************/
        
        SELECT @lnRetCd    = @@ERROR,
               @lnRowsProcessed = @@ROWCOUNT

        IF  @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Truncating Staging table tpzt_prime_grp_extr FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
        
        /**************  PRINT STEP 1 FOOTER DATA *************************/

        SELECT @ldtStepEndTime = GETDATE()

        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime    = @ldtStepStartTime,
            @pdtStepEndTime      = @ldtStepEndTime,
            @pdtProcessStartTime = @ldtProcessStartTime,
            @pnRowCount          = @lnRowsProcessed
            
        /**************  PRINT STEP 2 HEADER DATA *************************/

        SELECT @lnCurrentStep    = @lnCurrentStep + 1,
               @ldtStepStartTime = GETDATE(),
               @lvcMsg = @lvcObjectName + ': Populate the Staging table tpzt_prime_grp_extr with Monthly Records'

        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
            @pnStepNumber     = @lnCurrentStep,
            @pdtStepStartTime = @ldtStepStartTime,
            @pnTotalSteps     = @lnTotalSteps,
            @pchStepMsg       = @lvcMsg
         
        /************* STEP 2 Populate the Staging table tpzt_prime_grp_extr with Monthly Records *************/
        
        INSERT INTO fabncdv1stage.dbo.tpzt_prime_grp_extr
        (   
            GRP_ID,
            GRP_NAME,
            FROM_DT,
            THRU_DT,
            BENEFIT_CODE,
            GRP_CLIENT_DEF_DATA
        )        
        SELECT DISTINCT
            LEFT(grgr.GRGR_ID + SPACE(15) , 15),
            LEFT(LTRIM(RTRIM(grgr.GRGR_NAME)) + SPACE(25), 25),
            SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_EFF_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_EFF_DT,112),3,6),
            CASE WHEN cspi.CSPI_EFF_DT = cspi.CSPI_TERM_DT
                 THEN SUBSTRING(CONVERT(VARCHAR,DATEADD(DD, -1, cspi.CSPI_TERM_DT),112),1,1)+ SUBSTRING(CONVERT(VARCHAR,DATEADD(DD, -1, cspi.CSPI_TERM_DT),112),3,6)
                 WHEN SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6) = '9991231'
                 THEN '2391231'
                 ELSE SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,cspi.CSPI_TERM_DT,112),3,6)
            END,
            LEFT(LTRIM(RTRIM(CASE WHEN LTRIM(RTRIM(ISNULL(pagr.PAGR_ID,''))) <> ''
                                  THEN pagr.PAGR_ID
                                  ELSE grgr.GRGR_ID
                             END)) + SPACE(10) , 10),
           LEFT(SPACE(16)+SUBSTRING(LTRIM(RTRIM(grgr.GRGR_ID)),1,8)+SUBSTRING(LTRIM(RTRIM(pagr.PAGR_ID)),1,9)+SPACE(256),256)
            
        FROM
                   fabncdv1.dbo.CMC_PAGR_PARENT_GR pagr
        INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr
        ON         grgr.PAGR_CK = pagr.PAGR_CK
               INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi
        ON         cspi.GRGR_CK = grgr.GRGR_CK
        INNER JOIN fabncdv1stage.dbo.tpzt_vend_ext_prime_cw cw
        ON         cspi.CSPI_ID = cw.FACETS_MEDICAL
        AND        GETDATE() BETWEEN cw.TRANSLATION_EFFECTIVE_DATE AND cw.TRANSLATION_EXPIRATION_DATE
        WHERE
            cspi.CSPD_CAT = 'M'
        AND EXISTS
        (
            SELECT 1 FROM 
                       fabncdv1.dbo.CMC_PAGR_PARENT_GR pagr
            INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grp
            ON         grp.PAGR_CK = pagr.PAGR_CK
            INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi
            ON         cspi.GRGR_CK = grp.GRGR_CK
            INNER JOIN fabncdv1stage.dbo.tpzt_vend_ext_prime_cw cw
            ON         cspi.CSPI_ID = cw.FACETS_PHARMACY
            AND        GETDATE() BETWEEN cw.TRANSLATION_EFFECTIVE_DATE AND cw.TRANSLATION_EXPIRATION_DATE
            WHERE 
                cspi.CSPD_CAT = 'R'
            AND grp.GRGR_CK = grgr.GRGR_CK
        )
        
        END 
    
        /************* Error Checking for Populating the Staging table tpzt_prime_grp_extr with Monthly Records *************/
        
        SELECT @lnRetCd    = @@ERROR,
               @lnRowsProcessed = @@ROWCOUNT

        IF  @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Populating the Staging table tpzt_prime_grp_extr with Monthly Records FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
        
        /**************  PRINT STEP 2 FOOTER DATA *************************/

        SELECT @ldtStepEndTime = GETDATE()

        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
            @pdtStepStartTime    = @ldtStepStartTime,
            @pdtStepEndTime      = @ldtStepEndTime,
            @pdtProcessStartTime = @ldtProcessStartTime,
            @pnRowCount          = @lnRowsProcessed
   
   
        /**************  PRINT JOB FOOTER DATA ****************************/

        SELECT @ldtProcessEndTime = GETDATE()
        
        EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr
            @pchObjectName         = @lvcObjectName,
            @pdtProcessStartTime   = @ldtProcessStartTime,
            @pdtProcessEndTime     = @ldtProcessEndTime
        RETURN  @lnRetCd
   
END

GO

/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_prime_group_extr') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.tpzp_prime_group_extr >>>'
ELSE
    PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_prime_group_extr >>>'
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/ 