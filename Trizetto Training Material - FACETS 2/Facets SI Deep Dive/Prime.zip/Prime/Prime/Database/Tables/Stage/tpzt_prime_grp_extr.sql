/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzt_prime_grp_extr') IS NOT NULL
BEGIN
    DROP TABLE dbo.tpzt_prime_grp_extr
    IF OBJECT_ID('dbo.tpzt_prime_grp_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_prime_grp_extr >>>'
    ELSE
        PRINT '<<< DROPPED TABLE dbo.tpzt_prime_grp_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/
/****************************************************************
**   NAME                  : tpzt_prime_grp_extr
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the records related to Prime Daily Group Extract or 
**                           Prime Monthly Group Extract depending on the parameter provided to the stored procedure
**
**   REVISION HISTORY      :
**
**   VERSION   DATE         DEVELOPER        DESCRIPTION
**   -------   ----------   -------------    ------------------
**   1.0       02/10/2014   Divya Anne       Initial Version
**   1.1       02/26/2014   Divya Anne       Modified GRP_CLIENT_DEF_DATA
**   1.2       04/21/2014   M Shweta Rao     Modified PLAN_ID
****************************************************************/
CREATE TABLE dbo.tpzt_prime_grp_extr
(
    CARRIER                         VARCHAR(9)            DEFAULT       'NC2000   ',
    ACCOUNT                         VARCHAR(15)           DEFAULT       'UWNSMAL        ',
    GRP_ID                          VARCHAR(15)           NULL,
    GRP_NAME                        VARCHAR(25)           NULL,
    ADDRESS_1                       VARCHAR(25)           DEFAULT       SPACE(25),
    ADDRESS_2                       VARCHAR(15)           DEFAULT       SPACE(15),
    CITY                            VARCHAR(20)           DEFAULT       SPACE(20),
    STATE_NAME                      VARCHAR(2)            DEFAULT       SPACE(2),
    ZIP_CODE_1                      VARCHAR(5)            DEFAULT       SPACE(5),
    ZIP_CODE_2                      VARCHAR(4)            DEFAULT       SPACE(4),
    ZIP_CODE_3                      VARCHAR(2)            DEFAULT       SPACE(2),
    COUNTRY                         VARCHAR(4)            DEFAULT       SPACE(4),
    PHONE_NO                        VARCHAR(10)           DEFAULT       '0000000000',
    CONTACT                         VARCHAR(25)           DEFAULT       SPACE(25),
    ORIG_FROM_DT                    VARCHAR(7)            DEFAULT       SPACE(7),
    BENEFIT_RESET_DT                VARCHAR(7)            DEFAULT       '0000000',
    SIC_CODE                        VARCHAR(4)            DEFAULT       '0000',
    LANG_CODE                       VARCHAR(1)            DEFAULT       SPACE(1),
    FROM_DT                         VARCHAR(7)            NULL,
    THRU_DT                         VARCHAR(7)            NULL,
    PLAN_ID                         VARCHAR(10)           DEFAULT       'NCGRPDEF  ',
    PLAN_EFF_DT                     VARCHAR(7)            DEFAULT       '2120101',
    BRAND                           VARCHAR(5)            DEFAULT       '00000',
    GENERIC                         VARCHAR(5)            DEFAULT       '00000',
    COPAY_3                         VARCHAR(5)            DEFAULT       '00000',
    COPAY_4                         VARCHAR(5)            DEFAULT       '00000',
    COPAY_5                         VARCHAR(5)            DEFAULT       '00000',
    COPAY_6                         VARCHAR(5)            DEFAULT       '00000',
    COPAY_7                         VARCHAR(5)            DEFAULT       '00000',
    COPAY_8                         VARCHAR(5)            DEFAULT       '00000',
    BENEFIT_CODE                    VARCHAR(10)           NULL,
    GRP_ID_CARD_DATA_FROM_DT        VARCHAR(7)            DEFAULT       '0000000',
    GRP_ID_CARD_DATA_THRU_DT        VARCHAR(7)            DEFAULT       '0000000',
    GRP_ID_CARD_LOGO                VARCHAR(5)            DEFAULT       SPACE(5),
    GRP_CARD_DATA                   VARCHAR(10)           DEFAULT       SPACE(10),
    DEPENDENT_AGE_FROM_DT           VARCHAR(7)            DEFAULT       '0000000',
    DEPENDENT_AGE_THRU_DT           VARCHAR(7)            DEFAULT       '0000000',
    DEPENDENT_AGE_MAX               VARCHAR(2)            DEFAULT       '00',
    DEPENDENT_DATE_QUALIFIER        VARCHAR(1)            DEFAULT       SPACE(1),
    DEPENDENT_ELIG_QUALIFIER        VARCHAR(1)            DEFAULT       SPACE(1),
    STUDENT_AGE_MAX                 VARCHAR(2)            DEFAULT       '00',
    STUDENT_DT_QUALIFIER            VARCHAR(1)            DEFAULT       SPACE(1),
    STUDENT_ELIG_QUALIFIER          VARCHAR(1)            DEFAULT       SPACE(1),
    OTHER_AGE_MAX                   VARCHAR(2)            DEFAULT       '00',
    OTHER_DT_QUALIFIER              VARCHAR(1)            DEFAULT       SPACE(1),
    OTHER_ELIG_QUALIFIER            VARCHAR(1)            DEFAULT       SPACE(1),
    FILLER_1                        VARCHAR(5)            DEFAULT       SPACE(5),
    GRP_CLIENT_DEF_DATA_EFF_DT      VARCHAR(7)            DEFAULT       '0000000',
    GRP_CLIENT_DEF_DATA_THR_DT      VARCHAR(7)            DEFAULT       '0000000',
    GRP_CLIENT_DEF_DATA             VARCHAR(256)          NULL,
    GRP_ID_CARD_TXT1                VARCHAR(30)           DEFAULT       SPACE(30),
    GRP_ID_CARD_TXT2                VARCHAR(30)           DEFAULT       SPACE(30),
    GRP_ID_CARD_TXT3                VARCHAR(30)           DEFAULT       SPACE(30),
    CLIENT_ID                       VARCHAR(9)            DEFAULT       SPACE(9),
    FILLER_2                        VARCHAR(1)            DEFAULT       SPACE(1)
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_prime_grp_extr') IS NOT NULL
    PRINT '<<< CREATED TABLE dbo.tpzt_prime_grp_extr >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE dbo.tpzt_prime_grp_extr >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/