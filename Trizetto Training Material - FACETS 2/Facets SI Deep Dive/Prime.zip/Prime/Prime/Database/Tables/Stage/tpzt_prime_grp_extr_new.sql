/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzt_prime_grp_extr_new') IS NOT NULL
BEGIN
    DROP TABLE dbo.tpzt_prime_grp_extr_new
    IF OBJECT_ID('dbo.tpzt_prime_grp_extr_new') IS NOT NULL
        PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_prime_grp_extr_new >>>'
    ELSE
        PRINT '<<< DROPPED TABLE dbo.tpzt_prime_grp_extr_new >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/
/****************************************************************
**   NAME                  : tpzt_prime_grp_extr_new
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This table is used to hold the present day records for Prime Daily Group Extract
**
**   REVISION HISTORY      :
**
**   VERSION   DATE         DEVELOPER       DESCRIPTION
**   -------   ----------   -------------   ------------------
**   1.0       02/10/2014   Divya Anne      Initial Version
**   1.1       02/26/2014   Divya Anne      Inserted column GRP_CLIENT_DEF_DATA
****************************************************************/
CREATE TABLE dbo.tpzt_prime_grp_extr_new
(
    GRP_ID              VARCHAR(15)           NULL,
    GRP_NAME            VARCHAR(25)           NULL,
    FROM_DT             DECIMAL(7)            NULL,
    THRU_DT             DECIMAL(7)            NULL,
    PLAN_ID             VARCHAR(10)           NULL,
    BENEFIT_CODE        VARCHAR(10)           NULL,
    GRP_CLIENT_DEF_DATA VARCHAR(256)          NULL
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_prime_grp_extr_new') IS NOT NULL
    PRINT '<<< CREATED TABLE dbo.tpzt_prime_grp_extr_new >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE dbo.tpzt_prime_grp_extr_new >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/