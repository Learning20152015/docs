/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzt_prime_meme_extr_new') IS NOT NULL
BEGIN
    DROP TABLE dbo.tpzt_prime_meme_extr_new
    IF OBJECT_ID('dbo.tpzt_prime_meme_extr_new') IS NOT NULL
        PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_prime_meme_extr_new >>>'
    ELSE
        PRINT '<<< DROPPED TABLE dbo.tpzt_prime_meme_extr_new >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/
/****************************************************************
**   NAME                  : tpzt_prime_meme_extr_new
**
**   DATABASE LOCATION     : Custom Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Custom
**
**   FUNCTION              : This table is used to hold the present day's records for Prime Daily Member Extract.
**
** REVISION HISTORY        :
**
** VERSION     DATE        DEVELOPER         DESCRIPTION
** -------- ----------   -------------    ------------------
**   1.0    02/10/2014   Amit Payasi       Initial Version
****************************************************************/
CREATE TABLE dbo.tpzt_prime_meme_extr_new
(
    PRIME_CARRIER                                   varchar(9)                      NULL,     
    PRIME_GROUP                                     varchar(15)                     NULL,
    EXTERNAL_MEMBER_ID                              varchar(18)                     NULL,
    PERSON_CODE                                     varchar(3)                      NULL,
    RELATIONSHIP_CODE                               varchar(1)                      NULL,
    LAST_NAME                                       varchar(25)                     NULL,
    FIRST_NAME                                      varchar(15)                     NULL,
    MIDDLE_NAME                                     varchar(1)                      NULL,
    SEX_CODE                                        varchar(1)                      NULL,
    BIRTH_DATE                                      decimal(8)                      NULL,    
    SOCIAL_SECURITY_NBR                             decimal(9)                      NULL,
    ADDRESS_LINE_1                                  varchar(40)                     NULL,
    ADDRESS_LINE_2                                  varchar(40)                     NULL,    
    CITY                                            varchar(20)                     NULL,
    STATE                                           varchar(2)                      NULL,
    ZIP_CODE                                        varchar(5)                      NULL,
    ZIP_CODE_2                                      varchar(4)                      NULL,    
    COUNTRY_CODE                                    varchar(4)                      NULL,    
    FAMILY_TYPE                                     varchar(1)                      NULL,
    FAMILY_ID                                       varchar(18)                     NULL,    
    FROM_DATE                                       decimal(7)                      NULL,
    THRU_DATE                                       decimal(7)                      NULL,
    [PLAN]                                          varchar(10)                     NULL    
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_prime_meme_extr_new') IS NOT NULL
    PRINT '<<< CREATED TABLE dbo.tpzt_prime_meme_extr_new >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE dbo.tpzt_prime_meme_extr_new >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/