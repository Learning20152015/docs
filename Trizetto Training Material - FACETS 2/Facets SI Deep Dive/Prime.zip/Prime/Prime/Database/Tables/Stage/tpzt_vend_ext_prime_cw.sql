/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzt_vend_ext_prime_cw') IS NOT NULL
BEGIN
    DROP TABLE dbo.tpzt_vend_ext_prime_cw
    IF OBJECT_ID('dbo.tpzt_vend_ext_prime_cw') IS NOT NULL
        PRINT '<<< FAILED DROPPING TABLE dbo.tpzt_vend_ext_prime_cw >>>'
    ELSE
        PRINT '<<< DROPPED TABLE dbo.tpzt_vend_ext_prime_cw >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/
/****************************************************************
**   NAME                  : tpzt_vend_ext_prime_cw
**
**   DATABASE LOCATION     : Stage Database
**
**   PVCS LOCATION         : Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Tables\Stage
**
**   FUNCTION              : This crosswalk table is used to map the Facets CSPI_ID with Prime Plan Code
**
**   REVISION HISTORY      :
**
**   VERSION   DATE         DEVELOPER        DESCRIPTION
**   -------   ----------   -------------    ------------------
**   1.0       02/25/2014   Divya Anne       Initial Version
**   1.1       02/26/2014   Amit Payasi      Included columns
****************************************************************/
CREATE TABLE dbo.tpzt_vend_ext_prime_cw
(
    FACETS_MEDICAL_CSPI_ID      VARCHAR(10)           NULL,
    FACETS_PHARMACY_CSPI_ID     VARCHAR(10)           NULL,
    PRIME_PLAN_CODE             VARCHAR(10)           NULL
)
GO
/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/
IF OBJECT_ID('dbo.tpzt_vend_ext_prime_cw') IS NOT NULL
    PRINT '<<< CREATED TABLE dbo.tpzt_vend_ext_prime_cw >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE dbo.tpzt_vend_ext_prime_cw >>>'
GO
/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/