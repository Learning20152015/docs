/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_prime_member_extr') IS NOT NULL
BEGIN
    DROP PROCEDURE dbo.tpzp_prime_member_extr
    IF OBJECT_ID('dbo.tpzp_prime_member_extr') IS NOT NULL
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_prime_member_extr >>>'
    ELSE
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_prime_member_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/

CREATE PROCEDURE [dbo].[tpzp_prime_member_extr]

/****************************************************************
**   NAME                  :    tpzp_prime_member_extr
**
**
**   PVCS LOCATION         :    
**
**   FUNCTION              :    The scope of this stored procedure is to extract membership/eligibility fixed length file from Facets for NC Plan 
                                and send it to Prime. Extract all the Groups and Members who have active pharmacy eligibility.
**
**   PARAMETERS            :
**                   INPUT :    @pRunFreq
**                  OUTPUT :    
**
**   RETURN CODES          :    0 on success
**
**   TABLES REFERENCED     :
**                FACETS   :    
**                FACETSXC :    N/A
**                CUSTOM   :    
**                STAGE    :    fabncdv1stage.dbo.tpzt_comm_elig_extr, fabncdv1stage.dbo.tpzt_vend_ext_common_cw
**
**   PROCEDURES REFERENCED :    N/A
**                  FACETS :    N/A
**                  CUSTOM :    N/A
**
**   STANDARD LOGGING PROCS:    harcore.dbo.harsp_gen_util_job_hdr_lgr
**                              harcore.dbo.harsp_gen_util_job_ftr_lgr
**                              harcore.dbo.harsp_gen_util_step_hdr_lgr
**                              harcore.dbo.harsp_gen_util_step_ftr_lgr
**
** REVISION HISTORY        :
**  VERSION    DATE        DEVELOPER        DESCRIPTION
** -------- ----------   --------------  -------------------
**    1.0   02/13/2014   Amit Payasi      Initial version
**    1.1   02/25/2014   Amit Payasi      Include current, previous(EXPIRATION DATE within the last 18 months) 
                                          and any future dated  benefit records for incremental extract 
**    1.2   02/26/2014   Amit Payasi      Process membership at the Certificate-level (all members written to extract for a certificate, or none written) 
**    1.3   02/28/2014   Amit Payasi      Changed version and developer history
**    1.4   02/28/2014   Divya.Anne       Revised Logic as per Review 
**    1.5   02/28/2014   Divya.Anne       Changed version and developer history 
**    1.6   03/28/2014   Shekhar Kadam    Added Custodial address field
**    1.7   03/31/2014   Shekhar Kadam    updated MEME_SFX with MEME_SFX_VCHAR field
**    1.8   03/01/2014   Amit Payasi      updated selection criteria based on cross walk table CR
**    1.9   04/16/2014   M Shweta Rao     updated selection criteria based on CR
**    1.10  04/22/2014   M Shweta Rao     Updated the Mapping for the field PHONE
**    1.11  04/28/2014   Divya Anne       Modified logic for ZIP_CODE and COUNTRY_CODE
**    1.12  04/29/2014   Shekhar Kadam  Full extracts is also for 18 months
**    1.13  05/01/2014   Shekhar Kadam    Adding record to  tpzt_prime_grp_extr_new stage table in monthly extract.
**    1.14  05/06/2014   Divya Anne       Updated the logic for COUNTRY_CODE and the Prime Plan Codes
**    1.15  05/07/2014   Shekhar Kadam    Updated the logic for EXPIRATION DATE within the last 18 months
**    1.16  05/09/2014   Shekhar Kadam    Dependent�s SSN blank then Use Subscriber�s SSN if Subscriber�s SSN is also blank then Zeroes
                                          and Any date greater than 2391231 is set equal to 2391231
**    1.17  05/14/2014   Shekhar Kadam    Updated the logic for through greater than 2391231 is set equal to 2391231
**    1.18  07/15/2014   Amit Payasi      Updated the logic for for cross walk table termination date
**    1.19  08/19/2014   Amit Payasi      Updated the logic for FROM_DATE and THRU_DATE
**    1.20  08/22/2014   Amit Payasi      Updated the logic to fix UAT issue
****************************************************************/

(
    @pRunFreq       VARCHAR(10)
)

AS

BEGIN


   /****************************************************************
   **          DECLARE LOCAL VARIABLES                            **
   ****************************************************************/
   DECLARE @lnRetCd                INT              -- Proc return code
   DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field
   DECLARE @lnCurrentStep          INT              -- Current Step Number
   DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time
   DECLARE @lnTotalSteps           INT              -- Total Steps In Proc
   DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name
   DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name
   DECLARE @lvcDBName              VARCHAR(32)      -- DB Name
   DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version
   DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name
   DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time
   DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step
   DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time
   DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
   
   /****************************************************************
   **          INITIALIZE  VARIABLES                              **
   ****************************************************************/
    SELECT  @lnRetCd          = 0,
            @lvcMsg           = NULL,
            @lnCurrentStep    = 0,
            @lnTotalSteps     = 2,
            @ldtStepEndTime   = NULL,
            @lvcVersionNum    = '1.20'
   
    SELECT  @lvcServerName          = @@SERVERNAME,
            @lvcDBName              = DB_NAME(),
            @lvcUser                = USER_NAME(),
            @lvcObjectName          = OBJECT_NAME(@@PROCID),
            @ldtProcessStartTime    = GETDATE()
      
   /****************************************************************
   **               BEGIN PROCESS                                 **
   *****************************************************************/
    
    /**************  PRINT JOB HEADER DATA *************************/
    
    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr
        @pchObjectName        = @lvcObjectName,
        @pdtProcessStartTime  = @ldtProcessStartTime,
        @pchServerName        = @lvcServerName,
        @pchDBName            = @lvcDBName,
        @pchUserName          = @lvcUser,
        @pchVersionNum        = @lvcVersionNum
      
      
   
   /**************  PRINT STEP 1  HEADER DATA *************************/

   SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime = GETDATE(),
      @lvcMsg = @lvcObjectName + ': Populate stage table tpzt_prime_meme_extr for Prime Daily member Extract'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
     @pnStepNumber     = @lnCurrentStep,
     @pdtStepStartTime = @ldtStepStartTime,
     @pnTotalSteps     = @lnTotalSteps,
     @pchStepMsg       = @lvcMsg

    /********** STEP 1 Populate stage table tpzt_prime_meme_extr for Prime Daily Group Extract **********/
    
    IF UPPER(@pRunFreq) = 'DAILY'
        BEGIN
        
        /************* STEP 1(a) Truncate stage table tpzt_prime_meme_extr_old *************/
        
        TRUNCATE TABLE fabncdv1stage.dbo.tpzt_prime_meme_extr_old
        
        /************* Error Checking for Truncating stage table tpzt_prime_meme_extr_old *************/
        
        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Truncating stage table tpzt_prime_meme_extr_old FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
        
        /************* STEP 1(b) Inserting data into stage table tpzt_prime_meme_extr_old from stage table tpzt_prime_meme_extr_new *************/
        
        INSERT INTO fabncdv1stage.dbo.tpzt_prime_meme_extr_old
        (
        
            PRIME_CARRIER,
            PRIME_GROUP,
            EXTERNAL_MEMBER_ID,
            PERSON_CODE,
            RELATIONSHIP_CODE,
            LAST_NAME,
            FIRST_NAME,
            MIDDLE_NAME,
            SEX_CODE,
            BIRTH_DATE,
            SOCIAL_SECURITY_NBR,
            ADDRESS_LINE_1,
            ADDRESS_LINE_2,
            CITY,
            STATE,
            ZIP_CODE,
            ZIP_CODE_2,
            COUNTRY_CODE,
            PHONE,
            FAMILY_TYPE,
            FAMILY_ID,
            FROM_DATE,
            THRU_DATE,
            [PLAN]                              
        )
        SELECT
            PRIME_CARRIER,
            PRIME_GROUP,
            EXTERNAL_MEMBER_ID,
            PERSON_CODE,
            RELATIONSHIP_CODE,
            LAST_NAME,
            FIRST_NAME,    
            MIDDLE_NAME,
            SEX_CODE,
            BIRTH_DATE,
            SOCIAL_SECURITY_NBR,
            ADDRESS_LINE_1,
            ADDRESS_LINE_2,
            CITY,
            STATE,
            ZIP_CODE,
            ZIP_CODE_2,
            COUNTRY_CODE,
            PHONE,
            FAMILY_TYPE,
            FAMILY_ID,
            FROM_DATE,
            THRU_DATE,
            [PLAN]
            
        FROM    fabncdv1stage.dbo.tpzt_prime_meme_extr_new                          
        
        /************* Error Checking for Inserting data into stage table tpzt_prime_meme_extr_old from stage table tpzt_prime_meme_extr_new *************/
        
        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Inserting data into stage table tpzt_prime_meme_extr_old from stage table tpzt_prime_meme_extr_new FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
            PRINT  @lvcMsg
            RETURN @lnRetCd
        END
   
        /************* STEP 1(c) Truncate stage table tpzt_prime_meme_extr_new *************/
        
        TRUNCATE TABLE fabncdv1stage.dbo.tpzt_prime_meme_extr_new
        
        /************* Error Checking for Truncating stage table tpzt_prime_meme_extr_new *************/
        
        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Truncating stage table tpzt_prime_meme_extr_new FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
      
        
        /************* STEP 1(d.1) Temporary table #Exclude_DY_SBSB_ID created to o    Exclude whole family from extract 
        if subscribers or member last name is blank and Exclude whole family from extract if subscribers or member external id ie SBSB_ID + MEME_SFX is blank  *************/  
        SELECT 
            DISTINCT elig.SBSB_ID
            INTO
                    #Exclude_DY_SBSB_ID
            FROM 
            fabncdv1stage.dbo.tpzt_comm_elig_extr elig
            WHERE(ISNULL(elig.SBSB_ID,'') = '' 
                    AND ISNULL(CAST(elig.MEME_SFX_VCHAR AS VARCHAR(10)),'')='')
                    OR LTRIM(RTRIM(isnull(elig.MEME_LAST_NAME,''))) = '' 
                    
                            
        /************* STEP 1(d) Populating the stage table tpzt_prime_meme_extr_new *************/  
        
        INSERT INTO fabncdv1stage.dbo.tpzt_prime_meme_extr_new
        (
            PRIME_CARRIER,
            PRIME_GROUP,
            EXTERNAL_MEMBER_ID,
            PERSON_CODE,
            RELATIONSHIP_CODE,
            LAST_NAME,
            FIRST_NAME,
            MIDDLE_NAME,
            SEX_CODE,
            BIRTH_DATE,
            SOCIAL_SECURITY_NBR,
            ADDRESS_LINE_1,
            ADDRESS_LINE_2,
            CITY,
            STATE,
            ZIP_CODE,
            ZIP_CODE_2,
            COUNTRY_CODE,
            PHONE,
            FAMILY_TYPE,
            FAMILY_ID,
            FROM_DATE,
            THRU_DATE,
            [PLAN]
        )
        SELECT
        
            DISTINCT   
            'NC2000   ',
            LEFT(elig.GRGR_ID + SPACE(15) , 15),
            LEFT(CONCAT( elig.SBSB_ID,elig.MEME_SFX_VCHAR)+ SPACE(18) , 18) AS SBSB_ID_MEME_SFX,
            LEFT(CAST(elig.MEME_SFX_VCHAR AS VARCHAR(3))+ SPACE(3),3),
            LEFT(elig.MEME_REL + SPACE(1),1),
            LEFT(elig.MEME_LAST_NAME + SPACE(25),25),
            LEFT(elig.MEME_FIRST_NAME + SPACE(15),15),
            LEFT(elig.MEME_MID_INIT + SPACE(1),1),
            LEFT(elig.MEME_SEX + SPACE(1),1),
            CAST(convert(varchar,elig.MEME_BIRTH_DT,112) AS DECIMAL(8)),           
            --CASE WHEN LTRIM(RTRIM(elig.MEME_SSN)) IS NOT NULL
            --     THEN elig.MEME_SSN
            --     ELSE 0
            --END,
            CASE WHEN LTRIM(RTRIM(elig.MEME_SSN)) IS NOT NULL AND LTRIM(RTRIM(elig.MEME_SSN)) <> '' 
                 THEN elig.MEME_SSN 
                 ELSE '000000000' 
            END, 
            CASE WHEN elig.ENAD_ADDR1  IS NOT NULL AND LTRIM(RTRIM(elig.ENAD_ADDR1)) <> ''
                 THEN LEFT(elig.ENAD_ADDR1 + SPACE(40),40)
                 WHEN elig.MCRP_ADDR1 IS NOT NULL  AND LTRIM(RTRIM(elig.MCRP_ADDR1)) <> ''
                 THEN LEFT(elig.MCRP_ADDR1 + SPACE(40),40)
                 ELSE  LEFT(elig.SBAD_ADDR1 + SPACE(40),40)
            END ,
            CASE WHEN elig.ENAD_ADDR1  IS NOT NULL AND LTRIM(RTRIM(elig.ENAD_ADDR1)) <> ''
                 THEN LEFT(elig.ENAD_ADDR2 + SPACE(40),40)
                 WHEN elig.MCRP_ADDR1 IS NOT NULL  AND LTRIM(RTRIM(elig.MCRP_ADDR1)) <> ''
                 THEN LEFT(elig.MCRP_ADDR2 + SPACE(40),40)
                 ELSE LEFT(elig.SBAD_ADDR2 + SPACE(40),40)
            END,           
            CASE WHEN elig.ENAD_ADDR1  IS NOT NULL AND LTRIM(RTRIM(elig.ENAD_ADDR1)) <> ''
                 THEN LEFT(elig.ENAD_CITY + SPACE(20),20)
                 WHEN elig.MCRP_ADDR1 IS NOT NULL  AND LTRIM(RTRIM(elig.MCRP_ADDR1)) <> ''
                 THEN LEFT(elig.MCRP_CITY + SPACE(20),20)
                 ELSE LEFT(elig.SBAD_CITY + SPACE(20),20)
            END,
            CASE WHEN elig.ENAD_ADDR1  IS NOT NULL AND LTRIM(RTRIM(elig.ENAD_ADDR1)) <> ''
                 THEN LEFT(elig.ENAD_STATE + SPACE(2),2)
                 WHEN elig.MCRP_ADDR1 IS NOT NULL  AND LTRIM(RTRIM(elig.MCRP_ADDR1)) <> ''
                 THEN LEFT(elig.MCRP_STATE + SPACE(2),2)
                 ELSE LEFT(elig.SBAD_STATE + SPACE(2),2)
            END,
            CASE WHEN elig.ENAD_ADDR1  IS NOT NULL AND LTRIM(RTRIM(elig.ENAD_ADDR1)) <> ''
                 THEN LEFT(CAST(elig.ENAD_ZIP AS VARCHAR(5))+SPACE(5),5)
                 WHEN elig.MCRP_ADDR1 IS NOT NULL  AND LTRIM(RTRIM(elig.MCRP_ADDR1)) <> ''
                 THEN LEFT(CAST(elig.MCRP_ZIP AS VARCHAR(5))+SPACE(5),5)
                 ELSE LEFT(CAST(elig.SBAD_ZIP AS VARCHAR(5))+SPACE(5),5)
            END,
            SPACE(4),                   
            CASE WHEN elig.ENAD_ADDR1  IS NOT NULL AND LTRIM(RTRIM(elig.ENAD_ADDR1)) <> '' AND elig.ENAD_CTRY_CD <> 'USA'
                 THEN LEFT(elig.ENAD_CTRY_CD + SPACE(4),4)
                 WHEN elig.MCRP_ADDR1 IS NOT NULL AND LTRIM(RTRIM(elig.MCRP_ADDR1)) <> '' AND elig.MCRP_CTRY_CD <> 'USA'
                 THEN LEFT(elig.MCRP_CTRY_CD + SPACE(4),4)
                 WHEN elig.SBAD_ADDR1 IS NOT NULL AND LTRIM(RTRIM(elig.SBAD_ADDR1)) <> '' AND elig.SBAD_CTRY_CD <> 'USA'
                 THEN LEFT(elig.SBAD_CTRY_CD + SPACE(4),4)
                 ELSE SPACE(4)
            END,
            LEFT(LTRIM(RTRIM(elig.MEME_CELL_PHONE)) + SPACE(10), 10),           
            SPACE(1),
            LEFT(CAST(elig.SBSB_ID AS VARCHAR(18))  + SPACE(18),18),            
            CASE WHEN grgr.GRGR_CURR_ANNV_DT >= elig.MEPE_EFF_DT
                 THEN CAST(SUBSTRING(CONVERT(VARCHAR,grgr.GRGR_CURR_ANNV_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,grgr.GRGR_CURR_ANNV_DT,112),3,6) AS DECIMAL(7))
                 ELSE CAST(SUBSTRING(CONVERT(VARCHAR,elig.MEPE_EFF_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,elig.MEPE_EFF_DT,112),3,6) AS DECIMAL(7))
            END,
            CASE WHEN grgr.GRGR_NEXT_ANNV_DT >= elig.MEPE_TERM_DT
                 THEN CAST(SUBSTRING(CONVERT(VARCHAR,elig.MEPE_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,elig.MEPE_TERM_DT,112),3,6) AS DECIMAL(7))
                 WHEN grgr.GRGR_NEXT_ANNV_DT IN ('1753-01-01 00:00:00.000','9999-12-31 00:00:00.000')  
                 THEN 2391231
                 ELSE CAST(SUBSTRING(CONVERT(VARCHAR,DATEADD(DD, -1, grgr.GRGR_NEXT_ANNV_DT),112),1,1)+ SUBSTRING(CONVERT(VARCHAR,DATEADD(DD, -1, grgr.GRGR_NEXT_ANNV_DT),112),3,6) AS DECIMAL(7))
            END,
            LEFT(CAST(xwk.PRIME_PHARMACY AS VARCHAR(10))  + SPACE(10),10)
            
        FROM fabncdv1stage.dbo.tpzt_comm_elig_extr elig
        INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr
        ON grgr.GRGR_CK = elig.GRGR_CK
        INNER JOIN fabncdv1stage.dbo.tpzt_vend_ext_prime_cw xwk
        ON  elig.CSPI_ID= xwk.FACETS_MEDICAL AND xwk.TRANSLATION_EXPIRATION_DATE >= DATEADD(MM,-18,GETDATE())
        WHERE elig.CSPD_CAT = 'M'             
            AND EXISTS 
            ( 
                SELECT 1 FROM fabncdv1stage.dbo.tpzt_comm_elig_extr comm 
                INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr
                ON grgr.GRGR_CK = comm.GRGR_CK
                INNER JOIN fabncdv1stage.dbo.tpzt_vend_ext_prime_cw cw 
                ON comm.CSPI_ID = cw.FACETS_PHARMACY
                AND xwk.FACETS_MEDICAL = cw.FACETS_MEDICAL
                AND xwk.PRIME_PHARMACY = cw.PRIME_PHARMACY
                AND cw.TRANSLATION_EXPIRATION_DATE >= DATEADD(MM,-18,GETDATE())  
                WHERE comm.CSPD_CAT = 'R' 
                    AND comm.SBSB_ID = elig.SBSB_ID 
            )            
            AND NOT EXISTS
            (SELECT 1 FROM #Exclude_DY_SBSB_ID tmp WHERE 
            elig.SBSB_ID=tmp.SBSB_ID)
            AND
             elig.MEPE_TERM_DT >= DATEADD(MM,-18,GETDATE())
			AND xwk.HDHP_CERTIFICATE_TYPE = CASE WHEN (SELECT COUNT(MEME.MEME_CK) AS FMLY_NO FROM fabncdv1.dbo.CMC_MEME_MEMBER MEME 
														WHERE MEME.SBSB_CK = elig.SBSB_CK 
														AND (elig.MEPE_EFF_DT BETWEEN GETDATE() AND elig.MEPE_TERM_DT
														OR GETDATE() BETWEEN elig.MEPE_EFF_DT AND elig.MEPE_TERM_DT )
														GROUP BY MEME.SBSB_CK) > 1  
												THEN CASE WHEN xwk.HDHP_CERTIFICATE_TYPE = 'FMLY' THEN 'FMLY'
													WHEN xwk.HDHP_CERTIFICATE_TYPE = '' THEN ''
													END
											WHEN (SELECT COUNT(MEME.MEME_CK) AS FMLY_NO FROM fabncdv1.dbo.CMC_MEME_MEMBER MEME 
														WHERE MEME.SBSB_CK = elig.SBSB_CK 
														AND (elig.MEPE_EFF_DT BETWEEN GETDATE() AND elig.MEPE_TERM_DT
														OR GETDATE() BETWEEN elig.MEPE_EFF_DT AND elig.MEPE_TERM_DT )
														GROUP BY MEME.SBSB_CK) = 1 
												THEN CASE WHEN xwk.HDHP_CERTIFICATE_TYPE = 'INDV' THEN 'INDV'
													WHEN xwk.HDHP_CERTIFICATE_TYPE = '' THEN ''
													END
											END
 
			
			 
            
         /************* Dropping Temporary table  #Exclude_DY_SBSB_ID*************/         
         DROP TABLE #Exclude_DY_SBSB_ID
            
        /************* Error Checking for Truncating stage table tpzt_prime_meme_extr *************/
        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Populating the stage table tpzt_prime_meme_extr_new '
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END



        /************* STEP 1(h) Update tpzt_prime_meme_extr to get if subscriber has dependent or not *************/
        
        UPDATE fabncdv1stage.dbo.tpzt_prime_meme_extr_new 
        SET FAMILY_TYPE = CASE WHEN Outer_Qry.MEM_CNT > 1 
                               THEN 1
                               ELSE 2
                          END
        FROM (SELECT MAIN.SBSB_ID,
                    COUNT(MAIN.MEME_CK) AS MEM_CNT
                    FROM
                    (
                        SELECT DISTINCT
                        sbsc.MEME_CK,
                        sbsc.SBSB_ID  
                        FROM tpzt_comm_elig_extr sbsc        
                    ) MAIN
                    GROUP BY MAIN.SBSB_ID
                ) Outer_Qry
                            
        INNER JOIN fabncdv1stage.dbo.tpzt_prime_meme_extr_new elig 
        ON Outer_Qry.SBSB_ID = elig.FAMILY_ID
        
        
        
                            
        /************* Error Checking for Update tpzt_prime_meme_extr to get if subscriber has dependent or not *************/
        
        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Update tpzt_prime_meme_extr to get if subscriber has dependent or not FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
            
            
          
          /************* Error Checking for Update tpzt_prime_meme_extr to get if subscriber has dependent or not *************/
        
        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Update tpzt_prime_meme_extr to get if subscriber has dependent or not FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
            
            
         /************* STEP 1(h) Update tpzt_prime_meme_extr to get RELATIONSHIP values from crosswalk table *************/
        
        UPDATE fabncdv1stage.dbo.tpzt_prime_meme_extr_new
        SET  RELATIONSHIP_CODE = CASE WHEN cmn.FACETS_VALUE NOT IN ('M','H','W','S','D','O')
                                      THEN '4'
                                      ELSE cmn.TOPAZ_VALUE
                                 END
        FROM    fabncdv1stage.dbo.tpzt_prime_meme_extr_new meme
        INNER JOIN tpzt_vend_ext_common_cw cmn 
        ON  meme.RELATIONSHIP_CODE=cmn.FACETS_VALUE
        WHERE cmn.VENDOR = 'PRIME' 
        AND cmn.BUSINESS_KEY='RELATIONSHIP'
        
          
            
        
        /************* Error Checking for Update tpzt_prime_meme_extr to get RELATIONSHIP values from crosswalk table *************/
        
        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Update tpzt_prime_meme_extr to get RELATIONSHIP values from crosswalk table FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END


        /*************  Update tpzt_prime_meme_extr_new  **************/
        /********1. Dependent�s SSN blank then Use Subscriber�s SSN if Subscriber�s SSN is also blank then Zeroes
        ******   2. if Subscriber�s SSN is blank then Zeroes **/

            UPDATE DEP 
            SET DEP.SOCIAL_SECURITY_NBR =   SUB.SOCIAL_SECURITY_NBR 
                    FROM fabncdv1stage.dbo.tpzt_prime_meme_extr_new DEP 
                    JOIN fabncdv1stage.dbo.tpzt_prime_meme_extr_new SUB ON SUB.FAMILY_ID = DEP.FAMILY_ID 
                    WHERE DEP.SOCIAL_SECURITY_NBR = '000000000' AND DEP.RELATIONSHIP_CODE <> 1 
                    AND SUB.RELATIONSHIP_CODE = 1 

        /************* Error Checking for ************/
        /********1. Dependent�s SSN blank then Use Subscriber�s SSN if Subscriber�s SSN is also blank then Zeroes
        ******   2. if Subscriber�s SSN is blank then Zeroes **/
                
                SELECT @lnRetCd    = @@ERROR,
                @lnRowsProcessed = @@ROWCOUNT

                IF @lnRetCd <> 0
                    BEGIN
                        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                        + ' : Update tpzt_prime_meme_extr_new  FAILED'
                        + ' RETURNCODE : '
                        + CONVERT(CHAR(6),@lnRetCd)
                        PRINT  @lvcMsg
                        RETURN @lnRetCd
                    END


        /************* STEP 1(i) Update tpzt_prime_meme_extr_new to set the Any date greater than 2391231 needs to be set equal to 2391231  **************/
        
         UPDATE fabncdv1stage.dbo.tpzt_prime_meme_extr_new
          SET  THRU_DATE = cast(2391231 as decimal(7))
         WHERE cast(THRU_DATE as decimal (7))>= cast(2391231 as decimal(7))
		 
		 

         /************* Error Checking for Update tpzt_prime_meme_extr_new to set the Any date greater than 2391231 needs to be set equal to 2391231 *************/
                
                SELECT @lnRetCd    = @@ERROR,
                @lnRowsProcessed = @@ROWCOUNT

                IF @lnRetCd <> 0
                    BEGIN
                        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                        + ' : Update tpzt_prime_meme_extr_new to update date greater than 2391231 FAILED'
                        + ' RETURNCODE : '
                        + CONVERT(CHAR(6),@lnRetCd)
                        PRINT  @lvcMsg
                        RETURN @lnRetCd
                    END

            
  
        /************* STEP 1(e) Truncate stage table tpzt_prime_meme_extr *************/
        
        TRUNCATE TABLE fabncdv1stage.dbo.tpzt_prime_meme_extr
        
        /************* Error Checking for Truncating stage table tpzt_prime_meme_extr *************/
        
        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Truncating stage table tpzt_prime_meme_extr FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
        
        /************* STEP 1(f) Populate the temp table #tmp_member_certificate_level with Daily changed Records  *************/
        
        CREATE TABLE #tmp_member_certificate_level
        (
        PRIME_CARRIER                                   varchar(9)                     NULL,     
        PRIME_GROUP                                     varchar(15)                     NULL,
        EXTERNAL_MEMBER_ID                              varchar(18)                     NULL,
        PERSON_CODE                                     varchar(3)                      NULL,
        RELATIONSHIP_CODE                               varchar(1)                      NULL,
        LAST_NAME                                       varchar(25)                     NULL,
        FIRST_NAME                                      varchar(15)                     NULL,
        MIDDLE_NAME                                     varchar(1)                      NULL,
        SEX_CODE                                        varchar(1)                      NULL,
        BIRTH_DATE                                      decimal(8)                      NULL,    
        SOCIAL_SECURITY_NBR                             varchar(9)                      NULL,
        ADDRESS_LINE_1                                  varchar(40)                     NULL,
        ADDRESS_LINE_2                                  varchar(40)                     NULL,    
        CITY                                            varchar(20)                     NULL,
        STATE                                           varchar(2)                      NULL,
        ZIP_CODE                                        varchar(5)                      NULL,
        ZIP_CODE_2                                      varchar(4)                      NULL,    
        COUNTRY_CODE                                    varchar(4)                      NULL,
        PHONE                                           varchar(10)                     NULL,
        FAMILY_TYPE                                     varchar(1)                      NULL,
        FAMILY_ID                                       varchar(18)                     NULL,    
        FROM_DATE                                       decimal(7)                      NULL,
        THRU_DATE                                       decimal(7)                      NULL,
        [PLAN]                                          varchar(10)                     NULL    
        )
       
        INSERT INTO #tmp_member_certificate_level
        (
            PRIME_CARRIER,
            PRIME_GROUP,
            EXTERNAL_MEMBER_ID,
            PERSON_CODE,
            RELATIONSHIP_CODE,
            LAST_NAME,
            FIRST_NAME,
            MIDDLE_NAME,
            SEX_CODE,
            BIRTH_DATE,
            SOCIAL_SECURITY_NBR,
            ADDRESS_LINE_1,
            ADDRESS_LINE_2,
            CITY,
            STATE,
            ZIP_CODE,
            ZIP_CODE_2,
            COUNTRY_CODE,
            PHONE,
            FAMILY_TYPE,
            FAMILY_ID,
            FROM_DATE,
            THRU_DATE,
            [PLAN]
        )
       
        SELECT        
            curr.PRIME_CARRIER,            
            curr.PRIME_GROUP,
            curr.EXTERNAL_MEMBER_ID,
            curr.PERSON_CODE,
            curr.RELATIONSHIP_CODE,
            curr.LAST_NAME,
            curr.FIRST_NAME,
            curr.MIDDLE_NAME,
            curr.SEX_CODE,
            CASE 
                WHEN curr.BIRTH_DATE =0
                THEN '00000000'
                ELSE  
                CAST(curr.BIRTH_DATE AS VARCHAR(8))
            END AS BIRTH_DATE,            
            --CASE WHEN curr.SOCIAL_SECURITY_NBR=0
            --    THEN '000000000'
            --    ELSE RIGHT('000000000' +CAST( curr.SOCIAL_SECURITY_NBR AS VARCHAR(9)),9)
            --END AS SOCIAL_SECURITY_NBR,
            curr.SOCIAL_SECURITY_NBR,
            curr.ADDRESS_LINE_1,
            curr.ADDRESS_LINE_2,            
            curr.CITY,
            curr.STATE,
            curr.ZIP_CODE,
            curr.ZIP_CODE_2,            
            curr.COUNTRY_CODE,                        
            curr.PHONE,
            curr.FAMILY_TYPE,
            curr.FAMILY_ID,           
            curr.FROM_DATE,
            curr.THRU_DATE,
            curr.[PLAN]          
       
        FROM fabncdv1stage.dbo.tpzt_prime_meme_extr_new curr
        EXCEPT
        SELECT        
            prev.PRIME_CARRIER,            
            prev.PRIME_GROUP,
            prev.EXTERNAL_MEMBER_ID,
            prev.PERSON_CODE,
            prev.RELATIONSHIP_CODE,
            prev.LAST_NAME,
            prev.FIRST_NAME,
            prev.MIDDLE_NAME,
            prev.SEX_CODE,
            CASE WHEN prev.BIRTH_DATE =0
                 THEN '00000000'
                 ELSE  
                 CAST(prev.BIRTH_DATE AS VARCHAR(8))
            END AS BIRTH_DATE,            
            --CASE WHEN prev.SOCIAL_SECURITY_NBR=0
            --     THEN '000000000'
            --     ELSE 
            --     RIGHT('000000000' + CAST( prev.SOCIAL_SECURITY_NBR AS VARCHAR(9)),9)
            --END AS SOCIAL_SECURITY_NBR,
            prev.SOCIAL_SECURITY_NBR,
            prev.ADDRESS_LINE_1,
            prev.ADDRESS_LINE_2,            
            prev.CITY,
            prev.STATE,
            prev.ZIP_CODE,
            prev.ZIP_CODE_2,            
            prev.COUNTRY_CODE,                        
            prev.PHONE,
            prev.FAMILY_TYPE,
            prev.FAMILY_ID,           
            prev.FROM_DATE,
            prev.THRU_DATE,
            prev.[PLAN]          
       
        FROM 
        fabncdv1stage.dbo.tpzt_prime_meme_extr_old prev
        
        
        /************* STEP 1(f) Populate the stage table tpzt_prime_meme_extr with Daily changed Certificate-level Records  *************/
        INSERT INTO fabncdv1stage.dbo.tpzt_prime_meme_extr
        (
            PRIME_CARRIER,
            PRIME_GROUP,
            EXTERNAL_MEMBER_ID,
            PERSON_CODE,
            RELATIONSHIP_CODE,
            LAST_NAME,
            FIRST_NAME,
            MIDDLE_NAME,
            SEX_CODE,
            BIRTH_DATE,
            SOCIAL_SECURITY_NBR,
            ADDRESS_LINE_1,
            ADDRESS_LINE_2,
            CITY,
            STATE,
            ZIP_CODE,
            ZIP_CODE_2,
            COUNTRY_CODE,
            PHONE,
            FAMILY_TYPE,
            FAMILY_ID,
            FROM_DATE,
            THRU_DATE,
            [PLAN]
        )
        SELECT 
            PRIME_CARRIER,            
            PRIME_GROUP,
            EXTERNAL_MEMBER_ID,
            PERSON_CODE,
            RELATIONSHIP_CODE,
            LAST_NAME,
            FIRST_NAME,
            MIDDLE_NAME,
            SEX_CODE,
            CASE 
                WHEN BIRTH_DATE =0
                THEN '00000000'
                ELSE  
                CAST(BIRTH_DATE AS VARCHAR(8))
            END,            
            --CASE WHEN SOCIAL_SECURITY_NBR=0 OR SOCIAL_SECURITY_NBR = '' OR SOCIAL_SECURITY_NBR = 'NULL'
            --    THEN '000000000'
            --    ELSE RIGHT('000000000' +CAST( SOCIAL_SECURITY_NBR AS VARCHAR(9)),9)
            --END,
            SOCIAL_SECURITY_NBR,
            ADDRESS_LINE_1,
            ADDRESS_LINE_2,            
            CITY,
            STATE,
            ZIP_CODE,
            ZIP_CODE_2,            
            COUNTRY_CODE,                        
            PHONE,
            FAMILY_TYPE,
            FAMILY_ID,           
            FROM_DATE,
            THRU_DATE,
            [PLAN] FROM fabncdv1stage.dbo.tpzt_prime_meme_extr_new WHERE FAMILY_ID IN(SELECT FAMILY_ID FROM #tmp_member_certificate_level)
        
		-- Updating FROM_DATE and THRU_DATE for NULL Members
		UPDATE extr
		SET  THRU_DATE = CAST(SUBSTRING(CONVERT(VARCHAR,DATEADD(DD,-1,CAST(SUBSTRING(FROM_DATE,1,1)+'0' +  SUBSTRING( FROM_DATE,2,6) AS DATE)),112),1,1)+ SUBSTRING(CONVERT(VARCHAR,DATEADD(DD,-1,CAST(SUBSTRING(FROM_DATE,1,1)+'0' +  SUBSTRING( FROM_DATE,2,6) AS DATE)),112),3,6) AS DECIMAL(7))
				FROM  tpzt_prime_meme_extr extr
		 WHERE FROM_DATE = THRU_DATE
		 
        DROP TABLE #tmp_member_certificate_level
 
        /************* Error Checking for Populate the stage table tpzt_prime_meme_extr with Daily Records *************/
        
        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Populate the stage table tpzt_prime_meme_extr with Daily Records FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
         

        
    END
       
   /**************  PRINT STEP 1 FOOTER DATA *************************/

   SELECT @ldtStepEndTime = GETDATE()

   EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
     @pdtStepStartTime    = @ldtStepStartTime,
     @pdtStepEndTime      = @ldtStepEndTime,
     @pdtProcessStartTime = @ldtProcessStartTime,
     @pnRowCount          = @lnRowsProcessed
   
   
   /**************  PRINT STEP 2  HEADER DATA *************************/

   SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime = GETDATE(),
      @lvcMsg = @lvcObjectName + ': Populate stage table tpzt_prime_meme_extr for Prime Monthly member Extract'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
     @pnStepNumber     = @lnCurrentStep,
     @pdtStepStartTime = @ldtStepStartTime,
     @pnTotalSteps     = @lnTotalSteps,
     @pchStepMsg       = @lvcMsg

    /********** STEP 2 Populate stage table tpzt_prime_meme_extr for Prime Monthly Group Extract **********/
    
    IF UPPER(@pRunFreq) = 'MONTHLY'
        BEGIN
        
        /************* STEP 2(a) Truncate stage table tpzt_prime_meme_extr_new *************/
        
        TRUNCATE TABLE fabncdv1stage.dbo.tpzt_prime_meme_extr_new
        
        /************* Error Checking for Truncating stage table tpzt_prime_meme_extr_new *************/
        
        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Truncating stage table tpzt_prime_meme_extr_new FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
        
        
         /************* STEP 2(b) Temporary table #Exclude_MO_SBSB_ID created to Exclude whole family from extract 
        if subscribers or member last name is blank and Exclude whole family from extract if subscribers or member external 
        id ie SBSB_ID + MEME_SFX is blank  *************/  
        SELECT 
            DISTINCT elig.SBSB_ID
            INTO
                   #Exclude_MO_SBSB_ID
            FROM 
            fabncdv1stage.dbo.tpzt_comm_elig_extr elig
           WHERE (ISNULL(elig.SBSB_ID,'') = '' 
                    AND ISNULL(CAST(elig.MEME_SFX_VCHAR AS VARCHAR(10)),'')='')
                    OR LTRIM(RTRIM(isnull(elig.MEME_LAST_NAME,''))) = '' 
        
        /************* STEP 2(b.1) Populate the stage table tpzt_prime_meme_extr_new with Monthly Records *************/
        INSERT INTO  fabncdv1stage.dbo.tpzt_prime_meme_extr_new
        (
            PRIME_CARRIER,
            PRIME_GROUP,
            EXTERNAL_MEMBER_ID,
            PERSON_CODE,
            RELATIONSHIP_CODE,
            LAST_NAME,
            FIRST_NAME,
            MIDDLE_NAME,
            SEX_CODE,
            BIRTH_DATE,
            SOCIAL_SECURITY_NBR,
            ADDRESS_LINE_1,
            ADDRESS_LINE_2,
            CITY,
            STATE,
            ZIP_CODE,
            ZIP_CODE_2,
            COUNTRY_CODE,
            PHONE,
            FAMILY_TYPE,
            FAMILY_ID,
            FROM_DATE,
            THRU_DATE,
            [PLAN]
        )
        SELECT
            DISTINCT   
            'NC2000   ',            
            LEFT(elig.GRGR_ID + SPACE(15) , 15),
            LEFT(CONCAT( elig.SBSB_ID,elig.MEME_SFX_VCHAR)+ SPACE(18) , 18) AS SBSB_ID_MEME_SFX,
            LEFT(CAST(elig.MEME_SFX_VCHAR AS VARCHAR(3))+ SPACE(3),3),
            LEFT(elig.MEME_REL + SPACE(1),1),
            LEFT(elig.MEME_LAST_NAME + SPACE(25),25),
            LEFT(elig.MEME_FIRST_NAME + SPACE(15),15),
            LEFT(elig.MEME_MID_INIT + SPACE(1),1),
            LEFT(elig.MEME_SEX + SPACE(1),1),
            CAST(convert(varchar,elig.MEME_BIRTH_DT,112) AS DECIMAL(8)),           
            CASE WHEN LTRIM(RTRIM(elig.MEME_SSN)) IS NOT NULL AND  LTRIM(RTRIM(elig.MEME_SSN)) <> ''
                 THEN elig.MEME_SSN
                 ELSE '000000000'
            END,
           CASE WHEN elig.ENAD_ADDR1  IS NOT NULL AND LTRIM(RTRIM(elig.ENAD_ADDR1)) <> ''
                 THEN LEFT(elig.ENAD_ADDR1 + SPACE(40),40)
                 WHEN elig.MCRP_ADDR1 IS NOT NULL  AND LTRIM(RTRIM(elig.MCRP_ADDR1)) <> ''
                 THEN LEFT(elig.MCRP_ADDR1 + SPACE(40),40)
                 ELSE  LEFT(elig.SBAD_ADDR1 + SPACE(40),40)
            END ,
            CASE WHEN elig.ENAD_ADDR1  IS NOT NULL AND LTRIM(RTRIM(elig.ENAD_ADDR1)) <> ''
                 THEN LEFT(elig.ENAD_ADDR2 + SPACE(40),40)
                 WHEN elig.MCRP_ADDR1 IS NOT NULL  AND LTRIM(RTRIM(elig.MCRP_ADDR1)) <> ''
                 THEN LEFT(elig.MCRP_ADDR2 + SPACE(40),40)
                 ELSE LEFT(elig.SBAD_ADDR2 + SPACE(40),40)
            END,            
            CASE WHEN elig.ENAD_ADDR1  IS NOT NULL AND LTRIM(RTRIM(elig.ENAD_ADDR1)) <> ''
                 THEN LEFT(elig.ENAD_CITY + SPACE(20),20)
                 WHEN elig.MCRP_ADDR1 IS NOT NULL  AND LTRIM(RTRIM(elig.MCRP_ADDR1)) <> ''
                 THEN LEFT(elig.MCRP_CITY + SPACE(20),20)
                 ELSE LEFT(elig.SBAD_CITY + SPACE(20),20)
            END,
            CASE WHEN elig.ENAD_ADDR1  IS NOT NULL AND LTRIM(RTRIM(elig.ENAD_ADDR1)) <> ''
                 THEN LEFT(elig.ENAD_STATE + SPACE(2),2)
                 WHEN elig.MCRP_ADDR1 IS NOT NULL  AND LTRIM(RTRIM(elig.MCRP_ADDR1)) <> ''
                 THEN LEFT(elig.MCRP_STATE + SPACE(2),2)
                 ELSE LEFT(elig.SBAD_STATE + SPACE(2),2)
            END,
            CASE WHEN elig.ENAD_ADDR1  IS NOT NULL AND LTRIM(RTRIM(elig.ENAD_ADDR1)) <> ''
                 THEN LEFT(CAST(elig.ENAD_ZIP AS VARCHAR(5))+SPACE(5),5)
                 WHEN elig.MCRP_ADDR1 IS NOT NULL  AND LTRIM(RTRIM(elig.MCRP_ADDR1)) <> ''
                 THEN LEFT(CAST(elig.MCRP_ZIP AS VARCHAR(5))+SPACE(5),5)
                 ELSE LEFT(CAST(elig.SBAD_ZIP AS VARCHAR(5))+SPACE(5),5)
            END,
            SPACE(4),                   
            CASE WHEN elig.ENAD_ADDR1  IS NOT NULL AND LTRIM(RTRIM(elig.ENAD_ADDR1)) <> '' AND elig.ENAD_CTRY_CD <> 'USA'
                 THEN LEFT(elig.ENAD_CTRY_CD + SPACE(4),4)
                 WHEN elig.MCRP_ADDR1 IS NOT NULL AND LTRIM(RTRIM(elig.MCRP_ADDR1)) <> '' AND elig.MCRP_CTRY_CD <> 'USA'
                 THEN LEFT(elig.MCRP_CTRY_CD + SPACE(4),4)
                 WHEN elig.SBAD_ADDR1 IS NOT NULL AND LTRIM(RTRIM(elig.SBAD_ADDR1)) <> '' AND elig.SBAD_CTRY_CD <> 'USA'
                 THEN LEFT(elig.SBAD_CTRY_CD + SPACE(4),4)
                 ELSE SPACE(4)
            END,
            LEFT(LTRIM(RTRIM(elig.MEME_CELL_PHONE)) + SPACE(10), 10),
            space(1),
            LEFT(CAST(elig.SBSB_ID AS VARCHAR(18))  + SPACE(18),18),            
            CASE WHEN grgr.GRGR_CURR_ANNV_DT >= elig.MEPE_EFF_DT
                 THEN CAST(SUBSTRING(CONVERT(VARCHAR,grgr.GRGR_CURR_ANNV_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,grgr.GRGR_CURR_ANNV_DT,112),3,6) AS DECIMAL(7))
                 ELSE CAST(SUBSTRING(CONVERT(VARCHAR,elig.MEPE_EFF_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,elig.MEPE_EFF_DT,112),3,6) AS DECIMAL(7))
            END,
            CASE WHEN grgr.GRGR_NEXT_ANNV_DT >= elig.MEPE_TERM_DT
                 THEN CAST(SUBSTRING(CONVERT(VARCHAR,elig.MEPE_TERM_DT,112),1,1)+ SUBSTRING(CONVERT(VARCHAR,elig.MEPE_TERM_DT,112),3,6) AS DECIMAL(7))
                 WHEN grgr.GRGR_NEXT_ANNV_DT IN ('1753-01-01 00:00:00.000','9999-12-31 00:00:00.000')  
                 THEN 2391231
                 ELSE CAST(SUBSTRING(CONVERT(VARCHAR,DATEADD(DD, -1, grgr.GRGR_NEXT_ANNV_DT),112),1,1)+ SUBSTRING(CONVERT(VARCHAR,DATEADD(DD, -1, grgr.GRGR_NEXT_ANNV_DT),112),3,6) AS DECIMAL(7))
            END,
            LEFT(CAST(xwk.PRIME_PHARMACY AS VARCHAR(10))  + SPACE(10),10) 
            
        FROM fabncdv1stage.dbo.tpzt_comm_elig_extr elig 
        INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr
        ON grgr.GRGR_CK = elig.GRGR_CK
        INNER JOIN fabncdv1stage.dbo.tpzt_vend_ext_prime_cw xwk
        ON  elig.CSPI_ID= xwk.FACETS_MEDICAL AND xwk.TRANSLATION_EXPIRATION_DATE >= DATEADD(MM,-18,GETDATE())
        WHERE elig.CSPD_CAT = 'M'             
            AND EXISTS 
            ( 
                SELECT 1 FROM fabncdv1stage.dbo.tpzt_comm_elig_extr comm 
                INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr
                ON grgr.GRGR_CK = comm.GRGR_CK
                INNER JOIN fabncdv1stage.dbo.tpzt_vend_ext_prime_cw cw 
                ON comm.CSPI_ID = cw.FACETS_PHARMACY 
                AND xwk.FACETS_MEDICAL = cw.FACETS_MEDICAL
                AND xwk.PRIME_PHARMACY = cw.PRIME_PHARMACY                
                AND cw.TRANSLATION_EXPIRATION_DATE >= DATEADD(MM,-18,GETDATE())
                WHERE comm.CSPD_CAT = 'R' 
                    AND comm.SBSB_ID = elig.SBSB_ID 
            )            
            AND NOT EXISTS
            (SELECT 1 FROM #Exclude_MO_SBSB_ID tmp WHERE 
            elig.SBSB_ID=tmp.SBSB_ID)
            AND
            elig.MEPE_TERM_DT >= DATEADD(MM,-18,GETDATE())
			AND xwk.HDHP_CERTIFICATE_TYPE = CASE WHEN (SELECT COUNT(MEME.MEME_CK) AS FMLY_NO FROM fabncdv1.dbo.CMC_MEME_MEMBER MEME 
														WHERE MEME.SBSB_CK = elig.SBSB_CK 
														AND (elig.MEPE_EFF_DT BETWEEN GETDATE() AND elig.MEPE_TERM_DT
														OR GETDATE() BETWEEN elig.MEPE_EFF_DT AND elig.MEPE_TERM_DT) 
														GROUP BY MEME.SBSB_CK) > 1  
												THEN CASE WHEN xwk.HDHP_CERTIFICATE_TYPE = 'FMLY' THEN 'FMLY'
													WHEN xwk.HDHP_CERTIFICATE_TYPE = '' THEN ''
													END
											WHEN (SELECT COUNT(MEME.MEME_CK) AS FMLY_NO FROM fabncdv1.dbo.CMC_MEME_MEMBER MEME 
														WHERE MEME.SBSB_CK = elig.SBSB_CK 
														AND (elig.MEPE_EFF_DT BETWEEN GETDATE() AND elig.MEPE_TERM_DT
														OR GETDATE() BETWEEN elig.MEPE_EFF_DT AND elig.MEPE_TERM_DT )
														GROUP BY MEME.SBSB_CK) = 1 
												THEN CASE WHEN xwk.HDHP_CERTIFICATE_TYPE = 'INDV' THEN 'INDV'
													WHEN xwk.HDHP_CERTIFICATE_TYPE = '' THEN ''
													END
											END
       
            
         /************* Dropping Temporary table #ExcludeSBSB_ID*************/
         DROP TABLE #Exclude_MO_SBSB_ID      
        
        /************* Error Checking for Populate the stage table tpzt_prime_meme_extr with Monthly Records *************/
        
        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Populate the stage table tpzt_prime_meme_extr with Monthly Records FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
        END
        
        
        
         /************* STEP 2(b) Update tpzt_prime_meme_extr_new to get member has dependent or not *************/
        UPDATE fabncdv1stage.dbo.tpzt_prime_meme_extr_new
        SET FAMILY_TYPE = CASE WHEN Outer_Qry.MEM_CNT > 1 
                               THEN 1
                               ELSE 2
                          END
        FROM (SELECT MAIN.SBSB_ID,
                     COUNT(MAIN.MEME_CK) AS MEM_CNT
              FROM (SELECT DISTINCT
                        sbsc.MEME_CK,
                        sbsc.SBSB_ID  
                        FROM fabncdv1stage.dbo.tpzt_comm_elig_extr sbsc           
                    ) MAIN
              GROUP BY MAIN.SBSB_ID
             ) Outer_Qry
        
        INNER JOIN fabncdv1stage.dbo.tpzt_prime_meme_extr_new elig 
        ON Outer_Qry.SBSB_ID = elig.FAMILY_ID
                            
        /************* Error Checking for Update tpzt_prime_meme_extr_new to get member has dependent or not *************/
        
        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Update tpzt_prime_meme_extr to get member has dependent or not FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END        
                            
        /************* STEP 2(c) Update tpzt_prime_meme_extr_new to get RELATIONSHIP values from crosswalk table *************/
                
        UPDATE    meme 
        SET RELATIONSHIP_CODE=CASE WHEN cmn.FACETS_VALUE NOT IN ('M','H','W','S','D','O')
                                                   THEN '4'
                                                   ELSE cmn.TOPAZ_VALUE
                                                   END
            FROM fabncdv1stage.dbo.tpzt_prime_meme_extr_new meme
                INNER JOIN 
                    fabncdv1stage.dbo.tpzt_vend_ext_common_cw cmn 
            ON         meme.RELATIONSHIP_CODE=cmn.FACETS_VALUE
            WHERE cmn.VENDOR = 'PRIME' 
                  AND cmn.BUSINESS_KEY='RELATIONSHIP'
                  
   
        /************* Error Checking for Update tpzt_prime_meme_extr to get RELATIONSHIP values from crosswalk table *************/
        
        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Update tpzt_prime_meme_extr to get RELATIONSHIP values from crosswalk table FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
      
      
      /*************  Update tpzt_prime_meme_extr_new  **************/
        /********1. Dependent�s SSN blank then Use Subscriber�s SSN if Subscriber�s SSN is also blank then Zeroes
        ******   2. if Subscriber�s SSN is blank then Zeroes **/

            UPDATE DEP 
            SET DEP.SOCIAL_SECURITY_NBR =   SUB.SOCIAL_SECURITY_NBR 
                    FROM fabncdv1stage.dbo.tpzt_prime_meme_extr_new DEP 
                    JOIN fabncdv1stage.dbo.tpzt_prime_meme_extr_new SUB ON SUB.FAMILY_ID = DEP.FAMILY_ID 
                    WHERE DEP.SOCIAL_SECURITY_NBR = '000000000' AND DEP.RELATIONSHIP_CODE <> 1 
                    AND SUB.RELATIONSHIP_CODE = 1 

        /************* Error Checking for ************/
        /********1. Dependent�s SSN blank then Use Subscriber�s SSN if Subscriber�s SSN is also blank then Zeroes
        ******   2. if Subscriber�s SSN is blank then Zeroes **/
                
                SELECT @lnRetCd    = @@ERROR,
                @lnRowsProcessed = @@ROWCOUNT

                IF @lnRetCd <> 0
                    BEGIN
                        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                        + ' : Update tpzt_prime_meme_extr_new  FAILED'
                        + ' RETURNCODE : '
                        + CONVERT(CHAR(6),@lnRetCd)
                        PRINT  @lvcMsg
                        RETURN @lnRetCd
                    END
  
    
        /************* STEP 1(i) Update tpzt_prime_meme_extr_new to set the Any date greater than 2391231 needs to be set equal to 2391231  **************/
        
         UPDATE fabncdv1stage.dbo.tpzt_prime_meme_extr_new
              SET  THRU_DATE = cast(2391231 as decimal(7))
             WHERE cast(THRU_DATE as decimal (7))>= cast(2391231 as decimal(7))

         /************* Error Checking for Update tpzt_prime_meme_extr_new to set the Any date greater than 2391231 needs to be set equal to 2391231 *************/
                
                SELECT @lnRetCd    = @@ERROR,
                @lnRowsProcessed = @@ROWCOUNT

                IF @lnRetCd <> 0
                    BEGIN
                        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                        + ' : Update tpzt_prime_meme_extr_new to update date greater than 2391231 FAILED'
                        + ' RETURNCODE : '
                        + CONVERT(CHAR(6),@lnRetCd)
                        PRINT  @lvcMsg
                        RETURN @lnRetCd
                    END

   
     /************* STEP 2(d) Truncate stage table tpzt_prime_meme_extr_new *************/
   
        TRUNCATE TABLE fabncdv1stage.dbo.tpzt_prime_meme_extr
   
    /************* Error Checking for Truncating stage table tpzt_prime_meme_extr_new *************/
        
        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Truncating stage table tpzt_prime_meme_extr_new FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
            
      /************* STEP 2(e) Insert record into tpzt_prime_meme_extr *************/       
   
           INSERT INTO fabncdv1stage.dbo.tpzt_prime_meme_extr
                (
                    PRIME_CARRIER,
                    PRIME_GROUP,
                    EXTERNAL_MEMBER_ID,
                    PERSON_CODE,
                    RELATIONSHIP_CODE,
                    LAST_NAME,
                    FIRST_NAME,
                    MIDDLE_NAME,
                    SEX_CODE,
                    BIRTH_DATE,
                    SOCIAL_SECURITY_NBR,
                    ADDRESS_LINE_1,
                    ADDRESS_LINE_2,
                    CITY,
                    STATE,
                    ZIP_CODE,
                    ZIP_CODE_2,
                    COUNTRY_CODE,
                    PHONE,
                    FAMILY_TYPE,
                    FAMILY_ID,
                    FROM_DATE,
                    THRU_DATE,
                    [PLAN]
                )
                select  PRIME_CARRIER,
                        PRIME_GROUP,
                        EXTERNAL_MEMBER_ID,
                        PERSON_CODE,
                        RELATIONSHIP_CODE,
                        LAST_NAME,
                        FIRST_NAME,
                        MIDDLE_NAME,
                        SEX_CODE,
                        BIRTH_DATE,
                        SOCIAL_SECURITY_NBR,
                        ADDRESS_LINE_1,
                        ADDRESS_LINE_2,
                        CITY,
                        STATE,
                        ZIP_CODE,
                        ZIP_CODE_2,
                        COUNTRY_CODE,
                        PHONE,
                        FAMILY_TYPE,
                        FAMILY_ID,
                        FROM_DATE,
                        THRU_DATE,
                        [PLAN]
                  FROM fabncdv1stage.dbo.tpzt_prime_meme_extr_new
           
		   -- Updating FROM_DATE and THRU_DATE for NULL Members
		UPDATE extr
		SET  THRU_DATE = CAST(SUBSTRING(CONVERT(VARCHAR,DATEADD(DD,-1,CAST(SUBSTRING(FROM_DATE,1,1)+'0' +  SUBSTRING( FROM_DATE,2,6) AS DATE)),112),1,1)+ SUBSTRING(CONVERT(VARCHAR,DATEADD(DD,-1,CAST(SUBSTRING(FROM_DATE,1,1)+'0' +  SUBSTRING( FROM_DATE,2,6) AS DATE)),112),3,6) AS DECIMAL(7))
				FROM  tpzt_prime_meme_extr extr
		 WHERE FROM_DATE = THRU_DATE
		 
           /************* Error Checking for Insert record into tpzt_prime_meme_extr *************/
        
        SELECT @lnRetCd    = @@ERROR,
        @lnRowsProcessed = @@ROWCOUNT

        IF @lnRetCd <> 0
            BEGIN
                SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                + ' : Insert record into tpzt_prime_meme_extr FAILED'
                + ' RETURNCODE: '
                + CONVERT(CHAR(6),@lnRetCd)
                PRINT  @lvcMsg
                RETURN @lnRetCd
            END
     
   
      /**************  PRINT STEP 2 FOOTER DATA *************************/

       SELECT @ldtStepEndTime = GETDATE()

       EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
         @pdtStepStartTime    = @ldtStepStartTime,
         @pdtStepEndTime      = @ldtStepEndTime,
         @pdtProcessStartTime = @ldtProcessStartTime,
         @pnRowCount          = @lnRowsProcessed
       
   
   
   /**************  PRINT JOB FOOTER DATA ****************************/

   SELECT @ldtProcessEndTime = GETDATE()
   
   EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr
     @pchObjectName         = @lvcObjectName,
     @pdtProcessStartTime   = @ldtProcessStartTime,
     @pdtProcessEndTime     = @ldtProcessEndTime
   RETURN  @lnRetCd  
    
    END
END
GO
/****************************************************************
** BEGIN MAINTENANCE WRAPPER.                                  **
****************************************************************/
IF OBJECT_ID('dbo.tpzp_prime_member_extr') IS NOT NULL
    PRINT '<<< CREATED PROCEDURE dbo.tpzp_prime_member_extr >>>'
ELSE
   PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_prime_member_extr >>>'
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
****************************************************************/ 