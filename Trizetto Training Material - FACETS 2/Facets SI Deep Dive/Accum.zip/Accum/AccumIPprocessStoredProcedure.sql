/**************************************************************** 
** BEGIN MAINTENANCE WRAPPER.                                  ** 
****************************************************************/ 
IF OBJECT_ID('dbo.tpzp_update_accum_ip') IS NOT NULL 
  BEGIN 
      DROP PROCEDURE dbo.tpzp_update_accum_ip 

      IF OBJECT_ID('dbo.tpzp_update_accum_ip') IS NOT NULL 
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_update_accum_ip >>>' 
      ELSE 
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_update_accum_ip >>>' 
  END 

GO 
/**************************************************************** 
** END MAINTENANCE WRAPPER.                                    ** 
****************************************************************/ 
CREATE PROCEDURE [dbo].[tpzp_update_accum_ip] 
/**************************************************************** 
**   NAME                  :  tpzp_update_accum_ip  
** 
** 
**   PVCS LOCATION         :   Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Stored Procedures\Custom
** 
**   FUNCTION              :  To update custom IsFailed column of table tpzt_accum_ip and ERR_DESC column of table tpzt_accum_resp 
** 
**   PARAMETERS            : 
**   OUTPUT                : 
**   RETURN CODES          :  0 on success 
** 
**   TABLES REFERENCED     : 
**                FACETS   :  N/A 
**                FACETSXC :  N/A 
**                CUSTOM   :  fabncdv1custom.dbo.tpzt_accum_ip 
**                            fabncdv1custom.dbo.tpzt_accum_resp 
**                STAGE    :  fabncdv1stage.dbo.tpzt_accum_error
** 
**   PROCEDURES REFERENCED :  N/A 
**                  FACETS :  N/A 
**                  CUSTOM :  N/A 
**   STANDARD LOGGING PROCS: 
**                           harcore.dbo.harsp_gen_util_job_hdr_lgr 
**                           harcore.dbo.harsp_gen_util_job_ftr_lgr 
**                           harcore.dbo.harsp_gen_util_step_hdr_lgr 
**                           harcore.dbo.harsp_gen_util_step_ftr_lgr 
** 
** REVISION HISTORY        : 
** VERSION  DATE         DEVELOPER           DESCRIPTION 
** -------- ----------   -----------------   -------------------- 
** 1.0      10/20/2014   Sameeksha Joshi     Initial version
****************************************************************/ 

(
    @ptblERROR_FILE        dbo.tpzt_error_file_data    READONLY 
)

AS 
  BEGIN 
      /**************************************************************** 
      **          DECLARE LOCAL VARIABLES                            ** 
      ****************************************************************/ 
      DECLARE @lnRetCd INT -- Proc return code 
      DECLARE @lvcMsg VARCHAR(255) -- Generic Message Field 
      DECLARE @lnCurrentStep INT -- Current Step Number 
      DECLARE @ldtStepStartTime DATETIME -- Step Start Date / Time 
      DECLARE @lnTotalSteps INT -- Total Steps In Proc 
      DECLARE @lvcObjectName VARCHAR(32) -- SP Name 
      DECLARE @lvcServerName VARCHAR(32) -- DB Server Name 
      DECLARE @lvcDBName VARCHAR(32) -- DB Name 
      DECLARE @lvcVersionNum VARCHAR(32) -- Object Version 
      DECLARE @lvcUser VARCHAR(32) -- Executing User Name 
      DECLARE @lvcJeGrpCount VARCHAR(32) -- Number of JE group extract 
      DECLARE @ldtProcessStartTime DATETIME -- Job Start Date / Time 
      DECLARE @lnRowsProcessed INT -- Rows Processed by Step 
      DECLARE @ldtStepEndTime DATETIME -- Step End Date / Time 
      DECLARE @ldtProcessEndTime DATETIME -- Job End Date / Time 
      DECLARE @lnTotRecordCnt INT 

    /**************************************************************** 
    **          INITIALIZE  VARIABLES                              ** 
    ****************************************************************/ 
    SELECT @lnRetCd = 0, 
         @lvcMsg = NULL, 
         @lnCurrentStep = 0, 
         @lnTotalSteps = 1, 
         @ldtStepEndTime = NULL 

    SELECT @lvcServerName = @@SERVERNAME, 
         @lvcDBName = DB_NAME(), 
         @lvcUser = USER_NAME(), 
         @lvcObjectName = OBJECT_NAME(@@PROCID), 
         @ldtProcessStartTime = GETDATE() 

    /**************************************************************** 
    **               BEGIN PROCESS                                 ** 
    *****************************************************************/ 
  
    /**************  PRINT JOB HEADER DATA *************************/ 
    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr 
        @pchObjectName = @lvcObjectName, 
        @pdtProcessStartTime = @ldtProcessStartTime, 
        @pchServerName = @lvcServerName, 
        @pchDBName = @lvcDBName, 
        @pchUserName = @lvcUser, 
        @pchVersionNum = @lvcVersionNum 

        
    /**************  PRINT STEP 1  HEADER DATA *************************/ 
        SELECT @lnCurrentStep = @lnCurrentStep + 1, 
                @ldtStepStartTime = GETDATE(), 
                @lvcMsg = @lvcObjectName + ': Updating table tpzt_accum_ip ' 

        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr 
              @pnStepNumber = @lnCurrentStep, 
              @pdtStepStartTime = @ldtStepStartTime, 
              @pnTotalSteps = @lnTotalSteps, 
              @pchStepMsg = @lvcMsg 

    /********** STEP 1 Updating table tpzt_accum_ip   **********/ 

	UPDATE error
		SET STATUS = 'PEND',
			ERR_DESC = LTRIM(RTRIM(temp.ERROR))
		FROM fabncdv1stage.dbo.tpzt_accum_error error
		INNER JOIN  @ptblERROR_FILE temp
		ON temp.LINE_NO = error.LINE_NO
		
		-- Updating ERR_DESC in resp table . concatenation of error messages from error table
		UPDATE resp
		SET ERR_DESC = ( STUFF((SELECT ', ' + LTRIM(RTRIM(err1.ERR_DESC))
				FROM fabncdv1stage.dbo.tpzt_accum_error err1
				WHERE err1.ACCUM_ID = resp.ACCUM_ID 
				FOR XML PATH('')),1,1,'')
				),
			REC_STATUS = 'PEND',
			STATUS = 'PEND' ,
			[MODE] = 'N'
		FROM fabncdv1custom.dbo.tpzt_accum_resp resp
		INNER JOIN fabncdv1stage.dbo.tpzt_accum_error err 
		ON err.ACCUM_ID = resp.ACCUM_ID  
		WHERE err.STATUS ='PEND'
		AND REC_STATUS = 'Received'
		AND  RESP_STATUS = 'N'
		AND  CONVERT(VARCHAR(8),LAST_UPD_DT, 112) = CONVERT(VARCHAR(8), @ldtProcessStartTime, 112)
				
	    UPDATE accum
		SET STATUS = 'PEND' ,
			[MODE] = 'N'
		FROM fabncdv1custom.dbo.tpzt_accum_ip accum
		INNER JOIN fabncdv1stage.dbo.tpzt_accum_error err
		ON err.ACCUM_ID = accum.ACCUM_ID
		INNER JOIN @ptblERROR_FILE temp
		ON temp.LINE_NO = err.LINE_NO
		INNER JOIN fabncdv1custom.dbo.tpzt_accum_resp resp
		ON resp.ACCUM_ID = err.ACCUM_ID
        WHERE resp.REC_STATUS = 'PEND'
		AND   resp.RESP_STATUS = 'N'
		AND   CONVERT(VARCHAR(8),resp.LAST_UPD_DT, 112) = CONVERT(VARCHAR(8), @ldtProcessStartTime, 112)
		
		
		
    /************* Error checking for Creating Temp Tables  **********/ 
        SELECT @lnRetCd = @@ERROR, 
               @lnRowsProcessed = @@ROWCOUNT 

        IF @lnRetCd <> 0 
        BEGIN 
              SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109) 
                               + ' : Updating table tpzt_accum_ip FAILED' 
                               + ' RETURNCODE: ' + CONVERT(CHAR(6), @lnRetCd) 
              PRINT @lvcMsg 
              RETURN @lnRetCd 
        END 

    /**************  PRINT STEP 1 FOOTER DATA *************************/ 
        SELECT @ldtStepEndTime = GETDATE() 

        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr 
          @pdtStepStartTime = @ldtStepStartTime, 
          @pdtStepEndTime = @ldtStepEndTime, 
          @pdtProcessStartTime = @ldtProcessStartTime, 
          @pnRowCount = @lnRowsProcessed 
    			  
    /**************  PRINT JOB FOOTER DATA ****************************/ 
    SELECT @ldtProcessEndTime = GETDATE() 

    EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr 
        @pchObjectName = @lvcObjectName, 
        @pdtProcessStartTime = @ldtProcessStartTime, 
        @pdtProcessEndTime = @ldtProcessEndTime 
    
    RETURN @lnRetCd 
  END 

/**************************************************************** 
** BEGIN MAINTENANCE WRAPPER.                                  ** 
****************************************************************/ 
GO 
IF OBJECT_ID('dbo.tpzp_update_accum_ip') IS NOT NULL 
  PRINT '<<< CREATED PROCEDURE dbo.tpzp_update_accum_ip >>>' 
ELSE 
  PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_update_accum_ip >>>' 
GO 
/**************************************************************** 
** END MAINTENANCE WRAPPER.                                    ** 
****************************************************************/ 

