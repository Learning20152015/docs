/**************************************************************** 
** BEGIN MAINTENANCE WRAPPER.                                  ** 
****************************************************************/ 
IF OBJECT_ID('dbo.tpzp_accum_ext') IS NOT NULL 
  BEGIN 
      DROP PROCEDURE dbo.tpzp_accum_ext 

      IF OBJECT_ID('dbo.tpzp_accum_ext') IS NOT NULL 
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_accum_ext >>>' 
      ELSE 
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_accum_ext >>>' 
  END 

GO 
/**************************************************************** 
** END MAINTENANCE WRAPPER.                                    ** 
****************************************************************/ 
CREATE PROCEDURE [dbo].[tpzp_accum_ext] 
/**************************************************************** 
**   NAME                  :  tpzp_accum_ext  
** 
** 
**   PVCS LOCATION         :   Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Stored Procedures\Custom
** 
**   FUNCTION              :  To Create keyword file for ABI core job
** 
**   PARAMETERS            : 
**   OUTPUT                : 
**   RETURN CODES          :  0 on success 
** 
**   TABLES REFERENCED     : 
**                FACETS   :  N/A 
**                FACETSXC :  N/A 
**                CUSTOM   :  fabncdv1custom.dbo.tpzt_accum_ip 
**                            fabncdv1custom.dbo.tpzt_accum_resp 
**                STAGE    :  fabncdv1stage.dbo.tpzt_accum_error
** 
**   PROCEDURES REFERENCED :  N/A 
**                  FACETS :  N/A 
**                  CUSTOM :  N/A 
**   STANDARD LOGGING PROCS: 
**                           harcore.dbo.harsp_gen_util_job_hdr_lgr 
**                           harcore.dbo.harsp_gen_util_job_ftr_lgr 
**                           harcore.dbo.harsp_gen_util_step_hdr_lgr 
**                           harcore.dbo.harsp_gen_util_step_ftr_lgr 
** 
** REVISION HISTORY        : 
** VERSION  DATE         DEVELOPER           DESCRIPTION 
** -------- ----------   -----------------   -------------------- 
** 1.0      11/21/2013   Samir Dharmadhikari  Initial version
** 1.1      12/18/2013   Suwarna Patil        Updated as per code review comments
** 1.2      01/15/2014   Suwarna Patil        Updated as per new technical specification 
** 1.3      05/23/2014   Sameeksha Joshi      Updated the value of column PDPD_ACC_SFX, Hardcoded it to "MED"
** 1.4      05/26/2014   Sameeksha Joshi      Updated to include condition for INPUT_FLAG
** 1.5      09/26/2014   Sameeksha Joshi      Updated condition of comparison with GETDATE()
** 1.6      10/06/2014   Sameeksha Joshi      Updated FAAC_ACC_IND value to N to prevent insertion of family details in member table
** 1.10		12/18/2014	 Sameeksha Joshi	  Updated for PLAN Year modifications
** 1.11	    02/19/2015   Divya Chinnasamy	  Updated to order the FAAC and MEAC amount
****************************************************************/ 
AS 
  BEGIN 
      /**************************************************************** 
      **          DECLARE LOCAL VARIABLES                            ** 
      ****************************************************************/ 
      DECLARE @lnRetCd INT -- Proc return code 
      DECLARE @lvcMsg VARCHAR(255) -- Generic Message Field 
      DECLARE @lnCurrentStep INT -- Current Step Number 
      DECLARE @ldtStepStartTime DATETIME -- Step Start Date / Time 
      DECLARE @lnTotalSteps INT -- Total Steps In Proc 
      DECLARE @lvcObjectName VARCHAR(32) -- SP Name 
      DECLARE @lvcServerName VARCHAR(32) -- DB Server Name 
      DECLARE @lvcDBName VARCHAR(32) -- DB Name 
      DECLARE @lvcVersionNum VARCHAR(32) -- Object Version 
      DECLARE @lvcUser VARCHAR(32) -- Executing User Name 
      DECLARE @lvcJeGrpCount VARCHAR(32) -- Number of JE group extract 
      DECLARE @ldtProcessStartTime DATETIME -- Job Start Date / Time 
      DECLARE @lnRowsProcessed INT -- Rows Processed by Step 
      DECLARE @ldtStepEndTime DATETIME -- Step End Date / Time 
      DECLARE @ldtProcessEndTime DATETIME -- Job End Date / Time 
      DECLARE @lnTotRecordCnt INT 

    /**************************************************************** 
    **          INITIALIZE  VARIABLES                              ** 
    ****************************************************************/ 
    SELECT @lnRetCd = 0, 
         @lvcMsg = NULL, 
         @lnCurrentStep = 0, 
         @lnTotalSteps = 12, 
         @ldtStepEndTime = NULL 

    SELECT @lvcServerName = @@SERVERNAME, 
         @lvcDBName = DB_NAME(), 
         @lvcUser = USER_NAME(), 
         @lvcObjectName = OBJECT_NAME(@@PROCID), 
         @ldtProcessStartTime = GETDATE() 

    /**************************************************************** 
    **               BEGIN PROCESS                                 ** 
    *****************************************************************/ 
  
    /**************  PRINT JOB HEADER DATA *************************/ 
    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr 
        @pchObjectName = @lvcObjectName, 
        @pdtProcessStartTime = @ldtProcessStartTime, 
        @pchServerName = @lvcServerName, 
        @pchDBName = @lvcDBName, 
        @pchUserName = @lvcUser, 
        @pchVersionNum = @lvcVersionNum 

        
    /**************  PRINT STEP 1  HEADER DATA *************************/ 
        SELECT @lnCurrentStep = @lnCurrentStep + 1, 
                @ldtStepStartTime = GETDATE(), 
                @lvcMsg = @lvcObjectName + ': Creating temp table #tempFAACKW, #tempMEACKW ' 

        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr 
              @pnStepNumber = @lnCurrentStep, 
              @pdtStepStartTime = @ldtStepStartTime, 
              @pnTotalSteps = @lnTotalSteps, 
              @pchStepMsg = @lvcMsg 

    /********** STEP 1 Creating Temp Tables   **********/ 
       
        CREATE TABLE #tempFAACKW 
        (
            RECTYPE                CHAR(4),
            ACCUM_ID            CHAR(51),
            FAAC_UPDATE_CODE    CHAR(2),
            GRGR_ID                CHAR(8),
            SBSB_ID                CHAR(9),
            PDPD_ACC_SFX        CHAR(4),
            FAAC_ACC_TYPE        CHAR(1),
            ACAC_ACC_NO            CHAR(4),
            ACAC_PLAN_YEAR        VARCHAR(10),
            FAAC_AMT1            MONEY NULL
        )

        CREATE TABLE #tempMEACKW 
        (
            RECTYPE                CHAR(4),
            ACCUM_ID            CHAR(51),
            MEAC_UPDATE_CODE    CHAR(2),
            GRGR_ID                CHAR(8),
            SBSB_ID                CHAR(9),
            MEME_SFX            CHAR(1),
            PDPD_ACC_SFX        CHAR(4),
            MEAC_ACC_TYPE        CHAR(1),
            ACAC_ACC_NO            CHAR(4),
            ACAC_PLAN_YEAR        VARCHAR(10),
            MEAC_AMT1            MONEY,
            FAAC_ACC_IND        CHAR(1),
			SERVICE_DT			VARCHAR(10),
			CSPD_CAT			CHAR(1)
        )
        
        
    /************* Error checking for Creating Temp Tables  **********/ 
        SELECT @lnRetCd = @@ERROR, 
               @lnRowsProcessed = @@ROWCOUNT 

        IF @lnRetCd <> 0 
        BEGIN 
              SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109) 
                               + ' : Creating Temp Tables  FAILED' 
                               + ' RETURNCODE: ' + CONVERT(CHAR(6), @lnRetCd) 
              PRINT @lvcMsg 
              RETURN @lnRetCd 
        END 

    /**************  PRINT STEP 1 FOOTER DATA *************************/ 
        SELECT @ldtStepEndTime = GETDATE() 

        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr 
          @pdtStepStartTime = @ldtStepStartTime, 
          @pdtStepEndTime = @ldtStepEndTime, 
          @pdtProcessStartTime = @ldtProcessStartTime, 
          @pnRowCount = @lnRowsProcessed 
    

    /**************  PRINT STEP 2  HEADER DATA *************************/ 
        SELECT @lnCurrentStep = @lnCurrentStep + 1, 
           @ldtStepStartTime = GETDATE(), 
           @lvcMsg = @lvcObjectName + ': Finding the Product ID for the incoming accumulator specific members ' 

        EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr 
          @pnStepNumber = @lnCurrentStep, 
          @pdtStepStartTime = @ldtStepStartTime, 
          @pnTotalSteps = @lnTotalSteps, 
          @pchStepMsg = @lvcMsg 

    /********** STEP 2 Finding the Product ID for the incoming accumulator specific members  **********/ 
    
    SELECT 
                accs.ACCUM_ID,
			    'MED' AS PDPD_ACC_SFX, --pdpd.PDPD_ACC_SFX,
                mepe.PDPD_ID, 
                mepe.CSPD_CAT ,
                accs.GRGR_ID
    INTO #tempPDPD
    
    FROM        fabncdv1custom.dbo.tpzt_accum_ip accs 
    INNER JOIN  fabncdv1.dbo.CMC_SBSB_SUBSC sbsb 
    ON            accs.SBSB_ID = sbsb.SBSB_ID 
    INNER JOIN  fabncdv1.dbo.CMC_GRGR_GROUP grgr ON
                accs.GRGR_ID = grgr.GRGR_ID AND
                sbsb.GRGR_CK = grgr.GRGR_CK
    INNER JOIN  fabncdv1.dbo.CMC_MEME_MEMBER meme ON
                accs.MEME_SFX = meme.MEME_SFX AND
                sbsb.SBSB_CK = meme.SBSB_CK AND
                sbsb.GRGR_CK = meme.GRGR_CK
    INNER JOIN  fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe ON
                mepe.MEME_CK = meme.MEME_CK 
	INNER JOIN  fabncdv1.dbo.CMC_PDPD_PRODUCT pdpd ON
			    mepe.PDPD_ID = pdpd.PDPD_ID
    WHERE
                mepe.CSPD_CAT IN ('M','R') AND
                accs.DOS_DT BETWEEN mepe.MEPE_EFF_DT AND mepe.MEPE_TERM_DT AND
                accs.DOS_DT BETWEEN pdpd.PDPD_EFF_DT AND pdpd.PDPD_TERM_DT AND
                mepe. MEPE_ELIG_IND = 'Y' AND 
				accs.INPUT_FLAG = 'N'
				AND accs.STATUS = 'PASS'

    /************* Error checking for Finding the Product ID for the incoming accumulator specific members  **********/ 
    SELECT @lnRetCd = @@ERROR, 
           @lnRowsProcessed = @@ROWCOUNT 

    IF @lnRetCd <> 0 
      BEGIN 
          SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109) 
                           + ' : Finding the Product ID for the incoming accumulator specific members FAILED' 
                           + ' RETURNCODE: ' + CONVERT(CHAR(6), @lnRetCd) 
          PRINT @lvcMsg 
          RETURN @lnRetCd 
      END 

    /**************  PRINT STEP 2 FOOTER DATA *************************/ 
    SELECT @ldtStepEndTime = GETDATE() 

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pdtStepEndTime = @ldtStepEndTime, 
      @pdtProcessStartTime = @ldtProcessStartTime, 
      @pnRowCount = @lnRowsProcessed 
    
   /**************  PRINT STEP 3  HEADER DATA *************************/ 
    SELECT @lnCurrentStep = @lnCurrentStep + 1, 
           @ldtStepStartTime = GETDATE(), 
           @lvcMsg = @lvcObjectName + ': Inserting the Family Accumulator Information for Deductible ' 

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr 
      @pnStepNumber = @lnCurrentStep, 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pnTotalSteps = @lnTotalSteps, 
      @pchStepMsg = @lvcMsg 
            
    /********** STEP 3 Insert the Family Accumulator Information for Deductibles  **********/ 
    
    INSERT INTO #tempFAACKW
    SELECT 
                'FAAC' AS RECTYPE,
                accs.ACCUM_ID,
                'AP' AS FAAC_UPDATE_CODE,
                accs.GRGR_ID,
                accs.SBSB_ID,
                'MED' AS PDPD_ACC_SFX, --temp.PDPD_ACC_SFX  AS PDPD_ACC_SFX,
                accs.ACCUM_TYPE AS FAAC_ACC_TYPE,
                CASE 
                       WHEN temp.CSPD_CAT = 'M' THEN '2'  
                       WHEN temp.CSPD_CAT = 'R' THEN '41'
                END 
                AS ACAC_ACC_NO, 
                '' AS ACAC_PLAN_YEAR,
                accs.ACCUM_AMOUNT AS FAAC_AMT1
    FROM        fabncdv1custom.dbo.tpzt_accum_ip accs 
    INNER JOIN  #tempPDPD temp 
    ON          temp.ACCUM_ID = accs.ACCUM_ID
    WHERE       accs.ACCUM_TYPE = 'D' AND 
				accs.INPUT_FLAG = 'N'
				AND accs.STATUS = 'PASS'

    /************* Error checking for Inserting the Family Accumulator Information for Deductibles **********/ 
    SELECT @lnRetCd = @@ERROR, 
           @lnRowsProcessed = @@ROWCOUNT 

    IF @lnRetCd <> 0 
      BEGIN 
          SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109) 
                           + ' : Inserting the Family Accumulator Information for Deductible FAILED' 
                           + ' RETURNCODE: ' + CONVERT(CHAR(6), @lnRetCd) 
          PRINT @lvcMsg 
          RETURN @lnRetCd 
      END 

    /**************  PRINT STEP 3 FOOTER DATA *************************/ 
    SELECT @ldtStepEndTime = GETDATE() 

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pdtStepEndTime = @ldtStepEndTime, 
      @pdtProcessStartTime = @ldtProcessStartTime, 
      @pnRowCount = @lnRowsProcessed

    /**************  PRINT STEP 4  HEADER DATA *************************/ 
    SELECT @lnCurrentStep = @lnCurrentStep + 1, 
           @ldtStepStartTime = GETDATE(), 
           @lvcMsg = @lvcObjectName + ': Inserting the Member Level Accumulator Information for Deductible ' 

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr 
      @pnStepNumber = @lnCurrentStep, 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pnTotalSteps = @lnTotalSteps, 
      @pchStepMsg = @lvcMsg 
            
    /********** STEP 4 Insert the Member Level Accumulator Information for Deductibles **********/ 
    
    INSERT INTO #tempMEACKW
    SELECT 
                'MEAC' AS RECTYPE,
                accs.ACCUM_ID,
                'AP' AS MEAC_UPDATE_CODE,
                accs.GRGR_ID,
                accs.SBSB_ID,
                accs.MEME_SFX AS MEME_SFX,
                'MED' AS PDPD_ACC_SFX,    --temp.PDPD_ACC_SFX AS PDPD_ACC_SFX,
                accs.ACCUM_TYPE AS MEAC_ACC_TYPE,
                CASE 
                       WHEN temp.CSPD_CAT = 'M' THEN '2'  
                       WHEN temp.CSPD_CAT = 'R'    THEN '41'
                END 
                AS ACAC_ACC_NO, 
                '' AS ACAC_PLAN_YEAR,
                accs.ACCUM_AMOUNT AS MEAC_AMT1,
                'N' AS FAAC_ACC_IND,
				CONVERT(VARCHAR(10), accs.DOS_DT, 101) AS SERVICE_DT,
				CASE 
                       WHEN temp.CSPD_CAT = 'M' THEN 'M'  
                       WHEN temp.CSPD_CAT = 'R' THEN 'R'
                END AS CSPD_CAT
    FROM        fabncdv1custom.dbo.tpzt_accum_ip accs 
    INNER JOIN    #tempPDPD temp 
    ON            temp.ACCUM_ID = accs.ACCUM_ID
    WHERE        accs .ACCUM_TYPE = 'D' AND 
				 accs.INPUT_FLAG = 'N'
				 AND accs.STATUS = 'PASS'

    /************* Error checking for Inserting the Member Level Accumulator Information **********/ 
    SELECT @lnRetCd = @@ERROR, 
           @lnRowsProcessed = @@ROWCOUNT 

    IF @lnRetCd <> 0 
      BEGIN 
          SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109) 
                           + ' : Inserting the Member Level Accumulator Information for Deductible FAILED' 
                           + ' RETURNCODE: ' + CONVERT(CHAR(6), @lnRetCd) 
          PRINT @lvcMsg 
          RETURN @lnRetCd 
      END 

    /**************  PRINT STEP 4 FOOTER DATA *************************/ 
    SELECT @ldtStepEndTime = GETDATE() 

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pdtStepEndTime = @ldtStepEndTime, 
      @pdtProcessStartTime = @ldtProcessStartTime, 
      @pnRowCount = @lnRowsProcessed
        
/**************  PRINT STEP 5  HEADER DATA *************************/ 
    SELECT @lnCurrentStep = @lnCurrentStep + 1, 
           @ldtStepStartTime = GETDATE(), 
           @lvcMsg = @lvcObjectName + ': Inserting the Family Accumulator Information for Limits ' 

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr 
      @pnStepNumber = @lnCurrentStep, 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pnTotalSteps = @lnTotalSteps, 
      @pchStepMsg = @lvcMsg 
    
    /********** STEP 5 Insert the Family Accumulator Information  for Limits **********/ 
    
    INSERT INTO #tempFAACKW
    SELECT 
                'FAAC' AS RECTYPE,
                accs.ACCUM_ID,
                'AP' AS FAAC_UPDATE_CODE,
                accs.GRGR_ID,
                accs.SBSB_ID,
                'MED' AS PDPD_ACC_SFX,  --temp.PDPD_ACC_SFX  AS PDPD_ACC_SFX,
                accs.ACCUM_TYPE AS FAAC_ACC_TYPE,
                CASE 
                       WHEN    temp.CSPD_CAT = 'M' THEN '1002'  
                       WHEN temp.CSPD_CAT = 'R'    THEN '1502'
                END 
                AS ACAC_ACC_NO,
                '' AS ACAC_PLAN_YEAR,
                accs.ACCUM_AMOUNT AS FAAC_AMT1
    FROM        fabncdv1custom.dbo.tpzt_accum_ip accs 
    INNER JOIN    #tempPDPD temp 
    ON            temp.ACCUM_ID = accs.ACCUM_ID
    WHERE        accs.ACCUM_TYPE = 'L' AND 
				accs.INPUT_FLAG = 'N'
				AND accs.STATUS = 'PASS'

    /************* Error checking for Inserting the Family Accumulator Information  **********/ 
    SELECT @lnRetCd = @@ERROR, 
           @lnRowsProcessed = @@ROWCOUNT 

    IF @lnRetCd <> 0 
      BEGIN 
          SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109) 
                           + ' : Inserting the Family Accumulator Information for Limits FAILED' 
                           + ' RETURNCODE: ' + CONVERT(CHAR(6), @lnRetCd) 
          PRINT @lvcMsg 
          RETURN @lnRetCd 
      END 

    /**************  PRINT STEP 5 FOOTER DATA *************************/ 
    SELECT @ldtStepEndTime = GETDATE() 

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pdtStepEndTime = @ldtStepEndTime, 
      @pdtProcessStartTime = @ldtProcessStartTime, 
      @pnRowCount = @lnRowsProcessed

    /**************  PRINT STEP 6  HEADER DATA *************************/ 
    SELECT @lnCurrentStep = @lnCurrentStep + 1, 
           @ldtStepStartTime = GETDATE(), 
           @lvcMsg = @lvcObjectName + ': Inserting the Member Level Accumulator Information for Limits ' 

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr 
      @pnStepNumber = @lnCurrentStep, 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pnTotalSteps = @lnTotalSteps, 
      @pchStepMsg = @lvcMsg 
    
    /********** STEP 6 Insert the Member Level Accumulator Information for Limits**********/ 
    INSERT INTO #tempMEACKW 
    SELECT      'MEAC' AS RECTYPE,
                accs.ACCUM_ID,
                'AP' AS MEAC_UPDATE_CODE,
                accs.GRGR_ID,
                accs.SBSB_ID,
                accs. MEME_SFX AS MEME_SFX,
                'MED'  AS PDPD_ACC_SFX,   --temp.PDPD_ACC_SFX  AS PDPD_ACC_SFX,
                accs. ACCUM_TYPE AS MEAC_ACC_TYPE,
                CASE 
                       WHEN temp.CSPD_CAT = 'M' THEN '2'  
                       WHEN temp.CSPD_CAT = 'R'    THEN '502'
                END 
                AS ACAC_ACC_NO,
                '' AS ACAC_PLAN_YEAR,
                accs.ACCUM_AMOUNT AS MEAC_AMT1,
                'N' AS FAAC_ACC_IND,
				CONVERT(VARCHAR(10), accs.DOS_DT, 101) AS SERVICE_DT,
				CASE 
                       WHEN temp.CSPD_CAT = 'M' THEN 'M'  
                       WHEN temp.CSPD_CAT = 'R' THEN 'R'
                END AS CSPD_CAT
    FROM        fabncdv1custom.dbo.tpzt_accum_ip accs 
    INNER JOIN  #tempPDPD temp 
    ON            temp.ACCUM_ID = accs.ACCUM_ID
    WHERE        accs.ACCUM_TYPE = 'L' AND 
				 accs.INPUT_FLAG = 'N'
				 AND accs.STATUS = 'PASS'

        /************* Error checking for Inserting the Member Level Accumulator Information  **********/ 
        SELECT @lnRetCd = @@ERROR, 
               @lnRowsProcessed = @@ROWCOUNT 

        IF @lnRetCd <> 0 
          BEGIN 
              SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109) 
                               + ' : Inserting the Member Level Accumulator Information for Limits FAILED' 
                               + ' RETURNCODE: ' + CONVERT(CHAR(6), @lnRetCd) 
              PRINT @lvcMsg 
              RETURN @lnRetCd 
          END 

        /**************  PRINT STEP 6 FOOTER DATA *************************/ 
        SELECT @ldtStepEndTime = GETDATE() 

        EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr 
          @pdtStepStartTime = @ldtStepStartTime, 
          @pdtStepEndTime = @ldtStepEndTime, 
          @pdtProcessStartTime = @ldtProcessStartTime, 
          @pnRowCount = @lnRowsProcessed    
        
		 /**************  PRINT STEP 7  HEADER DATA *************************/ 
    SELECT @lnCurrentStep = @lnCurrentStep + 1, 
           @ldtStepStartTime = GETDATE(), 
           @lvcMsg = @lvcObjectName + ': Inserting the Plan begin date information into temp table #temp_Plan_Dt' 

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr 
      @pnStepNumber = @lnCurrentStep, 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pnTotalSteps = @lnTotalSteps, 
      @pchStepMsg = @lvcMsg 
    
    /********** STEP 7 Inserting the Plan begin date information into temp table #temp_Plan_Dt**********/
	SELECT	RIGHT('0' + CAST(cspi.CSPI_PDPD_BEG_MMDD AS NVARCHAR),4) AS CSPI_PDPD_BEG_MMDD ,
				accs.ACCUM_ID, 
				accs.GRGR_ID , 
				accs.SBSB_ID ,
				accs.DOS_DT
			INTO #temp_Plan_Dt
		FROM fabncdv1custom.dbo.tpzt_accum_ip accs 
		INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb ON accs.SBSB_ID = sbsb.SBSB_ID
		INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr ON sbsb.GRGR_CK = grgr.GRGR_CK
														AND accs.GRGR_ID = grgr.GRGR_ID
		INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme ON sbsb.SBSB_CK = meme.SBSB_CK 
														AND grgr.GRGR_CK = meme.GRGR_CK
														AND accs.MEME_SFX = meme.MEME_SFX
		INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe ON meme.MEME_CK = mepe.MEME_CK 												
		INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi ON mepe.CSPI_ID = cspi.CSPI_ID 
														AND mepe.GRGR_CK = cspi.GRGR_CK 
														AND mepe.CSCS_ID = cspi.CSCS_ID
														AND mepe.CSPD_CAT = cspi.CSPD_CAT														
		WHERE   
				mepe.CSPD_CAT = 'M' 
				AND accs.DOS_DT BETWEEN mepe.MEPE_EFF_DT AND mepe.MEPE_TERM_DT
				AND accs.DOS_DT BETWEEN cspi.CSPI_EFF_DT AND cspi.CSPI_TERM_DT
				AND mepe.MEPE_ELIG_IND = 'Y'
				AND accs.INPUT_FLAG = 'N'
				AND accs.STATUS = 'PASS'
				
	/************* Error checking for Inserting the Plan begin date information into temp table #temp_Plan_Dt  **********/ 
    SELECT @lnRetCd = @@ERROR, 
           @lnRowsProcessed = @@ROWCOUNT 

    IF @lnRetCd <> 0 
      BEGIN 
          SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109) 
                           + ' : Inserting the Plan begin date information into temp table #temp_Plan_Dt FAILED' 
                           + ' RETURNCODE: ' + CONVERT(CHAR(6), @lnRetCd) 
          PRINT @lvcMsg 
          RETURN @lnRetCd 
      END 

    /**************  PRINT STEP 7 FOOTER DATA *************************/ 
    SELECT @ldtStepEndTime = GETDATE() 

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pdtStepEndTime = @ldtStepEndTime, 
      @pdtProcessStartTime = @ldtProcessStartTime, 
      @pnRowCount = @lnRowsProcessed

	   /**************  PRINT STEP 8  HEADER DATA *************************/ 
    SELECT @lnCurrentStep = @lnCurrentStep + 1, 
           @ldtStepStartTime = GETDATE(), 
           @lvcMsg = @lvcObjectName + ': Updating Family Level Accumulator Information for inserting ACAC_PLAN_YEAR' 

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr 
      @pnStepNumber = @lnCurrentStep, 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pnTotalSteps = @lnTotalSteps, 
      @pchStepMsg = @lvcMsg 
    
    /********** STEP 8 Updating Family Level Accumulator Information for inserting ACAC_PLAN_YEAR**********/
	UPDATE faackw
				SET ACAC_PLAN_YEAR =  CASE WHEN (SUBSTRING(LEFT(CONVERT(VARCHAR(8),plandt.DOS_DT,112) + SPACE(8),8),5,4) >= plandt.CSPI_PDPD_BEG_MMDD)
										THEN '01/01/' + CONVERT(CHAR,YEAR(plandt.DOS_DT))
										ELSE '01/01/' + CONVERT(CHAR,YEAR(plandt.DOS_DT)-1)
										END  
				FROM #tempFAACKW faackw 
				INNER JOIN #temp_Plan_Dt plandt 
					ON faackw.ACCUM_ID = plandt.ACCUM_ID 
					AND faackw.GRGR_ID = plandt.GRGR_ID 
					AND faackw.SBSB_ID = plandt.SBSB_ID 
				
	/************* Error checking for Updating Family Level Accumulator Information for inserting ACAC_PLAN_YEAR  **********/ 
    SELECT @lnRetCd = @@ERROR, 
           @lnRowsProcessed = @@ROWCOUNT 

    IF @lnRetCd <> 0 
      BEGIN 
          SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109) 
                           + ' : Updating Family Level Accumulator Information for inserting ACAC_PLAN_YEAR FAILED' 
                           + ' RETURNCODE: ' + CONVERT(CHAR(6), @lnRetCd) 
          PRINT @lvcMsg 
          RETURN @lnRetCd 
      END 

    /**************  PRINT STEP 8 FOOTER DATA *************************/ 
    SELECT @ldtStepEndTime = GETDATE() 

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pdtStepEndTime = @ldtStepEndTime, 
      @pdtProcessStartTime = @ldtProcessStartTime, 
      @pnRowCount = @lnRowsProcessed
	  
	/**************  PRINT STEP 9  HEADER DATA *************************/ 
    SELECT @lnCurrentStep = @lnCurrentStep + 1, 
           @ldtStepStartTime = GETDATE(), 
           @lvcMsg = @lvcObjectName + ': Updating Member Level Accumulator Information for inserting ACAC_PLAN_YEAR' 

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr 
      @pnStepNumber = @lnCurrentStep, 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pnTotalSteps = @lnTotalSteps, 
      @pchStepMsg = @lvcMsg 
    
    /********** STEP 9 Updating Member Level Accumulator Information for inserting ACAC_PLAN_YEAR**********/
	UPDATE meackw
				SET ACAC_PLAN_YEAR =  CASE WHEN (SUBSTRING(LEFT(CONVERT(VARCHAR(8),plandt.DOS_DT,112) + SPACE(8),8),5,4) >= plandt.CSPI_PDPD_BEG_MMDD)
										THEN '01/01/' + CONVERT(CHAR,YEAR(plandt.DOS_DT))
										ELSE '01/01/' + CONVERT(CHAR,YEAR(plandt.DOS_DT)-1)
										END  
				FROM #tempMEACKW meackw 
				INNER JOIN #temp_Plan_Dt plandt 
					ON meackw.ACCUM_ID = plandt.ACCUM_ID 
					AND meackw.GRGR_ID = plandt.GRGR_ID 
					AND meackw.SBSB_ID = plandt.SBSB_ID 
					AND meackw.SERVICE_DT = CONVERT(VARCHAR(10), plandt.DOS_DT, 101)
				
	/************* Error checking for Updating Member Level Accumulator Information for inserting ACAC_PLAN_YEAR  **********/ 
    SELECT @lnRetCd = @@ERROR, 
           @lnRowsProcessed = @@ROWCOUNT 

    IF @lnRetCd <> 0 
      BEGIN 
          SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109) 
                           + ' : Updating Member Level Accumulator Information for inserting ACAC_PLAN_YEAR FAILED' 
                           + ' RETURNCODE: ' + CONVERT(CHAR(6), @lnRetCd) 
          PRINT @lvcMsg 
          RETURN @lnRetCd 
      END 

    /**************  PRINT STEP 9 FOOTER DATA *************************/ 
    SELECT @ldtStepEndTime = GETDATE() 

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pdtStepEndTime = @ldtStepEndTime, 
      @pdtProcessStartTime = @ldtProcessStartTime, 
      @pnRowCount = @lnRowsProcessed
                    
    /**************  PRINT STEP 10  HEADER DATA *************************/ 
        SELECT @lnCurrentStep = @lnCurrentStep + 1, 
               @ldtStepStartTime = GETDATE(), 
               @lvcMsg = @lvcObjectName + ': Updating the record status as Pend for Accumulator for no matching found ' 

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr 
          @pnStepNumber = @lnCurrentStep, 
          @pdtStepStartTime = @ldtStepStartTime, 
          @pnTotalSteps = @lnTotalSteps, 
          @pchStepMsg = @lvcMsg 
        
    /********** STEP 10 Updating the record status as Pend for Accumulator for no matching found **********/ 
        
    UPDATE 
            fabncdv1custom.dbo.tpzt_accum_resp 
    SET        REC_STATUS = 'PEND',
            ERR_DESC = 'Eligibility for the Input Member is not found',
			STATUS = 'PEND',
			[MODE] = 'N'
    FROM    fabncdv1custom.dbo.tpzt_accum_resp acre
    WHERE    CONVERT(VARCHAR(8),acre.LAST_UPD_DT, 112) = CONVERT(VARCHAR(8), GETDATE(), 112) AND
            acre.REC_STATUS = 'Received' AND
            acre.RESP_STATUS = 'N' AND 
            acre.ACCUM_ID NOT IN (SELECT ACCUM_ID FROM #tempFAACKW ) AND 
            acre.ACCUM_ID NOT IN (SELECT ACCUM_ID FROM #tempMEACKW ) 
			
	UPDATE
		accum
		SET STATUS = 'PEND',
			[MODE] = 'N'
		FROM fabncdv1custom.dbo.tpzt_accum_ip accum
		INNER JOIN fabncdv1custom.dbo.tpzt_accum_resp resp
			ON accum.ACCUM_ID = resp.ACCUM_ID
		WHERE resp.STATUS = 'PEND'
		AND resp.ERR_DESC = 'Eligibility for the Input Member is not found'
		AND CONVERT(VARCHAR(8),resp.LAST_UPD_DT, 112) = CONVERT(VARCHAR(8), GETDATE(), 112) 
        AND resp.REC_STATUS = 'Received' 
        AND resp.RESP_STATUS = 'N' 
    
	
    /************* Error checking for Updating the record status as Pend for Accumulator for no matching found  **********/ 
    SELECT @lnRetCd = @@ERROR, 
           @lnRowsProcessed = @@ROWCOUNT 

    IF @lnRetCd <> 0 
      BEGIN 
          SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109) 
                           + ' : Updating the record status as Pend for Accumulator for no matching found FAILED' 
                           + ' RETURNCODE: ' + CONVERT(CHAR(6), @lnRetCd) 
          PRINT @lvcMsg 
          RETURN @lnRetCd 
      END 

    /**************  PRINT STEP 10 FOOTER DATA *************************/ 
    SELECT @ldtStepEndTime = GETDATE() 

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pdtStepEndTime = @ldtStepEndTime, 
      @pdtProcessStartTime = @ldtProcessStartTime, 
      @pnRowCount = @lnRowsProcessed

      /**************  PRINT STEP 11  HEADER DATA *************************/ 
    SELECT @lnCurrentStep = @lnCurrentStep + 1, 
           @ldtStepStartTime = GETDATE(), 
           @lvcMsg = @lvcObjectName + ': Truncating stage table tpzt_accum_error ' 

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr 
      @pnStepNumber = @lnCurrentStep, 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pnTotalSteps = @lnTotalSteps, 
      @pchStepMsg = @lvcMsg 
            
    /********** STEP 11 Truncating stage table 'tpzt_accum_error' **********/ 
        
    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_accum_error

    /************* Error checking for Truncating stage table 'tpzt_accum_error'  **********/ 
    SELECT @lnRetCd = @@ERROR, 
           @lnRowsProcessed = @@ROWCOUNT 

    IF @lnRetCd <> 0 
      BEGIN 
          SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109) 
                           + ' : Truncating stage table tpzt_accum_error FAILED' 
                           + ' RETURNCODE: ' + CONVERT(CHAR(6), @lnRetCd) 
          PRINT @lvcMsg 
          RETURN @lnRetCd 
      END 

    /**************  PRINT STEP 11 FOOTER DATA *************************/ 
    SELECT @ldtStepEndTime = GETDATE() 

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pdtStepEndTime = @ldtStepEndTime, 
      @pdtProcessStartTime = @ldtProcessStartTime, 
      @pnRowCount = @lnRowsProcessed
  
       /**************  PRINT STEP 12  HEADER DATA *************************/ 
    SELECT @lnCurrentStep = @lnCurrentStep + 1, 
           @ldtStepStartTime = GETDATE(), 
           @lvcMsg = @lvcObjectName + ': Creating recordset for Keyword File ' 

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr 
          @pnStepNumber = @lnCurrentStep, 
          @pdtStepStartTime = @ldtStepStartTime, 
          @pnTotalSteps = @lnTotalSteps, 
          @pchStepMsg = @lvcMsg 
            
    /********** STEP 12 Creating recordset for Keyword File ordered by FAAC_AMT1/MEAC_AMT1 **********/ 
        
    SELECT DISTINCT 
           ACCUM_ID,
           RECTYPE,
           FAAC_UPDATE_CODE,
           GRGR_ID,
           SBSB_ID,
           PDPD_ACC_SFX,
           FAAC_ACC_TYPE,
           ACAC_ACC_NO,
           ACAC_PLAN_YEAR,
           FAAC_AMT1
    FROM #tempFAACKW ORDER BY GRGR_ID, SBSB_ID, PDPD_ACC_SFX, FAAC_ACC_TYPE,ACAC_ACC_NO, FAAC_AMT1 DESC

    SELECT DISTINCT 
           ACCUM_ID,
           RECTYPE,
           MEAC_UPDATE_CODE,
           GRGR_ID,
           SBSB_ID,
           MEME_SFX,
           PDPD_ACC_SFX,
           MEAC_ACC_TYPE,
           ACAC_ACC_NO,
           ACAC_PLAN_YEAR,
           MEAC_AMT1,
           FAAC_ACC_IND,
		   SERVICE_DT,
		   CSPD_CAT
    FROM #tempMEACKW ORDER BY GRGR_ID, SBSB_ID, PDPD_ACC_SFX, MEAC_ACC_TYPE,ACAC_ACC_NO, MEAC_AMT1 DESC

    /************* Error checking for Updating the record status as Pend for Accumulator for no matching found  **********/ 
    SELECT @lnRetCd = @@ERROR, 
           @lnRowsProcessed = @@ROWCOUNT 

    IF @lnRetCd <> 0 
      BEGIN 
          SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109) 
                           + ' : Creating recordset for Keyword File FAILED' 
                           + ' RETURNCODE: ' + CONVERT(CHAR(6), @lnRetCd) 
          PRINT @lvcMsg 
          RETURN @lnRetCd 
      END 

    /**************  PRINT STEP 12 FOOTER DATA *************************/ 
    SELECT @ldtStepEndTime = GETDATE() 

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pdtStepEndTime = @ldtStepEndTime, 
      @pdtProcessStartTime = @ldtProcessStartTime, 
      @pnRowCount = @lnRowsProcessed
	  
    /**************  PRINT JOB FOOTER DATA ****************************/ 
    SELECT @ldtProcessEndTime = GETDATE() 

    EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr 
        @pchObjectName = @lvcObjectName, 
        @pdtProcessStartTime = @ldtProcessStartTime, 
        @pdtProcessEndTime = @ldtProcessEndTime 
    
    RETURN @lnRetCd 
  END 

/**************************************************************** 
** BEGIN MAINTENANCE WRAPPER.                                  ** 
****************************************************************/ 
GO 
IF OBJECT_ID('dbo.tpzp_accum_ext') IS NOT NULL 
  PRINT '<<< CREATED PROCEDURE dbo.tpzp_accum_ext >>>' 
ELSE 
  PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_accum_ext >>>' 
GO 
/**************************************************************** 
** END MAINTENANCE WRAPPER.                                    ** 
****************************************************************/ 

