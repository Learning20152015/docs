/**************************************************************** 
** BEGIN MAINTENANCE WRAPPER.                                  ** 
****************************************************************/ 
IF OBJECT_ID('dbo.tpzp_accum_input_flag_update') IS NOT NULL 
  BEGIN 
      DROP PROCEDURE dbo.tpzp_accum_input_flag_update 

      IF OBJECT_ID('dbo.tpzp_accum_input_flag_update') IS NOT NULL 
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_accum_input_flag_update >>>' 
      ELSE 
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_accum_input_flag_update >>>' 
  END 

GO 
/**************************************************************** 
** END MAINTENANCE WRAPPER.                                    ** 
****************************************************************/ 
CREATE PROCEDURE [dbo].[tpzp_accum_input_flag_update] 
/**************************************************************** 
**   NAME                  :  tpzp_accum_input_flag_update  
** 
** 
**   PVCS LOCATION         :   Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Stored Procedures\Custom
** 
**   FUNCTION              :  To update column INPUT_FLAG from N to Y
** 
**   PARAMETERS            : 
**   OUTPUT                : 
**   RETURN CODES          :  0 on success 
** 
**   TABLES REFERENCED     : 
**                FACETS   :  N/A 
**                FACETSXC :  N/A 
**                CUSTOM   :  fabncdv1custom.dbo.tpzt_accum_ip 
**                            fabncdv1custom.dbo.tpzt_accum_resp 
**                STAGE    :  fabncdv1stage.dbo.tpzt_accum_error
** 
**   PROCEDURES REFERENCED :  N/A 
**                  FACETS :  N/A 
**                  CUSTOM :  N/A 
**   STANDARD LOGGING PROCS: 
**                           harcore.dbo.harsp_gen_util_job_hdr_lgr 
**                           harcore.dbo.harsp_gen_util_job_ftr_lgr 
**                           harcore.dbo.harsp_gen_util_step_hdr_lgr 
**                           harcore.dbo.harsp_gen_util_step_ftr_lgr 
** 
** REVISION HISTORY        : 
** VERSION  DATE         DEVELOPER           DESCRIPTION 
** -------- ----------   -----------------   -------------------- 
** 1.0      11/06/2014   Sameeksha Joshi     Initial version
****************************************************************/ 
AS 
  BEGIN 
      /**************************************************************** 
      **          DECLARE LOCAL VARIABLES                            ** 
      ****************************************************************/ 
      DECLARE @lnRetCd INT -- Proc return code 
      DECLARE @lvcMsg VARCHAR(255) -- Generic Message Field 
      DECLARE @lnCurrentStep INT -- Current Step Number 
      DECLARE @ldtStepStartTime DATETIME -- Step Start Date / Time 
      DECLARE @lnTotalSteps INT -- Total Steps In Proc 
      DECLARE @lvcObjectName VARCHAR(32) -- SP Name 
      DECLARE @lvcServerName VARCHAR(32) -- DB Server Name 
      DECLARE @lvcDBName VARCHAR(32) -- DB Name 
      DECLARE @lvcVersionNum VARCHAR(32) -- Object Version 
      DECLARE @lvcUser VARCHAR(32) -- Executing User Name 
      DECLARE @lvcJeGrpCount VARCHAR(32) -- Number of JE group extract 
      DECLARE @ldtProcessStartTime DATETIME -- Job Start Date / Time 
      DECLARE @lnRowsProcessed INT -- Rows Processed by Step 
      DECLARE @ldtStepEndTime DATETIME -- Step End Date / Time 
      DECLARE @ldtProcessEndTime DATETIME -- Job End Date / Time 
      DECLARE @lnTotRecordCnt INT 

    /**************************************************************** 
    **          INITIALIZE  VARIABLES                              ** 
    ****************************************************************/ 
    SELECT @lnRetCd = 0, 
         @lvcMsg = NULL, 
         @lnCurrentStep = 0, 
         @lnTotalSteps = 1, 
         @ldtStepEndTime = NULL 

    SELECT @lvcServerName = @@SERVERNAME, 
         @lvcDBName = DB_NAME(), 
         @lvcUser = USER_NAME(), 
         @lvcObjectName = OBJECT_NAME(@@PROCID), 
         @ldtProcessStartTime = GETDATE() 

    /**************************************************************** 
    **               BEGIN PROCESS                                 ** 
    *****************************************************************/ 
  
    /**************  PRINT JOB HEADER DATA *************************/ 
    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr 
        @pchObjectName = @lvcObjectName, 
        @pdtProcessStartTime = @ldtProcessStartTime, 
        @pchServerName = @lvcServerName, 
        @pchDBName = @lvcDBName, 
        @pchUserName = @lvcUser, 
        @pchVersionNum = @lvcVersionNum 
		
	/**************  PRINT STEP 1  HEADER DATA *************************/ 
    SELECT @lnCurrentStep = @lnCurrentStep + 1, 
           @ldtStepStartTime = GETDATE(), 
           @lvcMsg = @lvcObjectName + ': Updating table tpzt_accum_ip for INPUT_FLAG = Y ' 

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr 
          @pnStepNumber = @lnCurrentStep, 
          @pdtStepStartTime = @ldtStepStartTime, 
          @pnTotalSteps = @lnTotalSteps, 
          @pchStepMsg = @lvcMsg 
            
    /********** STEP 1 Updating table tpzt_accum_ip for INPUT_FLAG = Y **********/ 
        
    UPDATE fabncdv1custom.dbo.tpzt_accum_ip
	SET INPUT_FLAG = 'Y'
	WHERE INPUT_FLAG = 'N'

    /************* Error checking for Updating table tpzt_accum_ip for INPUT_FLAG = Y  **********/ 
    SELECT @lnRetCd = @@ERROR, 
           @lnRowsProcessed = @@ROWCOUNT 

    IF @lnRetCd <> 0 
      BEGIN 
          SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109) 
                           + ' : Updating table tpzt_accum_ip for INPUT_FLAG = Y FAILED' 
                           + ' RETURNCODE: ' + CONVERT(CHAR(6), @lnRetCd) 
          PRINT @lvcMsg 
          RETURN @lnRetCd 
      END 

    /**************  PRINT STEP 1 FOOTER DATA *************************/ 
    SELECT @ldtStepEndTime = GETDATE() 

    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr 
      @pdtStepStartTime = @ldtStepStartTime, 
      @pdtStepEndTime = @ldtStepEndTime, 
      @pdtProcessStartTime = @ldtProcessStartTime, 
      @pnRowCount = @lnRowsProcessed
	  	  
    /**************  PRINT JOB FOOTER DATA ****************************/ 
    SELECT @ldtProcessEndTime = GETDATE() 

    EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr 
        @pchObjectName = @lvcObjectName, 
        @pdtProcessStartTime = @ldtProcessStartTime, 
        @pdtProcessEndTime = @ldtProcessEndTime 
    
    RETURN @lnRetCd 
  END 

/**************************************************************** 
** BEGIN MAINTENANCE WRAPPER.                                  ** 
****************************************************************/ 
GO 
IF OBJECT_ID('dbo.tpzp_accum_input_flag_update') IS NOT NULL 
  PRINT '<<< CREATED PROCEDURE dbo.tpzp_accum_input_flag_update >>>' 
ELSE 
  PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_accum_input_flag_update >>>' 
GO 
/**************************************************************** 
** END MAINTENANCE WRAPPER.                                    ** 
****************************************************************/ 