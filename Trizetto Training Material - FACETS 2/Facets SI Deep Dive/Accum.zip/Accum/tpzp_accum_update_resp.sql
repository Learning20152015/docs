/**************************************************************** 
** BEGIN MAINTENANCE WRAPPER.                                  ** 
****************************************************************/ 
IF OBJECT_ID('dbo.tpzp_accum_update_resp') IS NOT NULL 
  BEGIN 
      DROP PROCEDURE dbo.tpzp_accum_update_resp 

      IF OBJECT_ID('dbo.tpzp_accum_update_resp') IS NOT NULL 
        PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_accum_update_resp >>>' 
      ELSE 
        PRINT '<<< DROPPED PROCEDURE dbo.tpzp_accum_update_resp >>>' 
  END 

GO 
/**************************************************************** 
** END MAINTENANCE WRAPPER.                                    ** 
****************************************************************/ 
CREATE PROCEDURE [dbo].[tpzp_accum_update_resp]

/****************************************************************
**   NAME                  :    tpzp_accum_update_resp
**
**
**   PVCS LOCATION         :    Facets-HW Hosted\Facets\TPZ_501\Database\SQL Server\Stored Procedures\Custom
**
**   FUNCTION              :    Update the tpzt_accum_resp table to genrate response file
**
**   PARAMETERS            :
**                   INPUT :    @ptblERROR_FILE
**                  OUTPUT :    
**
**   RETURN CODES          :    0 on success
**
**   TABLES REFERENCED     :
**                FACETS   :    N/A
**                FACETSXC :    N/A
**                CUSTOM   :    fabncdv1custom.dbo.tpzt_accum_resp
**                              
**                STAGE    :    fabncdv1stage..tpzt_accum_error
**
**   PROCEDURES REFERENCED :    N/A
**                  FACETS :    N/A
**                  CUSTOM :    N/A
**   STANDARD LOGGING PROCS:
**                           harcore.dbo.harsp_gen_util_job_hdr_lgr
**                           harcore.dbo.harsp_gen_util_job_ftr_lgr
**                           harcore.dbo.harsp_gen_util_step_hdr_lgr
**                           harcore.dbo.harsp_gen_util_step_ftr_lgr
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER             DESCRIPTION
** -------- ----------   -----------------     --------------------
** 1.0      12/3/2013    Samir Dharmadhikari    Initial version
** 1.1      12/18/2013   Suwarna Patil          Updated
** 1.2      06/23/2013   Sameeksha Joshi        Updated the length of foeld ACCUM_ID
** 1.6      11/06/2013   Sameeksha Joshi        Updated for Defect # 300-78183 
** 1.7      11/13/2013   Sameeksha Joshi        Updated to send status as FAIL for both PEND and FAIL in update mode 
****************************************************************/

(
    @ptblERROR_FILE        dbo.tpzt_error_file_data    READONLY 
)

AS

BEGIN

   /****************************************************************
   **          DECLARE LOCAL VARIABLES                            **
   ****************************************************************/
   DECLARE @lnRetCd                INT              -- Proc return code
   DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field
   DECLARE @lnCurrentStep          INT              -- Current Step Number
   DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time
   DECLARE @lnTotalSteps           INT              -- Total Steps In Proc
   DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name
   DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name
   DECLARE @lvcDBName              VARCHAR(32)      -- DB Name
   DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version
   DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name
   DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time
   DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step
   DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time
   DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
   
   DECLARE @lnRecCount             INT              -- Record Count
   DECLARE @lnRowCountReopen       INT              -- Reopen Row Count
   DECLARE @lnRowCountClose        INT              -- Updated Row Count
   DECLARE @lnRowCountCreate       INT              -- Created Row Count
   DECLARE @lvcExportDataFormat    VARCHAR(3)       -- Export Data Format
   
   DECLARE @lvcLINE_NO             VARCHAR(10) 
   DECLARE @lvcREC_TYPE            VARCHAR(4)
   DECLARE @lvcGRGR_ID           VARCHAR(8)
   DECLARE @lvcSBSB_ID               VARCHAR(9) 
   DECLARE @lvcMEME_SFX           VARCHAR(10)
   DECLARE @lvcACAC_ACC_NO       VARCHAR(4)
   DECLARE @lvcPDPD_ACC_SFX        VARCHAR(4)
   DECLARE @lvcFAAC_ACC_IND       VARCHAR(2)
   DECLARE @lvcERROR               VARCHAR(100)
   DECLARE @lvcMEAC_AMT1       VARCHAR(25)
   DECLARE @lvcFAAC_AMT1       VARCHAR(25)
   DECLARE @lvcACCUM_ID           VARCHAR(51)
  
   
   /****************************************************************
   **          INITIALIZE  VARIABLES                              **
   ****************************************************************/
    SELECT    @lnRetCd          = 0,
            @lvcMsg           = NULL,
            @lnCurrentStep    = 0,
            @lnTotalSteps     = 8,
            @ldtStepEndTime   = NULL
    
   
    SELECT @lvcServerName     = @@SERVERNAME,
      @lvcDBName              = DB_NAME(),
      @lvcUser                = USER_NAME(),
      @lvcObjectName          = OBJECT_NAME(@@PROCID),
      @ldtProcessStartTime    = GETDATE()
      
   /****************************************************************
   **               BEGIN PROCESS                                 **
   *****************************************************************/
    
    /**************  PRINT JOB HEADER DATA *************************/
    
    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr
     @pchObjectName        = @lvcObjectName,
     @pdtProcessStartTime  = @ldtProcessStartTime,
     @pchServerName        = @lvcServerName,
     @pchDBName            = @lvcDBName,
     @pchUserName          = @lvcUser,
     @pchVersionNum        = @lvcVersionNum
      
      
   
   /**************  PRINT STEP 1  HEADER DATA *************************/

   SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime = GETDATE(),
      @lvcMsg = @lvcObjectName + ': Creating cursor for looping in ERROR File table '

   EXEC harcore..harsp_gen_util_step_hdr_lgr
     @pnStepNumber     = @lnCurrentStep,
     @pdtStepStartTime = @ldtStepStartTime,
     @pnTotalSteps     = @lnTotalSteps,
     @pchStepMsg       = @lvcMsg

    /********** STEP 1 Creating cursor for looping in ERROR File table  **********/
    
   DECLARE  CURSOR_ERR CURSOR FOR
   SELECT   LINE_NO, ACAC_ACC_NO, ERROR
   FROM        @ptblERROR_FILE
   
   OPEN        CURSOR_ERR
   
   /************* Error checking for Creating cursor for looping in ERROR File table  **********/

   SELECT @lnRetCd    = @@ERROR,
     @lnRowsProcessed = @@ROWCOUNT

   IF @lnRetCd <> 0
   BEGIN
     SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                       + ' : Creating cursor for looping in ERROR File table  FAILED'
                       + ' RETURNCODE: '
                       + CONVERT(CHAR(6),@lnRetCd)
   PRINT  @lvcMsg
   RETURN @lnRetCd
   END
   
   /**************  PRINT STEP 1 FOOTER DATA *************************/

   SELECT @ldtStepEndTime = GETDATE()

   EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
     @pdtStepStartTime    = @ldtStepStartTime,
     @pdtStepEndTime      = @ldtStepEndTime,
     @pdtProcessStartTime = @ldtProcessStartTime,
     @pnRowCount          = @lnRowsProcessed
   
      
   /**************  PRINT STEP 2  HEADER DATA *************************/

   SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime = GETDATE(),
      @lvcMsg = @lvcObjectName + ': Searching ACCUM_ID from error table matching with error file data'

   EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
     @pnStepNumber     = @lnCurrentStep,
     @pdtStepStartTime = @ldtStepStartTime,
     @pnTotalSteps     = @lnTotalSteps,
     @pchStepMsg       = @lvcMsg

    /********** STEP 2 Searching ACCUM_ID from error table matching with error file data **********/

   FETCH NEXT FROM CURSOR_ERR   
   INTO  @lvcLINE_NO, @lvcACAC_ACC_NO, @lvcERROR  
        
    
   WHILE @@FETCH_STATUS = 0
       BEGIN
                   SELECT   @lvcACCUM_ID = ACCUM_ID 
                   FROM        fabncdv1stage.dbo.tpzt_accum_error
                   WHERE    LINE_NO = CONVERT(INT,@lvcLINE_NO)
                   AND        ACAC_ACC_NO = @lvcACAC_ACC_NO
                             
   
   /************* Error checking for Searching ACCUM_ID from error table matching with error file data **********/

   SELECT @lnRetCd    = @@ERROR,
     @lnRowsProcessed = @@ROWCOUNT

   IF @lnRetCd <> 0
   BEGIN
     SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
                       + ' : Searching ACCUM_ID from error table matching with error file data  FAILED'
                       + ' RETURNCODE: '
                       + CONVERT(CHAR(6),@lnRetCd)
   PRINT  @lvcMsg
   RETURN @lnRetCd
   END
   
   /**************  PRINT STEP 2 FOOTER DATA *************************/

   SELECT @ldtStepEndTime = GETDATE()

   EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
     @pdtStepStartTime    = @ldtStepStartTime,
     @pdtStepEndTime      = @ldtStepEndTime,
     @pdtProcessStartTime = @ldtProcessStartTime,
     @pnRowCount          = @lnRowsProcessed
   
   
   /**************  PRINT STEP 3  HEADER DATA *************************/

   SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime = GETDATE(),
      @lvcMsg = @lvcObjectName + ':Updating Response table for matching ACCUM_ID  '

   EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
     @pnStepNumber     = @lnCurrentStep,
     @pdtStepStartTime = @ldtStepStartTime,
     @pnTotalSteps     = @lnTotalSteps,
     @pchStepMsg       = @lvcMsg

    /********** STEP 3 Updating Response table for matching ACCUM_ID **********/

           IF(@lvcERROR LIKE '% eligibility for SERVICE_DT%')
           BEGIN
               
               UPDATE    fabncdv1custom.dbo.tpzt_accum_resp
               SET      REC_STATUS  = 'FAIL',
                        ERR_DESC    = @lvcERROR,
                        LAST_UPD_DT = @ldtProcessStartTime,
						STATUS = 'FAIL',
						[MODE] = 'U'
               WHERE    ACCUM_ID = @lvcACCUM_ID
               AND      REC_STATUS = 'Received'
               AND      RESP_STATUS = 'N'
			   AND      CONVERT(VARCHAR(8),LAST_UPD_DT, 112) = CONVERT(VARCHAR(8), @ldtProcessStartTime, 112)
			   
			   UPDATE   fabncdv1stage.dbo.tpzt_accum_error
				SET		STATUS = 'FAIL',
						ERR_DESC    =  @lvcERROR						
				WHERE   ACCUM_ID = @lvcACCUM_ID
				AND 	LINE_NO = @lvcLINE_NO
						   
			   UPDATE   accum
			   SET		STATUS = 'FAIL',
						[MODE] = 'U'
			   FROM 	fabncdv1custom.dbo.tpzt_accum_ip accum
			   INNER JOIN fabncdv1custom.dbo.tpzt_accum_resp resp
			  	 ON 	accum.ACCUM_ID = resp.ACCUM_ID
			   WHERE 	resp.STATUS = 'FAIL'
						AND resp.[MODE] = 'U'
				
           END
           
           ELSE
           
           BEGIN
           
               UPDATE    fabncdv1custom.dbo.tpzt_accum_resp
               SET      REC_STATUS  = 'FAIL',
                        ERR_DESC    = @lvcERROR,
                        LAST_UPD_DT = @ldtProcessStartTime,
						STATUS = 'FAIL',
						[MODE] = 'U'
               WHERE    ACCUM_ID = @lvcACCUM_ID
               AND      REC_STATUS = 'Received'
               AND      RESP_STATUS = 'N'
			   AND      CONVERT(VARCHAR(8),LAST_UPD_DT, 112) = CONVERT(VARCHAR(8), @ldtProcessStartTime, 112)
           
				UPDATE  accum
				SET 	STATUS = 'FAIL',
						[MODE] = 'U'
				FROM 	fabncdv1custom.dbo.tpzt_accum_ip accum
				INNER JOIN fabncdv1custom.dbo.tpzt_accum_resp resp
					ON 	accum.ACCUM_ID = resp.ACCUM_ID
				WHERE 	resp.STATUS = 'FAIL'
				
				UPDATE err
				SET STATUS = 'FAIL',
					ERR_DESC = @lvcERROR
					FROM fabncdv1stage.dbo.tpzt_accum_error err
					WHERE ACCUM_ID = @lvcACCUM_ID
						AND LINE_NO = @lvcLINE_NO
           END
           
           FETCH NEXT FROM CURSOR_ERR   
           INTO  @lvcLINE_NO, @lvcACAC_ACC_NO, @lvcERROR  
    END
    CLOSE CURSOR_ERR
    DEALLOCATE CURSOR_ERR     

   /************* Error checking for Updating Response table for matching ACCUM_ID **********/

   SELECT @lnRetCd    = @@ERROR,
     @lnRowsProcessed = @@ROWCOUNT

   IF @lnRetCd <> 0
   BEGIN
     SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
       + ' : Updating Response table for matching ACCUM_ID   FAILED'
       + ' RETURNCODE: '
       + CONVERT(CHAR(6),@lnRetCd)
   PRINT  @lvcMsg
   RETURN @lnRetCd
   END
   
   /**************  PRINT STEP 3 FOOTER DATA *************************/

   SELECT @ldtStepEndTime = GETDATE()

   EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
     @pdtStepStartTime    = @ldtStepStartTime,
     @pdtStepEndTime      = @ldtStepEndTime,
     @pdtProcessStartTime = @ldtProcessStartTime,
     @pnRowCount          = @lnRowsProcessed
   
   /**************  PRINT STEP 4  HEADER DATA *************************/

   SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime = GETDATE(),
      @lvcMsg = @lvcObjectName + ':Updating Response table for other ACCUM_ID  '

   EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
     @pnStepNumber     = @lnCurrentStep,
     @pdtStepStartTime = @ldtStepStartTime,
     @pnTotalSteps     = @lnTotalSteps,
     @pchStepMsg       = @lvcMsg

    /********** STEP 4 Updating Response table for other ACCUM_ID **********/
    
    UPDATE    resp
    SET        resp.REC_STATUS  = 'PASS',
            resp.LAST_UPD_DT = @ldtProcessStartTime,
			STATUS='PASS',
			[MODE] = 'U'
    FROM    fabncdv1custom.dbo.tpzt_accum_resp resp 
    INNER 
    JOIN    fabncdv1stage.dbo.tpzt_accum_error err
    ON        resp.ACCUM_ID =  err.ACCUM_ID
    WHERE    REC_STATUS = 'Received'
    AND        RESP_STATUS = 'N'
	AND		 resp.STATUS='PASS'
	AND      CONVERT(VARCHAR(8),resp.LAST_UPD_DT, 112) = CONVERT(VARCHAR(8), @ldtProcessStartTime, 112)
    
	UPDATE    ip
    SET     STATUS='PASS',
			[MODE] = 'U'
    FROM    fabncdv1custom.dbo.tpzt_accum_ip ip 
    INNER 
    JOIN    fabncdv1custom.dbo.tpzt_accum_resp resp 
    ON        resp.ACCUM_ID =  ip.ACCUM_ID
    WHERE   resp.[MODE] = 'U'
	AND		 resp.STATUS='PASS'
	AND      CONVERT(VARCHAR(8),resp.LAST_UPD_DT, 112) = CONVERT(VARCHAR(8), @ldtProcessStartTime, 112)
	
    UPDATE    fabncdv1custom.dbo.tpzt_accum_resp
    SET        REC_STATUS  = 'FAIL',
            LAST_UPD_DT = @ldtProcessStartTime,
            ERR_DESC = 'Matching Records Not Found in Facets Records',
			STATUS = 'FAIL',
			[MODE] = 'U'
    WHERE    ACCUM_ID NOT IN (SELECT ACCUM_ID FROM fabncdv1stage.dbo.tpzt_accum_error)
    AND        REC_STATUS = 'Received'
    AND        RESP_STATUS = 'N'
	AND      CONVERT(VARCHAR(8),LAST_UPD_DT, 112) = CONVERT(VARCHAR(8), @ldtProcessStartTime, 112)
    
	 /************* Error checking for Updating Response table for other ACCUM_ID **********/

   SELECT @lnRetCd    = @@ERROR,
     @lnRowsProcessed = @@ROWCOUNT

   IF @lnRetCd <> 0
   BEGIN
     SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
       + ' : Updating Response table for other ACCUM_ID  FAILED'
       + ' RETURNCODE: '
       + CONVERT(CHAR(6),@lnRetCd)
   PRINT  @lvcMsg
   RETURN @lnRetCd
   END
   
   /**************  PRINT STEP 4 FOOTER DATA *************************/

   SELECT @ldtStepEndTime = GETDATE()

   EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
     @pdtStepStartTime    = @ldtStepStartTime,
     @pdtStepEndTime      = @ldtStepEndTime,
     @pdtProcessStartTime = @ldtProcessStartTime,
     @pnRowCount          = @lnRowsProcessed
	 
	 /**************  PRINT STEP 5  HEADER DATA *************************/

   SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime = GETDATE(),
      @lvcMsg = @lvcObjectName + ':Updating accum id in response table  '

   EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
     @pnStepNumber     = @lnCurrentStep,
     @pdtStepStartTime = @ldtStepStartTime,
     @pnTotalSteps     = @lnTotalSteps,
     @pchStepMsg       = @lvcMsg

    /********** STEP 5 Updating accum id in response table **********/
	-- Selecting ACCUM_ID and STATUS into temp table
	SELECT 
		CASE WHEN UPPER(SUBSTRING(ACCUM_ID,LEN(ACCUM_ID),1)) IN ('L','D')
			THEN SUBSTRING(ACCUM_ID,1,LEN(ACCUM_ID)-1)
			ELSE ACCUM_ID
			END  AS ACCUM_ID,
			REC_STATUS	
		INTO #TEMP_ACCUM_ID
	FROM fabncdv1custom.dbo.tpzt_accum_resp
	WHERE RESP_STATUS = 'N'
	AND   CONVERT(VARCHAR(8),LAST_UPD_DT, 112) = CONVERT(VARCHAR(8), @ldtProcessStartTime, 112)
	
	UPDATE TEMP
	SET REC_STATUS = 'FAIL' -- ,ACCUM_ID
	FROM #TEMP_ACCUM_ID TEMP
	WHERE ACCUM_ID IN (SELECT ACCUM_ID FROM #TEMP_ACCUM_ID WHERE REC_STATUS='FAIL')
		AND REC_STATUS='PASS'
		
	UPDATE TEMP
	SET REC_STATUS = 'PEND' -- ,ACCUM_ID
	FROM #TEMP_ACCUM_ID TEMP
	WHERE ACCUM_ID IN (SELECT ACCUM_ID FROM #TEMP_ACCUM_ID WHERE REC_STATUS='PEND')
	AND REC_STATUS='PASS'
	
	UPDATE TEMP
	SET REC_STATUS = 'FAIL' -- ,ACCUM_ID
	FROM #TEMP_ACCUM_ID TEMP
	WHERE ACCUM_ID IN (SELECT ACCUM_ID FROM #TEMP_ACCUM_ID WHERE REC_STATUS='PEND')
	AND REC_STATUS='FAIL'

	-- Updating tpzt_accum_resp
	UPDATE RESP
	SET REC_STATUS = TEMP.REC_STATUS
	FROM fabncdv1custom.dbo.tpzt_accum_resp RESP
	INNER JOIN #TEMP_ACCUM_ID TEMP
		ON TEMP.ACCUM_ID = CASE WHEN UPPER(SUBSTRING(RESP.ACCUM_ID,LEN(RESP.ACCUM_ID),1)) IN ('L','D')
							THEN SUBSTRING(RESP.ACCUM_ID,1,LEN(RESP.ACCUM_ID)-1)
							ELSE RESP.ACCUM_ID
							END 
	WHERE  CONVERT(VARCHAR(8),RESP.LAST_UPD_DT, 112) = CONVERT(VARCHAR(8), @ldtProcessStartTime, 112)
	
	-- Updating ERR_DESC in resp table . concatenation of error messages from error table
	UPDATE resp
    SET ERR_DESC = ( STUFF((SELECT ', ' + LTRIM(RTRIM(err1.ERR_DESC))
            FROM fabncdv1stage.dbo.tpzt_accum_error err1
            WHERE err1.ACCUM_ID = resp.ACCUM_ID 
            FOR XML PATH('')),1,1,'')
            )
	FROM fabncdv1custom.dbo.tpzt_accum_resp resp
	INNER JOIN fabncdv1stage.dbo.tpzt_accum_error err 
	ON err.ACCUM_ID = resp.ACCUM_ID  
	WHERE REC_STATUS IN ('PEND','FAIL')
    AND    RESP_STATUS = 'N'
	AND  CONVERT(VARCHAR(8),LAST_UPD_DT, 112) = CONVERT(VARCHAR(8), @ldtProcessStartTime, 112)
	
	
    /************* Error checking for Updating accum id in response table **********/

   SELECT @lnRetCd    = @@ERROR,
     @lnRowsProcessed = @@ROWCOUNT

   IF @lnRetCd <> 0
   BEGIN
     SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
       + ' : Updating accum id in response table  FAILED'
       + ' RETURNCODE: '
       + CONVERT(CHAR(6),@lnRetCd)
   PRINT  @lvcMsg
   RETURN @lnRetCd
   END
   
   /**************  PRINT STEP 5 FOOTER DATA *************************/

   SELECT @ldtStepEndTime = GETDATE()

   EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
     @pdtStepStartTime    = @ldtStepStartTime,
     @pdtStepEndTime      = @ldtStepEndTime,
     @pdtProcessStartTime = @ldtProcessStartTime,
     @pnRowCount          = @lnRowsProcessed
     
     /**************  PRINT STEP 6  HEADER DATA *************************/

   SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime = GETDATE(),
      @lvcMsg = @lvcObjectName + ':Creating temp table for Response file  '

   EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
     @pnStepNumber     = @lnCurrentStep,
     @pdtStepStartTime = @ldtStepStartTime,
     @pnTotalSteps     = @lnTotalSteps,
     @pchStepMsg       = @lvcMsg

    /********** STEP 6 Creating temp table for Response file **********/
    
     
    SELECT  '|' + ACCUM_ID + '|' + REC_STATUS + '|' + [MODE] + '|' + UPPER(LTRIM(RTRIM(ERR_DESC))) + '|' AS DATA_ELEMENT 
    INTO    #tempResp
    
    FROM    fabncdv1custom.dbo.tpzt_accum_resp 
    WHERE    CONVERT(VARCHAR(8), LAST_UPD_DT, 112) = CONVERT(VARCHAR(8), GETDATE(),112) 
    AND        RESP_STATUS = 'N'
	
    
    SELECT    DATA_ELEMENT 
    FROM    #tempResp
    
    /************* Error checking for Creating temp table for Response file **********/

   SELECT @lnRetCd    = @@ERROR,
     @lnRowsProcessed = @@ROWCOUNT

   IF @lnRetCd <> 0
   BEGIN
     SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
       + ' : Creating temp table for Response file  FAILED'
       + ' RETURNCODE: '
       + CONVERT(CHAR(6),@lnRetCd)
   PRINT  @lvcMsg
   RETURN @lnRetCd
   END
   
   /**************  PRINT STEP 6 FOOTER DATA *************************/

   SELECT @ldtStepEndTime = GETDATE()

   EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
     @pdtStepStartTime    = @ldtStepStartTime,
     @pdtStepEndTime      = @ldtStepEndTime,
     @pdtProcessStartTime = @ldtProcessStartTime,
     @pnRowCount          = @lnRowsProcessed
     
     /**************  PRINT STEP 7  HEADER DATA *************************/

   SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime = GETDATE(),
      @lvcMsg = @lvcObjectName + ':Fetching data for Response file  '

   EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
     @pnStepNumber     = @lnCurrentStep,
     @pdtStepStartTime = @ldtStepStartTime,
     @pnTotalSteps     = @lnTotalSteps,
     @pchStepMsg       = @lvcMsg

    /********** STEP 7 Fetching data for Response file **********/
    
    SELECT DATA_ELEMENT FROM  #tempResp
    
    /************* Error checking for Fetching data for Response file **********/

   SELECT @lnRetCd    = @@ERROR,
     @lnRowsProcessed = @@ROWCOUNT

   IF @lnRetCd <> 0
   BEGIN
     SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
       + ' : Fetching data for Response file  FAILED'
       + ' RETURNCODE: '
       + CONVERT(CHAR(6),@lnRetCd)
   PRINT  @lvcMsg
   RETURN @lnRetCd
   END
   
   /**************  PRINT STEP 7 FOOTER DATA *************************/

   SELECT @ldtStepEndTime = GETDATE()

   EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
     @pdtStepStartTime    = @ldtStepStartTime,
     @pdtStepEndTime      = @ldtStepEndTime,
     @pdtProcessStartTime = @ldtProcessStartTime,
     @pnRowCount          = @lnRowsProcessed
     
      /**************  PRINT STEP 8  HEADER DATA *************************/

   SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime = GETDATE(),
      @lvcMsg = @lvcObjectName + ':Updating RESP_STATUS for proccessed Accumulators  '

   EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
     @pnStepNumber     = @lnCurrentStep,
     @pdtStepStartTime = @ldtStepStartTime,
     @pnTotalSteps     = @lnTotalSteps,
     @pchStepMsg       = @lvcMsg

    /********** STEP 8 Fetching data for Response file **********/
    
    UPDATE  fabncdv1custom.dbo.tpzt_accum_resp
    SET        RESP_STATUS = 'Y' 
    WHERE    RESP_STATUS = 'N' 
    AND        CONVERT(VARCHAR(8),LAST_UPD_DT, 112) = CONVERT(VARCHAR(8), GETDATE(), 112)
    
    /************* Error checking for Updating RESP_STATUS for proccessed Accumulators **********/

   SELECT @lnRetCd    = @@ERROR,
     @lnRowsProcessed = @@ROWCOUNT

   IF @lnRetCd <> 0
   BEGIN
     SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
       + ' : Updating RESP_STATUS for proccessed Accumulators  FAILED'
       + ' RETURNCODE: '
       + CONVERT(CHAR(6),@lnRetCd)
   PRINT  @lvcMsg
   RETURN @lnRetCd
   END
   
   /**************  PRINT STEP 8 FOOTER DATA *************************/

   SELECT @ldtStepEndTime = GETDATE()

   EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
     @pdtStepStartTime    = @ldtStepStartTime,
     @pdtStepEndTime      = @ldtStepEndTime,
     @pdtProcessStartTime = @ldtProcessStartTime,
     @pnRowCount          = @lnRowsProcessed
     
    /**************  PRINT JOB FOOTER DATA ****************************/

   SELECT @ldtProcessEndTime = GETDATE()
   EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr
     @pchObjectName         = @lvcObjectName,
     @pdtProcessStartTime   = @ldtProcessStartTime,
     @pdtProcessEndTime     = @ldtProcessEndTime
   
   RETURN  @lnRetCd
   
END
/**************************************************************** 
** BEGIN MAINTENANCE WRAPPER.                                  ** 
****************************************************************/ 
GO 
IF OBJECT_ID('dbo.tpzp_accum_update_resp') IS NOT NULL 
  PRINT '<<< CREATED PROCEDURE dbo.tpzp_accum_update_resp >>>' 
ELSE 
  PRINT '<<< FAILED CREATING PROCEDURE dbo.tpzp_accum_update_resp >>>' 
GO 
/**************************************************************** 
** END MAINTENANCE WRAPPER.                                    ** 
****************************************************************/ 



