/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID('dbo.tpzv_prime_uid_extr') IS NOT NULL
BEGIN
  DROP VIEW dbo.tpzv_prime_uid_extr
  IF OBJECT_ID('dbo.tpzv_prime_uid_extr') IS NOT NULL
      PRINT '<<< FAILED DROPPING VIEW dbo.tpzv_prime_uid_extr >>>'
  ELSE
      PRINT '<<< DROPPED VIEW dbo.tpzv_prime_uid_extr >>>'
END
GO

/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/

CREATE VIEW dbo.tpzv_prime_uid_extr

/***********************************************************************
**   NAME                  : tpzv_prime_uid_extr
**
**   FUNCTION              : This view is used to output PRIME UID extract daily data.
**   DATABASE LOCATION     : Stage
**
**   TABLES REFERENCED     :
**                FACETS   : None
**                CUSTOM   : None
**                STAGE    : tpzt_prime_uid_extr
**
** REVISION  HISTORY       :
**
** VERSION      DATE       DEVELOPER          DESCRIPTION
**--------   ----------    --------------     ---------------
**  1.0       04/04/2014   Praveen    Initial Version
**************************************************************************/
AS
    
        
        SELECT  tblOuter.InfoMemberRecord
                FROM
                (
                SELECT 
                    TOP 100 PERCENT tblSorted.SN, tblSorted.InfoMemberRecord 
                FROM 
                    (SELECT    1                         AS SN,
                    LEFT('0'+'NC' +
                    CONVERT(VARCHAR(8),GETDATE(),112)+
					REPLACE(CONVERT(VARCHAR(8),GETDATE(),108),':','')+
                    SPACE(123),140)                      AS InfoMemberRecord
        UNION ALL
                SELECT  2 AS SN,
                    UPPER
                    (
                    RECTYP 									    +
                    PRMCAR       								+
					LEFT(LTRIM(RTRIM(OLDMEMBID))+ SPACE(12),12)	+
                    LEFT(LTRIM(RTRIM(NEWMEMBID))+ SPACE(12),12)   +
                    FILLER_1 ) AS InfoMemberRecord
                FROM fabncdv1stage.dbo.tpzt_prime_uid_extr
        UNION ALL
                SELECT  
                    3                                 AS SN,
                    LEFT('8'+ 
                    RIGHT('000000'+CAST(COUNT(*) AS VARCHAR(6)),6)+SPACE(133),140) AS InfoMemberRecord 
                FROM  fabncdv1stage.dbo.tpzt_prime_uid_extr )tblSorted ORDER BY tblSorted.SN ASC)tblOuter
GO

/****************************************************************
BEGIN MAINTENANCE WRAPPER:
****************************************************************/

IF OBJECT_ID ('dbo.tpzv_prime_uid_extr') IS NOT NULL
  PRINT '<<< CREATED VIEW dbo.tpzv_prime_uid_extr>>>'
ELSE
  PRINT '<<< FAILED CREATING VIEW dbo.tpzv_prime_uid_extr >>>'
GO

/****************************************************************
END MAINTENANCE WRAPPER.
****************************************************************/