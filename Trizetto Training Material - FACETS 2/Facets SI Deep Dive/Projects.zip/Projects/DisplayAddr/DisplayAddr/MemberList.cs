﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml;



namespace DisplayAddr
{
    public partial class MemberList : FacetsControlLibrary.FacetsBaseControl
    {
        public MemberList()
        {
            InitializeComponent();
        }

         

        private int MemberList_FacetsWinPostOpen(object sender, FacetsControlLibrary.FacetsEventArgs e)
        {
            string strSBSData = null;
            this.GetData("SBSB", ref strSBSData);
           // label1.Text = strSBSData;

            DataTable memberDataTable = new DataTable();
            DataColumn dataColumn = new DataColumn();

            XmlDocument memberXmlDoc = new XmlDocument();
            memberXmlDoc.LoadXml(strSBSData);

            //if (memberXmlDoc.SelectSingleNode("//FacetsData[@name='RETURN_CODE']").InnerText == "0")
            //{
                // Create DataTable to store the member data
                
                dataColumn.DataType = Type.GetType("System.String");
                dataColumn.ColumnName = "SBSB_LAST_NAME";
                memberDataTable.Columns.Add(dataColumn);

                dataColumn = new DataColumn();
                dataColumn.DataType = Type.GetType("System.String");
                dataColumn.ColumnName = "SBSB_CK";
                memberDataTable.Columns.Add(dataColumn);

                dataColumn = new DataColumn();
                dataColumn.DataType = Type.GetType("System.String");
                dataColumn.ColumnName = "SBSB_ID";
                memberDataTable.Columns.Add(dataColumn);
            //}

                foreach (XmlNode claimNode in memberXmlDoc.SelectNodes("//FacetsData"))
                {
                    DataRow memberRow;
                    memberRow = memberDataTable.NewRow();
                    memberRow["SBSB_LAST_NAME"] = claimNode.SelectSingleNode("Column[@name='SBSB_LAST_NAME']").InnerText;
                    memberRow["SBSB_ID"] = claimNode.SelectSingleNode("Column[@name='SBSB_ID']").InnerText;
                    memberRow["SBSB_CK"] = claimNode.SelectSingleNode("Column[@name='SBSB_CK']").InnerText;
                    memberDataTable.Rows.Add(memberRow);
                }

                // Update the datasource
                DGMemberView.DataSource = memberDataTable;


                //StringReader stream;
                //stream = new StringReader(strSBSData);
                ////XmlReader xmlFile = XmlReader.Create(stream, new XmlReaderSettings());
                //DataSet dataSet = new DataSet();
                //dataSet.ReadXml(stream);
                //DGMemberView.DataSource = dataSet;
            return default(int);
       
        }

        private int MemberList_FacetsWinPreSave(object sender, FacetsControlLibrary.FacetsEventArgs e)
        {
            return default(int);
        }


      


    }
}
