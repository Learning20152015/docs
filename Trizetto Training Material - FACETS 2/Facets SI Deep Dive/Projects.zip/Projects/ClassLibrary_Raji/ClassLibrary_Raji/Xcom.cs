﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ErCoreIfcExtensionData;

namespace RequireEmpId
{
    
   
    public class Xcom
    {
              public Xcom() { }

        public bool CheckEmpID(IFaExtensionData extData,string facetsId)
        {
            string strSBSB;
            //string allSBSBData;

            strSBSB = extData.GetData("SBSB");
           // allSBSBData = extData.GetData("");

            return true;
        }
        ~ Xcom() { }

    }

}
