/***************************************************************
  BEGIN MAINTENANCE WRAPPER.
***************************************************************/

IF OBJECT_ID('dbo.tpzp_usable_membership_extr') IS NOT NULL
BEGIN
  DROP PROCEDURE dbo.tpzp_usable_membership_extr

  IF OBJECT_ID('dbo.tpzp_usable_membership_extr') IS NOT NULL
    PRINT '<<< FAILED DROPPING PROCEDURE dbo.tpzp_usable_membership_extr >>>'
  ELSE
    PRINT '<<< DROPPED PROCEDURE dbo.tpzp_usable_membership_extr >>>'
END
GO
/****************************************************************
** END MAINTENANCE WRAPPER.                                    **
***************************************************************/

CREATE PROCEDURE [dbo].[tpzp_usable_membership_extr]

/****************************************************************
**   NAME                  : dbo.tpzp_usable_membership_extr
**
**
**   PVCS LOCATION         :  
**
**   FUNCTION              : STEP 1 Truncating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr_new
**                           STEP 2 Obtaining Last Run Date from the custom table tpzt_last_rundate
**                           STEP 3 Populating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr_new with present days record
**                           STEP 4 Update staging table tpzt_usable_membership_extr_new for PDTHRU Column
**                           STEP 5 Update staging table tpzt_usable_membership_extr_new for EFF dates
**                           STEP 6 Update staging table tpzt_usable_membership_extr_new for EXP dates
**                           STEP 7 Updating stage table for monthly rates for various products
**                           STEP 8 Truncate Staging table tpzt_usable_membership_error
**                           STEP 9 Insert error records in staging table tpzt_usable_membership_error
**                           STEP 10 Truncating stage table fabncdv1stage.dbo.tpzt_usable_membership_extr
**                           STEP 11 Inserting updated records in stage table fabncdv1stage.dbo.tpzt_usable_membership_extr
**                           STEP 12 Updating LAST_RUN_DATE in table tpzt_last_rundate
**
**   PARAMETERS            :
**                   INPUT :
**                  OUTPUT :
**
**   RETURN CODES          : 0 on success
**
**   TABLES REFERENCED     :
**                FACETS   : fabncdv1.dbo.CMC_SBSA_SALARY
**                           fabncdv1.dbo.CMC_CSPI_CS_PLAN
**                           fabncdv1.dbo.CMC_SBSR_SB_RATE
**                           fabncdv1.dbo.CMC_SBCS_CLASS
**
**                FACETSXC : N/A
**                CUSTOM   : fabncdv1custom.dbo.tpzt_last_rundate
**                           fabncdv1custom.dbo.tpzt_usable_vltd
**                           fabncdv1custom.dbo.tpzt_usable_vstd
**                           fabncdv1custom.dbo.tpzt_usable_vadd
**                           fabncdv1custom.dbo.tpzt_usable_vl
**                           fabncdv1custom.dbo.tpzt_usable_ltd
**                           fabncdv1custom.dbo.tpzt_usable_wdb
**                           fabncdv1custom.dbo.tpzt_usable_dl
**                           fabncdv1custom.dbo.tpzt_usable_gtl_add
**                STAGE    : 
**
**   PROCEDURES REFERENCED :
**                  FACETS :
**                  CUSTOM :
**   STANDARD LOGGING PROCS:
**                           harcore.dbo.harsp_gen_util_job_hdr_lgr
**                           harcore.dbo.harsp_gen_util_job_ftr_lgr
**                           harcore.dbo.harsp_gen_util_step_hdr_lgr
**                           harcore.dbo.harsp_gen_util_step_ftr_lgr
**
** REVISION HISTORY        :
** VERSION  DATE         DEVELOPER           DESCRIPTION
** -------- ----------   -----------------   --------------------
** 1.0      08/20/2014    Ghazala Ameen      Initial Version
** 1.1      08/26/2014    Shekhar Kadam      Date format is updated from cyymmdd to ccyymmdd and field position is updated
** 1.2      08/27/2014    Ghazala Ameen      Updated field length
** 1.3      09/01/2014    Ghazala Ameen      Updated for EFFECTIVE, EXPIRY Dates
** 1.4      09/10/2014    Ghazala Ameen      Updated selection criteria for 12 months contion 
                                             and updated monthly rates for various products
** 1.5      10/10/2014    Shekhar Kadam      Use the member eligibility termination date instead of class termination dates in selection criteria.
                                                As per new BRD received on 10/10/2014                                               
** 1.6      10/21/2014    Shekhar Kadam      Correction in mapping field for CNX table.
** 1.7      10/23/2014    Shekhar Kadam      Updated missing joins.
** 1.8      10/28/2014    Shekhar Kadam      Assigning blank value to Last Change Date field for all prod cat
                                             Assigning C value to Rate Method  field if value is FLAT.
** 1.9      10/30/2014    Shekhar Kadam      Logic updated for Rate Method for all the product.
** 1.10     12/09/2014    Ramkumar Paulraj   Updated Joining conditions for Benefit Rate per Unit columns
****************************************************************/
AS

BEGIN



/****************************************************************
**          DECLARE LOCAL VARIABLES                            **
****************************************************************/

    DECLARE @lnRetCd                INT              -- Proc return code
    DECLARE @ldtProcessStartTime    DATETIME         -- Job Start Date / Time
    DECLARE @ldtProcessEndTime      DATETIME         -- Job End Date / Time
    DECLARE @ldtStepStartTime       DATETIME         -- Step Start Date / Time
    DECLARE @ldtStepEndTime         DATETIME         -- Step End Date / Time
    DECLARE @lnCurrentStep          INT              -- Current Step Number
    DECLARE @lnTotalSteps           INT              -- Total Steps In Proc
    DECLARE @lvcMsg                 VARCHAR(255)     -- Generic Message Field
    DECLARE @lvcServerName          VARCHAR(32)      -- DB Server Name
    DECLARE @lvcDBName              VARCHAR(32)      -- DB Name
    DECLARE @lvcVersionNum          VARCHAR(32)      -- Object Version
    DECLARE @lvcUser                VARCHAR(32)      -- Executing User Name
    DECLARE @lvcObjectName          VARCHAR(32)      -- SP Name
    DECLARE @lnRowsProcessed        INT              -- Rows Processed by Step
    DECLARE @ldtLastRunDt           DATETIME         -- Last run date
    DECLARE @ldtCurrentDate         DATETIME         -- Current date

DECLARE @EffDate TABLE
    (
        GRGR_ID      VARCHAR(8),
        MEME_REL     VARCHAR(1),
        MEME_CK         int,
        A            VARCHAR(8),
        B            VARCHAR(8),
        E            VARCHAR(8),
        K            VARCHAR(8),
        L            VARCHAR(8),
        S            VARCHAR(8),
        T            VARCHAR(8),
        X            VARCHAR(8),
        Y            VARCHAR(8),
        Z            VARCHAR(8),
        J            VARCHAR(8)
    )
    
    
    DECLARE @TermDate TABLE
    (
        GRGR_ID      VARCHAR(8),
        MEME_REL     VARCHAR(1),
        MEME_CK         int,
        A            VARCHAR(8),
        B            VARCHAR(8),
        E            VARCHAR(8),
        K            VARCHAR(8),
        L            VARCHAR(8),
        S            VARCHAR(8),
        T            VARCHAR(8),
        X            VARCHAR(8),
        Y            VARCHAR(8),
        Z            VARCHAR(8),
        J            VARCHAR(8)
    )
 


/****************************************************************
**          INITIALIZE  VARIABLES                              **
****************************************************************/



    DECLARE @CommnTable TABLE
    (
        MEME_CK            int,
        SBSB_CK            int,
        GRGR_CK            int,
        SGSG_CK            int,
        GRGR_ID            varchar(8),
        CSCS_ID            varchar(4),
        CSPI_ID            varchar(8),
        CSPD_CAT        varchar(1),
        MEMBNO            varchar(12),
        MEME_REL        varchar(1)
    )    
    

DECLARE @SBSRATE TABLE
    (
        MEME_CK            int,
        GRGR_ID      VARCHAR(8),
        MEME_REL     VARCHAR(1),
        A            VARCHAR(8),
        --B            VARCHAR(8),
        E            VARCHAR(8),
        K            VARCHAR(8),
        L            VARCHAR(8),
        S            VARCHAR(8),
        T            VARCHAR(8),
        X            VARCHAR(8),
        Y            VARCHAR(8),
       -- Z            VARCHAR(8),
        J            VARCHAR(8)
    )
 
 DECLARE @SBSRATES_SUB TABLE
    (
        MEME_CK            int,
        GRGR_ID      VARCHAR(8),
        MEME_REL     VARCHAR(1),
        B            VARCHAR(8),
        Z            VARCHAR(8)
        
    )   

 DECLARE @SBSRATES_DEP TABLE
    (
        MEME_CK            int,
        GRGR_ID      VARCHAR(8),
        MEME_REL     VARCHAR(1),
        B            VARCHAR(8),
        Z            VARCHAR(8)
        
    )  


/****************************************************************
**          INITIALIZE  VARIABLES                              **
****************************************************************/
    

    SELECT @lnRetCd        = 0,
      @lvcMsg              = NULL,
      @lnCurrentStep       = 0,  
      @lnTotalSteps        = 11,
      @ldtStepEndTime      = NULL,
      @lvcVersionNum       = '1.10'

    SELECT @lvcServerName  = @@SERVERNAME,
      @lvcDBName           = DB_NAME(),
      @lvcUser             = USER_NAME(),
      @lvcObjectName       = OBJECT_NAME(@@PROCID),
      @ldtProcessStartTime = GETDATE(),
      @ldtCurrentDate      = CONVERT(VARCHAR (10), GETDATE(), 101)

/****************************************************************
**               BEGIN PROCESS                                 **
*****************************************************************/

/**************  PRINT JOB HEADER DATA *************************/

    EXEC harcore.dbo.harsp_gen_util_job_hdr_lgr
      @pchObjectName        = @lvcObjectName,
      @pdtProcessStartTime  = @ldtProcessStartTime,
      @pchServerName        = @lvcServerName,
      @pchDBName            = @lvcDBName,
      @pchUserName          = @lvcUser,
      @pchVersionNum        = @lvcVersionNum

/**************  PRINT STEP 1 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': fetching Last run date'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 1 fetching Last run date **********/
    
 SELECT @ldtLastRunDt =  LAST_RUN_DATE
    FROM fabncdv1custom.dbo.tpzt_last_rundate
    WHERE INTERFACE_IDENTIFIER  = 'VE9006'
      AND INTERFACE_DESCRIPTION = 'USABLE_MEMBERSHIP'


/********** Error Checking for truncate statement ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Fetching Last run date FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 1 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed


/**************  PRINT STEP 2 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Fetching the data into common table'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 2 Fetching the data into common table  **********/

insert into @CommnTable
                    (
                         MEME_CK,
                         SBSB_CK,
                         GRGR_CK,
                         SGSG_CK,
                         GRGR_ID,    
                         CSCS_ID,    
                         CSPI_ID,
                         CSPD_CAT,    
                         MEMBNO    ,
                         MEME_REL
                     )
SELECT DISTINCT
        MEME_CK            =  meme.MEME_CK,
        SBSB_CK            = sbsb.SBSB_CK,
        GRGR_CK            =  grgr.GRGR_CK,
        SGSG_CK         =  sgsg.SGSG_CK,
        GRGR_ID            =  grgr.GRGR_ID,
        CSCS_ID            =  mepe.CSCS_ID,
        CSPI_ID         =  cspi.CSPI_ID,
        CSPD_CAT        =  cspi.CSPD_CAT,
        MEMBNO            =  sbsb.SBSB_ID,
        MEME_REL        =  meme.MEME_REL
        
 FROM  
        fabncdv1.dbo.CMC_GRGR_GROUP grgr 
        INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK    
        INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb ON sbsb.GRGR_CK = grgr.GRGR_CK 
        INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme ON meme.SBSB_CK = sbsb.SBSB_CK
        INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi ON cspi.GRGR_CK = grgr.GRGR_CK
        INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe ON meme.MEME_CK = mepe.MEME_CK
                                                        AND sgsg.SGSG_CK = mepe.SGSG_CK
                                                        and cspi.CSPI_ID = mepe.CSPI_ID
                                                        and cspi.CSCS_ID = mepe.CSCS_ID
                                                        and cspi.CSPD_CAT = mepe.CSPD_CAT
        LEFT JOIN fabncdv1..CMC_SBSA_SALARY sbsa ON sbsb.SBSB_CK = sbsa.SBSB_CK
                                                AND grgr.GRGR_CK = sbsa.GRGR_CK
         
    WHERE mepe.CSPD_CAT IN ('X','Y','L','A','S','T','Z','B','E','K','J') 
        AND mepe.MEPE_ELIG_IND ='Y'
         AND( 
                (mepe.MEPE_TERM_DT >= DATEADD(dd,1,@ldtLastRunDt)
                 AND mepe.MEPE_TERM_DT > mepe.MEPE_EFF_DT) --AND cspi.CSPI_TERM_DT > cspi.CSPI_EFF_DT)
                OR  CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112) > DATEADD(mm,-12,CONVERT(VARCHAR(8),GETDATE(),112))
            )
        

/********** Error Fetching the data into common table  ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Fetching the data into common table  FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 2 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount              = @lnRowsProcessed



/**************  PRINT STEP 3 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Fetching the data into common table'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 3 Fetching the data into common table  **********/

TRUNCATE TABLE fabncdv1stage.dbo.tpzt_usable_membership_extr_new  

/********** Error Fetching the data into common table  ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Fetching the data into common table FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 3 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount              = @lnRowsProcessed



/**************  PRINT STEP 4 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': inserting data into membership table  '

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 4 inserting data into membership table   **********/

INSERT INTO fabncdv1stage.dbo.tpzt_usable_membership_extr_new  
      (
        GRGR_ID,
        --GRGR_ID_OLD,
        CSCS_ID,
        --CSCS_ID_OLD,
        --CSPI_ID,
        SGSG_CK,
        MEME_CK,
        GRPNUM,
        METIND,
        MEMBNO,
        LSTNAM,
        FSTNAM,
        MIDNAM,
        BTHDAT,
        SEXCOD,
        SSN   ,
        SALARY,
        CLSCOD,
        PDTHRU,
        HIRDAT,
        AGE   ,
        ACCTNO,
        CLSEFFDAT,
        CLSEXPDAT
      )   
   SELECT DISTINCT
        GRGR_ID       = LEFT(ISNULL(LTRIM(RTRIM(grgr.GRGR_ID)),'') + SPACE(8),8),
        CSCS_ID       = LEFT(ISNULL(LTRIM(RTRIM(mepe.CSCS_ID)),'') + SPACE(4),4),
        SGSG_CK       =  sgsg.SGSG_CK,
        MEME_CK          = meme.MEME_CK,
        GRPNUM        =  LEFT(ISNULL(LTRIM(RTRIM(grgr.GRGR_ID)),'') + SPACE(8),8),
        METIND          = '',
        MEMBNO        =  LEFT(ISNULL(LTRIM(RTRIM(sbsb.SBSB_ID)),'') + SPACE(12),12),
        LSTNAM        =  LEFT(SUBSTRING(LTRIM(RTRIM(ISNULL(meme.MEME_LAST_NAME,''))),1,15) + SPACE(15),15),
        FSTNAM        =  LEFT(SUBSTRING(LTRIM(RTRIM(ISNULL(meme.MEME_FIRST_NAME,''))),1,10) + SPACE(10),10),
        MIDNAM        =  LEFT(ISNULL(LTRIM(RTRIM(meme.MEME_MID_INIT)),'') + SPACE(1),1),
        BTHDAT        =  ISNULL(CONVERT(VARCHAR(8),meme.MEME_BIRTH_DT,112),'00000000'),
        SEXCOD        =  LEFT(ISNULL(LTRIM(RTRIM(meme.MEME_SEX)),'') + SPACE(1),1),
        SSN           =  LEFT(ISNULL(LTRIM(RTRIM(meme.MEME_SSN)),'') + SPACE(9),9),
        SALARY        =  RIGHT(REPLICATE('0', 9) + CAST(CAST(ISNULL(sbsa.SBSA_SAL_AMT,'0')AS NUMERIC(9,0)) AS VARCHAR(9)) ,9),
        CLSCOD        =  LEFT(ISNULL(LTRIM(RTRIM(mepe.CSCS_ID)),'') + SPACE(4),4),
        PDTHRU        =  ISNULL(CONVERT(VARCHAR(8),grgr.GRGR_ORIG_EFF_DT,112),'00000000'),
        HIRDAT        =  ISNULL(CONVERT(VARCHAR(8),sbsb.SBSB_HIRE_DT,112),'00000000'),
        AGE           =  RIGHT(REPLICATE('0',3) + CAST(ISNULL(DATEDIFF(yy, CONVERT(VARCHAR(8),meme.MEME_BIRTH_DT,112), CONVERT(VARCHAR(8),GETDATE(),112)),'   ')AS VARCHAR) ,3),
        ACCTNO        =  LEFT(SUBSTRING(LTRIM(RTRIM(ISNULL(sgsg.SGSG_ID,''))),1,10) + SPACE(10),10),
        CLSEFFDAT     =  ISNULL(CONVERT(VARCHAR(8),cspi.CSPI_EFF_DT,112),'00000000'),
        CLSEXPDAT     =  ISNULL(CONVERT(VARCHAR(8),cspi.CSPI_TERM_DT,112),'00000000')
        
        
 FROM  
        fabncdv1.dbo.CMC_GRGR_GROUP grgr 
        INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK    
        INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb ON sbsb.GRGR_CK = grgr.GRGR_CK 
        INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme ON meme.SBSB_CK = sbsb.SBSB_CK
        INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi ON cspi.GRGR_CK = grgr.GRGR_CK
        INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe ON meme.MEME_CK = mepe.MEME_CK
                                                        AND sgsg.SGSG_CK = mepe.SGSG_CK
                                                        and cspi.CSPI_ID = mepe.CSPI_ID
                                                        and cspi.CSCS_ID = mepe.CSCS_ID
                                                        and cspi.CSPD_CAT = mepe.CSPD_CAT
        LEFT JOIN fabncdv1..CMC_SBSA_SALARY sbsa ON sbsb.SBSB_CK = sbsa.SBSB_CK
                                                AND grgr.GRGR_CK = sbsa.GRGR_CK
         
    WHERE mepe.CSPD_CAT IN ('X','Y','L','A','S','T','Z','B','E','K','J') 
        AND mepe.MEPE_ELIG_IND ='Y'
         AND( 
                (mepe.MEPE_TERM_DT >= DATEADD(dd,1,@ldtLastRunDt)
                 AND mepe.MEPE_TERM_DT > mepe.MEPE_EFF_DT) --AND cspi.CSPI_TERM_DT > cspi.CSPI_EFF_DT)
                OR  CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112) > DATEADD(mm,-12,CONVERT(VARCHAR(8),GETDATE(),112))
            )


/********** Error inserting data into membership table   ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : inserting data into membership table  FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 4 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount              = @lnRowsProcessed
      
---------------------sbsr rate--------------------------------------------------------------------------------------------------------------------------------------------

/**************  PRINT STEP 5 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ':updating rate field for all the product list '

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 5 updating rate field for all the product list  **********/


INSERT INTO @SBSRATE 
        SELECT MEME_CK,GRGR_ID,MEME_REL, A = ISNULL(A,'00000000'),
                                 E =ISNULL(E,'00000000'),
                                 K =ISNULL(K,'00000000'),
                                 L =ISNULL(L,'00000000'),
                                 S=ISNULL(S,'00000000'),
                                 T=ISNULL(T,'00000000'),
                                 X=ISNULL(X,'00000000'),
                                 Y=ISNULL(Y,'00000000'),
                                 J =ISNULL(J,'00000000')
        FROM
           (
                SELECT DISTINCT
                            MEME_CK = comm.MEME_CK ,
                            GRGR_ID = comm.GRGR_ID,  
                            CSPDCAT =comm.CSPD_CAT, 
                            MEME_REL = comm.MEME_REL,
                            SBSR_RATE = ISNULL(sbsr.SBSR_PREM_SB,0)
                FROM  @CommnTable comm   
                            left  join fabncdv1.dbo.CMC_SBSR_SB_RATE sbsr on  comm.SBSB_CK = sbsr.SBSB_CK 
                                                                           and comm.CSPI_ID= sbsr.PDPD_ID
                where  comm.CSPD_CAT IN ('X','Y','L','A','S','T','E','K','J')    
                and comm.MEME_REL ='M'
            )d
            pivot
            (
                max(SBSR_RATE)
                for CSPDCAT in (A,E,K,L,S,T,X,Y,J)
            ) AS piv

--select * from @SBSRATE

 UPDATE extr
    SET LIFMTHPRM = L, ADDMTHPRM = A, DLIMTHPRM = T, WDBMTHPRM = X, LTDMTHPRM = Y , SLIMTHPRM = S, SADMTHPRM = E,
         VSTDMTHPRM = K, VLTDMTHPRM = J
    FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @SBSRATE SBSR  ON SBSR.GRGR_ID = extr.GRGR_ID
                            and SBSR.MEME_CK = extr.MEME_CK
    

INSERT INTO @SBSRATES_SUB 
        SELECT MEME_CK,GRGR_ID,MEME_REL, 
                B = ISNULL(B,'00000000'),
                Z = ISNULL(Z,'00000000')
        FROM
           (
                SELECT DISTINCT
                MEME_CK = comm.MEME_CK ,
                GRGR_ID = comm.GRGR_ID,  
                CSPDCAT =comm.CSPD_CAT, 
                MEME_REL = comm.MEME_REL,
                SBSR_RATE = isnull(sbsr.SBSR_PREM_SB,0)
             
                FROM  @CommnTable comm   
                            left  join fabncdv1.dbo.CMC_SBSR_SB_RATE sbsr on  comm.SBSB_CK = sbsr.SBSB_CK 
                                                                            and comm.CSPI_ID = sbsr.PDPD_ID
                where  comm.CSPD_CAT IN ('B','Z')    
                and comm.MEME_REL = 'M'
            )d
            pivot
            (
                max(SBSR_RATE)
                for CSPDCAT in (B,Z)
            ) AS piv
            

    UPDATE extr
    SET VLIFMTHPRM = Z,VADDMTHPRM = B
    FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new extr
     INNER JOIN @SBSRATES_SUB SBSR      ON SBSR.GRGR_ID = extr.GRGR_ID
                                        and SBSR.MEME_CK = extr.MEME_CK

  
  
INSERT INTO @SBSRATES_DEP 
                 SELECT MEME_CK,GRGR_ID,MEME_REL, 
                            B = ISNULL(B,'00000000'),
                            Z = ISNULL(Z,'00000000')
        FROM
           (
                SELECT DISTINCT
                            MEME_CK = comm.MEME_CK ,
                            GRGR_ID = comm.GRGR_ID,  
                            CSPDCAT =comm.CSPD_CAT, 
                            MEME_REL = comm.MEME_REL,
                            SBSR_RATE = isnull(sbsr.SBSR_PREM_DEP,0)
                FROM  @CommnTable comm   
                            left  join fabncdv1.dbo.CMC_SBSR_SB_RATE sbsr on  comm.SBSB_CK = sbsr.SBSB_CK 
                                                                            and comm.CSPI_ID = sbsr.PDPD_ID
                where  comm.CSPD_CAT IN ('B','Z')    
                and  comm.MEME_REL IN ('S','D','H','W')   
            )d
            pivot
            (
                max(SBSR_RATE)
                for CSPDCAT in (B,Z)
            ) AS piv
  
  


    UPDATE extr
    SET VLIFCHMTHPRM = Z,VADDCHMTHPRM = B
    FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @SBSRATES_DEP SBSR ON SBSR.GRGR_ID = extr.GRGR_ID
                                    and SBSR.MEME_CK = extr.MEME_CK
    AND SBSR.MEME_REL IN ('S','D')
    
    
     UPDATE extr
    SET VLIFSPMTHPRM = Z,VADDSPMTHPRM = B
    FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @SBSRATES_DEP SBSR ON SBSR.GRGR_ID = extr.GRGR_ID
                                    and SBSR.MEME_CK = extr.MEME_CK
    AND SBSR.MEME_REL IN ('H','W')          


/********** Error updating rate field for all the product list   ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Updating rate field for all the product list FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 5 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount              = @lnRowsProcessed
      

---------------------sbsr rate END --------------------------------------------------------------------------------------------------------------------------------------------

/**************  PRINT STEP 6 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': updating Paid Thru Date '

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 6 updating Paid Thru Date  **********/

          
     UPDATE  new
     SET new.PDTHRU = ISNULL(CONVERT(VARCHAR(8), blbe.BLBL_END_DT,112),'00000000')
     FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new new
       JOIN
           ( SELECT blei.BLEI_CK,blei.BLEI_BILL_LEVEL_CK, MAX(blbl.BLBL_END_DT) AS BLBL_END_DT 
                    FROM fabncdv1.dbo.CMC_BLBL_BILL_SUMM blbl
                            inner join fabncdv1.dbo.CMC_BLEI_ENTY_INFO blei on blei.BLEI_CK = blbl.BLEI_CK
                            
                 WHERE  blbl.BLBL_PAID_STS in (2,3)
                 GROUP BY blei.BLEI_CK,blei.BLEI_BILL_LEVEL_CK) as blbe
                 ON blbe.BLEI_BILL_LEVEL_CK = new.SGSG_CK


/********** Error  updating Paid Thru Date  ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : updating Paid Thru Date FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 6 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount              = @lnRowsProcessed
      


/**************  PRINT STEP 7 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': updating the effective date  '

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 7 updating the effective date **********/

INSERT INTO @EffDate 
        SELECT GRGR_ID,MEME_REL, MEME_CK,
                A = ISNULL(A,'00000000'),B = ISNULL(B,'00000000'),E =ISNULL(E,'00000000'),K =ISNULL(K,'00000000'),L =ISNULL(L,'00000000'),S=ISNULL(S,'00000000'),T=ISNULL(T,'00000000'),X=ISNULL(X,'00000000'),Y=ISNULL(Y,'00000000'),Z=ISNULL(Z,'00000000'),J =ISNULL(J,'00000000')
        FROM
                (
                SELECT DISTINCT
                GRGR_ID = comm.GRGR_ID,  
                MEME_REL = comm.MEME_REL,
                comm.MEME_CK,
                DATEt     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(mepe1.MEPE_EFF_DT),112)    
                                                FROM  fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe1
                                                     WHERE comm.SGSG_CK = mepe1.SGSG_CK
                                                     AND comm.GRGR_CK = mepe1.GRGR_CK  
                                                     AND comm.CSPI_ID = mepe1.CSPI_ID
                                                     AND  comm.CSPD_CAT IN ('X','Y','L','A','S','T','Z','B','E','K','J')   
                                                     AND  mepe1.MEPE_ELIG_IND = 'Y'    
                                             ),'00000000')
                   , CSPDCAT =comm.CSPD_CAT
                                     
                FROM  @CommnTable comm    
            )d
            pivot
            (
            max(DATEt)
            for CSPDCAT in (A,B,E,K,L,S,T,X,Y,Z,J)
            ) AS piv
            

 UPDATE extr
    SET LIFEFFDAT = L, ADDEFFDAT = A, DLIEFFDAT = T, WDBEFFDAT = X, LTDEFFDAT = Y , SLIEFFDAT = S, SADEFFDAT = E,
         VSTDEFFDAT = K, VLTDEFFDAT = J
    FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @EffDate EFDT   ON EFDT.GRGR_ID = extr.GRGR_ID
                                and EFDT.MEME_CK = extr.MEME_CK
    
    UPDATE extr
    SET VLIFEFFDAT = Z,VADDEFFDAT = B
    FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @EffDate EFDT  ON  EFDT.GRGR_ID = extr.GRGR_ID
                                and EFDT.MEME_CK = extr.MEME_CK
    where EFDT.MEME_REL = 'M'

    UPDATE extr
    SET VLIFEFFDAT_SPOUSE = Z,VADDSPEFFDAT = B
    FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @EffDate EFTE  ON EFTE.GRGR_ID = extr.GRGR_ID
                                and EFTE.MEME_CK = extr.MEME_CK
    where  EFTE.MEME_REL IN ('H','W')

    UPDATE extr
    SET VLIFEFFDAT_CHILD = Z,VADDCHEFFDAT = B
    FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @EffDate EFTE   ON EFTE.GRGR_ID = extr.GRGR_ID
                                and EFTE.MEME_CK = extr.MEME_CK
    where EFTE.MEME_REL IN ('S','D')          
    



 INSERT INTO @TermDate
    SELECT GRGR_ID,MEME_REL,MEME_CK,
            A = ISNULL(A,'00000000'),B = ISNULL(B,'00000000'),E =ISNULL(E,'00000000'),K =ISNULL(K,'00000000'),L =ISNULL(L,'00000000'),S=ISNULL(S,'00000000'),
            T=ISNULL(T,'00000000'),X=ISNULL(X,'00000000'),Y=ISNULL(Y,'00000000'),Z=ISNULL(Z,'00000000'),J =ISNULL(J,'00000000')
        FROM
                (
                SELECT DISTINCT
                GRGR_ID = comm.GRGR_ID,  -- comm.MEME_CK, MEMBNO    ,
                MEME_REL = comm.MEME_REL,
                MEME_CK = comm.MEME_CK,
                DATEt     =  ISNULL((SELECT CONVERT(VARCHAR(8),max(mepe1.MEPE_TERM_DT),112)    
                                                 FROM  fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe1
                                                     WHERE comm.SGSG_CK = mepe1.SGSG_CK
                                                     AND comm.GRGR_CK = mepe1.GRGR_CK  
                                                     AND mepe1.MEME_CK = comm.MEME_CK 
                                                      AND comm.CSPI_ID = mepe1.CSPI_ID  
                                                     AND  comm.CSPD_CAT IN ('X','Y','L','A','S','T','Z','B','E','K','J')   
                                                     AND  mepe1.MEPE_ELIG_IND = 'Y'    
                                             ),'00000000')
                 ,CSPDCAT =comm.CSPD_CAT
                                   
                FROM  @CommnTable comm   
            )d
            pivot
            (
            max(DATEt)
            for CSPDCAT in (A,B,E,K,L,S,T,X,Y,Z,J)
            ) AS piv
        
   
    UPDATE extr
    SET LIFEXPDAT = CASE WHEN L ='21991231'
                            THEN '99991231'
                        ELSE L
                    END, 
        ADDEXPDAT = CASE WHEN A ='21991231'
                            THEN '99991231'
                        ELSE A
                    END,  
        DLIEXPDAT = CASE WHEN T ='21991231'
                            THEN '99991231'
                        ELSE T
                    END, 
        WDBEXPDAT = CASE WHEN X ='21991231'
                            THEN '99991231'
                        ELSE X
                    END,  
        LTDEXPDAT = CASE WHEN Y ='21991231'
                            THEN '99991231'
                        ELSE Y
                    END,  
        SLIEXPDAT = CASE WHEN S ='21991231'
                            THEN '99991231'
                        ELSE S
                    END,  
        SADEXPDAT =  CASE WHEN E ='21991231'
                            THEN '99991231'
                        ELSE E
                    END,  
        VSTDDEXPDAT = CASE WHEN K ='21991231'
                            THEN '99991231'
                        ELSE K
                    END,  
        VLTDDEXPDAT = CASE WHEN J ='21991231'
                            THEN '99991231'
                        ELSE J
                    END
    FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @TermDate TEDT  ON TEDT.GRGR_ID = extr.GRGR_ID
                                and TEDT.MEME_CK = extr.MEME_CK

    UPDATE extr
    SET VLIFDEXPDAT = CASE WHEN Z ='21991231'
                            THEN '99991231'
                        ELSE Z
                    END,
        VADDEXPDAT = CASE WHEN B ='21991231'
                            THEN '99991231'
                        ELSE B
                    END
    FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @TermDate TEDT  ON TEDT.GRGR_ID = extr.GRGR_ID
                                and TEDT.MEME_CK = extr.MEME_CK
    where  TEDT.MEME_REL = 'M'

    UPDATE extr
    SET VLIFDEXPDAT_SPOUSE = CASE WHEN Z ='21991231'
                                    THEN '99991231'
                                ELSE Z
                            END,
        VADDSPEXPDAT = CASE WHEN B ='21991231'
                            THEN '99991231'
                        ELSE B
                    END
    FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @TermDate TEDT  ON TEDT.GRGR_ID = extr.GRGR_ID
                                and TEDT.MEME_CK = extr.MEME_CK
    where  TEDT.MEME_REL IN ('H','W')

    UPDATE extr
    SET VLIFDEXPDAT_CHILD = CASE WHEN Z ='21991231'
                                    THEN '99991231'
                                ELSE Z
                            END,
        VADDCHEXPDAT = CASE WHEN B ='21991231'
                            THEN '99991231'
                         ELSE B
                      END
    FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new extr
    INNER JOIN @TermDate TEDT  ON TEDT.GRGR_ID = extr.GRGR_ID
                                and TEDT.MEME_CK = extr.MEME_CK
    where  TEDT.MEME_REL IN ('S','D')


/********** Error updating the effective date   ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : updating the effective date FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 7 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount              = @lnRowsProcessed


/**************  PRINT STEP 8 HEADER DATA *************************/

    SELECT @lnCurrentStep = @lnCurrentStep + 1,
     @ldtStepStartTime    = GETDATE(),
     @lvcMsg              = @lvcObjectName + ': Update Benefit Amount, Benefit Rate per Unit and Rate Methods for Life '

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg
      
/********** STEP 8 update Benefit Amount, Benefit Rate per Unit and Rate Methods for Life  **********/


    DECLARE @BenefitData TABLE(
        GRGR_ID                        VARCHAR(8),
        CSPI_ID                           varchar(8),
        CSPD_CAT                      varchar(1),
        CSCS_ID                        VARCHAR(04),
        MEME_REL                       varchar(1),
        BENEFIT_AMOUNT_FOR_LIFE        VARCHAR(12),
        BENEFIT_AMOUNT_FOR_ADD         VARCHAR(12),
        BENEFIT_AMOUNT_FOR_DEP         VARCHAR(12),
        BENEFIT_AMOUNT_FOR_STD         VARCHAR(12),
        BENEFIT_AMOUNT_FOR_LTD         VARCHAR(12),
        BENEFIT_AMOUNT_FOR_SLI         VARCHAR(12),
        BENEFIT_AMOUNT_FOR_SAD         VARCHAR(12),
        BENEFIT_AMOUNT_FOR_VLIF        VARCHAR(12),
        BENEFIT_AMOUNT_FOR_VLIFSP      VARCHAR(12),
        BENEFIT_AMOUNT_FOR_VLIFCH      VARCHAR(12),
        BENEFIT_AMOUNT_FOR_VADD        VARCHAR(12),
        BENEFIT_AMOUNT_FOR_VADDSP      VARCHAR(12),
        BENEFIT_AMOUNT_FOR_VADDCH      VARCHAR(12),
        BENEFIT_AMOUNT_FOR_VLTD        VARCHAR(12),
        BENEFIT_AMOUNT_FOR_VSTD        VARCHAR(12),
        BENEFIT_RATE_PER_UNIT_LIFE     VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_ADD      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_DEP      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_STD      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_LTD      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_SLI      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_SAD      VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VLIF     VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VLIFSP   VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VLIFCH   VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VADD     VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VADDSP   VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VADDCH   VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VLTD     VARCHAR(11),
        BENEFIT_RATE_PER_UNIT_VSTD     VARCHAR(11),
        
        LIFRATSRC                       varchar(10),
        ADDRATSRC                    varchar(10),
        DLIRATSRC                    varchar(10),
        WDBRATSRC                    varchar(10),
        LTDRATSRC                    varchar(10),
        SLIRATSRC                    varchar(10),
        SADRATSRC                    varchar(10),
        VLIFRATSRC                    varchar(10),
        VLIFSPRATSRC                varchar(10),
        VLIFCHRATSRC                varchar(10),
        VADDRATSRC                    varchar(10),
        VADDSPRATSRC                varchar(10),
        VADDCHRATSRC                varchar(10),
        VSTDRATSRC                    varchar(10),
        VLTDRATSRC                    varchar(10)
     )
        
                
    INSERT INTO @BenefitData
    SELECT DISTINCT
        GRGR_ID = grgr.GRGR_ID,
        CSPI_ID = cspi.CSPI_ID,
        CSPD_CAT = cspi.CSPD_CAT,
        CSCS_ID  = cspi.CSCS_ID,
        MEME_REL =    meme.MEME_REL,
        BENEFIT_AMOUNT_FOR_LIFE        = RIGHT(REPLICATE('0',12) + CAST(CAST(ISNULL((SELECT distinct isnull(gtl.BENEFIT_AMOUNT,0) 
                                          FROM fabncdv1custom.dbo.tpzt_usable_gtl_add gtl
                                          WHERE gtl.GRGR_ID = grgr.GRGR_ID
                                          AND gtl.CSCS_ID = cspi.CSCS_ID
                                          AND gtl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'L'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),12),
                                          
        BENEFIT_AMOUNT_FOR_ADD         = RIGHT(REPLICATE('0',12) + CAST(CAST(ISNULL((SELECT distinct isnull(gtl.BENEFIT_AMOUNT,0) 
                                            FROM fabncdv1custom.dbo.tpzt_usable_gtl_add gtl
                                            WHERE gtl.GRGR_ID = grgr.GRGR_ID
                                            AND gtl.CSCS_ID = cspi.CSCS_ID
                                             AND gtl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'A'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),12),
                                            
        BENEFIT_AMOUNT_FOR_DEP         = RIGHT(REPLICATE('0',12) + CAST(CAST(ISNULL((SELECT distinct isnull(usabledl.[PLAN],0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_dl usabledl
                                            WHERE usabledl.GRGR_ID = grgr.GRGR_ID 
                                            AND usabledl.CSCS_ID = cspi.CSCS_ID
                                             AND usabledl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'T'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),12),
                                            
        BENEFIT_AMOUNT_FOR_STD         = RIGHT(REPLICATE('0',12) + CAST(CAST(ISNULL((SELECT distinct isnull(usablewdb.BENEFIT_AMOUNT,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_wdb usablewdb
                                              WHERE usablewdb.GRGR_ID = grgr.GRGR_ID 
                                            AND usablewdb.CSCS_ID = cspi.CSCS_ID
                                             AND usablewdb.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'X'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),12),
                                            
        BENEFIT_AMOUNT_FOR_LTD         = RIGHT(REPLICATE('0',12) + CAST(CAST(ISNULL((SELECT distinct isnull(usableltd.MONTHLY_MAXIMUM,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_ltd usableltd
                                            WHERE usableltd.GRGR_ID = grgr.GRGR_ID 
                                            AND usableltd.CSCS_ID = cspi.CSCS_ID
                                             AND usableltd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'Y'),'0000000.0000')AS NUMERIC(16,4)) AS VARCHAR),12),
                                            
        BENEFIT_AMOUNT_FOR_SLI         = RIGHT(REPLICATE('0',12) + CAST(CAST(ISNULL((SELECT distinct isnull(usablesl.BENEFIT_AMOUNT,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_sli usablesl
                                            WHERE usablesl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablesl.CSCS_ID = cspi.CSCS_ID
                                             AND usablesl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'S'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),12),
                                            
        BENEFIT_AMOUNT_FOR_SAD         = RIGHT(REPLICATE('0',12) + CAST(CAST(ISNULL((SELECT distinct isnull(usablesa.BENEFIT_AMOUNT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_sad usablesa
                                            WHERE usablesa.GRGR_ID = grgr.GRGR_ID 
                                            AND usablesa.CSCS_ID = cspi.CSCS_ID
                                             AND usablesa.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'E'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),12),
                                            
        BENEFIT_AMOUNT_FOR_VLIF        = RIGHT(REPLICATE('0',12) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevl.BENEFIT_AMOUNT,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_vl usablevl
                                              WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'Z'
                                            AND meme.MEME_REL = 'M'
                                            ),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),12),
                                            
        BENEFIT_AMOUNT_FOR_VLIFSP      = RIGHT(REPLICATE('0',12) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevl.SPOUSE_AMOUNT,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_vl usablevl
                                            WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'Z'
                                            AND meme.MEME_REL IN('H','W')
                                            ),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),12),
                                            
        BENEFIT_AMOUNT_FOR_VLIFCH      = RIGHT(REPLICATE('0',12) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevl.DEPENDANT_CHILD_COVERAGE,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_vl usablevl
                                            WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'Z'
                                            AND meme.MEME_REL IN('S','D')
                                            ),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),12),
                                            
        BENEFIT_AMOUNT_FOR_VADD        = RIGHT(REPLICATE('0',12) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevadd.BENEFIT_AMOUNT,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'B'
                                            AND meme.MEME_REL = 'M'
                                            ),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),12),
                                            
        BENEFIT_AMOUNT_FOR_VADDSP      = RIGHT(REPLICATE('0',12) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevadd.SPOUSE_AMOUNT,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'B'
                                            AND meme.MEME_REL IN('H','W')
                                            ),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),12),
                                            
        BENEFIT_AMOUNT_FOR_VADDCH      = RIGHT(REPLICATE('0',12) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevadd.DEP_CHILD_COVERAGE,0)
                                            FROM fabncdv1custom.dbo.tpzt_usable_vadd usablevadd
                               WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'B'
                                            AND meme.MEME_REL IN('S','D')
                                            ),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),12),
        
        BENEFIT_AMOUNT_FOR_VLTD        = RIGHT(REPLICATE('0',12) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevltd.MAXIMUM_AMOUNT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vltd usablevltd
                                            WHERE usablevltd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevltd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevltd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'J'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),12),

        BENEFIT_AMOUNT_FOR_VSTD        = RIGHT(REPLICATE('0',12) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevstd.MAX_WEEKLY_BENEFIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vstd usablevstd
                                            WHERE usablevstd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevstd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevstd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'K'),'0000000.0000')AS NUMERIC(11,4)) AS VARCHAR),12),
------------------------------------------------------------------------------------------------------------------------------------------------

                
                                            
        BENEFIT_RATE_PER_UNIT_LIFE =   RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablegtl.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_gtl_add usablegtl
                                            WHERE usablegtl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablegtl.CSCS_ID = cspi.CSCS_ID
                                             AND usablegtl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'L'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
                                            
        BENEFIT_RATE_PER_UNIT_ADD      =  RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablegtl.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_gtl_add usablegtl
                                            WHERE usablegtl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablegtl.CSCS_ID = cspi.CSCS_ID
                                             AND usablegtl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'A'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
                                            
        BENEFIT_RATE_PER_UNIT_DEP      =  RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usabledl.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_dl usabledl
                                            WHERE usabledl.GRGR_ID = grgr.GRGR_ID 
                                            AND usabledl.CSCS_ID = cspi.CSCS_ID
                                             AND usabledl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'T'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
                                            
        
        BENEFIT_RATE_PER_UNIT_STD      = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablewdb.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_wdb usablewdb
                               WHERE usablewdb.GRGR_ID = grgr.GRGR_ID 
                                            AND usablewdb.CSCS_ID = cspi.CSCS_ID
                                             AND usablewdb.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'X'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
        
        BENEFIT_RATE_PER_UNIT_LTD      = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usableltd.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_ltd usableltd
                                            WHERE usableltd.GRGR_ID = grgr.GRGR_ID 
                                            AND usableltd.CSCS_ID = cspi.CSCS_ID
                                             AND usableltd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'Y'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
                                            
        BENEFIT_RATE_PER_UNIT_SLI      = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablesli.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_sli usablesli
                                            WHERE usablesli.GRGR_ID = grgr.GRGR_ID 
                                            AND usablesli.CSCS_ID = cspi.CSCS_ID
                                             AND usablesli.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'S'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
                                            
        BENEFIT_RATE_PER_UNIT_SAD      = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablesad.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_sad usablesad
                                            WHERE usablesad.GRGR_ID = grgr.GRGR_ID 
                                            AND usablesad.CSCS_ID = cspi.CSCS_ID
                                             AND usablesad.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'E'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
                                            
        BENEFIT_RATE_PER_UNIT_VLIF     = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevl.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vl usablevl
                                            WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'Z'
                                            AND meme.MEME_REL = 'M'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
                                            
        BENEFIT_RATE_PER_UNIT_VLIFSP   = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevl.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vl usablevl
                                            WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'Z'
                                            AND meme.MEME_REL IN('H','W')),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
                                            
        BENEFIT_RATE_PER_UNIT_VLIFCH   = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevl.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vl usablevl
                                            WHERE usablevl.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevl.CSCS_ID = cspi.CSCS_ID
                                             AND usablevl.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'Z'
                                            AND meme.MEME_REL IN('D','S')),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
                                            
        BENEFIT_RATE_PER_UNIT_VADD     = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevadd.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'B'
                                            AND meme.MEME_REL = 'M'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
                                            
        BENEFIT_RATE_PER_UNIT_VADDSP   = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevadd.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'B'
                                            AND meme.MEME_REL IN('H','W')),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
        
                                            
        BENEFIT_RATE_PER_UNIT_VADDCH   = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevadd.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vadd usablevadd
                                            WHERE usablevadd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevadd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevadd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT= 'B'
                                            AND meme.MEME_REL IN('D','S')),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
                                            
        BENEFIT_RATE_PER_UNIT_VLTD     = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevltd.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vltd usablevltd
                                            WHERE usablevltd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevltd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevltd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'J'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
        
        BENEFIT_RATE_PER_UNIT_VSTD     = RIGHT(REPLICATE('0',11) + CAST(CAST(ISNULL((SELECT distinct isnull(usablevstd.BENEFIT_RATE_PER_UNIT,0)
                                              FROM fabncdv1custom.dbo.tpzt_usable_vstd usablevstd
                                            WHERE usablevstd.GRGR_ID = grgr.GRGR_ID 
                                            AND usablevstd.CSCS_ID = cspi.CSCS_ID
                                             AND usablevstd.CSPI_ID = cspi.CSPI_ID
                                          AND cspi.CSPD_CAT = 'K'),'00000.00000')AS NUMERIC(9,2)) AS VARCHAR),11),
        
-------------        
         LIFRATSRC = (select distinct case when  isnull(upper(gtl.BENEFIT_TYPE),'') = 'FLAT'
                                                                        then 'C'
                                                                   when  isnull(upper(gtl.BENEFIT_TYPE),'') = 'SALARY'
                                                                        then 'S'
                                                                end
                                                                
                                                from fabncdv1custom.dbo.tpzt_usable_gtl_add gtl 
                                                    where  gtl.GRGR_ID = grgr.GRGR_ID 
                                                        AND gtl.CSCS_ID = cspi.CSCS_ID
                                                        AND gtl.CSPI_ID = cspi.CSPI_ID 
                                                    and substring(gtl.CSPI_ID,2,1) = 'L'
                                            ),


        ADDRATSRC = (select distinct  case when  isnull(upper(gtl.BENEFIT_TYPE),'') = 'FLAT'
                                                        then 'C'
                                                   when  isnull(upper(gtl.BENEFIT_TYPE),'') = 'SALARY'
                                                        then 'S'
                                                end
                                from fabncdv1custom.dbo.tpzt_usable_gtl_add gtl 
                                    where  gtl.GRGR_ID = grgr.GRGR_ID 
                                        AND gtl.CSCS_ID = cspi.CSCS_ID
                                        AND gtl.CSPI_ID = cspi.CSPI_ID 
                                    and substring(gtl.CSPI_ID,2,1) = 'A'
                            ),


        DLIRATSRC  = 'C', --(select distinct 'C'
                            --    from fabncdv1custom.dbo.tpzt_usable_dl dl
                            --        where dl.GRGR_ID = new.GRGR_ID  
                            --        and substring(dl.CSPI_ID,2,1) = 'T'
                            --),

        WDBRATSRC    = (select distinct case when  isnull(upper(wdb.BENEFIT_TYPE),'') = 'FLAT'
                                                            then 'C'
                                                when  isnull(upper(wdb.BENEFIT_TYPE),'') = 'SALARY'
                                                        then 'S'
                                                else ''
                                                    end
                                    from fabncdv1custom.dbo.tpzt_usable_wdb wdb
                                        where wdb.GRGR_ID = grgr.GRGR_ID 
                                            AND wdb.CSCS_ID = cspi.CSCS_ID
                                            AND wdb.CSPI_ID = cspi.CSPI_ID 
                                        and substring(wdb.CSPI_ID,2,1) = 'X'
                                ),



        LTDRATSRC    = 'S',--(select distinct 'S'
                            --    from fabncdv1custom.dbo.tpzt_usable_ltd ltd
                            --        where ltd.GRGR_ID = new.GRGR_ID  
                            --        and substring(ltd.CSPI_ID,2,1) = 'Y'
                            --),



        SLIRATSRC    =  (select distinct case when isnull(upper(sli.BENEFIT_TYPE),'') = 'FLAT'
                                                        then 'C'
                                                     when  isnull(upper(sli.BENEFIT_TYPE),'') = 'SALARY'    
                                                        then 'S'
                                                end
                                from fabncdv1custom.dbo.tpzt_usable_sli sli
                                    where sli.GRGR_ID = grgr.GRGR_ID  
                                            AND sli.CSCS_ID = cspi.CSCS_ID
                                            AND sli.CSPI_ID = cspi.CSPI_ID 
                                    and substring(sli.CSPI_ID,2,1) = 'S'
                            ),


        SADRATSRC    = (select distinct case when  isnull(upper(sad.BENEFIT_TYPE),'') = 'FLAT'
                                                        then 'C'
                                                    when  isnull(upper(sad.BENEFIT_TYPE),'') = 'SALARY'
                                                        then 'S'
                                                end
                                from fabncdv1custom.dbo.tpzt_usable_sad sad
                                    where sad.GRGR_ID = grgr.GRGR_ID 
                                    AND sad.CSCS_ID = cspi.CSCS_ID
                                    AND sad.CSPI_ID = cspi.CSPI_ID  
                                    and substring(sad.CSPI_ID,2,1) = 'E'
                            ),



        VLIFRATSRC    = (select distinct case when isnull(vl.BENEFIT_AMOUNT,0) <> 0
                                                then  'C'
                                            when  isnull(vl.TIMES_SALARY,'') <> ''
                                                then 'S'
                                        end
                                    from fabncdv1custom.dbo.tpzt_usable_vl vl
                                        where vl.GRGR_ID = grgr.GRGR_ID  
                                            AND vl.CSCS_ID = cspi.CSCS_ID
                                            AND vl.CSPI_ID = cspi.CSPI_ID  
                                        and substring(vl.CSPI_ID,2,1) = 'Z'
                                ),




        VLIFSPRATSRC    = (select distinct case when  isnull(vl.SPOUSE_AMOUNT,0) <> 0
                                            then  'C'
                                        when  isnull(vl.TIMES_SALARY,'') <> ''
                                            then 'S'
                                    end
                                from fabncdv1custom.dbo.tpzt_usable_vl vl
                                    where vl.GRGR_ID = grgr.GRGR_ID 
                                        AND vl.CSCS_ID = cspi.CSCS_ID
                                            AND vl.CSPI_ID = cspi.CSPI_ID 
                                    and substring(vl.CSPI_ID,2,1) = 'Z'
                            ),



        VLIFCHRATSRC = (select distinct case when  isnull(vl.DEPENDANT_CHILD_COVERAGE,0) <> 0
                                                then  'C'
                                            when  isnull(vl.TIMES_SALARY,'')<> ''
                                                then 'S'
                                        end
                                    from fabncdv1custom.dbo.tpzt_usable_vl vl
                                        where vl.GRGR_ID = grgr.GRGR_ID 
                                            AND vl.CSCS_ID = cspi.CSCS_ID
                                            AND vl.CSPI_ID = cspi.CSPI_ID 
                                        and substring(vl.CSPI_ID,2,1) = 'Z'
                                ),





        VADDRATSRC    = (select distinct case when  isnull(vadd.BENEFIT_AMOUNT,0) <> 0
                                            then  'C'
                                        when isnull(vadd.TIMES_SALARY,'') <> ''
                                            then 'S'
                                    end
                                from fabncdv1custom.dbo.tpzt_usable_vadd vadd
                                    where vadd.GRGR_ID = grgr.GRGR_ID 
                                        AND vadd.CSCS_ID = cspi.CSCS_ID
                                        AND vadd.CSPI_ID = cspi.CSPI_ID 
                                    and substring(vadd.CSPI_ID,2,1) = 'B'
                            ),




        VADDSPRATSRC    = (select distinct case when  isnull(vadd.SPOUSE_AMOUNT,0) <> 0
                                            then  'C'
                                        when  isnull(vadd.TIMES_SALARY,'') <> ''
                                            then 'S'
                                    end
                                from fabncdv1custom.dbo.tpzt_usable_vadd vadd
                                    where vadd.GRGR_ID = grgr.GRGR_ID  
                                        AND vadd.CSCS_ID = cspi.CSCS_ID
                                        AND vadd.CSPI_ID = cspi.CSPI_ID 
                                    and substring(vadd.CSPI_ID,2,1) = 'B'
                            ),




        VADDCHRATSRC    = (select distinct  case when isnull(vadd.DEP_CHILD_COVERAGE,0) <> 0
                                                then  'C'
                                            when  isnull(vadd.TIMES_SALARY,'') <> ''
                                                then 'S'
                                        end
                                    from fabncdv1custom.dbo.tpzt_usable_vadd vadd
                                        where vadd.GRGR_ID = grgr.GRGR_ID  
                                            AND vadd.CSCS_ID = cspi.CSCS_ID
                                            AND vadd.CSPI_ID = cspi.CSPI_ID 
                                        and substring(vadd.CSPI_ID,2,1) = 'B'
                                ),




        VSTDRATSRC    = (select distinct case when  isnull(upper(vstd.BENEFIT_TYPE),'')= 'FLAT'
                                                        then 'C'
                                                    when  isnull(upper(vstd.BENEFIT_TYPE),'')= 'SALARY'
                                                        then 'S'
                                                end
                                from fabncdv1custom.dbo.tpzt_usable_vstd vstd
                                    where vstd.GRGR_ID = grgr.GRGR_ID 
                                        AND vstd.CSCS_ID = cspi.CSCS_ID
                                        AND vstd.CSPI_ID = cspi.CSPI_ID  
                                    and substring(vstd.CSPI_ID,2,1) = 'K'
                            ),




        VLTDRATSRC    = (select distinct case when  isnull(upper(vltd.BENEFIT_TYPE),0) = 'FLAT'
                                                            then 'C'
                                                        when  isnull(upper(vltd.BENEFIT_TYPE),'')= 'SALARY'
                                                            then 'S'
                                                    end        
                                    from fabncdv1custom.dbo.tpzt_usable_vltd vltd
                                        where vltd.GRGR_ID = grgr.GRGR_ID  
                                            AND vltd.CSCS_ID = cspi.CSCS_ID
                                            AND vltd.CSPI_ID = cspi.CSPI_ID
                                        and substring(vltd.CSPI_ID,2,1) = 'Y'
                                )
        
        
        
        
                                            
   FROM  
        fabncdv1.dbo.CMC_GRGR_GROUP grgr 
        INNER JOIN fabncdv1.dbo.CMC_SGSG_SUB_GROUP sgsg ON sgsg.GRGR_CK = grgr.GRGR_CK    
        INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb ON sbsb.GRGR_CK = grgr.GRGR_CK 
        INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme ON meme.SBSB_CK = sbsb.SBSB_CK
        INNER JOIN fabncdv1.dbo.CMC_CSPI_CS_PLAN cspi ON cspi.GRGR_CK = grgr.GRGR_CK
        INNER JOIN fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe ON meme.MEME_CK = mepe.MEME_CK
                                                        AND sgsg.SGSG_CK = mepe.SGSG_CK
                                                        and cspi.CSPI_ID = mepe.CSPI_ID
                                                        and cspi.CSCS_ID = mepe.CSCS_ID
                                                        and cspi.CSPD_CAT = mepe.CSPD_CAT
        LEFT JOIN fabncdv1..CMC_SBSA_SALARY sbsa ON sbsb.SBSB_CK = sbsa.SBSB_CK
                                                AND grgr.GRGR_CK = sbsa.GRGR_CK
         
    WHERE mepe.CSPD_CAT IN ('X','Y','L','A','S','T','E','K','J','Z','B')
        AND mepe.MEPE_ELIG_IND ='Y'
         AND( 
                (mepe.MEPE_TERM_DT >= DATEADD(dd,1,@ldtLastRunDt)
                 AND mepe.MEPE_TERM_DT > mepe.MEPE_EFF_DT) --AND cspi.CSPI_TERM_DT > cspi.CSPI_EFF_DT)
                OR  CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112) > DATEADD(mm,-12,CONVERT(VARCHAR(8),GETDATE(),112))
            )

 
---------------updated the extr table    
    
UPDATE new
        SET new.LIFACTVOL = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_LIFE,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                AND bnft.CSPD_CAT = 'L'
                                                                and bnft.MEME_REL = 'M'   and bnft.CSCS_ID = new.CSCS_ID
                                            ),
            new.ADDACTVOL = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_ADD,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                AND bnft.CSPD_CAT = 'A'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
            new.DLIACTVOL = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_DEP,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                AND bnft.CSPD_CAT = 'T'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
          new.WDBACTVOL = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_STD,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                AND bnft.CSPD_CAT = 'X'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
         new.LTDACTVOL = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_LTD,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                AND bnft.CSPD_CAT = 'Y'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
                                            
         new.SLIACTVOL = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_SLI,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                AND bnft.CSPD_CAT = 'S'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),                                        
                                            
          new.SADACTVOL = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_SAD,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                AND bnft.CSPD_CAT = 'E'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
         new.VLIFACTVOL = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VLIF,0)
                                           FROM     @BenefitData bnft  
                                           WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                            AND bnft.CSPD_CAT = 'Z'
                                                            and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                        ),    
         new.VLIFSPACTVOL = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VLIFSP,0)
                                           FROM     @BenefitData bnft  
                                           WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                            AND bnft.CSPD_CAT = 'Z'
                                                            and bnft.MEME_REL in ('H','W')  and bnft.CSCS_ID = new.CSCS_ID
                                        ),    
                                                                                
         new.VLIFCHACTVOL = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VLIFCH,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'Z'
                                                                and bnft.MEME_REL in ('S','D')  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
         new.VADDACTVOL = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VADD,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'B'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
                                            
         new.VADDSPACTVOL = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VADDSP,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'B'
                                                                and bnft.MEME_REL in ('H','W')  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
                                            
         new.VADDCHACTVOL = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VADDCH,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'B'
                                                                and bnft.MEME_REL in ('S','D')  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
        
        new.VSTDACTVOL = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VSTD,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'K'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
                                            
        new.VLTDACTVOL = (SELECT distinct isnull(bnft.BENEFIT_AMOUNT_FOR_VLTD,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'J'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),
--------------------------------------------------    
            new.LIFRPERUT = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_LIFE IS NOT NULL
                                                                            THEN RIGHT(REPLICATE('0',3) + CONVERT(VARCHAR,CONVERT(DECIMAL(9,2), BENEFIT_RATE_PER_UNIT_LIFE)),6)
                                                                         ELSE '000.00'
                                                                  END
                                                    --isnull(bnft.BENEFIT_RATE_PER_UNIT_LIFE,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'L'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
            new.ADDRPERUT = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_ADD IS NOT NULL
                                                                         THEN RIGHT(REPLICATE('0',3) + CONVERT(VARCHAR,CONVERT(DECIMAL(9,2), BENEFIT_RATE_PER_UNIT_ADD)),6)
                                                                         ELSE '000.00'
                                                                  END 
                                                --isnull(bnft.BENEFIT_RATE_PER_UNIT_ADD,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'A'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
            new.DLIRPERUT = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_DEP IS NOT NULL
                                                                         THEN RIGHT(REPLICATE('0',3) + CONVERT(VARCHAR,CONVERT(DECIMAL(9,2), BENEFIT_RATE_PER_UNIT_DEP)),6)
                                                                         ELSE '000.00'
                                                                  END 
                                                    --isnull(bnft.BENEFIT_RATE_PER_UNIT_DEP,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'T'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
            new.WDBRPERUT = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_STD IS NOT NULL
                                                                         THEN RIGHT(REPLICATE('0',3) + CONVERT(VARCHAR,CONVERT(DECIMAL(9,2), BENEFIT_RATE_PER_UNIT_STD)),6)
                                                                         ELSE '000.00'
                                                                  END
                                                    --isnull(bnft.BENEFIT_RATE_PER_UNIT_STD,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'X'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
        new.LTDRPERUT = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_LTD IS NOT NULL
                                                                         THEN RIGHT(REPLICATE('0',3) + CONVERT(VARCHAR,CONVERT(DECIMAL(9,2), BENEFIT_RATE_PER_UNIT_LTD)),6)
                                                                         ELSE '000.00'
                                                                  END 
                                                    --isnull(bnft.BENEFIT_RATE_PER_UNIT_LTD,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'Y'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
        new.SLIRPERUT = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_SLI IS NOT NULL
                                                                         THEN RIGHT(REPLICATE('0',3) + CONVERT(VARCHAR,CONVERT(DECIMAL(9,2), BENEFIT_RATE_PER_UNIT_SLI)),6)
                                                                         ELSE '000.00'
                                                                  END
                                                    --isnull(bnft.BENEFIT_RATE_PER_UNIT_SLI,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'S'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
        new.SADRPERUT = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_SAD IS NOT NULL
                                                                         THEN RIGHT(REPLICATE('0',3) + CONVERT(VARCHAR,CONVERT(DECIMAL(9,2), BENEFIT_RATE_PER_UNIT_SAD)),6)
                                                                         ELSE '000.00'
                                                                  END 
                                                    --isnull(bnft.BENEFIT_RATE_PER_UNIT_SAD,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'E'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),
        new.VLIFRPERUT = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_VLIF IS NOT NULL
                                                                         THEN RIGHT(REPLICATE('0',3) + CONVERT(VARCHAR,CONVERT(DECIMAL(9,2), BENEFIT_RATE_PER_UNIT_VLIF)),6)
                                                                         ELSE '000.00'
                                                                  END
                                                                --isnull(bnft.BENEFIT_RATE_PER_UNIT_VLIF,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'Z'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),
        new.VLIFSPRPERUT = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_VLIFSP IS NOT NULL
                                                                         THEN RIGHT(REPLICATE('0',3) + CONVERT(VARCHAR,CONVERT(DECIMAL(9,2), BENEFIT_RATE_PER_UNIT_VLIFSP)),6)
                                                                         ELSE '000.00'
                                                                  END
                                                                --isnull(bnft.BENEFIT_RATE_PER_UNIT_VLIFSP,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'Z'
                                                                and bnft.MEME_REL in ('H','W')  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
        new.VLIFCHRPERUT = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_VLIFCH IS NOT NULL
                                                                         THEN RIGHT(REPLICATE('0',3) + CONVERT(VARCHAR,CONVERT(DECIMAL(9,2), BENEFIT_RATE_PER_UNIT_VLIFCH)),6)
                                                                         ELSE '000.00'
                                                                  END
                                                                --isnull(bnft.BENEFIT_RATE_PER_UNIT_VLIFCH,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'Z'
                                                                and bnft.MEME_REL in ('S','D')  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
        new.VADDRPERUT = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_VADD IS NOT NULL
                                                                         THEN RIGHT(REPLICATE('0',3) + CONVERT(VARCHAR,CONVERT(DECIMAL(9,2), BENEFIT_RATE_PER_UNIT_VADD)),6)
                                                                         ELSE '000.00'
                                                                  END
                                                        --isnull(bnft.BENEFIT_RATE_PER_UNIT_VADD,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'B'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
        new.VADDSPRPERUT = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_VADDSP IS NOT NULL
                                                                         THEN RIGHT(REPLICATE('0',3) + CONVERT(VARCHAR,CONVERT(DECIMAL(9,2), BENEFIT_RATE_PER_UNIT_VADDSP)),6)
                                                                         ELSE '000.00'
                                                                  END
                                                                -- isnull(bnft.BENEFIT_RATE_PER_UNIT_VADDSP,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'B'
                                                                and bnft.MEME_REL in ('H','W')  and bnft.CSCS_ID = new.CSCS_ID
                                            ),    
        new.VADDCHRPERUT = (SELECT distinct  CASE WHEN BENEFIT_RATE_PER_UNIT_VADDCH IS NOT NULL
                                                                         THEN RIGHT(REPLICATE('0',3) + CONVERT(VARCHAR,CONVERT(DECIMAL(9,2), BENEFIT_RATE_PER_UNIT_VADDCH)),6)
                                                                         ELSE '000.00'
                                                                  END
                                                                -- isnull( bnft.BENEFIT_RATE_PER_UNIT_VADDCH,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'B'
                                                                and bnft.MEME_REL in ('S','D')  and bnft.CSCS_ID = new.CSCS_ID
                                            ),
        new.VSTDRPERUT = (SELECT distinct  CASE WHEN BENEFIT_RATE_PER_UNIT_VSTD IS NOT NULL
                                                                         THEN RIGHT(REPLICATE('0',3) + CONVERT(VARCHAR,CONVERT(DECIMAL(9,2), BENEFIT_RATE_PER_UNIT_VSTD)),6)
                                                                         ELSE '000.00'
                                                                  END
                                                                --isnull( bnft.BENEFIT_RATE_PER_UNIT_VLTD,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'K'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),
        new.VLTDRPERUT = (SELECT distinct CASE WHEN BENEFIT_RATE_PER_UNIT_VLTD IS NOT NULL
                                                                         THEN RIGHT(REPLICATE('0',3) + CONVERT(VARCHAR,CONVERT(DECIMAL(9,2), BENEFIT_RATE_PER_UNIT_VLTD)),6)
                                                                         ELSE '000.00'
                                                                  END
                                                                --isnull(bnft.BENEFIT_RATE_PER_UNIT_VSTD,0)
                                               FROM     @BenefitData bnft  
                                               WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                                
                                                                AND bnft.CSPD_CAT = 'J'
                                                                and bnft.MEME_REL = 'M'  and bnft.CSCS_ID = new.CSCS_ID
                                            ),
---------------------- Rate Method     
        new.LIFRATSRC    =    (select LIFRATSRC 
                                from @BenefitData bnft  
                                       WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                        AND bnft.CSPD_CAT = 'L'
                                                        and bnft.MEME_REL = 'M'   and bnft.CSCS_ID = new.CSCS_ID
                            ),
        new.ADDRATSRC    =    (select ADDRATSRC 
                            from @BenefitData bnft  
                                   WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                    AND bnft.CSPD_CAT = 'A'
                                                    and bnft.MEME_REL = 'M'    and bnft.CSCS_ID = new.CSCS_ID
                        ),    
        new.DLIRATSRC    =    (select DLIRATSRC 
                            from @BenefitData bnft  
                                   WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                    AND bnft.CSPD_CAT = 'T'
                                                    and bnft.MEME_REL = 'M'    and bnft.CSCS_ID = new.CSCS_ID
                        ),                
        new.WDBRATSRC    =    (select WDBRATSRC 
                            from @BenefitData bnft  
                                   WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                    AND bnft.CSPD_CAT = 'X'
                                                    and bnft.MEME_REL = 'M'    and bnft.CSCS_ID = new.CSCS_ID
                        ),                
        new.LTDRATSRC    =    (select LTDRATSRC 
                            from @BenefitData bnft  
                                   WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                    AND bnft.CSPD_CAT = 'Y'
                                                    and bnft.MEME_REL = 'M'    and bnft.CSCS_ID = new.CSCS_ID
                        ),                
        new.SLIRATSRC    =    (select SLIRATSRC 
                            from @BenefitData bnft  
                                   WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                    AND bnft.CSPD_CAT = 'S'
                                                    and bnft.MEME_REL = 'M'    and bnft.CSCS_ID = new.CSCS_ID
                        ),                
        new.SADRATSRC    =    (select SADRATSRC 
                            from @BenefitData bnft  
                                   WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                    AND bnft.CSPD_CAT = 'E'
                                                    and bnft.MEME_REL = 'M'    and bnft.CSCS_ID = new.CSCS_ID
                        ),                
        new.VLIFRATSRC    =    (select VLIFRATSRC 
                            from @BenefitData bnft  
                                   WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                    AND bnft.CSPD_CAT = 'Z'
                                                    and bnft.MEME_REL = 'M'    and bnft.CSCS_ID = new.CSCS_ID
                        ),                
        new.VLIFSPRATSRC    =    (select VLIFSPRATSRC 
                            from @BenefitData bnft  
                                   WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                    AND bnft.CSPD_CAT = 'Z'
                                                    and bnft.MEME_REL = 'M'    and bnft.CSCS_ID = new.CSCS_ID
                        ),
        new.VLIFCHRATSRC    =    (select VLIFCHRATSRC 
                            from @BenefitData bnft  
                                   WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                    AND bnft.CSPD_CAT = 'Z'
                                                    and bnft.MEME_REL = 'M'    and bnft.CSCS_ID = new.CSCS_ID
                        ),
        new.VADDRATSRC    =    (select VADDRATSRC 
                            from @BenefitData bnft  
                                   WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                    AND bnft.CSPD_CAT = 'B'
                                                    and bnft.MEME_REL = 'M'    and bnft.CSCS_ID = new.CSCS_ID
                        ),
        new.VADDSPRATSRC    =    (select VADDSPRATSRC 
                            from @BenefitData bnft  
                                   WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                    AND bnft.CSPD_CAT = 'B'
                                                    and bnft.MEME_REL = 'M'    and bnft.CSCS_ID = new.CSCS_ID
                        ),
        new.VADDCHRATSRC    =    (select VADDCHRATSRC 
                            from @BenefitData bnft  
                                   WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                    AND bnft.CSPD_CAT = 'B'
                                                    and bnft.MEME_REL = 'M'    and bnft.CSCS_ID = new.CSCS_ID
                        ),
        new.VSTDRATSRC    =    (select VSTDRATSRC 
                            from @BenefitData bnft  
                                   WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                    AND bnft.CSPD_CAT = 'K'
                                                    and bnft.MEME_REL = 'M'    and bnft.CSCS_ID = new.CSCS_ID
                        ),
        new.VLTDRATSRC    =    (select VLTDRATSRC 
                            from @BenefitData bnft  
                                   WHERE  bnft.GRGR_ID = new.GRGR_ID
                                                    AND bnft.CSPD_CAT = 'J'
                                                    and bnft.MEME_REL = 'M'    and bnft.CSCS_ID = new.CSCS_ID
                        )                        
                                    
FROM  fabncdv1stage.dbo.tpzt_usable_membership_extr_new new



 


/********** Error Update Benefit Amount, Benefit Rate per Unit and Rate Methods for Life  ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : Update Benefit Amount, Benefit Rate per Unit and Rate Methods for Life FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 5 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount              = @lnRowsProcessed









/**************  PRINT STEP 5A HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime      = GETDATE(),
      @lvcMsg                = @lvcObjectName + ': update the METIND '

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 5A  update the METIND  tpzt_usable_membership_extr **********/

;with CTE_TEMP
    (    SUBCOUNT,
        GRGR_ID
    )
    as
    (
            SELECT  SUBCOUNT, 
                          --CASE WHEN a.CNT > 9 
                                --  THEN 'N' -- Non-Trust Group
                                -- ELSE  'Y'
                          --END AS METIND,
                    a.GRGR_ID
            FROM 
                   (SELECT       grgr.GRGR_ID, COUNT(sbsb.SBSB_ID) AS SUBCOUNT
                   FROM   fabncdv1.dbo.CMC_GRGR_GROUP grgr
                    INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb  ON sbsb.GRGR_CK = grgr.GRGR_CK
                   WHERE sbsb.SBSB_CK IN ( 
                                                            SELECT DISTINCT meme.SBSB_CK 
                                                            FROM   fabncdv1.dbo.CMC_MEPE_PRCS_ELIG mepe
                                                                          INNER JOIN fabncdv1.dbo.CMC_MEME_MEMBER meme    ON meme.MEME_CK = mepe.MEME_CK
                                                                          INNER JOIN fabncdv1.dbo.CMC_SBSB_SUBSC sbsb    ON sbsb.SBSB_CK = meme.SBSB_CK
                                                                          INNER JOIN fabncdv1.dbo.CMC_GRGR_GROUP grgr   ON sbsb.GRGR_CK = grgr.GRGR_CK
                                                                          INNER JOIN @CommnTable  usam                    ON usam.GRGR_ID = grgr.GRGR_ID --ON usam.MEMBNO = sbsb.SBSB_ID
                                                            WHERE 
                                                                          meme.MEME_REL = 'M'
                                                            AND           mepe.MEPE_ELIG_IND = 'Y'
                                                            AND           CONVERT(VARCHAR(8),mepe.MEPE_TERM_DT,112) > DATEADD(mm,-12,CONVERT(VARCHAR(8),GETDATE(),112))
                                                     )
                   GROUP BY grgr.GRGR_ID) a
)

update new
    set new.METIND = CASE WHEN  ( cte.SUBCOUNT < 10)
                            THEN 'Y'
                        ELSE 'N'
                     END
     from fabncdv1stage.dbo.tpzt_usable_membership_extr_new new 
                inner join CTE_TEMP cte on cte.GRGR_ID = new.GRPNUM
    

/********** Error update the METIND  ************************/

    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT
      IF @lnRetCd <> 0
       BEGIN
        SELECT @lvcMsg = CONVERT(CHAR(26), GETDATE(), 109)
          + ' : update the METIND FAILED'
          + ' RETURNCODE: '
          + CONVERT(CHAR(6),@lnRetCd)
        PRINT  @lvcMsg
        RETURN @lnRetCd
       END

/**************  PRINT STEP 5 FOOTER DATA *************************/

    SELECT @ldtStepEndTime    = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount              = @lnRowsProcessed



/**************  PRINT STEP 6 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime      = GETDATE(),
      @lvcMsg                = @lvcObjectName + ': Validate the record  '

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 6  Validate the record  tpzt_usable_membership_extr **********/

    INSERT INTO fabncdv1stage.dbo.tpzt_usable_membership_error
        (
            GRPNUM ,
            METIND ,
            MEMBNO ,
            LSTNAM ,
            FSTNAM ,
            BTHDAT ,
            SEXCOD ,
            SSN    ,
            CLSCOD ,
            CARCOD ,
            PDTHRU ,
            HIRDAT ,
            AGE    ,
            ACCTNO 
        )
    SELECT DISTINCT 
            GRPNUM = new.GRPNUM ,
            METIND = new.METIND ,
            MEMBNO = new.MEMBNO ,
            LSTNAM = new.LSTNAM ,
            FSTNAM = new.FSTNAM ,
            BTHDAT = new.BTHDAT ,
            SEXCOD = new.SEXCOD ,
            SSN    = new.SSN    ,
            CLSCOD = new.CLSCOD ,
            CARCOD = new.CARCOD ,
            PDTHRU = new.PDTHRU ,
            HIRDAT = new.HIRDAT ,
            AGE    = new.AGE    ,
            ACCTNO = new.ACCTNO 
        FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new new
        WHERE LTRIM(RTRIM(ISNULL(new.GRPNUM,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.METIND,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.MEMBNO,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.LSTNAM,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.FSTNAM,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.BTHDAT,'')))=''  OR LTRIM(RTRIM(ISNULL(new.BTHDAT,'')))='00000000'
            OR LTRIM(RTRIM(ISNULL(new.SEXCOD,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.SSN,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.CLSCOD,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.CARCOD,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.PDTHRU,'')))='' OR LTRIM(RTRIM(ISNULL(new.PDTHRU,'')))='00000000'
            OR LTRIM(RTRIM(ISNULL(new.HIRDAT,'')))='' OR LTRIM(RTRIM(ISNULL(new.HIRDAT,'')))='00000000'
            OR LTRIM(RTRIM(ISNULL(new.AGE,'')))=''
            OR LTRIM(RTRIM(ISNULL(new.ACCTNO,'')))=''
    
-----------------truncating the tpzt_usable_membership_extr_new to have valid record -------------------------------------
    DELETE FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new
     WHERE LTRIM(RTRIM(ISNULL(GRPNUM,'')))=''
            OR LTRIM(RTRIM(ISNULL(METIND,'')))=''
            OR LTRIM(RTRIM(ISNULL(MEMBNO,'')))=''
            OR LTRIM(RTRIM(ISNULL(LSTNAM,'')))=''
            OR LTRIM(RTRIM(ISNULL(FSTNAM,'')))=''
            OR LTRIM(RTRIM(ISNULL(BTHDAT,'')))=''  OR LTRIM(RTRIM(ISNULL(BTHDAT,'')))='00000000'
            OR LTRIM(RTRIM(ISNULL(SEXCOD,'')))=''
            OR LTRIM(RTRIM(ISNULL(SSN,'')))=''
            OR LTRIM(RTRIM(ISNULL(CLSCOD,'')))=''
            OR LTRIM(RTRIM(ISNULL(CARCOD,'')))=''
            OR LTRIM(RTRIM(ISNULL(PDTHRU,'')))='' OR LTRIM(RTRIM(ISNULL(PDTHRU,'')))='00000000'
            OR LTRIM(RTRIM(ISNULL(HIRDAT,'')))='' OR LTRIM(RTRIM(ISNULL(HIRDAT,'')))='00000000'
            OR LTRIM(RTRIM(ISNULL(AGE,'')))=''
            OR LTRIM(RTRIM(ISNULL(ACCTNO,'')))=''
    
/**********  Validate the record  tpzt_usable_membership_extr ***********/
    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT

    IF @lnRetCd <> 0
    BEGIN
      SELECT @lvcMsg = CONVERT(CHAR(26),GETDATE(), 109)
        + ' :  Validate the record  tpzt_usable_membership_extr FAILED'
        + ' RETURNCODE: '
        + CONVERT(CHAR(6),@lnRetCd)
      PRINT    @lvcMsg
      RETURN    @lnRetCd
    END

/**************  PRINT STEP 6 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed
      


/**************  PRINT STEP 7 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime      = GETDATE(),
      @lvcMsg                = @lvcObjectName + ': Validate the record  '

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 7  Validate the record  tpzt_usable_membership_extr **********/

   --Declare SubCountGrp int
   
   --select count(GRGR_ID ), comm.GRGR_ID
         --from @CommnTable comm
            --inner join fabncdv1stage.dbo.tpzt_usable_membership_extr_new new on new.GRPNUM = 



/**********  Validate the record  tpzt_usable_membership_extr ***********/
    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT

    IF @lnRetCd <> 0
    BEGIN
      SELECT @lvcMsg = CONVERT(CHAR(26),GETDATE(), 109)
        + ' :  Validate the record  tpzt_usable_membership_extr FAILED'
        + ' RETURNCODE: '
        + CONVERT(CHAR(6),@lnRetCd)
      PRINT    @lvcMsg
      RETURN    @lnRetCd
    END

/**************  PRINT STEP 7 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed
      
      
      
      

/**************  PRINT STEP 7 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime      = GETDATE(),
      @lvcMsg                = @lvcObjectName + ': truncate record from tpzt_usable_membership_extr '

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 7 truncate the table tpzt_usable_membership_extr **********/

    TRUNCATE TABLE fabncdv1stage.dbo.tpzt_usable_membership_extr 

/********** Error inserting record into tpzt_usable_membership_extr ***********/
    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT

    IF @lnRetCd <> 0
    BEGIN
      SELECT @lvcMsg = CONVERT(CHAR(26),GETDATE(), 109)
        + ' : truncate record from tpzt_usable_membership_extr FAILED'
        + ' RETURNCODE: '
        + CONVERT(CHAR(6),@lnRetCd)
      PRINT    @lvcMsg
      RETURN    @lnRetCd
    END

/**************  PRINT STEP 7 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed
      



/**************  PRINT STEP 6 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime      = GETDATE(),
      @lvcMsg                = @lvcObjectName + ': inserting record into tpzt_usable_membership_extr '

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 6 inserting record into tpzt_usable_membership_extr  **********/


      
INSERT INTO fabncdv1stage.dbo.tpzt_usable_membership_extr (GRPNUM, METIND, MEMBNO, LSTNAM, FSTNAM, MIDNAM, BTHDAT, SEXCOD, SSN, SALARY, CLSCOD, LIFMTHPRM, ADDMTHPRM, 
                                                DLIMTHPRM, WDBMTHPRM, LTDMTHPRM, SLIMTHPRM, SADMTHPRM, VLIFMTHPRM, VLIFSPMTHPRM, VLIFCHMTHPRM, VADDMTHPRM, VADDSPMTHPRM,
                                                 VADDCHMTHPRM, VSTDMTHPRM, VLTDMTHPRM, CARCOD, LIFACTVOL, LIFRPERUT, LIFRATSRC, ADDACTVOL, ADDRPERUT, ADDRATSRC, DLIACTVOL, 
                                                 DLIRPERUT, DLIRATSRC, WDBACTVOL, WDBRPERUT, WDBRATSRC, LTDACTVOL, LTDRPERUT, LTDRATSRC, SLIACTVOL, SLIRPERUT, SLIRATSRC, 
                                                 SADACTVOL, SADRPERUT, SADRATSRC, VLIFACTVOL, VLIFRPERUT, VLIFRATSRC, VLIFSPACTVOL, VLIFSPRPERUT, VLIFSPRATSRC, VLIFCHACTVOL, 
                                                 VLIFCHRPERUT, VLIFCHRATSRC, VADDACTVOL, VADDRPERUT, VADDRATSRC, VADDSPACTVOL, VADDSPRPERUT, VADDSPRATSRC, VADDCHACTVOL, 
                                                 VADDCHRPERUT, VADDCHRATSRC, VSTDACTVOL, VSTDRPERUT, VSTDRATSRC, VLTDACTVOL, VLTDRPERUT, VLTDRATSRC, PDTHRU, HIRDAT, AGE, 
                                                 ACCTNO, CLSEFFDAT, CLSEXPDAT, LIFEFFDAT, LIFEXPDAT, LIFREASCD, LIFLSTCHG, ADDEFFDAT, ADDEXPDAT, ADDREASCD, ADDLSTCHG, 
                                                 DLIEFFDAT, DLIEXPDAT, DLIREASCD, DLILSTCHG, WDBEFFDAT, WDBEXPDAT, WDBREASCD, WDBLSTCHG, LTDEFFDAT, LTDEXPDAT, LTDREASCD, 
                                                 LTDLSTCHG, SLIEFFDAT, SLIEXPDAT, SLIREASCD, SLILSTCHG, SADEFFDAT, SADEXPDAT, SADREASCD, SADLSTCHG, VLIFEFFDAT, VLIFDEXPDAT,
                                                  VLIFREASCD, VLIFLSTCHG, VLIFEFFDAT_SPOUSE, VLIFDEXPDAT_SPOUSE, VLIFREASCD_SPOUSE, VLIFLSTCHG_SPOUSE, VLIFEFFDAT_CHILD, 
                                                  VLIFDEXPDAT_CHILD, VLIFREASCD_CHILD, VLIFLSTCHG_CHILD, VADDEFFDAT, VADDEXPDAT, VADDREASCD, VADDLSTCHG, VADDSPEFFDAT, 
                                                  VADDSPEXPDAT, VADDSPREASCD, VADDSPLSTCHG, VADDCHEFFDAT, VADDCHEXPDAT, VADDCHREASCD, VADDCHLSTCHG, VSTDEFFDAT, VSTDDEXPDAT, 
                                                  VSTDREASCD, VSTDLSTCHG, VLTDEFFDAT, VLTDDEXPDAT, VLTDREASCD, VLTDLSTCHG
                                            )

SELECT  GRPNUM, METIND, MEMBNO, LSTNAM, FSTNAM, MIDNAM, BTHDAT, SEXCOD, SSN, SALARY, CLSCOD, LIFMTHPRM, ADDMTHPRM, 
        DLIMTHPRM, WDBMTHPRM, LTDMTHPRM, SLIMTHPRM, SADMTHPRM, VLIFMTHPRM, VLIFSPMTHPRM, VLIFCHMTHPRM, VADDMTHPRM, VADDSPMTHPRM, 
        VADDCHMTHPRM, VSTDMTHPRM, VLTDMTHPRM, CARCOD, LIFACTVOL, LIFRPERUT, LIFRATSRC, ADDACTVOL, ADDRPERUT, ADDRATSRC, DLIACTVOL, 
        DLIRPERUT, DLIRATSRC, WDBACTVOL, WDBRPERUT, WDBRATSRC, LTDACTVOL, LTDRPERUT, LTDRATSRC, SLIACTVOL, SLIRPERUT, SLIRATSRC, SADACTVOL, 
        SADRPERUT, SADRATSRC, VLIFACTVOL, VLIFRPERUT, VLIFRATSRC, VLIFSPACTVOL, VLIFSPRPERUT, VLIFSPRATSRC, VLIFCHACTVOL, VLIFCHRPERUT, VLIFCHRATSRC, 
        VADDACTVOL, VADDRPERUT, VADDRATSRC, VADDSPACTVOL, VADDSPRPERUT, VADDSPRATSRC, VADDCHACTVOL, VADDCHRPERUT, VADDCHRATSRC, VSTDACTVOL, VSTDRPERUT, 
        VSTDRATSRC, VLTDACTVOL, VLTDRPERUT, VLTDRATSRC, PDTHRU, HIRDAT, AGE, ACCTNO, CLSEFFDAT, CLSEXPDAT, LIFEFFDAT, LIFEXPDAT, LIFREASCD, LIFLSTCHG, 
        ADDEFFDAT, ADDEXPDAT, ADDREASCD, ADDLSTCHG, DLIEFFDAT, DLIEXPDAT, DLIREASCD, DLILSTCHG, WDBEFFDAT, WDBEXPDAT, WDBREASCD, WDBLSTCHG, LTDEFFDAT, 
        LTDEXPDAT, LTDREASCD, LTDLSTCHG, SLIEFFDAT, SLIEXPDAT, SLIREASCD, SLILSTCHG, SADEFFDAT, SADEXPDAT, SADREASCD, SADLSTCHG, VLIFEFFDAT, VLIFDEXPDAT, 
        VLIFREASCD, VLIFLSTCHG, VLIFEFFDAT_SPOUSE, VLIFDEXPDAT_SPOUSE, VLIFREASCD_SPOUSE, VLIFLSTCHG_SPOUSE, VLIFEFFDAT_CHILD, VLIFDEXPDAT_CHILD, 
        VLIFREASCD_CHILD, VLIFLSTCHG_CHILD, VADDEFFDAT, VADDEXPDAT, VADDREASCD, VADDLSTCHG, VADDSPEFFDAT, VADDSPEXPDAT, VADDSPREASCD, VADDSPLSTCHG, 
        VADDCHEFFDAT, VADDCHEXPDAT, VADDCHREASCD, VADDCHLSTCHG, VSTDEFFDAT, VSTDDEXPDAT, VSTDREASCD, VSTDLSTCHG, VLTDEFFDAT, VLTDDEXPDAT, VLTDREASCD, VLTDLSTCHG
      
FROM fabncdv1stage.dbo.tpzt_usable_membership_extr_new
    order by   GRPNUM,MEMBNO ASC


/********** Error inserting record into tpzt_usable_membership_extr ***********/
    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT

    IF @lnRetCd <> 0
    BEGIN
      SELECT @lvcMsg = CONVERT(CHAR(26),GETDATE(), 109)
        + ' : inserting record into tpzt_usable_membership_extr FAILED'
        + ' RETURNCODE: '
        + CONVERT(CHAR(6),@lnRetCd)
      PRINT    @lvcMsg
      RETURN    @lnRetCd
    END

/**************  PRINT STEP 6 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed




/**************  PRINT STEP 7 HEADER DATA *************************/

    SELECT @lnCurrentStep    = @lnCurrentStep + 1,
      @ldtStepStartTime      = GETDATE(),
      @lvcMsg                = @lvcObjectName + ': Updating LAST_RUN_DATE in table tpzt_last_rundate'

    EXEC harcore.dbo.harsp_gen_util_step_hdr_lgr
      @pnStepNumber       = @lnCurrentStep,
      @pdtStepStartTime   = @ldtStepStartTime,
      @pnTotalSteps       = @lnTotalSteps,
      @pchStepMsg         = @lvcMsg

/********** STEP 7 Updating LAST_RUN_DATE in table tpzt_last_rundate **********/
   
     UPDATE fabncdv1custom.dbo.tpzt_last_rundate
      SET LAST_RUN_DATE = GETDATE()
      WHERE INTERFACE_IDENTIFIER  = 'VE9006'
      AND INTERFACE_DESCRIPTION   = 'USABLE_MEMBERSHIP'
      
/********** Error checking for Updating LAST_RUN_DATE in table tpzt_last_rundate ***********/
    SELECT @lnRetCd    = @@ERROR,
      @lnRowsProcessed = @@ROWCOUNT

    IF @lnRetCd <> 0
    BEGIN
      SELECT @lvcMsg = CONVERT(CHAR(26),GETDATE(), 109)
        + ' : Updating LAST_RUN_DATE in table tpzt_last_rundate FAILED'
        + ' RETURNCODE: '
        + CONVERT(CHAR(6),@lnRetCd)
      PRINT    @lvcMsg
      RETURN    @lnRetCd
    END

/**************  PRINT STEP 7 FOOTER DATA *************************/

    SELECT @ldtStepEndTime = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_step_ftr_lgr
      @pdtStepStartTime       = @ldtStepStartTime,
      @pdtStepEndTime         = @ldtStepEndTime,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pnRowCount             = @lnRowsProcessed

/**************  PRINT JOB FOOTER DATA ****************************/

    SELECT @ldtProcessEndTime = GETDATE()
    EXEC harcore.dbo.harsp_gen_util_job_ftr_lgr
      @pchObjectName          = @lvcObjectName,
      @pdtProcessStartTime    = @ldtProcessStartTime,
      @pdtProcessEndTime      = @ldtProcessEndTime
    RETURN  @lnRetCd
END
GO
/****************************************************************
 BEGIN MAINTENANCE WRAPPER:
*****************************************************************/
IF OBJECT_ID('dbo.tpzp_usable_membership_extr') IS NOT NULL
  PRINT '<<< CREATED PROCEDURE dbo.tpzp_usable_membership_extr >>>'
       
ELSE
  PRINT '<<<ERROR CREATING PROCEDURE dbo.tpzp_usable_membership_extr >>>'
GO

/****************************************************************
 END MAINTENANCE WRAPPER:
*****************************************************************/







